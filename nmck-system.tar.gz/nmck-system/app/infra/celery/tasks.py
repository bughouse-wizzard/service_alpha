import asyncio
from datetime import datetime
from uuid import UUID
from celery import shared_task
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select

from app.infra.config import settings
from app.domain.entities.task import TaskEntity, TaskStatus
from app.adapters.eis.parser import EISParser
from app.adapters.parsers.match_engine import MatchEngine

# Создаем асинхронный движок для Celery задач
engine = create_async_engine(settings.database_url)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

# Инициализация парсеров
eis_parser = EISParser()
match_engine = MatchEngine()


@shared_task(bind=True, name="run_search_task")
def run_search_task(self, task_id: str):
    """Задача поиска контрактов в ЕИС"""
    
    # Запускаем асинхронную задачу
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(_run_search_task_async(task_id))


async def _run_search_task_async(task_id: str):
    """Асинхронная реализация задачи поиска"""
    
    async with AsyncSessionLocal() as db:
        try:
            # Получаем задачу
            stmt = select(TaskEntity).where(TaskEntity.id == UUID(task_id))
            result = await db.execute(stmt)
            task = result.scalar_one_or_none()
            
            if not task:
                raise ValueError(f"Задача {task_id} не найдена")
            
            # Обновляем статус
            task.status = TaskStatus.SEARCHING
            task.started_at = datetime.utcnow()
            task.stage = "Поиск кандидатов"
            task.progress = 10
            await db.commit()
            
            # Получаем данные из загрузки
            from app.domain.entities.upload import UploadEntity
            stmt = select(UploadEntity).where(UploadEntity.id == task.upload_id)
            result = await db.execute(stmt)
            upload = result.scalar_one_or_none()
            
            if not upload or not upload.extracted_data:
                raise ValueError("Данные загрузки не найдены")
            
            # Извлекаем требования
            requirements = upload.extracted_data
            
            # Этап 1: Поиск кандидатов в ЕИС
            task.stage = "Поиск контрактов"
            task.progress = 20
            await db.commit()
            
            candidates = await eis_parser.search_contracts(
                ktru_code=requirements.get("ktru_code"),
                product_name=requirements.get("name"),
                region=task.region,
                period_from=task.period_from,
                period_to=task.period_to,
                law_type=task.law_type,
            )
            
            task.total_found = len(candidates)
            task.stage = "Анализ контрактов"
            task.progress = 40
            await db.commit()
            
            # Этап 2: Анализ контрактов
            analyzed_contracts = []
            for i, candidate in enumerate(candidates):
                # Обновляем прогресс
                progress = 40 + int((i / len(candidates)) * 40)
                task.progress = progress
                task.message = f"Анализ контракта {i+1} из {len(candidates)}"
                await db.commit()
                
                try:
                    # Получаем детальную информацию о контракте
                    contract_data = await eis_parser.get_contract_details(candidate["url"])
                    
                    # Сравниваем характеристики
                    match_result = await match_engine.compare_characteristics(
                        requirements=requirements,
                        contract_data=contract_data,
                    )
                    
                    # Сохраняем контракт в БД
                    from app.domain.entities.contract import ContractEntity, MatchType, VendorStatus
                    
                    contract = ContractEntity(
                        task_id=task.id,
                        reg_number=contract_data.get("reg_number", ""),
                        eis_url=candidate["url"],
                        supplier_name=contract_data.get("supplier_name", ""),
                        supplier_inn=contract_data.get("supplier_inn"),
                        sign_date=contract_data.get("sign_date", datetime.utcnow()),
                        unit_price=contract_data.get("unit_price", 0),
                        currency=contract_data.get("currency", "RUB"),
                        match_percent=match_result["match_percent"],
                        match_type=MatchType.IDENTICAL if match_result["match_percent"] == 100 else MatchType.HOMOGENEOUS,
                        vendor_status=VendorStatus.MATCH if match_result["vendor_match"] else VendorStatus.MISMATCH,
                        raw_data=contract_data,
                    )
                    
                    db.add(contract)
                    await db.flush()  # Получаем ID контракта
                    
                    # Сохраняем лог сверки
                    from app.domain.entities.audit import ContractAuditEntity
                    
                    for audit_item in match_result.get("audit_log", []):
                        audit = ContractAuditEntity(
                            contract_id=contract.id,
                            key=audit_item["key"],
                            expected_value=audit_item.get("expected_value"),
                            found_value=audit_item.get("found_value"),
                            is_diff=audit_item.get("is_diff", False),
                            diff_reason=audit_item.get("diff_reason"),
                        )
                        db.add(audit)
                    
                    analyzed_contracts.append(contract)
                    task.total_analyzed += 1
                    
                except Exception as e:
                    # Пропускаем контракт с ошибкой
                    print(f"Ошибка при анализе контракта {candidate['url']}: {e}")
                    continue
            
            # Этап 3: Расчет НМЦК
            task.stage = "Расчет НМЦК"
            task.progress = 90
            await db.commit()
            
            if analyzed_contracts:
                # Автоматический выбор 3 лучших контрактов
                selected_contracts = await _auto_select_contracts(analyzed_contracts)
                
                # Расчет НМЦК
                nmck_value = await _calculate_nmck(selected_contracts)
                
                # Сохраняем выбор
                from app.domain.entities.selection import TaskSelectionEntity
                from datetime import datetime
                
                for contract in selected_contracts:
                    selection = TaskSelectionEntity(
                        task_id=task.id,
                        contract_id=contract.id,
                        selected_at=datetime.utcnow(),
                    )
                    db.add(selection)
                
                task.nmck_value = nmck_value
            
            # Завершаем задачу
            task.status = TaskStatus.DONE
            task.stage = "Завершено"
            task.progress = 100
            task.finished_at = datetime.utcnow()
            task.message = f"Найдено {len(analyzed_contracts)} подходящих контрактов"
            
            await db.commit()
            
            return {
                "task_id": task_id,
                "status": "completed",
                "contracts_found": len(analyzed_contracts),
                "nmck_value": task.nmck_value,
            }
            
        except Exception as e:
            # Обработка ошибок
            print(f"Ошибка в задаче {task_id}: {e}")
            
            # Обновляем статус задачи
            stmt = select(TaskEntity).where(TaskEntity.id == UUID(task_id))
            result = await db.execute(stmt)
            task = result.scalar_one_or_none()
            
            if task:
                task.status = TaskStatus.ERROR
                task.error_code = "SEARCH_ERROR"
                task.error_detail = str(e)
                task.finished_at = datetime.utcnow()
                await db.commit()
            
            raise


async def _auto_select_contracts(contracts):
    """Автоматический выбор 3 лучших контрактов"""
    
    # Сортируем по проценту совпадения (по убыванию) и цене (по возрастанию)
    sorted_contracts = sorted(
        contracts,
        key=lambda c: (-c.match_percent, c.unit_price)
    )
    
    # Выбираем контракты, следя за правилом поставщиков
    selected = []
    supplier_count = {}
    
    for contract in sorted_contracts:
        if len(selected) >= 3:
            break
        
        supplier = contract.supplier_inn or contract.supplier_name
        current_count = supplier_count.get(supplier, 0)
        
        # Проверяем правило: не более 2 контрактов от одного поставщика
        if current_count < 2:
            selected.append(contract)
            supplier_count[supplier] = current_count + 1
    
    return selected


async def _calculate_nmck(contracts):
    """Расчет НМЦК как среднее арифметическое цен выбранных контрактов"""
    
    if not contracts:
        return 0
    
    total_price = sum(contract.unit_price for contract in contracts)
    return total_price / len(contracts)