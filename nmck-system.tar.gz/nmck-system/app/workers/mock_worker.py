"""
Mock воркер для тестирования
"""
import time
import random
from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy.orm import Session

from app.domain.entities.task import TaskEntity, TaskStatus
from app.domain.entities.upload import UploadEntity
from app.domain.entities.contract import ContractEntity, MatchType, VendorStatus
from app.domain.entities.audit import ContractAuditEntity
from app.domain.entities.selection import TaskSelectionEntity
from app.domain.entities.calculation import TaskCalculationEntity
from app.infra.database import SessionLocal


def mock_run_search_task(task_id: str):
    """
    Mock функция для тестирования поиска контрактов.
    
    Args:
        task_id: ID задачи
    """
    # Создаем сессию базы данных
    db = SessionLocal()
    try:
        # Получаем задачу
        task = db.query(TaskEntity).filter(TaskEntity.id == task_id).first()
        if not task:
            print(f"Задача {task_id} не найдена")
            db.close()
            return
        
        # Обновляем статус задачи
        task.status = TaskStatus.SEARCHING
        task.started_at = datetime.utcnow()
        task.stage = "searching"
        task.progress = 10
        db.commit()
        
        # Имитируем поиск
        time.sleep(2)
        task.stage = "analyzing"
        task.progress = 50
        db.commit()
        
        time.sleep(2)
        task.stage = "analyzing"
        task.progress = 80
        db.commit()
        
        # Создаем mock контракты
        contracts = []
        for i in range(5):
            contract = ContractEntity(
                id=f"contract_{task_id}_{i}",
                task_id=task_id,
                reg_number=f"1234567890{i}",
                eis_url=f"https://zakupki.gov.ru/epz/order/notice/printForm/view.html?regNumber=1234567890{i}",
                supplier_name=f"Поставщик {i+1} ООО",
                supplier_inn=f"123456789{i}",
                sign_date=datetime.utcnow() - timedelta(days=random.randint(30, 365)),
                unit_price=random.uniform(50000, 150000),
                currency="RUB",
                match_percent=int(random.uniform(70, 100)),
                match_type=MatchType.HOMOGENEOUS if random.random() > 0.5 else MatchType.IDENTICAL,
                vendor_status=VendorStatus.MATCH if random.random() > 0.7 else VendorStatus.MISMATCH,
                raw_data={"mock": True, "index": i}
            )
            contracts.append(contract)
            db.add(contract)
        
        db.commit()
        
        # Автоматически выбираем 3 контракта
        selected_contracts = _mock_auto_select_contracts(contracts, db)
        
        # Рассчитываем НМЦК
        nmck_value = _calculate_nmck(selected_contracts)
        
        # Сохраняем расчет
        calculation = TaskCalculationEntity(
            task_id=task_id,
            method="average",
            nmc_value=nmck_value,
            currency="RUB",
            computed_at=datetime.utcnow(),
            details={"selected_contracts": [c.id for c in selected_contracts]}
        )
        db.add(calculation)
        
        # Обновляем задачу
        task.status = TaskStatus.DONE
        task.stage = "done"
        task.progress = 100
        task.nmck_value = nmck_value
        task.nmck_currency = "RUB"
        task.finished_at = datetime.utcnow()
        db.commit()
        
        print(f"Mock задача {task_id} успешно выполнена. Создано {len(contracts)} контрактов.")
        
    except Exception as e:
        # Обрабатываем ошибку
        if 'task' in locals():
            task.status = TaskStatus.ERROR
            task.error_code = "MOCK_ERROR"
            task.error_detail = str(e)
            task.finished_at = datetime.utcnow()
            db.commit()
        print(f"Ошибка при выполнении mock задачи {task_id}: {e}")
    finally:
        # Закрываем сессию
        db.close()


def _mock_auto_select_contracts(contracts: List[ContractEntity], db: Session) -> List[ContractEntity]:
    """
    Автоматически выбирает 3 лучших контракта с учетом ограничений.
    """
    if len(contracts) < 3:
        return contracts
    
    # Сортируем контракты по проценту совпадения (по убыванию)
    sorted_contracts = sorted(contracts, key=lambda c: c.match_percent, reverse=True)
    
    # Выбираем контракты, следя за ограничением по поставщикам
    selected = []
    suppliers_selected = set()
    
    for contract in sorted_contracts:
        if len(selected) >= 3:
            break
        
        # Проверяем ограничение по поставщикам
        if contract.supplier_inn in suppliers_selected and len(suppliers_selected) == 1:
            continue
        
        selected.append(contract)
        suppliers_selected.add(contract.supplier_inn)
    
    # Сохраняем выбор в БД
    for contract in selected:
        selection = TaskSelectionEntity(
            task_id=contract.task_id,
            contract_id=contract.id,
            selected_at=datetime.utcnow()
        )
        db.add(selection)
    
    return selected


def _calculate_nmck(contracts: List[ContractEntity]) -> float:
    """
    Рассчитывает НМЦК как среднее арифметическое цен выбранных контрактов.
    """
    if not contracts:
        return 0.0
    
    total_price = sum(contract.unit_price for contract in contracts)
    return total_price / len(contracts)