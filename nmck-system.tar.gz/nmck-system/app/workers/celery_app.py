"""
Celery приложение для фоновых задач
"""
import os
from celery import Celery
from app.infra.database import SessionLocal

# Настройки Celery
celery_app = Celery(
    "nmck_worker",
    broker=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0"),
    backend=os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/0"),
    include=["app.workers.search_worker"]
)

# Конфигурация
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=30 * 60,  # 30 минут
    task_soft_time_limit=25 * 60,  # 25 минут
    worker_max_tasks_per_child=100,
    worker_prefetch_multiplier=1,
)

# Импортируем задачи
from app.workers.search_worker import run_search_task