"""
Схемы для задач
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum

from pydantic import BaseModel, Field

from app.schemas.base import BaseSchema, TimestampMixin

# Перечисления для статусов
class TaskStatus(str, Enum):
    QUEUED = "queued"
    SEARCHING = "searching"
    DOWNLOADING = "downloading"
    ANALYZING = "analyzing"
    DONE = "done"
    ERROR = "error"

# Стадии задачи - просто строка, так как стадии могут быть разными
# TaskStage = str

# Схемы запросов
class TaskCreate(BaseSchema):
    """Создание задачи"""
    upload_id: str
    region: str = "Северо-Западный ФО"
    period_years: int = Field(default=3, ge=1, le=10)

class TaskCreateDirect(BaseSchema):
    """Создание задачи напрямую (без файла)"""
    ktru_code: Optional[str] = None
    product_name: str
    vendor: Optional[str] = None
    characteristics: List[Dict[str, Any]] = []
    region: str = "Северо-Западный ФО"
    period_years: int = Field(default=3, ge=1, le=10)

class TaskUpdate(BaseSchema):
    """Обновление задачи"""
    status: Optional[TaskStatus] = None
    stage: Optional[str] = None
    progress: Optional[int] = Field(default=None, ge=0, le=100)
    error_code: Optional[str] = None
    error_detail: Optional[str] = None

# Схемы ответов
class TaskResponse(TimestampMixin):
    """Ответ с информацией о задаче"""
    id: str
    session_id: str
    upload_id: str
    status: TaskStatus
    stage: str
    progress: int
    region: str
    period_from: Optional[datetime] = None
    period_to: Optional[datetime] = None
    created_at: datetime
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    error_code: Optional[str] = None
    error_detail: Optional[str] = None

class TaskListResponse(BaseSchema):
    """Список задач для истории"""
    id: str
    created_at: datetime
    status: TaskStatus
    stage: str
    progress: int
    region: str
    summary: Optional[str] = None
    search_time: Optional[int] = None  # Время поиска в секундах
    product_name: Optional[str] = None  # Наименование товара
    ktru_code: Optional[str] = None    # Код КТРУ

class TaskResultResponse(BaseSchema):
    """Результаты задачи"""
    task_id: str
    summary: Dict[str, Any]
    contracts: List[Dict[str, Any]]
    recommended_nmck: Optional[float] = None

class TaskProgressEvent(BaseSchema):
    """Событие прогресса задачи"""
    task_id: str
    stage: str
    progress: int
    message: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class TaskStatsResponse(BaseSchema):
    """Статистика по задачам"""
    active_tasks: int = 0
    total_found: int = 0
    total_tasks: int = 0
    avg_search_time: Optional[float] = None
    success_rate: Optional[float] = None
    queued_tasks: int = 0
    searching_tasks: int = 0
    done_tasks: int = 0
