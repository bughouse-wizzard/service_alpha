"""
Схемы для сессий
"""
from datetime import datetime
from typing import Optional

from app.schemas.base import BaseSchema, TimestampMixin

class SessionCreate(BaseSchema):
    """Создание сессии"""
    pass

class SessionResponse(TimestampMixin):
    """Ответ с информацией о сессии"""
    id: str
    created_at: datetime
    last_seen_at: datetime
    token: str  # Токен для совместимости с фронтендом
