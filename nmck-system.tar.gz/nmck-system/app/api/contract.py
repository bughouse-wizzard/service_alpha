"""
Роутер для работы с контрактами
"""
import json
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.infra.database import get_db
from app.domain.entities.session import SessionEntity as DBSession
from app.domain.entities.contract import ContractEntity
from app.domain.entities.audit import ContractAuditEntity
from app.schemas.contract import ContractResponse, AuditLogResponse

router = APIRouter()

@router.get("/contracts/{contract_id}/audit-log", response_model=List[AuditLogResponse])
async def get_contract_audit_log(
    request: Request,
    contract_id: str,
    db: Session = Depends(get_db)
):
    """
    Получить лог сверки характеристик для контракта.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем контракт
    contract = db.query(ContractEntity).filter(ContractEntity.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Контракт не найден")
    
    # Проверяем, что контракт принадлежит задаче пользователя
    task = contract.task
    if task.session_id != session_token:
        raise HTTPException(status_code=403, detail="Доступ запрещен")
    
    # Получаем лог сверки
    audit_rows = db.query(ContractAuditEntity).filter(
        ContractAuditEntity.contract_id == contract_id
    ).order_by(ContractAuditEntity.id).all()
    
    # Формируем ответ
    result = []
    for row in audit_rows:
        result.append(AuditLogResponse(
            key=row.key,
            expected_value=row.expected_value,
            found_value=row.found_value,
            is_diff=row.is_diff,
            diff_reason=row.diff_reason
        ))
    
    return result

@router.get("/contracts/{contract_id}/details")
async def get_contract_details(
    request: Request,
    contract_id: str,
    db: Session = Depends(get_db)
):
    """
    Получить детальную информацию о контракте.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем контракт
    contract = db.query(ContractEntity).filter(ContractEntity.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Контракт не найден")
    
    # Проверяем, что контракт принадлежит задаче пользователя
    task = contract.task
    if task.session_id != session_token:
        raise HTTPException(status_code=403, detail="Доступ запрещен")
    
    # Парсим raw данные
    raw_data = {}
    if contract.raw_payload_json:
        try:
            raw_data = json.loads(contract.raw_payload_json)
        except:
            raw_data = {"error": "Не удалось распарсить данные"}
    
    # Формируем ответ
    response = {
        "id": contract.id,
        "reg_number": contract.reg_number,
        "eis_url": contract.eis_url,
        "supplier_name": contract.supplier_name,
        "supplier_inn": contract.supplier_inn,
        "sign_date": contract.sign_date,
        "unit_price": contract.unit_price,
        "currency": contract.currency,
        "match_percent": contract.match_percent,
        "match_type": contract.match_type,
        "vendor_status": contract.vendor_status,
        "raw_data": raw_data
    }
    
    return response
