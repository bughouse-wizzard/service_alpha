"""
Роутер для выбора контрактов и расчета НМЦК
"""
import json
from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.infra.database import get_db
from app.domain.entities.session import SessionEntity as DBSession
from app.domain.entities.task import TaskEntity, TaskStatus
from app.domain.entities.contract import ContractEntity
from app.domain.entities.selection import TaskSelectionEntity
from app.domain.entities.calculation import TaskCalculationEntity
from app.schemas.selection import SelectionUpdate, SelectionResponse

router = APIRouter()

@router.post("/tasks/{task_id}/selection", response_model=SelectionResponse)
async def update_selection(
    request: Request,
    task_id: str,
    selection_data: SelectionUpdate,
    db: Session = Depends(get_db)
):
    """
    Обновить выбор контрактов для расчета НМЦК.
    
    Проверяет правило: нельзя выбрать 3 контракта от одного поставщика.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем задачу
    task = db.query(TaskEntity).filter(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session_token
    ).first()
    
    if not task:
        raise HTTPException(status_code=404, detail="Задача не найдена")
    
    if task.status != TaskStatus.DONE:
        raise HTTPException(status_code=400, detail="Задача еще не завершена")
    
    # Проверяем количество контрактов
    if len(selection_data.contract_ids) != 3:
        raise HTTPException(
            status_code=400,
            detail="Для расчета НМЦК необходимо выбрать ровно 3 контракта"
        )
    
    # Получаем информацию о выбранных контрактах
    contracts = db.query(ContractEntity).filter(
        ContractEntity.id.in_(selection_data.contract_ids),
        ContractEntity.task_id == task_id
    ).all()
    
    if len(contracts) != 3:
        raise HTTPException(
            status_code=400,
            detail="Не все выбранные контракты найдены"
        )
    
    # Проверяем правило поставщиков
    supplier_counts = {}
    for contract in contracts:
        supplier = contract.supplier_name
        supplier_counts[supplier] = supplier_counts.get(supplier, 0) + 1
    
    # Нельзя выбрать 3 контракта от одного поставщика
    for supplier, count in supplier_counts.items():
        if count >= 3:
            raise HTTPException(
                status_code=409,
                detail=f"Нельзя выбрать 3 контракта от одного поставщика ({supplier})",
                headers={"X-Supplier-Conflict": supplier}
            )
    
    # Удаляем старый выбор
    db.query(TaskSelectionEntity).filter(TaskSelectionEntity.task_id == task_id).delete()
    
    # Сохраняем новый выбор
    for contract_id in selection_data.contract_ids:
        selection = TaskSelectionEntity(
            task_id=task_id,
            contract_id=contract_id,
            selected_at=datetime.utcnow()
        )
        db.add(selection)
    
    # Рассчитываем НМЦК
    total_price = sum(contract.unit_price for contract in contracts)
    nmck_value = total_price / 3  # Среднее арифметическое
    
    # Сохраняем расчет
    calculation = TaskCalculationEntity(
        task_id=task_id,
        method="average",
        nmc_value=nmck_value,
        computed_at=datetime.utcnow(),
        details=json.dumps({
            "selected_contracts": selection_data.contract_ids,
            "calculation_method": "average",
            "contract_prices": [contract.unit_price for contract in contracts],
            "supplier_counts": supplier_counts
        })
    )
    
    db.add(calculation)
    db.commit()
    
    return SelectionResponse(
        task_id=task_id,
        selected_contracts=selection_data.contract_ids,
        nmck_value=nmck_value,
        calculation_method="average",
        supplier_counts=supplier_counts
    )

@router.get("/tasks/{task_id}/selection", response_model=SelectionResponse)
async def get_selection(
    request: Request,
    task_id: str,
    db: Session = Depends(get_db)
):
    """
    Получить текущий выбор контрактов для задачи.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем задачу
    task = db.query(TaskEntity).filter(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session_token
    ).first()
    
    if not task:
        raise HTTPException(status_code=404, detail="Задача не найдена")
    
    # Получаем выбранные контракты
    selections = db.query(TaskSelectionEntity).filter(
        TaskSelectionEntity.task_id == task_id
    ).all()
    
    selected_contract_ids = [selection.contract_id for selection in selections]
    
    # Получаем расчет НМЦК
    calculation = db.query(TaskCalculationEntity).filter(
        TaskCalculationEntity.task_id == task_id
    ).order_by(TaskCalculationEntity.computed_at.desc()).first()
    
    # Если есть выбранные контракты, получаем информацию о поставщиках
    supplier_counts = {}
    if selected_contract_ids:
        contracts = db.query(ContractEntity).filter(
            ContractEntity.id.in_(selected_contract_ids)
        ).all()
        
        for contract in contracts:
            supplier = contract.supplier_name
            supplier_counts[supplier] = supplier_counts.get(supplier, 0) + 1
    
    return SelectionResponse(
        task_id=task_id,
        selected_contracts=selected_contract_ids,
        nmck_value=calculation.nmc_value if calculation else None,
        calculation_method=calculation.method if calculation else None,
        supplier_counts=supplier_counts
    )
