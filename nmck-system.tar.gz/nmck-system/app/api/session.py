"""
Роутер для работы с сессиями
"""
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy.orm import Session

from app.infra.database import get_db
from app.domain.entities.session import SessionEntity
from app.schemas.session import SessionCreate, SessionResponse

router = APIRouter()

@router.get("/session", response_model=SessionResponse)
async def get_or_create_session(
    request: Request,
    response: Response,
    db: Session = Depends(get_db)
):
    """
    Получить или создать сессию.
    
    Если в куках есть session_token, возвращает существующую сессию.
    Если нет - создает новую сессию и устанавливает куку.
    """
    # Проверяем наличие session_token в куках
    session_token = request.cookies.get("session_token")
    
    if session_token:
        # Ищем существующую сессию
        session_entity = db.query(SessionEntity).filter(
            SessionEntity.id == session_token
        ).first()
        
        if session_entity:
            # Обновляем время последнего визита
            session_entity.last_seen_at = datetime.utcnow()
            db.commit()
            
            return SessionResponse(
                id=session_entity.id,
                created_at=session_entity.created_at,
                last_seen_at=session_entity.last_seen_at,
                token=session_entity.id  # Добавляем токен для совместимости с фронтендом
            )
    
    # Создаем новую сессию
    session_id = str(uuid.uuid4())
    session_entity = SessionEntity(
        id=session_id,
        token=session_id,  # Используем тот же ID как токен
        created_at=datetime.utcnow(),
        last_seen_at=datetime.utcnow()
    )
    
    db.add(session_entity)
    db.commit()
    
    # Устанавливаем куку
    response.set_cookie(
        key="session_token",
        value=session_id,
        httponly=True,
        max_age=86400 * 30,  # 30 дней
        samesite="lax"
    )
    
    return SessionResponse(
        id=session_entity.id,
        created_at=session_entity.created_at,
        last_seen_at=session_entity.last_seen_at,
        token=session_entity.id  # Добавляем токен для совместимости с фронтендом
    )

@router.delete("/session")
async def delete_session(
    request: Request,
    response: Response,
    db: Session = Depends(get_db)
):
    """
    Удалить сессию.
    
    Удаляет сессию из базы данных и очищает куку.
    """
    session_token = request.cookies.get("session_token")
    
    if session_token:
        # Удаляем сессию из базы
        db.query(SessionEntity).filter(SessionEntity.id == session_token).delete()
        db.commit()
    
    # Очищаем куку
    response.delete_cookie(key="session_token")
    
    return {"message": "Сессия удалена"}
