"""
Роутер для загрузки и обработки файлов с требованиями
"""
import os
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Request
from sqlalchemy.orm import Session

from app.infra.database import get_db
from app.domain.entities.session import SessionEntity as DBSession
from app.domain.entities.upload import UploadEntity
from app.schemas.upload import UploadResponse, UploadDetectionResponse, CharacteristicSchema
from app.adapters.file_parser import FileParser

router = APIRouter()

# Создаем директорию для загрузок, если её нет
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/uploads", response_model=UploadDetectionResponse)
async def upload_file(
    request: Request,
    file: UploadFile = File(...),
    source_type: Optional[str] = "freeform",
    db: Session = Depends(get_db)
):
    """
    Загрузить файл с требованиями к товару.
    
    Поддерживаемые форматы: TXT, XLSX, DOCX, PDF
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Проверяем существование сессии
    db_session = db.query(DBSession).filter(DBSession.id == session_token).first()
    if not db_session:
        raise HTTPException(status_code=401, detail="Недействительная сессия")
    
    # Проверяем расширение файла
    allowed_extensions = {'.txt', '.xlsx', '.docx', '.pdf'}
    file_ext = os.path.splitext(file.filename)[1].lower()
    
    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Неподдерживаемый формат файла. Разрешены: {', '.join(allowed_extensions)}"
        )
    
    # Генерируем уникальное имя файла
    file_id = str(uuid.uuid4())
    filename = f"{file_id}{file_ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    
    # Сохраняем файл
    try:
        content = await file.read()
        with open(filepath, "wb") as f:
            f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка сохранения файла: {str(e)}")
    
    # Парсим файл
    parser = FileParser()
    try:
        parsed_data = parser.parse_file(filepath, file_ext)
    except Exception as e:
        # Удаляем файл в случае ошибки парсинга
        os.remove(filepath)
        raise HTTPException(status_code=400, detail=f"Ошибка парсинга файла: {str(e)}")
    
    # Создаем запись в БД
    upload = UploadEntity(
        id=file_id,
        session_id=session_token,
        filename=file.filename,
        mime_type=file.content_type,
        storage_url=filepath,
        extracted_data=parsed_data.model_dump_json() if hasattr(parsed_data, 'model_dump_json') else parsed_data,
        created_at=datetime.utcnow()
    )
    
    db.add(upload)
    db.commit()
    db.refresh(upload)
    
    # Формируем ответ
    response_data = {
        "upload_id": upload.id,
        "detected": {
            "ktru_code": parsed_data.get("ktru_code"),
            "name": parsed_data.get("name"),
            "vendor": parsed_data.get("vendor"),
            "characteristics": [
                CharacteristicSchema(
                    key=char.get("key"),
                    value=char.get("value"),
                    unit=char.get("unit"),
                    operator=char.get("operator", "=")
                )
                for char in parsed_data.get("characteristics", [])
            ]
        },
        "warnings": parsed_data.get("warnings", [])
    }
    
    return UploadDetectionResponse(**response_data)

@router.get("/uploads/{upload_id}", response_model=UploadResponse)
async def get_upload(
    request: Request,
    upload_id: str,
    db: Session = Depends(get_db)
):
    """
    Получить информацию о загруженном файле.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем загрузку
    upload = db.query(Upload).filter(
        Upload.id == upload_id,
        Upload.session_id == session_token
    ).first()
    
    if not upload:
        raise HTTPException(status_code=404, detail="Загрузка не найдена")
    
    # Парсим сохраненные данные
    import json
    parsed_data = json.loads(upload.extracted_json)
    
    # Формируем ответ
    response_data = {
        "upload_id": upload.id,
        "detected": {
            "ktru_code": parsed_data.get("ktru_code"),
            "name": parsed_data.get("name"),
            "vendor": parsed_data.get("vendor"),
            "characteristics": [
                CharacteristicSchema(
                    key=char.get("key"),
                    value=char.get("value"),
                    unit=char.get("unit"),
                    operator=char.get("operator", "=")
                )
                for char in parsed_data.get("characteristics", [])
            ]
        },
        "warnings": parsed_data.get("warnings", [])
    }
    
    return UploadDetectionResponse(**response_data)

@router.delete("/uploads/{upload_id}")
async def delete_upload(
    request: Request,
    upload_id: str,
    db: Session = Depends(get_db)
):
    """
    Удалить загруженный файл.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем загрузку
    upload = db.query(Upload).filter(
        Upload.id == upload_id,
        Upload.session_id == session_token
    ).first()
    
    if not upload:
        raise HTTPException(status_code=404, detail="Загрузка не найдена")
    
    # Удаляем файл с диска
    if os.path.exists(upload.storage_url):
        os.remove(upload.storage_url)
    
    # Удаляем запись из БД
    db.delete(upload)
    db.commit()
    
    return {"message": "Файл удален"}
