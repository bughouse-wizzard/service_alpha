"""
Основной файл FastAPI приложения системы НМЦК
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from app.infra.database import get_db, engine
from app.domain.entities.base import Base
from app.schemas.session import SessionCreate, SessionResponse
from app.schemas.upload import UploadCreate, UploadResponse
from app.schemas.task import TaskCreate, TaskResponse, TaskListResponse
from app.schemas.contract import ContractResponse
from app.schemas.selection import SelectionUpdate, SelectionResponse
from app.api import session, upload, task, contract, selection

# Создаем таблицы в БД
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Система расчета НМЦК",
    description="Система автоматического поиска и расчета начальной максимальной цены контракта",
    version="1.0.0"
)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключаем статические файлы
app.mount("/static", StaticFiles(directory="static"), name="static")

# Подключаем роутеры
app.include_router(session.router, prefix="/api", tags=["Сессии"])
app.include_router(upload.router, prefix="/api", tags=["Загрузка файлов"])
app.include_router(task.router, prefix="/api", tags=["Задачи"])
app.include_router(contract.router, prefix="/api", tags=["Контракты"])
app.include_router(selection.router, prefix="/api", tags=["Выбор контрактов"])

# WebSocket соединения
class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, session_token: str):
        await websocket.accept()
        self.active_connections[session_token] = websocket

    def disconnect(self, session_token: str):
        if session_token in self.active_connections:
            del self.active_connections[session_token]

    async def send_personal_message(self, message: dict, session_token: str):
        if session_token in self.active_connections:
            websocket = self.active_connections[session_token]
            try:
                await websocket.send_json(message)
            except:
                self.disconnect(session_token)

    async def broadcast(self, message: dict):
        for connection in self.active_connections.values():
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

@app.websocket("/api/ws")
async def websocket_endpoint(websocket: WebSocket, session_token: str):
    await manager.connect(websocket, session_token)
    try:
        while True:
            # Ожидаем сообщения от клиента (ping/pong)
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        manager.disconnect(session_token)

@app.get("/")
async def root():
    from fastapi.responses import FileResponse
    return FileResponse("static/index.html")

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
