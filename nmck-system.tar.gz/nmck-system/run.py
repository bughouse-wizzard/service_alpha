#!/usr/bin/env python3
"""
Скрипт для запуска системы НМЦК
"""
import os
import sys
import uvicorn
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

if __name__ == "__main__":
    # Запускаем FastAPI приложение
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
