import os
import sys
import logging
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Configure logging
logger = logging.getLogger(__name__)

# Add parent dir to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import db
from llm.providers.registry import registry
from llm.providers.base import LLMConfig, LLMProviderType

# Import authentication modules
from auth import get_current_active_user, check_permission
from db.postgres.models.user import User

# Import project hierarchy models
from db.postgres.models.project import Project
from db.postgres.models.development_cycle import DevelopmentCycle
from db.postgres.models.epoch import Epoch
from db.postgres.models.epic import Epic
from db.postgres.models.work_item import WorkItem

# Import middleware
from .middleware import AuthMiddleware, RBACMiddleware

# Import i18n
from .i18n import get_language, translate, LocalizedJSONResponse

# Import admin router (will be imported in try-except block below)

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add authentication middleware
app.add_middleware(AuthMiddleware)

# Add RBAC middleware with permission mapping
permission_map = {
    "excluded": [
        "/api/auth/login",
        "/api/auth/register",
        "/api/auth/refresh",
        "/api/auth/initialize",
        "/docs",
        "/redoc",
        "/openapi.json",
    ]
}
app.add_middleware(RBACMiddleware, permission_map=permission_map)


# Pydantic models for request/response
class TeamCreate(BaseModel):
    name: str
    description: Optional[str] = None


class ProjectCreate(BaseModel):
    team_id: str
    name: str
    description: Optional[str] = None


# Project hierarchy models
class ProjectResponse(BaseModel):
    id: str
    name: str
    description: str
    status: str
    default_language: str
    created_at: str
    updated_at: str
    cycles_count: int = 0
    active_cycles_count: int = 0


class CycleResponse(BaseModel):
    id: str
    project_id: str
    cycle_number: int
    objective: str
    objective_lang: str
    status: str
    source_type: str
    source_ref: Optional[str] = None
    created_at: str
    updated_at: str
    epochs_count: int = 0
    completed_epochs_count: int = 0


class EpochResponse(BaseModel):
    id: str
    cycle_id: str
    title: str
    description: str
    order_index: int
    status: str
    created_at: str
    updated_at: str
    epics_count: int = 0
    completed_epics_count: int = 0


class EpicResponse(BaseModel):
    id: str
    epoch_id: str
    title: str
    description: str
    order_index: int
    status: str
    created_at: str
    updated_at: str
    work_items_count: int = 0
    completed_work_items_count: int = 0


class WorkItemResponse(BaseModel):
    id: str
    epic_id: str
    title: str
    description: str
    order_index: int
    status: str
    priority: int
    worker_type: str
    assignee_role: str
    depends_on: List[str] = []
    acceptance_criteria: List[Dict[str, Any]] = []
    labels: List[str] = []
    estimated_effort_minutes: Optional[int] = None
    repo_id: Optional[str] = None
    branch_name: Optional[str] = None
    pr_url: Optional[str] = None
    commit_sha: Optional[str] = None
    agent_conversation_id: Optional[str] = None
    agent_state: Optional[str] = None
    last_error: Optional[str] = None
    retry_count: int = 0
    created_at: str
    updated_at: str


class ProjectTreeResponse(BaseModel):
    project: ProjectResponse
    cycles: List[CycleResponse]
    epochs: List[EpochResponse]
    epics: List[EpicResponse]
    work_items: List[WorkItemResponse]


class FilterParams(BaseModel):
    status: Optional[str] = None
    search: Optional[str] = None
    limit: Optional[int] = 100
    offset: Optional[int] = 0


class LLMConfigCreate(BaseModel):
    provider_type: str
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    timeout: int = 30
    max_retries: int = 3
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    extra_params: Optional[dict] = None
    team_id: Optional[str] = None
    project_id: Optional[str] = None
    is_default: bool = False


class LLMConfigUpdate(BaseModel):
    provider_type: Optional[str] = None
    model: Optional[str] = None
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    timeout: Optional[int] = None
    max_retries: Optional[int] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    extra_params: Optional[dict] = None
    team_id: Optional[str] = None
    project_id: Optional[str] = None
    is_default: Optional[bool] = None


class TestProviderRequest(BaseModel):
    provider_id: str
    test_message: str = "Hello, are you working?"


@app.get("/api/pipelines")
def get_pipelines():
    conn = db.get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM pipelines ORDER BY created_at DESC")
    pipelines = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return pipelines


@app.get("/api/pipelines/{pipeline_id}")
def get_pipeline_details(pipeline_id: str):
    pipeline = db.get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return pipeline


@app.get("/api/tasks/{task_id}/logs")
def get_task_logs(task_id: str):
    conn = db.get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM logs WHERE task_id = ? ORDER BY id ASC", (task_id,))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs


# --- Team Management ---


@app.get("/api/teams")
def get_teams(current_user: User = Depends(get_current_active_user)):
    """Get all teams (requires authentication)"""
    # Check if user has permission to view teams
    if not check_permission(current_user, "view_teams"):
        raise HTTPException(status_code=403, detail="Not enough permissions to view teams")

    # Use PostgresDatabase for teams
    from db.postgres.database import PostgresDatabase

    teams = PostgresDatabase.get_all_teams()
    return teams


@app.get("/api/teams/{team_id}")
def get_team(team_id: str, current_user: User = Depends(get_current_active_user)):
    """Get specific team (requires team access)"""
    import uuid
    from db.postgres.database import PostgresDatabase

    try:
        team_uuid = uuid.UUID(team_id)

        # Check if user has access to this team
        user_teams = PostgresDatabase.get_user_teams(current_user.id)
        user_team_ids = [team["team_id"] for team in user_teams]

        if team_uuid not in user_team_ids and not check_permission(current_user, "manage_teams"):
            raise HTTPException(
                status_code=403, detail="Not enough permissions to access this team"
            )

        team = PostgresDatabase.get_team(team_uuid)
        if not team:
            raise HTTPException(status_code=404, detail="Team not found")

        return team
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid team ID format")


@app.post("/api/teams")
def create_team(team: TeamCreate, current_user: User = Depends(get_current_active_user)):
    """Create a new team (requires admin/team_lead permission)"""
    # Check permission
    if not check_permission(current_user, "manage_teams"):
        raise HTTPException(status_code=403, detail="Not enough permissions to create teams")

    # Use PostgresDatabase for teams
    from db.postgres.database import PostgresDatabase

    team_id = PostgresDatabase.create_team(team.name, team.description)
    team_data = PostgresDatabase.get_team(team_id)

    if not team_data:
        raise HTTPException(status_code=500, detail="Failed to create team")

    return team_data


# --- Project Management ---


@app.get("/api/projects")
def get_projects(
    team_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    lang: str = Depends(get_language),
):
    """Get projects (optionally filtered by team, requires authentication)"""
    from db.postgres.database import PostgresDatabase
    import uuid

    # Check if user has permission to view projects
    if not check_permission(current_user, "view_projects"):
        raise HTTPException(status_code=403, detail=translate("errors.forbidden", lang))

    if team_id:
        # Get projects for specific team (if user has access)
        try:
            team_uuid = uuid.UUID(team_id)
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_projects"
            ):
                raise HTTPException(status_code=403, detail=translate("errors.forbidden", lang))

            # Get projects for team
            projects = PostgresDatabase.get_projects_by_team(team_uuid)
            return projects
        except ValueError:
            raise HTTPException(status_code=400, detail=translate("errors.validation_error", lang))
    else:
        # Get all projects user has access to
        user_teams = PostgresDatabase.get_user_teams(current_user.id)
        user_team_ids = [team["team_id"] for team in user_teams]

        all_projects = []
        for team_id in user_team_ids:
            team_projects = PostgresDatabase.get_projects_by_team(team_id)
            all_projects.extend(team_projects)

        return all_projects


@app.get("/api/projects/{project_id}")
def get_project(project_id: str, current_user: User = Depends(get_current_active_user)):
    """Get specific project (requires project access)"""
    from db.postgres.database import PostgresDatabase
    import uuid

    try:
        project_uuid = uuid.UUID(project_id)

        # Get project
        project = PostgresDatabase.get_project(project_uuid)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")

        # Check if user has access to this project's team
        user_teams = PostgresDatabase.get_user_teams(current_user.id)
        user_team_ids = [team["team_id"] for team in user_teams]

        if project["team_id"] not in user_team_ids and not check_permission(
            current_user, "manage_projects"
        ):
            raise HTTPException(
                status_code=403, detail="Not enough permissions to access this project"
            )

        return project
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid project ID format")


@app.post("/api/projects")
def create_project(project: ProjectCreate, current_user: User = Depends(get_current_active_user)):
    """Create a new project (requires admin/team_lead permission)"""
    # Check permission
    if not check_permission(current_user, "manage_projects"):
        raise HTTPException(status_code=403, detail="Not enough permissions to create projects")

    # Use PostgresDatabase for projects
    from db.postgres.database import PostgresDatabase
    import uuid

    try:
        team_uuid = uuid.UUID(project.team_id)

        # Check if user has access to this team
        user_teams = PostgresDatabase.get_user_teams(current_user.id)
        user_team_ids = [team["team_id"] for team in user_teams]

        if team_uuid not in user_team_ids and not check_permission(current_user, "manage_projects"):
            raise HTTPException(
                status_code=403, detail="Not enough permissions to create projects in this team"
            )

        # Create project
        project_id = PostgresDatabase.create_project(
            team_id=team_uuid, name=project.name, description=project.description
        )

        project_data = PostgresDatabase.get_project(project_id)
        if not project_data:
            raise HTTPException(status_code=500, detail="Failed to create project")

        return project_data
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid team ID format")


@app.put("/api/projects/{project_id}")
def update_project(
    project_id: str, project: ProjectCreate, current_user: User = Depends(get_current_active_user)
):
    """Update project (requires admin/team_lead permission)"""
    from db.postgres.database import PostgresDatabase
    import uuid

    try:
        project_uuid = uuid.UUID(project_id)

        # Get existing project
        existing_project = PostgresDatabase.get_project(project_uuid)
        if not existing_project:
            raise HTTPException(status_code=404, detail="Project not found")

        # Check if user has permission to update this project
        user_teams = PostgresDatabase.get_user_teams(current_user.id)
        user_team_ids = [team["team_id"] for team in user_teams]

        if existing_project["team_id"] not in user_team_ids or not check_permission(
            current_user, "manage_projects"
        ):
            raise HTTPException(
                status_code=403, detail="Not enough permissions to update this project"
            )

        # Update project
        success = PostgresDatabase.update_project(
            project_id=project_uuid, name=project.name, description=project.description
        )

        if not success:
            raise HTTPException(status_code=500, detail="Failed to update project")

        updated_project = PostgresDatabase.get_project(project_uuid)
        return updated_project
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid project ID format")


# --- LLM Configuration Management ---


@app.get("/api/llm-configs")
def get_llm_configs(
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """Get LLM configurations"""
    # Check permission
    if not check_permission(current_user, "manage_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to view LLM configurations"
        )

    # If team_id is specified, check access
    if team_id:
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(team_id)
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to access this team's LLM configurations",
                )
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid team ID format")

    return db.get_llm_configs(team_id, project_id)


@app.get("/api/llm-configs/{config_id}")
def get_llm_config(config_id: str, current_user: User = Depends(get_current_active_user)):
    """Get LLM configuration by ID"""
    # Check permission
    if not check_permission(current_user, "manage_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to view LLM configurations"
        )

    config = db.get_llm_config(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="LLM configuration not found")

    # Check access to team/project if config is scoped
    if config.get("team_id"):
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(config["team_id"])
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to access this LLM configuration",
                )
        except ValueError:
            pass

    return config


@app.post("/api/llm-configs")
def create_llm_config(
    config: LLMConfigCreate, current_user: User = Depends(get_current_active_user)
):
    """Create a new LLM configuration"""
    # Check permission
    if not check_permission(current_user, "manage_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to create LLM configurations"
        )

    # If config is scoped to team, check access
    if config.team_id:
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(config.team_id)
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to create LLM configurations for this team",
                )
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid team ID format")

    # Validate provider type
    try:
        provider_type_enum = LLMProviderType(config.provider_type)
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid provider type. Must be one of: {[t.value for t in LLMProviderType]}",
        )

    # Create config in database
    config_id = db.create_llm_config(
        provider_type=config.provider_type,
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        timeout=config.timeout,
        max_retries=config.max_retries,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
        extra_params=config.extra_params,
        team_id=config.team_id,
        project_id=config.project_id,
        is_default=config.is_default,
    )

    # Also register in the runtime registry
    llm_config = LLMConfig(
        provider_type=provider_type_enum,
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        timeout=config.timeout,
        max_retries=config.max_retries,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
        extra_params=config.extra_params or {},
        team_id=config.team_id,
        project_id=config.project_id,
        is_default=config.is_default,
    )

    provider_id = registry.register_provider(llm_config)

    return {"id": config_id, "provider_id": provider_id, "config": llm_config.to_dict()}


@app.put("/api/llm-configs/{config_id}")
def update_llm_config(
    config_id: str,
    config_update: LLMConfigUpdate,
    current_user: User = Depends(get_current_active_user),
):
    """Update LLM configuration"""
    # Check permission
    if not check_permission(current_user, "manage_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to update LLM configurations"
        )

    # Get current config
    current_config = db.get_llm_config(config_id)
    if not current_config:
        raise HTTPException(status_code=404, detail="LLM configuration not found")

    # Check access to team if config is scoped
    if current_config.get("team_id"):
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(current_config["team_id"])
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to update this LLM configuration",
                )
        except ValueError:
            pass

    # Prepare update data
    update_data = {}
    for field, value in config_update.dict(exclude_unset=True).items():
        if value is not None:
            update_data[field] = value

    # Update in database
    success = db.update_llm_config(config_id, **update_data)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to update LLM configuration")

    # TODO: Update in runtime registry (would need to track provider_id)
    # For now, we'll rely on restart or manual refresh

    return {"success": True, "message": "LLM configuration updated"}


@app.delete("/api/llm-configs/{config_id}")
def delete_llm_config(config_id: str, current_user: User = Depends(get_current_active_user)):
    """Delete LLM configuration"""
    # Check permission
    if not check_permission(current_user, "manage_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to delete LLM configurations"
        )

    # Get current config to check access
    current_config = db.get_llm_config(config_id)
    if not current_config:
        raise HTTPException(status_code=404, detail="LLM configuration not found")

    # Check access to team if config is scoped
    if current_config.get("team_id"):
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(current_config["team_id"])
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to delete this LLM configuration",
                )
        except ValueError:
            pass

    success = db.delete_llm_config(config_id)
    if not success:
        raise HTTPException(status_code=404, detail="LLM configuration not found")

    # TODO: Remove from runtime registry

    return {"success": True, "message": "LLM configuration deleted"}


@app.get("/api/llm-configs/default")
def get_default_llm_config(
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """Get default LLM configuration for team/project"""
    # Check permission
    if not check_permission(current_user, "manage_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to view LLM configurations"
        )

    config = db.get_default_llm_config(team_id, project_id)
    if not config:
        raise HTTPException(status_code=404, detail="No default LLM configuration found")

    # Check access if config is scoped
    if config.get("team_id"):
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(config["team_id"])
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to access this LLM configuration",
                )
        except ValueError:
            pass

    return config


# --- LLM Provider Testing ---


@app.post("/api/llm-providers/test")
async def test_llm_provider(test_request: TestProviderRequest):
    """Test LLM provider connectivity"""
    provider = registry.get_provider(test_request.provider_id)
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found in registry")

    try:
        result = await registry.test_provider(test_request.provider_id, test_request.test_message)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Test failed: {str(e)}")


@app.get("/api/llm-providers")
def get_registered_providers():
    """Get all providers registered in runtime registry"""
    return registry.list_providers()


# --- VCS Configuration Management ---


class VCSConfigCreate(BaseModel):
    """VCS configuration creation schema."""

    name: str
    vcs_type: str  # github, gitlab, gitea, etc.
    base_url: Optional[str] = None
    api_token: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    team_id: Optional[str] = None
    project_id: Optional[str] = None
    is_default: bool = False


class VCSConfigUpdate(BaseModel):
    """VCS configuration update schema."""

    name: Optional[str] = None
    vcs_type: Optional[str] = None
    base_url: Optional[str] = None
    api_token: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    team_id: Optional[str] = None
    project_id: Optional[str] = None
    is_default: Optional[bool] = None


class ProjectRepoCreate(BaseModel):
    """Project repository creation schema."""

    project_id: str
    repo_url: str
    repo_name: str
    branch: str = "main"
    vcs_config_id: Optional[str] = None
    credentials_id: Optional[str] = None


@app.get("/api/vcs-configs")
def get_vcs_configs(
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """Get VCS configurations"""
    # Check permission
    if not check_permission(current_user, "manage_integrations"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to view VCS configurations"
        )

    # TODO: Implement VCS config retrieval from database
    # For now, return placeholder
    return {
        "message": "VCS configuration API coming soon",
        "team_id": team_id,
        "project_id": project_id,
    }


@app.post("/api/vcs-configs")
def create_vcs_config(
    config: VCSConfigCreate, current_user: User = Depends(get_current_active_user)
):
    """Create a new VCS configuration"""
    # Check permission
    if not check_permission(current_user, "manage_integrations"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to create VCS configurations"
        )

    # If config is scoped to team, check access
    if config.team_id:
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(config.team_id)
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_integrations"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to create VCS configurations for this team",
                )
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid team ID format")

    # TODO: Implement VCS config creation in database
    # For now, return placeholder
    return {
        "id": "placeholder-id",
        "name": config.name,
        "vcs_type": config.vcs_type,
        "message": "VCS configuration creation endpoint needs implementation",
    }


@app.get("/api/project-repos")
def get_project_repos(
    project_id: Optional[str] = None, current_user: User = Depends(get_current_active_user)
):
    """Get project repositories"""
    # Check permission
    if not check_permission(current_user, "view_projects"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to view project repositories"
        )

    if project_id:
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            project_uuid = uuid.UUID(project_id)

            # Get project to check access
            project = PostgresDatabase.get_project(project_uuid)
            if not project:
                raise HTTPException(status_code=404, detail="Project not found")

            # Check if user has access to this project's team
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if project["team_id"] not in user_team_ids and not check_permission(
                current_user, "manage_projects"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to access this project's repositories",
                )

            # TODO: Implement repository retrieval for project
            # For now, return placeholder
            return {
                "project_id": project_id,
                "repositories": [],
                "message": "Project repositories API coming soon",
            }
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid project ID format")

    # TODO: Implement repository retrieval for all user projects
    return {"message": "Project repositories API coming soon"}


@app.post("/api/project-repos")
def add_project_repo(
    repo: ProjectRepoCreate, current_user: User = Depends(get_current_active_user)
):
    """Add repository to project"""
    import uuid
    from db.postgres.database import PostgresDatabase

    try:
        project_uuid = uuid.UUID(repo.project_id)

        # Get project to check access
        project = PostgresDatabase.get_project(project_uuid)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")

        # Check if user has permission to manage this project
        user_teams = PostgresDatabase.get_user_teams(current_user.id)
        user_team_ids = [team["team_id"] for team in user_teams]

        if project["team_id"] not in user_team_ids or not check_permission(
            current_user, "manage_projects"
        ):
            raise HTTPException(
                status_code=403, detail="Not enough permissions to add repositories to this project"
            )

        # TODO: Implement repository addition to project
        # For now, return placeholder
        return {
            "id": "placeholder-repo-id",
            "project_id": repo.project_id,
            "repo_url": repo.repo_url,
            "repo_name": repo.repo_name,
            "branch": repo.branch,
            "message": "Repository addition endpoint needs implementation",
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid project ID format")


@app.delete("/api/project-repos/{repo_id}")
def remove_project_repo(repo_id: str, current_user: User = Depends(get_current_active_user)):
    """Remove repository from project"""
    # Check permission
    if not check_permission(current_user, "manage_projects"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to remove project repositories"
        )

    # TODO: Implement repository removal
    # For now, return placeholder
    return {
        "success": True,
        "message": f"Repository {repo_id} removed (placeholder)",
        "repo_id": repo_id,
    }


# --- Admin Dashboard Endpoints ---
# Note: Admin endpoints have been moved to dashboard/backend/admin/admin_api.py
# and are included via the admin_router


# --- LLM Configuration Management ---


@app.get("/api/llm-configs")
def get_llm_configs(
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """Get LLM configurations."""
    # Check permission
    if not check_permission(current_user, "view_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to view LLM configurations"
        )

    from db.postgres.database import PostgresDatabase

    try:
        # TODO: Implement actual LLM config retrieval from database
        # For now, return placeholder configurations
        configs = [
            {
                "id": "config-1",
                "provider_type": "openai",
                "model": "gpt-4",
                "api_key": "sk-...",
                "base_url": "https://api.openai.com/v1",
                "timeout": 30,
                "max_retries": 3,
                "temperature": 0.7,
                "max_tokens": 4096,
                "team_id": None,
                "project_id": None,
                "is_default": True,
                "created_at": "2024-01-18T14:20:00Z",
                "updated_at": "2024-01-19T10:30:00Z",
            },
            {
                "id": "config-2",
                "provider_type": "anthropic",
                "model": "claude-3-opus",
                "api_key": "sk-ant-...",
                "base_url": "https://api.anthropic.com/v1",
                "timeout": 60,
                "max_retries": 3,
                "temperature": 0.8,
                "max_tokens": 8192,
                "team_id": "team-1",
                "project_id": None,
                "is_default": False,
                "created_at": "2024-01-18T15:30:00Z",
                "updated_at": "2024-01-19T09:45:00Z",
            },
        ]

        # Filter by team/project if specified
        filtered_configs = []
        for config in configs:
            if team_id and config.get("team_id") != team_id:
                continue
            if project_id and config.get("project_id") != project_id:
                continue
            filtered_configs.append(config)

        return filtered_configs
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get LLM configurations: {str(e)}")


@app.post("/api/llm-configs")
def create_llm_config(
    config: LLMConfigCreate, current_user: User = Depends(get_current_active_user)
):
    """Create a new LLM configuration."""
    # Check permission
    if not check_permission(current_user, "create_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to create LLM configurations"
        )

    # Validate provider type
    if config.provider_type not in ["openai", "anthropic", "google", "azure", "local"]:
        raise HTTPException(
            status_code=400, detail=f"Unsupported provider type: {config.provider_type}"
        )

    # If config is scoped to team, check access
    if config.team_id:
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(config.team_id)
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_llm_configs"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to create LLM configurations for this team",
                )
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid team ID format")

    # TODO: Implement actual LLM config creation in database
    # For now, return placeholder
    return {
        "id": "new-config-id",
        "provider_type": config.provider_type,
        "model": config.model,
        "message": "LLM configuration created successfully (placeholder)",
    }


@app.put("/api/llm-configs/{config_id}")
def update_llm_config(
    config_id: str,
    config_update: LLMConfigUpdate,
    current_user: User = Depends(get_current_active_user),
):
    """Update an existing LLM configuration."""
    # Check permission
    if not check_permission(current_user, "edit_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to edit LLM configurations"
        )

    # TODO: Implement actual LLM config update in database
    # For now, return placeholder
    return {
        "id": config_id,
        "message": "LLM configuration updated successfully (placeholder)",
        "updated_fields": config_update.dict(exclude_unset=True),
    }


@app.delete("/api/llm-configs/{config_id}")
def delete_llm_config(config_id: str, current_user: User = Depends(get_current_active_user)):
    """Delete an LLM configuration."""
    # Check permission
    if not check_permission(current_user, "delete_llm_configs"):
        raise HTTPException(
            status_code=403, detail="Not enough permissions to delete LLM configurations"
        )

    # TODO: Implement actual LLM config deletion
    # For now, return placeholder
    return {
        "success": True,
        "message": f"LLM configuration {config_id} deleted (placeholder)",
        "config_id": config_id,
    }


# Import and include authentication router
try:
    from app_auth import router as auth_router

    app.include_router(auth_router)
except ImportError as e:
    print(f"Warning: Could not import auth router: {e}")
    print("Authentication endpoints will not be available.")

# Import and include project tree API router
try:
    from project_tree_api import router as project_tree_router

    app.include_router(project_tree_router)
except ImportError as e:
    print(f"Warning: Could not import project tree router: {e}")
    print("Project tree API endpoints will not be available.")

# Import and include project hierarchy API router
try:
    from project_hierarchy_api import router as project_hierarchy_router

    app.include_router(project_hierarchy_router)
except ImportError as e:
    print(f"Warning: Could not import project hierarchy router: {e}")
    print("Project hierarchy API endpoints will not be available.")

# Import and include admin API router
try:
    from .admin.admin_api import router as admin_router

    app.include_router(admin_router)
except ImportError as e:
    print(f"Warning: Could not import admin router: {e}")
    print("Admin API endpoints will not be available.")


# --- Jira Webhook Integration ---


class JiraWebhookPayload(BaseModel):
    """Jira webhook payload model."""

    webhookEvent: str
    timestamp: int
    issue: Dict[str, Any]
    user: Optional[Dict[str, Any]] = None
    changelog: Optional[Dict[str, Any]] = None


@app.post("/api/integrations/jira/webhook")
async def jira_webhook(
    payload: JiraWebhookPayload, current_user: User = Depends(get_current_active_user)
):
    """Handle Jira webhook events."""
    # Check permission
    if not check_permission(current_user, "manage_integrations"):
        raise HTTPException(status_code=403, detail="Not enough permissions to handle webhooks")

    try:
        # Import Jira integration
        from integrations.jira import get_jira_integration

        jira_integration = get_jira_integration()
        if not jira_integration:
            raise HTTPException(status_code=503, detail="Jira integration not configured")

        # Process webhook event
        result = jira_integration.process_webhook_event(payload.dict())

        # Log the event
        logger.info(
            f"Processed Jira webhook: {payload.webhookEvent} for issue {payload.issue.get('key')}"
        )

        return {"success": True, "message": "Webhook processed successfully", "result": result}

    except Exception as e:
        logger.error(f"Failed to process Jira webhook: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process webhook: {str(e)}")


# --- Integration Management ---


class IntegrationConfig(BaseModel):
    """Integration configuration model."""

    type: str  # "jira", "telegram", etc.
    name: str
    config: Dict[str, Any]
    team_id: Optional[str] = None
    project_id: Optional[str] = None
    enabled: bool = True


@app.get("/api/integrations")
def get_integrations(
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """Get integrations."""
    # Check permission
    if not check_permission(current_user, "view_integrations"):
        raise HTTPException(status_code=403, detail="Not enough permissions to view integrations")

    # TODO: Implement actual integration retrieval from database
    # For now, return placeholder data
    integrations = [
        {
            "id": "integration-1",
            "type": "jira",
            "name": "Jira Production",
            "config": {"base_url": "https://company.atlassian.net", "project_key": "PROJ"},
            "team_id": team_id,
            "project_id": project_id,
            "enabled": True,
            "created_at": "2024-01-18T14:20:00Z",
            "updated_at": "2024-01-19T10:30:00Z",
        },
        {
            "id": "integration-2",
            "type": "telegram",
            "name": "Telegram Notifications",
            "config": {"bot_token": "***", "chat_id": "-1001234567890"},
            "team_id": team_id,
            "project_id": project_id,
            "enabled": True,
            "created_at": "2024-01-18T15:30:00Z",
            "updated_at": "2024-01-19T09:45:00Z",
        },
    ]

    # Filter by team/project if specified
    filtered_integrations = []
    for integration in integrations:
        if team_id and integration.get("team_id") != team_id:
            continue
        if project_id and integration.get("project_id") != project_id:
            continue
        filtered_integrations.append(integration)

    return filtered_integrations


@app.post("/api/integrations")
def create_integration(
    integration: IntegrationConfig, current_user: User = Depends(get_current_active_user)
):
    """Create a new integration."""
    # Check permission
    if not check_permission(current_user, "create_integrations"):
        raise HTTPException(status_code=403, detail="Not enough permissions to create integrations")

    # Validate integration type
    if integration.type not in ["jira", "telegram", "webhook"]:
        raise HTTPException(
            status_code=400, detail=f"Unsupported integration type: {integration.type}"
        )

    # If integration is scoped to team/project, check access
    if integration.team_id:
        import uuid
        from db.postgres.database import PostgresDatabase

        try:
            team_uuid = uuid.UUID(integration.team_id)
            user_teams = PostgresDatabase.get_user_teams(current_user.id)
            user_team_ids = [team["team_id"] for team in user_teams]

            if team_uuid not in user_team_ids and not check_permission(
                current_user, "manage_integrations"
            ):
                raise HTTPException(
                    status_code=403,
                    detail="Not enough permissions to create integrations for this team",
                )
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid team ID format")

    # TODO: Implement actual integration creation in database
    # For now, return placeholder
    return {
        "id": "new-integration-id",
        "type": integration.type,
        "name": integration.name,
        "message": "Integration created successfully (placeholder)",
    }


# --- Telegram Notification Testing ---


class TelegramTestRequest(BaseModel):
    """Telegram test request model."""

    bot_token: str
    chat_id: str
    message: str = "Test notification from Orchestrator Bot"
    parse_mode: str = "HTML"


@app.post("/api/integrations/telegram/test")
async def test_telegram_integration(
    test_request: TelegramTestRequest, current_user: User = Depends(get_current_active_user)
):
    """Test Telegram integration."""
    # Check permission
    if not check_permission(current_user, "manage_integrations"):
        raise HTTPException(status_code=403, detail="Not enough permissions to test integrations")

    try:
        import aiohttp

        # Test Telegram API directly
        url = f"https://api.telegram.org/bot{test_request.bot_token}/sendMessage"
        params = {
            "chat_id": test_request.chat_id,
            "text": test_request.message,
            "parse_mode": test_request.parse_mode,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=params) as response:
                if response.status == 200:
                    result = await response.json()
                    if result.get("ok"):
                        return {
                            "success": True,
                            "message": "Telegram test successful",
                            "result": result,
                        }
                    else:
                        return {
                            "success": False,
                            "message": "Telegram API returned error",
                            "result": result,
                        }
                else:
                    error_text = await response.text()
                    raise HTTPException(
                        status_code=response.status, detail=f"Telegram API error: {error_text}"
                    )

    except Exception as e:
        logger.error(f"Failed to test Telegram integration: {e}")
        raise HTTPException(
            status_code=500, detail=f"Failed to test Telegram integration: {str(e)}"
        )


# --- System Event Notification Hooks ---


class SystemEventNotification(BaseModel):
    """System event notification model."""

    event_type: str
    project_id: Optional[str] = None
    pipeline_id: Optional[str] = None
    task_id: Optional[str] = None
    data: Dict[str, Any]


@app.post("/api/notifications/system-event")
async def handle_system_event(
    event: SystemEventNotification, current_user: User = Depends(get_current_active_user)
):
    """Handle system event and send notifications."""
    # Check permission (system events can be triggered by system itself)
    # For now, allow any authenticated user

    try:
        # Get Telegram integration
        from integrations.telegram import get_telegram_integration

        telegram_integration = get_telegram_integration()
        if not telegram_integration:
            logger.warning("Telegram integration not configured, skipping notification")
            return {"success": False, "message": "Telegram integration not configured"}

        # Create notification based on event type
        from integrations.telegram import (
            NotificationMessage,
            EventType,
            create_plan_ready_notification,
            create_plan_approved_notification,
            create_task_done_notification,
            create_merge_done_notification,
            create_validator_fail_notification,
            create_validator_pass_notification,
        )

        # Map event type to notification
        notification = None
        try:
            event_type_enum = EventType(event.event_type)

            if event_type_enum == EventType.PLAN_READY:
                notification = create_plan_ready_notification(
                    project_name=event.data.get("project_name", "Unknown Project"),
                    pipeline_id=event.pipeline_id or "unknown",
                    plan_details=event.data,
                )
            elif event_type_enum == EventType.PLAN_APPROVED:
                notification = create_plan_approved_notification(
                    project_name=event.data.get("project_name", "Unknown Project"),
                    pipeline_id=event.pipeline_id or "unknown",
                    approver=event.data.get("approver", "Unknown"),
                )
            elif event_type_enum == EventType.TASK_DONE:
                notification = create_task_done_notification(
                    project_name=event.data.get("project_name", "Unknown Project"),
                    pipeline_id=event.pipeline_id or "unknown",
                    task_id=event.task_id or "unknown",
                    task_name=event.data.get("task_name", "Unknown Task"),
                    result=event.data.get("result", {}),
                )
            elif event_type_enum == EventType.MERGE_DONE:
                notification = create_merge_done_notification(
                    project_name=event.data.get("project_name", "Unknown Project"),
                    pipeline_id=event.pipeline_id or "unknown",
                    branch=event.data.get("branch", "unknown"),
                    pr_url=event.data.get("pr_url", ""),
                    merge_result=event.data.get("merge_result", {}),
                )
            elif event_type_enum == EventType.VALIDATOR_FAIL:
                notification = create_validator_fail_notification(
                    project_name=event.data.get("project_name", "Unknown Project"),
                    pipeline_id=event.pipeline_id or "unknown",
                    validator_name=event.data.get("validator_name", "Unknown Validator"),
                    errors=event.data.get("errors", []),
                )
            elif event_type_enum == EventType.VALIDATOR_PASS:
                notification = create_validator_pass_notification(
                    project_name=event.data.get("project_name", "Unknown Project"),
                    pipeline_id=event.pipeline_id or "unknown",
                    validator_name=event.data.get("validator_name", "Unknown Validator"),
                )
            else:
                # Generic notification for other event types
                notification = NotificationMessage(
                    event_type=event_type_enum,
                    title=event.data.get("title", "System Event"),
                    message=event.data.get("message", "A system event occurred"),
                    details=event.data,
                    project_name=event.data.get("project_name"),
                    pipeline_id=event.pipeline_id,
                    task_id=event.task_id,
                    urgency=event.data.get("urgency", "normal"),
                )

        except ValueError:
            # Unknown event type, create generic notification
            notification = NotificationMessage(
                event_type=EventType.AGENT_ERROR,
                title="System Event",
                message=f"Event '{event.event_type}' occurred",
                details=event.data,
                urgency="normal",
            )

        # Send notification
        if notification:
            success = await telegram_integration.send_notification(notification)
            return {
                "success": success,
                "message": "Notification sent" if success else "Failed to send notification",
                "notification": notification.dict() if success else None,
            }
        else:
            return {"success": False, "message": "Failed to create notification"}

    except Exception as e:
        logger.error(f"Failed to handle system event: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to handle system event: {str(e)}")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
