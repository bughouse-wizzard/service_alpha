from __future__ import annotations

from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "nmck-mvp"
    app_version: str = "0.1.0"
    env: str = "dev"

    api_host: str = "0.0.0.0"
    api_port: int = 8000

    database_url: str
    redis_url: str

    celery_broker_url: str
    celery_result_backend: str

    deepseek_api_key: str | None = None

    cors_origins: List[str] = ["*"]

    log_level: str = "INFO"
    debug: bool = False

    zakupki_base: str = "https://zakupki.gov.ru"
    zakupki_timeout_sec: int = 30
    zakupki_min_delay_sec: float = 1.5
    zakupki_max_delay_sec: float = 3.5
    zakupki_max_retries: int = 3

    default_limit_contracts: int = 30
    default_region: str = "SZFO"

    ai_config_path: str = str(Path("config") / "ai_config.yaml")


settings = Settings()  # type: ignore[arg-type]