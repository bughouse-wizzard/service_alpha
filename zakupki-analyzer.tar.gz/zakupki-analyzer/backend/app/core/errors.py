from __future__ import annotations

from enum import StrEnum


class ErrorCode(StrEnum):
    INPUT_VALIDATION_ERROR = "INPUT_VALIDATION_ERROR"
    ZAKUPKI_FETCH_TIMEOUT = "ZAKUPKI_FETCH_TIMEOUT"
    ZAKUPKI_PARSE_ERROR = "ZAKUPKI_PARSE_ERROR"
    DOC_DOWNLOAD_ERROR = "DOC_DOWNLOAD_ERROR"
    DOC_TEXT_EXTRACT_ERROR = "DOC_TEXT_EXTRACT_ERROR"
    LLM_TIMEOUT = "LLM_TIMEOUT"
    LLM_RESPONSE_INVALID = "LLM_RESPONSE_INVALID"
    DB_CONSTRAINT_VIOLATION = "DB_CONSTRAINT_VIOLATION"
    STOP_REQUESTED = "STOP_REQUESTED"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"


class AppError(Exception):
    def __init__(self, code: ErrorCode, message: str, *, details: dict | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.details = details or {}