from __future__ import annotations

from pydantic import BaseModel, Field


class ApiError(BaseModel):
    error_code: str = Field(..., examples=["INPUT_VALIDATION_ERROR"])
    message: str
    details: dict = Field(default_factory=dict)