from datetime import datetime
from enum import Enum
from typing import Optional, List
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


class SearchStatus(str, Enum):
    """Статусы поиска."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    STOPPED = "stopped"
    FAILED = "failed"


class MatchType(str, Enum):
    """Типы совпадения."""
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    UNKNOWN = "unknown"


class ApiError(BaseModel):
    """Стандартный формат ошибки API."""
    error_code: str = Field(..., description="Код ошибки")
    message: str = Field(..., description="Сообщение об ошибке")
    details: Optional[dict] = Field(None, description="Дополнительные детали")


class SearchCreateRequest(BaseModel):
    """Запрос на создание поиска."""
    object_name: Optional[str] = Field(None, description="Наименование объекта закупки")
    ktru_code: str = Field(..., alias="ktru", description="КТРУ код", min_length=1, max_length=50)
    manufacturer_target: Optional[str] = Field(None, alias="manufacturer", description="Производитель (целевой)")
    customer_region: str = Field(default="СЗФО", alias="region", description="Регион/округ заказчика")
    law: str = Field(default="44", description="Закон (44/223-ФЗ)")
    execution_statuses: Optional[List[str]] = Field(default=["Исполнение завершено", "Исполнение прекращено"],
                                                   description="Статусы исполнения контракта")
    date_from: Optional[datetime] = Field(None, description="Дата начала периода")
    date_to: Optional[datetime] = Field(None, description="Дата окончания периода")
    limit_contracts: int = Field(default=30, alias="contract_limit", ge=1, le=1000, description="Лимит контрактов для обработки")
    target_specs_text: Optional[str] = Field(None, alias="characteristics", description="Текст характеристик из ТЗ")

    model_config = ConfigDict(populate_by_name=True)


class SearchBrief(BaseModel):
    """Краткая информация о поиске."""
    id: UUID = Field(..., description="ID поиска")
    ktru: str = Field(..., description="КТРУ код")
    object_name: Optional[str] = Field(None, description="Объект закупки")
    status: SearchStatus = Field(..., description="Статус поиска")
    created_at: datetime = Field(..., description="Дата создания")
    updated_at: datetime = Field(..., description="Дата обновления")
    contracts_found: Optional[int] = Field(None, description="Найдено контрактов")
    contracts_processed: Optional[int] = Field(None, description="Обработано контрактов")

    model_config = ConfigDict(from_attributes=True)


class SearchListResponse(BaseModel):
    """Список поисков."""
    searches: List[SearchBrief] = Field(..., description="Список поисков")
    total: int = Field(..., description="Общее количество поисков")
    
    model_config = ConfigDict(from_attributes=True)


class SearchDetailsResponse(BaseModel):
    """Детальная информация о поиске."""
    id: UUID = Field(..., description="ID поиска")
    ktru: str = Field(..., description="КТРУ код")
    manufacturer: Optional[str] = Field(None, description="Производитель")
    region: Optional[str] = Field(None, description="Регион/округ")
    date_from: Optional[datetime] = Field(None, description="Дата начала периода")
    date_to: Optional[datetime] = Field(None, description="Дата окончания периода")
    contract_limit: int = Field(..., description="Лимит контрактов")
    characteristics: Optional[str] = Field(None, description="Текст характеристик")
    status: SearchStatus = Field(..., description="Статус поиска")
    created_at: datetime = Field(..., description="Дата создания")
    updated_at: datetime = Field(..., description="Дата обновления")
    contracts_found: Optional[int] = Field(None, description="Найдено контрактов")
    contracts_processed: Optional[int] = Field(None, description="Обработано контрактов")
    nmck: Optional[float] = Field(None, description="Рассчитанная НМЦК")
    
    model_config = ConfigDict(from_attributes=True)


class SearchResultItem(BaseModel):
    """Элемент результата поиска."""
    reestr_number: str = Field(..., description="Реестровый номер контракта")
    contract_date: datetime = Field(..., description="Дата контракта")
    contract_price: float = Field(..., description="Цена контракта")
    unit_price: Optional[float] = Field(None, description="Цена за единицу")
    customer: str = Field(..., description="Заказчик")
    match_type: MatchType = Field(..., description="Тип совпадения")
    manufacturer_match: bool = Field(..., description="Совпадение производителя")
    is_2025_plus: bool = Field(..., description="Контракт 2025+")
    ai_score: float = Field(..., ge=0, le=1, description="AI оценка соответствия")
    accepted_for_nmc: bool = Field(..., description="Принят для НМЦК")
    selection_order: Optional[int] = Field(None, description="Порядок выбора (1-3)")
    
    model_config = ConfigDict(from_attributes=True)


class SearchResultListResponse(BaseModel):
    """Список результатов поиска."""
    results: List[SearchResultItem] = Field(..., description="Список результатов")
    total: int = Field(..., description="Общее количество результатов")
    
    model_config = ConfigDict(from_attributes=True)


class SearchSelectionUpdate(BaseModel):
    """Обновление выбора контрактов для НМЦК."""
    selected_reestr_numbers: List[str] = Field(
        ..., 
        description="Список реестровых номеров выбранных контрактов",
        min_items=1,
        max_items=3
    )


class SelectionPatchRequest(BaseModel):
    """Запрос на обновление выбора контрактов."""
    selected_contract_ids: List[str] = Field(
        ...,
        description="Список ID выбранных контрактов",
        min_items=1,
        max_items=3
    )


class SearchEvent(BaseModel):
    """Событие SSE для поиска."""
    id: str = Field(..., description="ID события")
    event: str = Field(..., description="Тип события")
    data: dict = Field(..., description="Данные события")