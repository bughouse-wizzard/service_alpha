from __future__ import annotations

from celery import Celery

from app.core.settings import settings

celery_app = Celery(
    "nmck",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.update(
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={"app.workers.tasks.*": {"queue": "nmck"}},
)