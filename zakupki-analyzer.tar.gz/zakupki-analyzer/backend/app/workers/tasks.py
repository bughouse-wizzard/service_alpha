from __future__ import annotations

import time
import uuid
from datetime import date
from decimal import Decimal

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import AppError, ErrorCode
from app.core.logging import log
from app.core.settings import settings
from app.infra.db.models import SearchRequest, SpecComparisonRow
from app.infra.db.repos import ResultRepo, SearchRepo
from app.infra.db.session import async_sessionmaker
from app.infra.events.event_broker import RedisEventBroker, StreamEvent
from app.services.ai.deepseek import DeepSeekClient
from app.services.docs.extractors import extract_text_from_pdf, extract_text_from_docx
from app.services.nmc_service import calc_nmc_avg
from app.services.zakupki.client import ZakupkiClient


def _now_ms() -> int:
    return int(time.time() * 1000)


async def _check_stop(db: AsyncSession, search_id: uuid.UUID) -> bool:
    obj = (await db.execute(sa.select(SearchRequest.stop_requested).where(SearchRequest.id == search_id))).scalar_one_or_none()
    return bool(obj)


async def _set_status(db: AsyncSession, search_id: uuid.UUID, status: str, *, error_code: str | None = None, error_message: str | None = None, runtime_ms: int | None = None) -> None:
    await db.execute(
        sa.update(SearchRequest)
        .where(SearchRequest.id == search_id)
        .values(status=status, error_code=error_code, error_message=error_message, runtime_ms=runtime_ms)
    )


async def _inc_processed(db: AsyncSession, search_id: uuid.UUID, inc: int = 1) -> int:
    await db.execute(
        sa.update(SearchRequest)
        .where(SearchRequest.id == search_id)
        .values(processed_count=SearchRequest.processed_count + inc)
    )
    res = await db.execute(sa.select(SearchRequest.processed_count).where(SearchRequest.id == search_id))
    return int(res.scalar_one())


async def _set_found_total(db: AsyncSession, search_id: uuid.UUID, found_total: int) -> None:
    await db.execute(sa.update(SearchRequest).where(SearchRequest.id == search_id).values(found_total=found_total))


async def _finalize(db: AsyncSession, search_id: uuid.UUID, repo: ResultRepo) -> None:
    # Используем SearchService для автовыбора top-3
    from app.services.search_service import SearchService
    from app.infra.events.event_broker import RedisEventBroker
    
    broker = RedisEventBroker(settings.redis_url)
    service = SearchService(db=db, broker=broker)
    
    selected_ids, nmc_value = await service.auto_select_top_3(search_id)
    
    logger = log().bind(service="worker", search_id=str(search_id))
    logger.info(
        "finalize_completed",
        selected_count=len(selected_ids),
        nmc_value=str(nmc_value) if nmc_value else None,
    )


# Celery task (sync wrapper) -> runs async pipeline
from app.workers.celery_app import celery_app


@celery_app.task(name="app.workers.tasks.run_search_pipeline")
def run_search_pipeline(search_id: str, request_id: str = "unknown") -> None:
    import asyncio
    asyncio.run(_run_search_pipeline_async(search_id, request_id=request_id))


async def _run_search_pipeline_async(search_id: str, *, request_id: str) -> None:
    started = _now_ms()
    broker = RedisEventBroker(settings.redis_url)
    sid = uuid.UUID(search_id)

    async with async_sessionmaker() as db:
        search_repo = SearchRepo()
        result_repo = ResultRepo()

        # Load search
        search = await search_repo.get(db, sid)
        if not search:
            return

        logger = log().bind(service="worker", search_id=search_id, request_id=request_id)

        try:
            logger.info("search_pipeline_started", step="ValidateInput")
            await broker.emit(search_id, StreamEvent("log", {"step": "ValidateInput", "msg": "OK"}))
            
            async with db.begin():
                await _set_status(db, sid, "RUNNING")

            if await _check_stop(db, sid):
                logger.warning("search_stopped_before_start", reason="stop_requested")
                raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before start")

            # FetchSearchResults
            zakupki = ZakupkiClient()
            try:
                # Проверяем stop перед сетевым действием
                if await _check_stop(db, sid):
                    logger.warning("search_stopped_before_fetch", reason="stop_requested")
                    raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before fetching results")
                
                # Подготавливаем параметры для поиска
                search_params = {
                    "ktru": search.ktru_code,
                    "region": search.customer_region,
                    "date_from": search.date_from.strftime("%d.%m.%Y") if search.date_from else "",
                    "date_to": search.date_to.strftime("%d.%m.%Y") if search.date_to else "",
                    "statuses": list(search.execution_statuses),
                    "fz44": True,
                    "limit": int(search.limit_contracts) if search.limit_contracts else settings.default_limit_contracts,
                }
                
                logger.info("fetching_search_results", params=search_params)
                
                # Получаем результаты поиска с ретраями
                max_retries = 3
                retry_delay = 2  # секунды
                html, url = None, None
                
                for attempt in range(max_retries):
                    try:
                        html, url = await zakupki.fetch_results_html(search_params)
                        break
                    except Exception as e:
                        if attempt == max_retries - 1:
                            logger.error("fetch_results_failed", attempt=attempt+1, error=str(e))
                            raise
                        logger.warning("fetch_results_retry", attempt=attempt+1, error=str(e), delay=retry_delay)
                        time.sleep(retry_delay)
                
                found_total, cards = zakupki.parse_results(html)
                
                logger.info("search_results_fetched", url=url, found_total=found_total, cards_count=len(cards))
                await broker.emit(search_id, StreamEvent("log", {
                    "step": "FetchSearchResults", 
                    "msg": f"URL: {url}, found_total: {found_total}, cards: {len(cards)}"
                }))
                
            finally:
                await zakupki.close()

            async with db.begin():
                await _set_found_total(db, sid, found_total)

            await broker.emit(search_id, StreamEvent("progress", {"step": "FetchSearchResults", "found_total": found_total}))
            await broker.emit(search_id, StreamEvent("log", {"step": "FetchSearchResults", "msg": f"found_total={found_total}"}))

            # IterateContracts (limit)
            limit = int(search.limit_contracts)
            cards = cards[:limit]
            logger.info("processing_contracts", limit=limit, cards_to_process=len(cards))

            ai = DeepSeekClient()

            try:
                # Нормализуем target_specs (из текста пользователя)
                target_text = (search.target_specs or {}).get("raw_text", "") or ""
                target_norm = None
                if target_text.strip() and settings.deepseek_api_key:
                    # Проверяем stop перед AI запросом
                    if await _check_stop(db, sid):
                        raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before target specs normalization")
                    
                    await broker.emit(search_id, StreamEvent("log", {"step": "NormalizeSpecs", "msg": "target"}))
                    target_norm = (await ai.normalize(target_text)).model_dump()
                    async with db.begin():
                        search.target_specs = {"raw_text": target_text, "normalized": target_norm}
                        await search_repo.update(db, search)

                for idx, card in enumerate(cards, start=1):
                    if await _check_stop(db, sid):
                        raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested during processing")

                    reestr = card.reestr_number
                    c_logger = logger.bind(reestr_number=reestr)
                    
                    try:
                        c_logger.info("processing_contract_started", contract_index=idx, total_contracts=len(cards))
                        await broker.emit(search_id, StreamEvent("log", {"step": "FetchContractCard", "reestr_number": reestr}))

                        # Получаем HTML карточки контракта и спецификации с ретраями
                        contract_html = None
                        for attempt in range(3):
                            try:
                                contract_html = await zakupki.fetch_contract_page(card.contract_url)
                                break
                            except Exception as e:
                                if attempt == 2:
                                    c_logger.error("fetch_contract_page_failed", attempt=attempt+1, error=str(e))
                                    raise
                                c_logger.warning("fetch_contract_page_retry", attempt=attempt+1, error=str(e))
                                time.sleep(1)
                        
                        common_data = zakupki.parse_contract_common(contract_html)
                        
                        items_html = None
                        for attempt in range(3):
                            try:
                                items_html = await zakupki.fetch_contract_items(card.reestr_number)
                                break
                            except Exception as e:
                                if attempt == 2:
                                    c_logger.error("fetch_contract_items_failed", attempt=attempt+1, error=str(e))
                                    raise
                                c_logger.warning("fetch_contract_items_retry", attempt=attempt+1, error=str(e))
                                time.sleep(1)
                        
                        spec_data = zakupki.parse_contract_items(items_html)
                        unit_price = spec_data.get("unit_price")
                        spec_text = spec_data.get("spec_text") or ""
                        
                        c_logger.info("contract_data_parsed", unit_price=unit_price, spec_text_length=len(spec_text))

                        # Определяем признак контракта 2025+
                        is_2025_plus = False
                        if card.sign_date:
                            try:
                                year = int(card.sign_date.split(".")[-1])
                                is_2025_plus = year >= 2025
                                c_logger.info("contract_year_determined", year=year, is_2025_plus=is_2025_plus)
                            except Exception as e:
                                c_logger.warning("failed_to_parse_year", error=str(e))
                                is_2025_plus = False

                        # Если контракт 2025+ — пытаемся получить печатную форму и извлечь текст
                        attachment_text = ""
                        if is_2025_plus:
                            try:
                                attachments_html = await zakupki.fetch_attachments(card.reestr_number)
                                file_url = zakupki.parse_attachments(attachments_html)
                                if file_url:
                                    c_logger.info("attachment_found", file_url=file_url)
                                    try:
                                        file_bytes = await zakupki.download_file(file_url)
                                        # Извлекаем текст из файла (PDF/DOCX)
                                        if file_url.lower().endswith(".pdf"):
                                            attachment_text = extract_text_from_pdf(file_bytes)
                                            c_logger.info("pdf_text_extracted", text_length=len(attachment_text))
                                        elif file_url.lower().endswith(".docx"):
                                            attachment_text = extract_text_from_docx(file_bytes)
                                            c_logger.info("docx_text_extracted", text_length=len(attachment_text))
                                    except Exception as e:
                                        c_logger.warning("attachment_processing_failed", error=str(e))
                            except Exception as e:
                                c_logger.warning("attachment_fetch_failed", error=str(e))
                        
                        # Если получили текст из печатной формы, используем его, иначе – текст спецификации из HTML
                        specs_raw = attachment_text or spec_text
                        if not specs_raw:
                            # Фолбэк: используем данные из карточки поиска, если спецификация пуста
                            card_info = f"Контракт {reestr}"
                            if card.sign_date:
                                card_info += f", дата: {card.sign_date}"
                            if card.price_total:
                                card_info += f", цена: {card.price_total}"
                            specs_raw = f"{card_info}. Характеристики: {search.object_name or ''}"
                            c_logger.warning("using_fallback_specs", fallback_reason="no_specs_found")
                        
                        c_logger.info("specs_prepared", source="attachment" if attachment_text else "html", length=len(specs_raw))
                        
                        found_norm = None
                        compare_res = None

                        if settings.deepseek_api_key:
                            # Проверяем stop перед AI запросами
                            if await _check_stop(db, sid):
                                raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before AI processing")
                            
                            try:
                                await broker.emit(search_id, StreamEvent("log", {"step": "NormalizeSpecs", "reestr_number": reestr}))
                                found_norm = (await ai.normalize(specs_raw)).model_dump()
                                c_logger.info("ai_normalization_completed", normalized_keys=list(found_norm.keys()) if found_norm else [])
                            except Exception as e:
                                c_logger.error("ai_normalization_failed", error=str(e))
                                # Продолжаем без нормализации

                            if target_norm and found_norm:
                                # Проверяем stop перед сравнением
                                if await _check_stop(db, sid):
                                    raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before AI comparison")
                                
                                try:
                                    await broker.emit(search_id, StreamEvent("log", {"step": "LLMCompareAndScore", "reestr_number": reestr}))
                                    compare_res = (await ai.compare(
                                        target_json=target_norm,
                                        found_json=found_norm,
                                        target_manufacturer=search.manufacturer_target,
                                    )).model_dump()
                                    c_logger.info("ai_comparison_completed", match_type=compare_res.get("match_type"), score=compare_res.get("score"))
                                except Exception as e:
                                    c_logger.error("ai_comparison_failed", error=str(e))
                                    # Продолжаем без сравнения

                        match_type = (compare_res or {}).get("match_type", "NO_MATCH")
                        ai_score = int((compare_res or {}).get("score", 0))
                        manufacturer_found = (compare_res or {}).get("manufacturer_found")
                        manufacturer_match = (compare_res or {}).get("manufacturer_match")

                        # PersistResult (UPSERT)
                        values = {
                            "id": uuid.uuid4(),
                            "search_id": sid,
                            "reestr_number": reestr,
                            "contract_url": card.contract_url,
                            "sign_date": None,
                            "unit_price": unit_price,
                            "currency": "RUB",
                            "match_type": match_type,
                            "ai_score": ai_score,
                            "manufacturer_found": manufacturer_found,
                            "manufacturer_match": manufacturer_match,
                            "is_2025_plus": is_2025_plus,
                            "accepted_for_nmc": False,
                            "specs_raw": specs_raw,
                            "raw_data_json": {
                                "search_card": {
                                    "reestr_number": card.reestr_number,
                                    "contract_url": card.contract_url,
                                    "sign_date": card.sign_date,
                                    "price_total": card.price_total
                                },
                                "parsed_data": {
                                    "is_2025_plus": is_2025_plus,
                                    "unit_price": str(unit_price) if unit_price else None
                                }
                            },
                            "ai_analysis": compare_res or {},
                            "error_code": None,
                            "error_message": None,
                        }

                        async with db.begin():
                            contract_id = await result_repo.upsert_contract_result(db, values=values)

                            # сравнение (rows)
                            rows_payload = (compare_res or {}).get("rows", [])
                            rows = [
                                SpecComparisonRow(
                                    contract_result_id=contract_id,
                                    name=r.get("name", ""),
                                    target_value=r.get("target"),
                                    actual_value=r.get("actual"),
                                    match_status=r.get("status", "UNKNOWN"),
                                    reason=r.get("reason"),
                                    weight=int(r.get("weight", 1) or 1),
                                )
                                for r in rows_payload
                                if r.get("name")
                            ]
                            if rows:
                                await result_repo.replace_comparison_rows(db, contract_id=contract_id, rows=rows)

                            processed = await _inc_processed(db, sid, 1)

                        # EmitProgressEvent + result_added
                        await broker.emit(search_id, StreamEvent("result_added", {
                            "id": str(contract_id),
                            "reestr_number": reestr,
                            "contract_url": card.contract_url,
                            "unit_price": str(unit_price) if unit_price is not None else None,
                            "match_type": match_type,
                            "ai_score": ai_score,
                            "manufacturer_found": manufacturer_found,
                            "manufacturer_match": manufacturer_match,
                            "is_2025_plus": is_2025_plus,
                        }))
                        await broker.emit(search_id, StreamEvent("progress", {"processed": processed, "limit": limit}))
                        
                        c_logger.info("contract_processing_completed", match_type=match_type, ai_score=ai_score, manufacturer_match=manufacturer_match)
                        
                    except Exception as e:
                        c_logger.error("contract_processing_failed", error=str(e), error_type=type(e).__name__)
                        # Увеличиваем счетчик обработанных даже при ошибке
                        try:
                            processed = await _inc_processed(db, sid, 1)
                            await broker.emit(search_id, StreamEvent("progress", {"processed": processed, "limit": limit}))
                        except Exception as inner_e:
                            logger.error("failed_to_update_progress", error=str(inner_e))
                        
                        # Продолжаем обработку следующих контрактов
                        continue

            finally:
                await ai.close()

            # FinalizeSearch (top-3 + NMC)
            async with db.begin():
                await _finalize(db, sid, result_repo)
                await _set_status(db, sid, "DONE", runtime_ms=_now_ms() - started)

            await broker.emit(search_id, StreamEvent("done", {"status": "DONE"}))

        except AppError as e:
            # STOP or ERROR
            status = "STOPPED" if e.code == ErrorCode.STOP_REQUESTED else "ERROR"
            async with db.begin():
                await _set_status(db, sid, status, error_code=e.code, error_message=str(e), runtime_ms=_now_ms() - started)
            await broker.emit(search_id, StreamEvent("error" if status == "ERROR" else "done", {"status": status, "error_code": e.code, "message": str(e)}))
            logger.warning("pipeline_finished_with_app_error", status=status, error_code=e.code, msg=str(e))
        except Exception as e:
            async with db.begin():
                await _set_status(db, sid, "ERROR", error_code=ErrorCode.UNKNOWN_ERROR, error_message=str(e), runtime_ms=_now_ms() - started)
            await broker.emit(search_id, StreamEvent("error", {"status": "ERROR", "error_code": ErrorCode.UNKNOWN_ERROR, "message": str(e)}))
            logger.exception("pipeline_crashed", msg=str(e))