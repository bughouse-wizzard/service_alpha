from datetime import datetime
from typing import Optional, List
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from fastapi.responses import StreamingResponse

from app.api.exceptions import ApiException
from app.schemas.search import (
    SearchCreateRequest,
    SearchBrief,
    SearchDetailsResponse,
    SearchResultItem,
    SearchSelectionUpdate,
    ApiError,
)
from app.services.search import SearchService

router = APIRouter(prefix="/api/search", tags=["search"])


@router.post(
    "/",
    response_model=SearchBrief,
    status_code=status.HTTP_201_CREATED,
    responses={
        400: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def create_search(
    request: SearchCreateRequest,
    service: SearchService = Depends(),
) -> SearchBrief:
    """
    Создать новый поиск контрактов.
    """
    try:
        search = await service.create_search(request)
        return search
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_400_BAD_REQUEST,
            error_code="VALIDATION_ERROR",
            message=str(e),
            details={"field": "request"},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Internal server error",
            details={"error": str(e)},
        )


@router.post(
    "/{search_id}/stop",
    response_model=SearchBrief,
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def stop_search(
    search_id: UUID,
    service: SearchService = Depends(),
) -> SearchBrief:
    """
    Остановить выполнение поиска.
    """
    try:
        search = await service.stop_search(search_id)
        return search
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to stop search",
            details={"error": str(e)},
        )


@router.get(
    "/",
    response_model=List[SearchBrief],
    responses={
        500: {"model": ApiError},
    },
)
async def list_searches(
    ktru: Optional[str] = Query(None, description="Фильтр по КТРУ"),
    status: Optional[str] = Query(None, description="Фильтр по статусу"),
    date_from: Optional[datetime] = Query(None, description="Дата создания от"),
    date_to: Optional[datetime] = Query(None, description="Дата создания до"),
    service: SearchService = Depends(),
) -> List[SearchBrief]:
    """
    Получить список поисков с фильтрацией.
    """
    try:
        searches = await service.list_searches(
            ktru=ktru,
            status=status,
            date_from=date_from,
            date_to=date_to,
        )
        return searches
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to list searches",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}",
    response_model=SearchDetailsResponse,
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def get_search(
    search_id: UUID,
    service: SearchService = Depends(),
) -> SearchDetailsResponse:
    """
    Получить детальную информацию о поиске.
    """
    try:
        search = await service.get_search(search_id)
        return search
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to get search",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}/results",
    response_model=List[SearchResultItem],
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def get_search_results(
    search_id: UUID,
    accepted_for_nmc: Optional[bool] = Query(None, description="Принят для НМЦК"),
    is_2025_plus: Optional[bool] = Query(None, description="Контракт 2025+"),
    manufacturer_match: Optional[bool] = Query(None, description="Совпадение производителя"),
    service: SearchService = Depends(),
) -> List[SearchResultItem]:
    """
    Получить результаты поиска с фильтрацией.
    """
    try:
        results = await service.get_search_results(
            search_id=search_id,
            accepted_for_nmc=accepted_for_nmc,
            is_2025_plus=is_2025_plus,
            manufacturer_match=manufacturer_match,
        )
        return results
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to get search results",
            details={"error": str(e)},
        )


@router.patch(
    "/{search_id}/selection",
    response_model=List[SearchResultItem],
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def update_selection(
    search_id: UUID,
    selection: SearchSelectionUpdate,
    service: SearchService = Depends(),
) -> List[SearchResultItem]:
    """
    Обновить выбор контрактов для НМЦК.
    """
    try:
        results = await service.update_selection(search_id, selection)
        return results
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to update selection",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}/events",
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def stream_search_events(
    search_id: UUID,
    last_event_id: Optional[str] = Query("$", description="ID последнего полученного события"),
    service: SearchService = Depends(),
) -> StreamingResponse:
    """
    Поток событий SSE для отслеживания прогресса поиска.
    """
    try:
        event_stream = await service.stream_search_events(search_id, last_event_id)
        return StreamingResponse(
            event_stream,
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to stream events",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}/report",
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def download_report(
    search_id: UUID,
    service: SearchService = Depends(),
):
    """
    Скачать отчёт по поиску (ZIP с XLSX и JSON).
    """
    try:
        report_data = await service.generate_report(search_id)
        return report_data
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to generate report",
            details={"error": str(e)},
        )