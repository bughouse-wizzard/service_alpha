from fastapi import HTTPException, status
from fastapi.responses import JSONResponse
from fastapi.requests import Request
from fastapi.exceptions import RequestValidationError
from typing import Union

from app.schemas.search import ApiError


class ApiException(HTTPException):
    """Базовое исключение API с единым форматом ошибок."""
    
    def __init__(
        self,
        status_code: int,
        error_code: str,
        message: str,
        details: dict = None
    ):
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        
        super().__init__(
            status_code=status_code,
            detail={
                "error_code": error_code,
                "message": message,
                "details": details or {}
            }
        )


async def api_exception_handler(request: Request, exc: ApiException) -> JSONResponse:
    """Обработчик для ApiException."""
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.detail
    )


async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Обработчик для HTTPException с преобразованием в единый формат."""
    if isinstance(exc.detail, dict) and "error_code" in exc.detail:
        # Уже в правильном формате
        detail = exc.detail
    else:
        # Преобразуем в единый формат
        detail = {
            "error_code": "HTTP_ERROR",
            "message": str(exc.detail) if exc.detail else "HTTP error occurred",
            "details": {}
        }
    
    return JSONResponse(
        status_code=exc.status_code,
        content=detail
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Обработчик для ошибок валидации Pydantic."""
    errors = []
    for error in exc.errors():
        errors.append({
            "loc": error["loc"],
            "msg": error["msg"],
            "type": error["type"]
        })
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "error_code": "VALIDATION_ERROR",
            "message": "Validation error",
            "details": {"errors": errors}
        }
    )


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Обработчик для всех остальных исключений."""
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error_code": "INTERNAL_ERROR",
            "message": "Internal server error",
            "details": {"error": str(exc)}
        }
    )