from __future__ import annotations

from fastapi import APIRouter

from app.core.settings import settings

router = APIRouter()


@router.get("/health", summary="Healthcheck")
async def health() -> dict:
    return {"status": "ok"}


@router.get("/version", summary="Build/version info")
async def version() -> dict:
    return {"name": settings.app_name, "version": settings.app_version, "env": settings.env}