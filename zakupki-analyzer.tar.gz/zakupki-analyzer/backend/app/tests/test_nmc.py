from __future__ import annotations

from decimal import Decimal

from app.services.nmc_service import calc_nmc_avg, calc_nmc_avg_safe


def test_calc_nmc_avg_empty():
    assert calc_nmc_avg([]) is None
    assert calc_nmc_avg([None]) is None
    assert calc_nmc_avg([None, None]) is None


def test_calc_nmc_avg_single():
    assert calc_nmc_avg([Decimal("100.00")]) == Decimal("100.00")
    assert calc_nmc_avg([Decimal("123.456")]) == Decimal("123.46")  # rounding


def test_calc_nmc_avg_multiple():
    # 100 + 200 + 300 = 600 / 3 = 200
    assert calc_nmc_avg([Decimal("100.00"), Decimal("200.00"), Decimal("300.00")]) == Decimal("200.00")
    # 100.555 + 200.444 = 301.0 / 2 = 150.5
    assert calc_nmc_avg([Decimal("100.555"), Decimal("200.444")]) == Decimal("150.50")


def test_calc_nmc_avg_rounding():
    # 100.005 + 100.005 = 200.01 / 2 = 100.005 -> 100.01 (round half up)
    assert calc_nmc_avg([Decimal("100.005"), Decimal("100.005")]) == Decimal("100.01")
    # 100.004 + 100.004 = 200.008 / 2 = 100.004 -> 100.00 (round half up)
    assert calc_nmc_avg([Decimal("100.004"), Decimal("100.004")]) == Decimal("100.00")


def test_calc_nmc_avg_mixed_types():
    # Тестирование разных типов данных
    assert calc_nmc_avg([100, 200, 300]) == Decimal("200.00")
    assert calc_nmc_avg([100.50, 200.75]) == Decimal("150.63")
    assert calc_nmc_avg(["100.50", "200.75"]) == Decimal("150.63")
    assert calc_nmc_avg(["100,50", "200,75"]) == Decimal("150.63")  # запятые вместо точек
    assert calc_nmc_avg(["100.50 руб", "200.75 руб"]) == Decimal("150.63")  # с валютой
    assert calc_nmc_avg([Decimal("100.50"), 200.75, "300.00"]) == Decimal("200.42")


def test_calc_nmc_avg_with_none():
    # Игнорирование None значений
    assert calc_nmc_avg([Decimal("100.00"), None, Decimal("200.00")]) == Decimal("150.00")
    assert calc_nmc_avg([None, Decimal("300.00"), None]) == Decimal("300.00")


def test_calc_nmc_avg_safe():
    # Безопасная версия должна работать даже с некорректными данными
    assert calc_nmc_avg_safe([100, 200, 300]) == Decimal("200.00")
    assert calc_nmc_avg_safe(["invalid", "data"]) is None
    assert calc_nmc_avg_safe([]) is None
    assert calc_nmc_avg_safe([None, None]) is None


def test_calc_nmc_avg_edge_cases():
    # Крайние случаи
    assert calc_nmc_avg([Decimal("0.00")]) == Decimal("0.00")
    assert calc_nmc_avg([Decimal("-100.00"), Decimal("100.00")]) == Decimal("0.00")
    assert calc_nmc_avg([Decimal("999999.99"), Decimal("0.01")]) == Decimal("500000.00")