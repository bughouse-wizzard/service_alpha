"""
Комплексные тесты для API эндпоинтов.
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock
from fastapi.testclient import TestClient
from datetime import datetime, date
from uuid import uuid4
import json

from app.main import app
from app.infra.db.enums import SearchStatus
from app.schemas.search import SearchCreateRequest, SearchBrief, SearchDetailsResponse


class TestSearchAPIComprehensive:
    """Комплексные тесты API поиска."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.client = TestClient(app)
        self.search_id = uuid4()
        self.mock_search_data = {
            "id": str(self.search_id),
            "ktru": "31.20.11.110",
            "manufacturer": "Производитель",
            "region": "Москва",
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
            "contract_limit": 100,
            "characteristics": "Характеристики"
        }
    
    def test_create_search_success(self):
        """Тест успешного создания поиска."""
        with patch('app.api.search.SearchService.create_search') as mock_create:
            mock_create.return_value = SearchBrief(
                id=self.search_id,
                ktru="31.20.11.110",
                status=SearchStatus.PENDING,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                contracts_found=0,
                contracts_processed=0
            )
            
            response = self.client.post("/api/search", json=self.mock_search_data)
            
            assert response.status_code == 201
            data = response.json()
            assert data["id"] == str(self.search_id)
            assert data["ktru"] == "31.20.11.110"
            assert data["status"] == SearchStatus.PENDING
            mock_create.assert_called_once()
    
    def test_create_search_validation_error(self):
        """Тест ошибки валидации при создании поиска."""
        invalid_data = self.mock_search_data.copy()
        invalid_data["ktru"] = ""  # Пустой КТРУ
        
        response = self.client.post("/api/search", json=invalid_data)
        
        assert response.status_code == 400
        data = response.json()
        assert "error_code" in data
        assert "message" in data
    
    def test_list_searches_success(self):
        """Тест успешного получения списка поисков."""
        with patch('app.api.search.SearchService.list_searches') as mock_list:
            mock_list.return_value = [
                SearchBrief(
                    id=self.search_id,
                    ktru="31.20.11.110",
                    status=SearchStatus.COMPLETED,
                    created_at=datetime.now(),
                    updated_at=datetime.now(),
                    contracts_found=10,
                    contracts_processed=10
                )
            ]
            
            response = self.client.get("/api/search")
            
            assert response.status_code == 200
            data = response.json()
            assert isinstance(data, list)
            assert len(data) == 1
            assert data[0]["id"] == str(self.search_id)
            mock_list.assert_called_once()
    
    def test_list_searches_empty(self):
        """Тест получения пустого списка поисков."""
        with patch('app.api.search.SearchService.list_searches') as mock_list:
            mock_list.return_value = []
            
            response = self.client.get("/api/search")
            
            assert response.status_code == 200
            data = response.json()
            assert data == []
    
    def test_get_search_success(self):
        """Тест успешного получения деталей поиска."""
        with patch('app.api.search.SearchService.get_search') as mock_get:
            mock_get.return_value = SearchDetailsResponse(
                id=self.search_id,
                ktru="31.20.11.110",
                status=SearchStatus.COMPLETED,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                contracts_found=10,
                contracts_processed=10,
                results=[],
                nmc_value=None,
                selected_contract_ids=[]
            )
            
            response = self.client.get(f"/api/search/{self.search_id}")
            
            assert response.status_code == 200
            data = response.json()
            assert data["id"] == str(self.search_id)
            assert data["status"] == SearchStatus.COMPLETED
            mock_get.assert_called_once_with(str(self.search_id))
    
    def test_get_search_not_found(self):
        """Тест получения несуществующего поиска."""
        with patch('app.api.search.SearchService.get_search') as mock_get:
            mock_get.return_value = None
            
            response = self.client.get(f"/api/search/{uuid4()}")
            
            assert response.status_code == 404
            data = response.json()
            assert "error_code" in data
            assert "NOT_FOUND" in data["error_code"]
    
    def test_stop_search_success(self):
        """Тест успешной остановки поиска."""
        with patch('app.api.search.SearchService.stop_search') as mock_stop:
            mock_stop.return_value = SearchBrief(
                id=self.search_id,
                ktru="31.20.11.110",
                status=SearchStatus.STOPPED,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                contracts_found=5,
                contracts_processed=5
            )
            
            response = self.client.post(f"/api/search/{self.search_id}/stop")
            
            assert response.status_code == 200
            data = response.json()
            assert data["status"] == SearchStatus.STOPPED
            mock_stop.assert_called_once_with(str(self.search_id))
    
    def test_stop_search_not_found(self):
        """Тест остановки несуществующего поиска."""
        with patch('app.api.search.SearchService.stop_search') as mock_stop:
            mock_stop.return_value = None
            
            response = self.client.post(f"/api/search/{uuid4()}/stop")
            
            assert response.status_code == 404
    
    def test_get_search_results_success(self):
        """Тест успешного получения результатов поиска."""
        with patch('app.api.search.SearchService.get_search_results') as mock_results:
            mock_results.return_value = {
                "results": [],
                "total": 0,
                "page": 1,
                "per_page": 20,
                "total_pages": 0
            }
            
            response = self.client.get(f"/api/search/{self.search_id}/results")
            
            assert response.status_code == 200
            data = response.json()
            assert "results" in data
            assert "total" in data
            mock_results.assert_called_once_with(str(self.search_id), page=1, per_page=20)
    
    def test_get_search_results_with_pagination(self):
        """Тест получения результатов с пагинацией."""
        with patch('app.api.search.SearchService.get_search_results') as mock_results:
            mock_results.return_value = {
                "results": [],
                "total": 0,
                "page": 2,
                "per_page": 10,
                "total_pages": 0
            }
            
            response = self.client.get(f"/api/search/{self.search_id}/results?page=2&per_page=10")
            
            assert response.status_code == 200
            mock_results.assert_called_once_with(str(self.search_id), page=2, per_page=10)
    
    def test_update_selection_success(self):
        """Тест успешного обновления выбора контрактов."""
        with patch('app.api.search.SearchService.update_selection') as mock_update:
            mock_update.return_value = SearchDetailsResponse(
                id=self.search_id,
                ktru="31.20.11.110",
                status=SearchStatus.COMPLETED,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                contracts_found=10,
                contracts_processed=10,
                results=[],
                nmc_value=150.50,
                selected_contract_ids=["contract1", "contract2", "contract3"]
            )
            
            selection_data = {
                "selected_contract_ids": ["contract1", "contract2", "contract3"]
            }
            
            response = self.client.patch(f"/api/search/{self.search_id}/selection", json=selection_data)
            
            assert response.status_code == 200
            data = response.json()
            assert data["nmc_value"] == 150.50
            assert len(data["selected_contract_ids"]) == 3
            mock_update.assert_called_once_with(str(self.search_id), selection_data["selected_contract_ids"])
    
    def test_update_selection_invalid_count(self):
        """Тест обновления выбора с неверным количеством контрактов."""
        selection_data = {
            "selected_contract_ids": ["contract1"]  # Должно быть 1-3 контракта
        }
        
        response = self.client.patch(f"/api/search/{self.search_id}/selection", json=selection_data)
        
        assert response.status_code == 200  # Или 400 в зависимости от валидации
    
    def test_system_endpoints(self):
        """Тест системных эндпоинтов."""
        # Health check
        response = self.client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data == {"status": "ok"}
        
        # Readiness check
        response = self.client.get("/ready")
        assert response.status_code == 200
        data = response.json()
        assert data == {"status": "ready"}
        
        # Version
        response = self.client.get("/version")
        assert response.status_code == 200
        data = response.json()
        assert "version" in data
        assert "build_date" in data
    
    def test_api_documentation(self):
        """Тест доступности документации API."""
        response = self.client.get("/docs")
        assert response.status_code == 200
        
        response = self.client.get("/redoc")
        assert response.status_code == 200
        
        response = self.client.get("/openapi.json")
        assert response.status_code == 200
        data = response.json()
        assert "openapi" in data
        assert "info" in data
        assert "paths" in data


class TestSSEEndpoints:
    """Тесты SSE эндпоинтов."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.client = TestClient(app)
        self.search_id = uuid4()
    
    def test_sse_events_endpoint(self):
        """Тест эндпоинта SSE событий."""
        # SSE эндпоинт возвращает поток событий
        # В тестах мы просто проверяем, что эндпоинт существует
        response = self.client.get(f"/api/search/{self.search_id}/events")
        
        # SSE обычно возвращает 200 с content-type text/event-stream
        # FastAPI TestClient может не поддерживать SSE полностью
        assert response.status_code in [200, 404]  # Зависит от реализации


class TestAPIErrorHandling:
    """Тесты обработки ошибок API."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.client = TestClient(app)
    
    def test_not_found_error(self):
        """Тест ошибки 404 для несуществующего пути."""
        response = self.client.get("/api/nonexistent")
        assert response.status_code == 404
    
    def test_method_not_allowed(self):
        """Тест ошибки 405 для недопустимого метода."""
        response = self.client.put("/health")
        assert response.status_code == 405
    
    def test_internal_server_error(self):
        """Тест обработки внутренней ошибки сервера."""
        with patch('app.api.system.health_check', side_effect=Exception("Test error")):
            response = self.client.get("/health")
            assert response.status_code == 500
            data = response.json()
            assert "error_code" in data
            assert "INTERNAL_ERROR" in data["error_code"]
