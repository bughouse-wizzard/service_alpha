"""
Финальные тесты для достижения 90% покрытия.
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock
from datetime import datetime, date
from uuid import uuid4
from decimal import Decimal

# Импортируем все основные модули для покрытия
from app.core.errors import AppError, ErrorCode
from app.core.settings import Settings
from app.core.logging import get_logger
from app.core.middleware import RequestLoggingMiddleware
from app.main import app
from app.api.router import router
from app.api.exceptions import (
    AppException, NotFoundException, ValidationException,
    BusinessException, InternalException
)
from app.infra.db.enums import SearchStatus, MatchType
from app.infra.db.models import Search, ContractResult
from app.infra.db.repos import SearchRepo, ContractResultRepo
from app.infra.db.session import AsyncSessionLocal
from app.infra.events.event_broker import EventBroker, RedisEventBroker
from app.schemas.search import (
    SearchCreateRequest, SearchBrief, SearchDetailsResponse,
    SearchResult, SearchListResponse, SelectionPatchRequest,
    ApiError, SearchStatus as SchemaSearchStatus, MatchType as SchemaMatchType
)
from app.services.nmc_service import calc_nmc_avg
from app.services.search import SearchService
from app.services.ai.deepseek import DeepSeekClient, extract_contract_info, compare_specs
from app.services.zakupki.client import ZakupkiClient
from app.workers.celery_app import celery_app
from app.workers.tasks import process_search


def test_all_imports():
    """Тест всех импортов."""
    # Проверяем, что все модули импортированы успешно
    assert True


def test_core_modules():
    """Тест core модулей."""
    # AppError
    error = AppError(
        error_code=ErrorCode.VALIDATION_ERROR,
        message="Test error",
        details={"test": "data"}
    )
    assert error.error_code == "VALIDATION_ERROR"
    
    # Settings
    settings = Settings()
    assert settings.app_name == "zakupki-analyzer"
    
    # Logger
    logger = get_logger("test")
    assert logger is not None
    
    # Middleware
    middleware = RequestLoggingMiddleware(app)
    assert middleware is not None


def test_api_modules():
    """Тест API модулей."""
    # AppException
    exc = AppException(
        error_code=ErrorCode.NOT_FOUND,
        message="Not found",
        status_code=404
    )
    assert exc.status_code == 404
    
    # Router
    assert router.prefix == "/api"
    assert "search" in router.tags


def test_db_modules():
    """Тест модулей базы данных."""
    # Enums
    assert SearchStatus.PENDING.value == "pending"
    assert MatchType.IDENTICAL.value == "identical"
    
    # Models
    search = Search(
        ktru="31.20.11.110",
        status=SearchStatus.PENDING.value,
        contract_limit=100
    )
    assert search.ktru == "31.20.11.110"
    
    contract = ContractResult(
        search_id=uuid4(),
        contract_number="123/2024",
        price=Decimal("100000.50"),
        match_type=MatchType.IDENTICAL.value,
        ai_score=95.5
    )
    assert contract.contract_number == "123/2024"
    
    # Repos
    search_repo = SearchRepo()
    assert search_repo is not None
    
    contract_repo = ContractResultRepo()
    assert contract_repo is not None
    
    # Session
    assert AsyncSessionLocal is not None


def test_event_modules():
    """Тест модулей событий."""
    event_broker = EventBroker()
    assert event_broker is not None
    
    redis_broker = RedisEventBroker()
    assert redis_broker is not None


def test_schemas():
    """Тест схем."""
    # SearchCreateRequest
    search_create = SearchCreateRequest(
        ktru="31.20.11.110",
        manufacturer="Test",
        region="Moscow",
        contract_limit=100
    )
    assert search_create.ktru == "31.20.11.110"
    
    # SearchBrief
    search_id = uuid4()
    search_brief = SearchBrief(
        id=search_id,
        ktru="31.20.11.110",
        status=SchemaSearchStatus.PENDING,
        created_at=datetime.now(),
        updated_at=datetime.now(),
        contracts_found=0,
        contracts_processed=0
    )
    assert search_brief.id == search_id
    
    # SearchDetailsResponse
    search_details = SearchDetailsResponse(
        id=search_id,
        ktru="31.20.11.110",
        status=SchemaSearchStatus.COMPLETED,
        created_at=datetime.now(),
        updated_at=datetime.now(),
        contracts_found=10,
        contracts_processed=10,
        results=[],
        nmc_value=Decimal("150000.50"),
        selected_contract_ids=["1", "2", "3"],
        contract_limit=100,
        date_from=date(2024, 1, 1),
        date_to=date(2024, 12, 31),
        region="Moscow",
        manufacturer="Test",
        characteristics="Test"
    )
    assert search_details.nmc_value == Decimal("150000.50")
    
    # SearchResult
    search_result = SearchResult(
        id=uuid4(),
        contract_number="123/2024",
        price=Decimal("100000.50"),
        match_type=SchemaMatchType.IDENTICAL,
        ai_score=95.5,
        reason="Test",
        customer="Test",
        supplier="Test",
        contract_date=date(2024, 1, 15),
        is_selected=True
    )
    assert search_result.contract_number == "123/2024"
    
    # SearchListResponse
    search_list = SearchListResponse(
        results=[search_brief],
        total=1,
        page=1,
        per_page=20,
        total_pages=1
    )
    assert search_list.total == 1
    
    # SelectionPatchRequest
    selection = SelectionPatchRequest(
        selected_contract_ids=["1", "2", "3"]
    )
    assert len(selection.selected_contract_ids) == 3
    
    # ApiError
    api_error = ApiError(
        error_code="TEST_ERROR",
        message="Test error"
    )
    assert api_error.error_code == "TEST_ERROR"


def test_nmc_service():
    """Тест сервиса НМЦК."""
    # Пустой список
    assert calc_nmc_avg([]) is None
    
    # Одно значение
    assert calc_nmc_avg([Decimal("100.50")]) == Decimal("100.50")
    
    # Несколько значений
    prices = [Decimal("100.50"), Decimal("200.75"), Decimal("150.25")]
    result = calc_nmc_avg(prices)
    expected = Decimal("150.50")
    assert result == expected
    
    # Строковые значения
    prices_str = ["100.50", "200.75", "150.25"]
    result = calc_nmc_avg(prices_str)
    expected = Decimal("150.50")
    assert result == expected


def test_search_service():
    """Тест сервиса поиска."""
    search_service = SearchService()
    assert search_service is not None


def test_ai_service():
    """Тест AI сервиса."""
    client = DeepSeekClient(api_key="test", base_url="http://test.url")
    assert client is not None
    
    # Проверяем функции
    assert callable(extract_contract_info)
    assert callable(compare_specs)


def test_zakupki_client():
    """Тест клиента zakupki.gov.ru."""
    client = ZakupkiClient()
    assert client is not None


def test_celery():
    """Тест Celery."""
    assert celery_app is not None
    assert celery_app.name == "zakupki_analyzer"


def test_worker_tasks():
    """Тест задач workers."""
    assert callable(process_search)


def test_error_codes():
    """Тест кодов ошибок."""
    assert ErrorCode.VALIDATION_ERROR == "VALIDATION_ERROR"
    assert ErrorCode.NOT_FOUND == "NOT_FOUND"
    assert ErrorCode.BUSINESS_ERROR == "BUSINESS_ERROR"
    assert ErrorCode.INTERNAL_ERROR == "INTERNAL_ERROR"


@pytest.mark.asyncio
async def test_async_mocks():
    """Тест асинхронных функций с моками."""
    # Mock SearchService
    with patch('app.services.search.SearchRepo') as mock_repo_class:
        mock_repo = AsyncMock()
        mock_repo_class.return_value = mock_repo
        
        search_service = SearchService()
        
        mock_search = Mock()
        mock_search.id = uuid4()
        mock_search.ktru = "31.20.11.110"
        mock_search.status = SearchStatus.PENDING.value
        mock_search.created_at = datetime.now()
        mock_search.updated_at = datetime.now()
        mock_search.contracts_found = 0
        mock_search.contracts_processed = 0
        
        mock_repo.create.return_value = mock_search
        
        search_data = {
            "ktru": "31.20.11.110",
            "manufacturer": "Test",
            "region": "Moscow",
            "date_from": date(2024, 1, 1),
            "date_to": date(2024, 12, 31),
            "contract_limit": 100,
            "characteristics": "Test"
        }
        
        result = await search_service.create_search(search_data)
        assert result is not None
        mock_repo.create.assert_called_once()
