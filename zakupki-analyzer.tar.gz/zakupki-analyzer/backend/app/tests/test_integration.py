"""
Интеграционные тесты для MVP системы анализа госзакупок.
Тестирует полный цикл: создание поиска → SSE прогресс → получение результатов.
"""
import pytest
import asyncio
from httpx import AsyncClient
from fastapi import FastAPI
import json
import time

from app.main import app
from app.infra.db.session import AsyncSessionLocal
from app.infra.db.models import Base, SearchRequest, ContractResult
from sqlalchemy import select


@pytest.fixture
async def test_app():
    """Фикстура для тестового приложения."""
    return app


@pytest.fixture
async def async_client(test_app: FastAPI):
    """Фикстура для асинхронного HTTP клиента."""
    async with AsyncClient(app=test_app, base_url="http://test") as client:
        yield client


@pytest.fixture(autouse=True)
async def setup_database():
    """Фикстура для настройки базы данных перед каждым тестом."""
    async with AsyncSessionLocal() as session:
        # Очищаем таблицы перед тестом
        await session.execute("TRUNCATE TABLE contract_result CASCADE")
        await session.execute("TRUNCATE TABLE search_request CASCADE")
        await session.commit()


class TestIntegrationSearchWorkflow:
    """Тесты полного рабочего процесса поиска."""
    
    async def test_create_search_and_get_progress(self, async_client: AsyncClient):
        """Тест создания поиска и получения прогресса через SSE."""
        # 1. Создаем поиск
        search_data = {
            "object_name": "Бумага офисная",
            "ktru_code": "22.11.11.110",
            "customer_region": "СЗФО",
            "date_from": "2023-01-01",
            "date_to": "2026-01-23",
            "limit_contracts": 5,
            "execution_statuses": ["Исполнение завершено"],
            "law": "44"
        }
        
        response = await async_client.post("/api/search", json=search_data)
        assert response.status_code == 201
        search_response = response.json()
        search_id = search_response["id"]
        assert search_id is not None
        
        # 2. Проверяем, что поиск появился в списке
        response = await async_client.get("/api/search")
        assert response.status_code == 200
        searches = response.json()["items"]
        assert len(searches) == 1
        assert searches[0]["id"] == search_id
        assert searches[0]["status"] == "RUNNING"
        
        # 3. Подключаемся к SSE потоку (имитируем подключение)
        # В реальном тесте мы бы использовали библиотеку для SSE,
        # но для интеграционного теста проверим, что эндпоинт существует
        response = await async_client.get(f"/api/search/{search_id}/events")
        # SSE endpoint должен возвращать 200 и правильные заголовки
        assert response.status_code == 200
        assert "text/event-stream" in response.headers.get("content-type", "")
        
        # 4. Проверяем, что можем получить детали поиска
        response = await async_client.get(f"/api/search/{search_id}")
        assert response.status_code == 200
        search_details = response.json()
        assert search_details["id"] == search_id
        assert search_details["status"] in ["RUNNING", "DONE", "STOPPED"]
        
        # 5. Проверяем, что можем получить результаты (даже если пустые)
        response = await async_client.get(f"/api/search/{search_id}/results")
        assert response.status_code == 200
        results = response.json()
        assert "items" in results
        assert "total" in results
        
        print(f"✅ Интеграционный тест пройден: создан поиск {search_id}")
    
    async def test_search_stop_functionality(self, async_client: AsyncClient):
        """Тест функциональности остановки поиска."""
        # 1. Создаем поиск
        search_data = {
            "object_name": "Принтер лазерный",
            "ktru_code": "30.23.14.110",
            "customer_region": "СЗФО",
            "date_from": "2023-01-01",
            "date_to": "2026-01-23",
            "limit_contracts": 3,
            "execution_statuses": ["Исполнение завершено"],
            "law": "44"
        }
        
        response = await async_client.post("/api/search", json=search_data)
        assert response.status_code == 201
        search_id = response.json()["id"]
        
        # 2. Останавливаем поиск
        response = await async_client.post(f"/api/search/{search_id}/stop")
        assert response.status_code == 200
        
        # 3. Проверяем, что статус изменился
        response = await async_client.get(f"/api/search/{search_id}")
        assert response.status_code == 200
        search_details = response.json()
        assert search_details["status"] == "STOPPED"
        
        print(f"✅ Тест остановки пройден: поиск {search_id} остановлен")
    
    async def test_search_pagination_and_filters(self, async_client: AsyncClient):
        """Тест пагинации и фильтров в истории поисков."""
        # Создаем несколько поисков
        search_templates = [
            {
                "object_name": f"Тестовый объект {i}",
                "ktru_code": f"22.11.11.{100 + i}",
                "customer_region": "СЗФО",
                "date_from": "2023-01-01",
                "date_to": "2026-01-23",
                "limit_contracts": 2,
                "execution_statuses": ["Исполнение завершено"],
                "law": "44"
            }
            for i in range(5)
        ]
        
        search_ids = []
        for data in search_templates:
            response = await async_client.post("/api/search", json=data)
            assert response.status_code == 201
            search_ids.append(response.json()["id"])
        
        # Тестируем пагинацию
        response = await async_client.get("/api/search", params={"page": 1, "size": 2})
        assert response.status_code == 200
        result = response.json()
        assert "items" in result
        assert "total" in result
        assert "page" in result
        assert "size" in result
        assert "pages" in result
        
        items = result["items"]
        assert len(items) <= 2  # Проверяем размер страницы
        
        # Тестируем фильтрацию по статусу
        response = await async_client.get("/api/search", params={"status": "RUNNING"})
        assert response.status_code == 200
        result = response.json()
        # Все созданные поиски должны быть в статусе RUNNING
        assert result["total"] >= 5
        
        print("✅ Тест пагинации и фильтров пройден")


class TestDatabaseMigrations:
    """Тесты миграций базы данных."""
    
    async def test_tables_exist_after_migrations(self):
        """Тест проверяет, что таблицы существуют после применения миграций."""
        async with AsyncSessionLocal() as session:
            # Проверяем существование основных таблиц
            tables_to_check = ["search_request", "contract_result", "spec_comparison_row"]
            
            for table_name in tables_to_check:
                # Проверяем через information_schema
                result = await session.execute(
                    f"""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = 'public' 
                        AND table_name = '{table_name}'
                    )
                    """
                )
                exists = result.scalar()
                assert exists, f"Таблица {table_name} должна существовать после миграций"
            
            print("✅ Тест существования таблиц после миграций пройден")
    
    async def test_search_request_model_crud(self):
        """Тест базовых CRUD операций для модели SearchRequest."""
        async with AsyncSessionLocal() as session:
            # Создаем тестовый поиск
            search = SearchRequest(
                id="test-search-123",
                status="RUNNING",
                ktru="22.11.11.110",
                object_name="Бумага офисная",
                found_total=10,
                processed_count=0
            )
            
            # Сохраняем
            session.add(search)
            await session.commit()
            
            # Читаем
            result = await session.execute(
                select(SearchRequest).where(SearchRequest.id == "test-search-123")
            )
            fetched = result.scalar_one()
            
            # Проверяем
            assert fetched.id == "test-search-123"
            assert fetched.status == "RUNNING"
            assert fetched.ktru == "22.11.11.110"
            
            # Обновляем
            fetched.status = "DONE"
            fetched.processed_count = 5
            await session.commit()
            
            # Проверяем обновление
            result = await session.execute(
                select(SearchRequest).where(SearchRequest.id == "test-search-123")
            )
            updated = result.scalar_one()
            assert updated.status == "DONE"
            assert updated.processed_count == 5
            
            # Удаляем
            await session.delete(updated)
            await session.commit()
            
            # Проверяем удаление
            result = await session.execute(
                select(SearchRequest).where(SearchRequest.id == "test-search-123")
            )
            assert result.scalar_one_or_none() is None
            
            print("✅ Тест CRUD операций для SearchRequest пройден")


if __name__ == "__main__":
    """Запуск тестов напрямую (для отладки)."""
    import asyncio
    
    async def run_tests():
        print("Запуск интеграционных тестов...")
        
        # Создаем тестовое приложение
        test_app = app
        
        async with AsyncClient(app=test_app, base_url="http://test") as client:
            tester = TestIntegrationSearchWorkflow()
            
            try:
                await tester.test_create_search_and_get_progress(client)
                print("✅ test_create_search_and_get_progress пройден")
            except Exception as e:
                print(f"❌ test_create_search_and_get_progress не пройден: {e}")
            
            try:
                await tester.test_search_stop_functionality(client)
                print("✅ test_search_stop_functionality пройден")
            except Exception as e:
                print(f"❌ test_search_stop_functionality не пройден: {e}")
        
        # Тест миграций
        migration_tester = TestDatabaseMigrations()
        try:
            await migration_tester.test_tables_exist_after_migrations()
            print("✅ test_tables_exist_after_migrations пройден")
        except Exception as e:
            print(f"❌ test_tables_exist_after_migrations не пройден: {e}")
        
        try:
            await migration_tester.test_search_request_model_crud()
            print("✅ test_search_request_model_crud пройден")
        except Exception as e:
            print(f"❌ test_search_request_model_crud не пройден: {e}")
    
    asyncio.run(run_tests())