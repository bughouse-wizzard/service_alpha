"""
Тесты для фоновых задач (Celery workers).
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from datetime import datetime
from uuid import uuid4
from decimal import Decimal

from app.workers.celery_app import celery_app
from app.infra.db.enums import SearchStatus, MatchType


class TestCeleryApp:
    """Тесты Celery приложения."""
    
    def test_celery_app_initialization(self):
        """Тест инициализации Celery приложения."""
        assert celery_app is not None
        assert hasattr(celery_app, 'name')
        assert hasattr(celery_app, 'broker_url')
        assert hasattr(celery_app, 'result_backend')
        
        # Проверяем основные настройки
        assert celery_app.name == 'zakupki_analyzer'
        assert 'redis' in celery_app.broker_url
        assert 'redis' in celery_app.result_backend
    
    def test_celery_task_registration(self):
        """Тест регистрации задач Celery."""
        # Проверяем, что основные задачи зарегистрированы
        from app.workers import tasks
        
        assert hasattr(tasks, 'process_search_task')
        assert hasattr(tasks, 'fetch_contracts_task')
        assert hasattr(tasks, 'analyze_contract_task')
        assert hasattr(tasks, 'calculate_nmc_task')
        
        # Проверяем, что задачи декорированы как Celery задачи
        assert hasattr(tasks.process_search_task, 'delay')
        assert hasattr(tasks.process_search_task, 'apply_async')


class TestWorkerTasks:
    """Тесты задач workers."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.search_id = uuid4()
    
    def test_process_search_task_structure(self):
        """Тест структуры задачи обработки поиска."""
        from app.workers.tasks import process_search_task
        
        # Проверяем, что функция существует
        assert callable(process_search_task)
        
        # Проверяем сигнатуру функции
        import inspect
        sig = inspect.signature(process_search_task)
        params = list(sig.parameters.keys())
        
        # Должен принимать search_id
        assert 'search_id' in params
    
    @patch('app.workers.tasks.SearchService')
    @patch('app.workers.tasks.ZakupkiClient')
    @patch('app.workers.tasks.extract_contract_info')
    @patch('app.workers.tasks.compare_specs')
    def test_process_search_task_mocked(self, mock_compare, mock_extract, mock_zakupki, mock_search_service):
        """Тест задачи обработки поиска с моками."""
        from app.workers.tasks import process_search_task
        
        # Настраиваем моки
        mock_search_service_instance = AsyncMock()
        mock_search_service.return_value = mock_search_service_instance
        
        mock_search = Mock()
        mock_search.id = self.search_id
        mock_search.ktru = "31.20.11.110"
        mock_search.region = "Москва"
        mock_search.date_from = datetime(2024, 1, 1).date()
        mock_search.date_to = datetime(2024, 12, 31).date()
        mock_search.limit_contracts = 10
        mock_search.characteristics = "Характеристики"
        
        mock_search_service_instance.get_search.return_value = mock_search
        
        mock_zakupki_instance = AsyncMock()
        mock_zakupki.return_value = mock_zakupki_instance
        
        mock_zakupki_instance.search_contracts.return_value = {
            "contracts": [
                {"id": "1", "number": "123", "price": 100000.50},
                {"id": "2", "number": "124", "price": 150000.75}
            ],
            "total": 2
        }
        
        mock_extract.return_value = {
            "product_name": "Оборудование",
            "price": 100000.50,
            "specifications": "Характеристики"
        }
        
        mock_compare.return_value = {
            "match_type": MatchType.IDENTICAL.value,
            "ai_score": 95.5,
            "reason": "Полное совпадение"
        }
        
        mock_search_service_instance.update_search_progress.return_value = None
        mock_search_service_instance.add_contract_result.return_value = None
        mock_search_service_instance.complete_search.return_value = None
        
        # Вызываем задачу
        result = process_search_task(str(self.search_id))
        
        # Проверяем результат
        assert result is not None
        assert "search_id" in result
        assert result["search_id"] == str(self.search_id)
        assert "processed" in result
        assert "found" in result
        
        # Проверяем вызовы моков
        mock_search_service_instance.get_search.assert_called_once_with(str(self.search_id))
        mock_zakupki_instance.search_contracts.assert_called_once()
        mock_extract.assert_called()
        mock_compare.assert_called()
    
    def test_fetch_contracts_task_structure(self):
        """Тест структуры задачи получения контрактов."""
        from app.workers.tasks import fetch_contracts_task
        
        assert callable(fetch_contracts_task)
        
        import inspect
        sig = inspect.signature(fetch_contracts_task)
        params = list(sig.parameters.keys())
        
        assert 'search_id' in params
        assert 'page' in params
    
    def test_analyze_contract_task_structure(self):
        """Тест структуры задачи анализа контракта."""
        from app.workers.tasks import analyze_contract_task
        
        assert callable(analyze_contract_task)
        
        import inspect
        sig = inspect.signature(analyze_contract_task)
        params = list(sig.parameters.keys())
        
        assert 'search_id' in params
        assert 'contract_data' in params
    
    def test_calculate_nmc_task_structure(self):
        """Тест структуры задачи расчета НМЦК."""
        from app.workers.tasks import calculate_nmc_task
        
        assert callable(calculate_nmc_task)
        
        import inspect
        sig = inspect.signature(calculate_nmc_task)
        params = list(sig.parameters.keys())
        
        assert 'search_id' in params
    
    @patch('app.workers.tasks.calc_nmc_avg')
    @patch('app.workers.tasks.SearchService')
    def test_calculate_nmc_task_mocked(self, mock_search_service, mock_calc_nmc):
        """Тест задачи расчета НМЦК с моками."""
        from app.workers.tasks import calculate_nmc_task
        
        # Настраиваем моки
        mock_search_service_instance = AsyncMock()
        mock_search_service.return_value = mock_search_service_instance
        
        mock_search = Mock()
        mock_search.id = self.search_id
        mock_search.selected_contract_ids = ["contract1", "contract2", "contract3"]
        
        mock_search_service_instance.get_search.return_value = mock_search
        
        mock_contract1 = Mock()
        mock_contract1.price = Decimal("100000.50")
        
        mock_contract2 = Mock()
        mock_contract2.price = Decimal("150000.75")
        
        mock_contract3 = Mock()
        mock_contract3.price = Decimal("125000.25")
        
        mock_search_service_instance.get_contract_results.return_value = [
            mock_contract1, mock_contract2, mock_contract3
        ]
        
        mock_calc_nmc.return_value = Decimal("125000.50")
        
        mock_search_service_instance.update_nmc_value.return_value = None
        
        # Вызываем задачу
        result = calculate_nmc_task(str(self.search_id))
        
        # Проверяем результат
        assert result is not None
        assert "search_id" in result
        assert result["search_id"] == str(self.search_id)
        assert "nmc_value" in result
        assert result["nmc_value"] == 125000.50
        
        # Проверяем вызовы моков
        mock_search_service_instance.get_search.assert_called_once_with(str(self.search_id))
        mock_search_service_instance.get_contract_results.assert_called_once()
        mock_calc_nmc.assert_called_once_with([
            Decimal("100000.50"), Decimal("150000.75"), Decimal("125000.25")
        ])
        mock_search_service_instance.update_nmc_value.assert_called_once_with(
            str(self.search_id), Decimal("125000.50")
        )


class TestTaskErrorHandling:
    """Тесты обработки ошибок в задачах."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.search_id = uuid4()
    
    @patch('app.workers.tasks.SearchService')
    def test_process_search_task_error(self, mock_search_service):
        """Тест обработки ошибки в задаче поиска."""
        from app.workers.tasks import process_search_task
        
        # Настраиваем мок для выброса исключения
        mock_search_service_instance = AsyncMock()
        mock_search_service.return_value = mock_search_service_instance
        
        mock_search_service_instance.get_search.side_effect = Exception("Test error")
        
        mock_search_service_instance.fail_search.return_value = None
        
        # Вызываем задачу
        result = process_search_task(str(self.search_id))
        
        # Проверяем, что задача завершилась с ошибкой
        assert result is not None
        assert "error" in result
        assert "Test error" in result["error"]
        
        # Проверяем, что был вызван fail_search
        mock_search_service_instance.fail_search.assert_called_once_with(
            str(self.search_id), "Test error"
        )
    
    @patch('app.workers.tasks.calc_nmc_avg')
    @patch('app.workers.tasks.SearchService')
    def test_calculate_nmc_task_no_contracts(self, mock_search_service, mock_calc_nmc):
        """Тест расчета НМЦК без контрактов."""
        from app.workers.tasks import calculate_nmc_task
        
        # Настраиваем моки
        mock_search_service_instance = AsyncMock()
        mock_search_service.return_value = mock_search_service_instance
        
        mock_search = Mock()
        mock_search.id = self.search_id
        mock_search.selected_contract_ids = []  # Пустой список
        
        mock_search_service_instance.get_search.return_value = mock_search
        
        mock_calc_nmc.return_value = None
        
        # Вызываем задачу
        result = calculate_nmc_task(str(self.search_id))
        
        # Проверяем результат
        assert result is not None
        assert "search_id" in result
        assert result["search_id"] == str(self.search_id)
        assert "nmc_value" in result
        assert result["nmc_value"] is None
        
        # calc_nmc_avg не должен вызываться для пустого списка
        mock_calc_nmc.assert_not_called()
