"""
Тесты для API эндпоинтов.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient
from uuid import uuid4
from datetime import datetime

from app.main import app
from app.schemas.search import SearchCreateRequest, SearchBrief, SearchDetailsResponse, SearchListResponse
from app.services.search_service import SearchService


class TestSearchAPI:
    """Тесты для API поиска."""
    
    def setup_method(self):
        """Настройка тестов."""
        self.client = TestClient(app)
        self.search_id = uuid4()
        self.ktru = "31.20.11.110"
        
    def test_create_search_schema_validation(self):
        """Тест валидации схемы создания поиска."""
        # Корректные данные
        valid_data = {
            "ktru": "31.20.11.110",
            "region": "Москва",
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
            "contract_limit": 100
        }
        
        schema = SearchCreateRequest(**valid_data)
        assert schema.ktru == valid_data["ktru"]
        assert schema.region == valid_data["region"]
        assert schema.contract_limit == valid_data["contract_limit"]
        
        # Неверные данные - должно вызывать ошибку
        invalid_data = {
            "ktru": "invalid_ktru",
            "region": "Москва",
            "date_from": "2024-01-01",
            "date_to": "2023-12-31",  # date_to раньше date_from
            "contract_limit": 0  # должно быть > 0
        }
        
        with pytest.raises(ValueError):
            SearchCreateRequest(**invalid_data)
    
    def test_search_brief_schema(self):
        """Тест схемы краткой информации о поиске."""
        data = {
            "id": self.search_id,
            "ktru": self.ktru,
            "region": "Москва",
            "status": "pending",
            "created_at": datetime.now(),
            "processed_count": 0,
            "found_total": 0
        }
        
        schema = SearchBrief(**data)
        assert schema.id == data["id"]
        assert schema.ktru == data["ktru"]
        assert schema.status == data["status"]
    
    def test_search_details_schema(self):
        """Тест схемы детальной информации о поиске."""
        data = {
            "id": self.search_id,
            "ktru": self.ktru,
            "region": "Москва",
            "status": "completed",
            "created_at": datetime.now(),
            "started_at": datetime.now(),
            "completed_at": datetime.now(),
            "processed_count": 100,
            "found_total": 50,
            "error_code": None,
            "error_message": None,
            "runtime_ms": 5000
        }
        
        schema = SearchDetailsResponse(**data)
        assert schema.id == data["id"]
        assert schema.ktru == data["ktru"]
        assert schema.status == data["status"]
        assert schema.processed_count == data["processed_count"]
        assert schema.found_total == data["found_total"]
    
    @patch("app.api.search.SearchService")
    def test_create_search_endpoint(self, mock_service_class):
        """Тест эндпоинта создания поиска."""
        mock_service = AsyncMock()
        mock_service.create_search.return_value = SearchBrief(
            id=self.search_id,
            ktru=self.ktru,
            region="Москва",
            status="pending",
            created_at=datetime.now(),
            processed_count=0,
            found_total=0
        )
        mock_service_class.return_value = mock_service
        
        # Мокаем зависимость
        app.dependency_overrides[SearchService] = lambda: mock_service
        
        try:
            response = self.client.post(
                "/api/search/",
                json={
                    "ktru": self.ktru,
                    "region": "Москва",
                    "date_from": "2024-01-01",
                    "date_to": "2024-12-31",
                    "contract_limit": 100
                }
            )
            
            assert response.status_code == 201
            data = response.json()
            assert data["ktru"] == self.ktru
            assert data["status"] == "pending"
        finally:
            # Очищаем оверрайды
            app.dependency_overrides.clear()
    
    @patch("app.api.search.SearchService")
    def test_list_searches_endpoint(self, mock_service_class):
        """Тест эндпоинта списка поисков."""
        mock_service = AsyncMock()
        mock_service.list_searches.return_value = [
            SearchBrief(
                id=self.search_id,
                ktru=self.ktru,
                region="Москва",
                status="completed",
                created_at=datetime.now(),
                processed_count=100,
                found_total=50
            )
        ]
        mock_service_class.return_value = mock_service
        
        app.dependency_overrides[SearchService] = lambda: mock_service
        
        try:
            response = self.client.get("/api/search/")
            
            assert response.status_code == 200
            data = response.json()
            assert isinstance(data, list)
            assert len(data) == 1
            assert data[0]["ktru"] == self.ktru
        finally:
            app.dependency_overrides.clear()
    
    @patch("app.api.search.SearchService")
    def test_get_search_endpoint(self, mock_service_class):
        """Тест эндпоинта получения деталей поиска."""
        mock_service = AsyncMock()
        mock_service.get_search.return_value = SearchDetailsResponse(
            id=self.search_id,
            ktru=self.ktru,
            region="Москва",
            status="completed",
            created_at=datetime.now(),
            started_at=datetime.now(),
            completed_at=datetime.now(),
            processed_count=100,
            found_total=50,
            error_code=None,
            error_message=None,
            runtime_ms=5000
        )
        mock_service_class.return_value = mock_service
        
        app.dependency_overrides[SearchService] = lambda: mock_service
        
        try:
            response = self.client.get(f"/api/search/{self.search_id}")
            
            assert response.status_code == 200
            data = response.json()
            assert data["id"] == str(self.search_id)
            assert data["ktru"] == self.ktru
            assert data["status"] == "completed"
        finally:
            app.dependency_overrides.clear()
    
    @patch("app.api.search.SearchService")
    def test_stop_search_endpoint(self, mock_service_class):
        """Тест эндпоинта остановки поиска."""
        mock_service = AsyncMock()
        mock_service.stop_search.return_value = SearchBrief(
            id=self.search_id,
            ktru=self.ktru,
            region="Москва",
            status="stopped",
            created_at=datetime.now(),
            processed_count=50,
            found_total=25
        )
        mock_service_class.return_value = mock_service
        
        app.dependency_overrides[SearchService] = lambda: mock_service
        
        try:
            response = self.client.post(f"/api/search/{self.search_id}/stop")
            
            assert response.status_code == 200
            data = response.json()
            assert data["id"] == str(self.search_id)
            assert data["status"] == "stopped"
        finally:
            app.dependency_overrides.clear()


class TestAPIExceptions:
    """Тесты обработки исключений в API."""
    
    def setup_method(self):
        """Настройка тестов."""
        self.client = TestClient(app)
    
    def test_api_exception_structure(self):
        """Тест структуры исключения API."""
        from app.api.exceptions import ApiException, ApiError
        
        exception = ApiException(
            status_code=400,
            error_code="VALIDATION_ERROR",
            message="Validation failed",
            details={"field": "ktru"}
        )
        
        assert exception.status_code == 400
        assert exception.error_code == "VALIDATION_ERROR"
        assert exception.message == "Validation failed"
        assert exception.details == {"field": "ktru"}
        
        # Проверка преобразования в ApiError
        api_error = exception.to_api_error()
        assert api_error.error_code == "VALIDATION_ERROR"
        assert api_error.message == "Validation failed"
        assert api_error.details == {"field": "ktru"}
