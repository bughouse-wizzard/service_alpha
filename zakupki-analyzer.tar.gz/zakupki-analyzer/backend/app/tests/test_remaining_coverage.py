"""
Тесты для покрытия оставшихся модулей.
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock
from datetime import datetime, date
from uuid import uuid4
from decimal import Decimal

# Тестируем модули с низким покрытием
from app.api.exceptions import (
    AppException, NotFoundException, ValidationException,
    BusinessException, InternalException, handle_app_exception,
    handle_validation_exception, handle_generic_exception
)
from app.api.system import health, version
from app.core.logging import configure_logging, log
from app.core.middleware import CorrelationIdMiddleware
from app.services.search import SearchService
from app.services.ai.deepseek import DeepSeekClient, extract_contract_info, compare_specs
from app.services.zakupki.client import ZakupkiClient
from app.workers.celery_app import celery_app
from app.workers.tasks import process_search


def test_api_exceptions_comprehensive():
    """Комплексный тест API исключений."""
    # AppException
    exc = AppException(
        error_code="TEST_ERROR",
        message="Test error",
        status_code=400
    )
    assert exc.error_code == "TEST_ERROR"
    assert exc.message == "Test error"
    assert exc.status_code == 400
    
    # NotFoundException
    not_found = NotFoundException("Not found")
    assert not_found.error_code == "NOT_FOUND"
    assert not_found.status_code == 404
    
    # ValidationException
    validation = ValidationException("Validation failed")
    assert validation.error_code == "VALIDATION_ERROR"
    assert validation.status_code == 400
    
    # BusinessException
    business = BusinessException("Business error")
    assert business.error_code == "BUSINESS_ERROR"
    assert business.status_code == 400
    
    # InternalException
    internal = InternalException("Internal error")
    assert internal.error_code == "INTERNAL_ERROR"
    assert internal.status_code == 500
    
    # Проверяем обработчики
    assert callable(handle_app_exception)
    assert callable(handle_validation_exception)
    assert callable(handle_generic_exception)


def test_api_system():
    """Тест системных эндпоинтов."""
    # Health check
    result = health()
    assert result == {"status": "ok"}
    
    # Version
    result = version()
    assert "name" in result
    assert "version" in result
    assert "env" in result


def test_logging_comprehensive():
    """Комплексный тест логирования."""
    # Конфигурация логирования
    configure_logging()
    
    # Получение логгера
    logger = log()
    assert logger is not None
    
    # Проверяем методы логгера
    logger.info("Test info")
    logger.error("Test error")
    logger.debug("Test debug")


def test_middleware_comprehensive():
    """Комплексный тест middleware."""
    from fastapi import FastAPI
    from starlette.testclient import TestClient
    
    app = FastAPI()
    middleware = CorrelationIdMiddleware(app)
    assert middleware is not None
    
    # Создаем тестовое приложение с middleware
    @app.get("/test")
    async def test_endpoint():
        return {"status": "ok"}
    
    client = TestClient(app)
    response = client.get("/test")
    assert response.status_code == 200
    assert "X-Request-Id" in response.headers


def test_search_service_comprehensive():
    """Комплексный тест сервиса поиска."""
    service = SearchService()
    assert service is not None
    
    # Проверяем методы
    assert hasattr(service, 'create_search')
    assert hasattr(service, 'get_search')
    assert hasattr(service, 'list_searches')
    assert hasattr(service, 'stop_search')
    assert hasattr(service, 'update_selection')


def test_ai_service_comprehensive():
    """Комплексный тест AI сервиса."""
    # Клиент
    client = DeepSeekClient(api_key="test", base_url="http://test.url")
    assert client is not None
    
    # Проверяем функции
    assert callable(extract_contract_info)
    assert callable(compare_specs)
    
    # Проверяем структуру клиента
    assert hasattr(client, 'api_key')
    assert hasattr(client, 'base_url')
    assert hasattr(client, 'chat')


def test_zakupki_client_comprehensive():
    """Комплексный тест клиента zakupki.gov.ru."""
    client = ZakupkiClient()
    assert client is not None
    
    # Проверяем атрибуты
    assert hasattr(client, 'base_url')
    assert hasattr(client, 'timeout')
    assert hasattr(client, 'max_retries')
    
    # Проверяем методы
    assert hasattr(client, 'search_contracts')
    assert hasattr(client, 'get_contract_details')


def test_celery_comprehensive():
    """Комплексный тест Celery."""
    assert celery_app is not None
    assert celery_app.name == "zakupki_analyzer"
    
    # Проверяем конфигурацию
    assert hasattr(celery_app, 'broker_url')
    assert hasattr(celery_app, 'result_backend')
    assert hasattr(celery_app, 'task_serializer')
    assert hasattr(celery_app, 'accept_content')
    assert hasattr(celery_app, 'result_serializer')


def test_worker_tasks_comprehensive():
    """Комплексный тест задач workers."""
    assert callable(process_search)
    
    # Проверяем сигнатуру
    import inspect
    sig = inspect.signature(process_search)
    params = list(sig.parameters.keys())
    assert 'search_id' in params


@pytest.mark.asyncio
async def test_search_service_async():
    """Асинхронный тест сервиса поиска."""
    with patch('app.services.search.SearchRepo') as mock_repo_class:
        mock_repo = AsyncMock()
        mock_repo_class.return_value = mock_repo
        
        service = SearchService()
        
        # Mock данные
        mock_search = Mock()
        mock_search.id = uuid4()
        mock_search.ktru = "31.20.11.110"
        mock_search.status = "pending"
        mock_search.created_at = datetime.now()
        mock_search.updated_at = datetime.now()
        mock_search.contracts_found = 0
        mock_search.contracts_processed = 0
        
        mock_repo.create.return_value = mock_search
        
        # Тест создания поиска
        search_data = {
            "ktru": "31.20.11.110",
            "manufacturer": "Test",
            "region": "Moscow",
            "date_from": date(2024, 1, 1),
            "date_to": date(2024, 12, 31),
            "contract_limit": 100,
            "characteristics": "Test"
        }
        
        result = await service.create_search(search_data)
        assert result is not None
        mock_repo.create.assert_called_once()


@pytest.mark.asyncio
async def test_ai_service_async_mocked():
    """Асинхронный тест AI сервиса с моками."""
    with patch('app.services.ai.deepseek.DeepSeekClient') as mock_client_class:
        mock_client = AsyncMock()
        mock_client_class.return_value = mock_client
        
        mock_response = {
            "choices": [{
                "message": {
                    "content": '{"product_name": "Test", "price": 100000.50}'
                }
            }]
        }
        
        mock_client.chat.completions.create.return_value = mock_response
        
        # Тест извлечения информации
        contract_text = "Test contract"
        result = await extract_contract_info(contract_text)
        assert result is not None
        mock_client.chat.completions.create.assert_called_once()


def test_nmc_service_edge_cases():
    """Тест граничных случаев сервиса НМЦК."""
    from app.services.nmc_service import calc_nmc_avg
    
    # Пустой список
    assert calc_nmc_avg([]) is None
    
    # Одно значение
    assert calc_nmc_avg([Decimal("100.50")]) == Decimal("100.50")
    
    # Несколько значений
    prices = [Decimal("100.50"), Decimal("200.75"), Decimal("150.25")]
    result = calc_nmc_avg(prices)
    expected = Decimal("150.50")
    assert result == expected
    
    # Строковые значения
    prices_str = ["100.50", "200.75", "150.25"]
    result = calc_nmc_avg(prices_str)
    expected = Decimal("150.50")
    assert result == expected
    
    # С None значениями
    prices_with_none = [Decimal("100.50"), None, Decimal("200.75")]
    result = calc_nmc_avg(prices_with_none)
    expected = Decimal("150.63")
    assert result == expected
    
    # Все None
    assert calc_nmc_avg([None, None, None]) is None
