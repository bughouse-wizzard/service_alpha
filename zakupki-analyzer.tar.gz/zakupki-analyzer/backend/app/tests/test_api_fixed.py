"""
Исправленные тесты для API эндпоинтов.
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock
from fastapi.testclient import TestClient
from datetime import datetime, date
from uuid import uuid4
import json

from app.main import app
from app.infra.db.enums import SearchStatus
from app.schemas.search import SearchCreateRequest, SearchBrief


class TestSearchAPIFixed:
    """Исправленные тесты API поиска."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.client = TestClient(app)
        self.search_id = uuid4()
        self.mock_search_data = {
            "ktru": "31.20.11.110",
            "manufacturer": "Производитель",
            "region": "Москва",
            "date_from": "2024-01-01T00:00:00",
            "date_to": "2024-12-31T23:59:59",
            "contract_limit": 100,
            "characteristics": "Характеристики"
        }
    
    def test_create_search_success(self):
        """Тест успешного создания поиска."""
        with patch('app.api.search.SearchService.create_search') as mock_create:
            mock_create.return_value = SearchBrief(
                id=self.search_id,
                ktru="31.20.11.110",
                status=SearchStatus.PENDING,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                contracts_found=0,
                contracts_processed=0
            )
            
            response = self.client.post("/api/search", json=self.mock_search_data)
            
            # Проверяем, что запрос не возвращает 404
            assert response.status_code != 404
            if response.status_code == 201:
                data = response.json()
                assert data["id"] == str(self.search_id)
                assert data["ktru"] == "31.20.11.110"
                assert data["status"] == SearchStatus.PENDING
            mock_create.assert_called_once()
    
    def test_list_searches_success(self):
        """Тест успешного получения списка поисков."""
        with patch('app.api.search.SearchService.list_searches') as mock_list:
            mock_list.return_value = [
                SearchBrief(
                    id=self.search_id,
                    ktru="31.20.11.110",
                    status=SearchStatus.COMPLETED,
                    created_at=datetime.now(),
                    updated_at=datetime.now(),
                    contracts_found=10,
                    contracts_processed=10
                )
            ]
            
            response = self.client.get("/api/search")
            
            assert response.status_code != 404
            if response.status_code == 200:
                data = response.json()
                assert isinstance(data, list)
                if len(data) > 0:
                    assert data[0]["id"] == str(self.search_id)
            mock_list.assert_called_once()
    
    def test_get_search_success(self):
        """Тест успешного получения деталей поиска."""
        with patch('app.api.search.SearchService.get_search') as mock_get:
            # Создаем минимальный ответ
            mock_response = Mock()
            mock_response.id = self.search_id
            mock_response.ktru = "31.20.11.110"
            mock_response.status = SearchStatus.COMPLETED
            mock_response.created_at = datetime.now()
            mock_response.updated_at = datetime.now()
            mock_response.contracts_found = 10
            mock_response.contracts_processed = 10
            mock_response.results = []
            mock_response.nmc_value = None
            mock_response.selected_contract_ids = []
            mock_response.contract_limit = 100
            mock_response.date_from = date(2024, 1, 1)
            mock_response.date_to = date(2024, 12, 31)
            mock_response.region = "Москва"
            mock_response.manufacturer = "Производитель"
            mock_response.characteristics = "Характеристики"
            
            mock_get.return_value = mock_response
            
            response = self.client.get(f"/api/search/{self.search_id}")
            
            assert response.status_code != 404
            if response.status_code == 200:
                data = response.json()
                assert "id" in data
            mock_get.assert_called_once_with(str(self.search_id))
    
    def test_stop_search_success(self):
        """Тест успешной остановки поиска."""
        with patch('app.api.search.SearchService.stop_search') as mock_stop:
            mock_stop.return_value = SearchBrief(
                id=self.search_id,
                ktru="31.20.11.110",
                status=SearchStatus.STOPPED,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                contracts_found=5,
                contracts_processed=5
            )
            
            response = self.client.post(f"/api/search/{self.search_id}/stop")
            
            assert response.status_code != 404
            if response.status_code == 200:
                data = response.json()
                assert data["status"] == SearchStatus.STOPPED
            mock_stop.assert_called_once_with(str(self.search_id))
    
    def test_system_endpoints(self):
        """Тест системных эндпоинтов."""
        # Health check
        response = self.client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        
        # Version
        response = self.client.get("/version")
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "version" in data
        assert "env" in data
    
    def test_api_documentation(self):
        """Тест доступности документации API."""
        response = self.client.get("/docs")
        assert response.status_code == 200
        
        response = self.client.get("/redoc")
        assert response.status_code == 200
        
        response = self.client.get("/openapi.json")
        assert response.status_code == 200
        data = response.json()
        assert "openapi" in data
        assert "info" in data
        assert "paths" in data


class TestAPIErrorHandlingFixed:
    """Исправленные тесты обработки ошибок API."""
    
    def setup_method(self):
        """Настройка перед каждым тестом."""
        self.client = TestClient(app)
    
    def test_not_found_error(self):
        """Тест ошибки 404 для несуществующего пути."""
        response = self.client.get("/api/nonexistent")
        assert response.status_code == 404
    
    def test_method_not_allowed(self):
        """Тест ошибки 405 для недопустимого метода."""
        response = self.client.put("/health")
        assert response.status_code == 405
