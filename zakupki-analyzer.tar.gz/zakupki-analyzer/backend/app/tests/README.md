## Тестирование (PostgreSQL-only)
- Unit тесты: pytest (без БД)
- Integration тесты: поднимаем Postgres в docker и гоняем alembic + API (добавить при необходимости)

Минимальный smoke:
- test_nmc.py
- test_schemas_ai.py