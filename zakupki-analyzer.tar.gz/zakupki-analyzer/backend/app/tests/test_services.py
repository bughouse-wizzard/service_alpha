"""
Тесты для сервисов бизнес-логики.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4
from datetime import datetime, date
from decimal import Decimal

from app.services.nmc_service import calc_nmc_avg
from app.schemas.search import SearchCreateRequest


class TestNmcService:
    """Тесты сервиса расчета НМЦК."""
    
    def test_calc_nmc_avg_empty(self):
        """Тест расчета НМЦК с пустым списком."""
        result = calc_nmc_avg([])
        assert result is None
    
    def test_calc_nmc_avg_single(self):
        """Тест расчета НМЦК с одним значением."""
        result = calc_nmc_avg([Decimal("100.50")])
        assert result == Decimal("100.50")
        
        # С разными типами
        result = calc_nmc_avg([100.50])
        assert result == Decimal("100.50")
        
        result = calc_nmc_avg(["100.50"])
        assert result == Decimal("100.50")
        
        result = calc_nmc_avg([100])
        assert result == Decimal("100")
    
    def test_calc_nmc_avg_multiple(self):
        """Тест расчета НМЦК с несколькими значениями."""
        prices = [Decimal("100.50"), Decimal("200.75"), Decimal("150.25")]
        result = calc_nmc_avg(prices)
        expected = Decimal("150.50")  # (100.50 + 200.75 + 150.25) / 3 = 150.50
        assert result == expected
    
    def test_calc_nmc_avg_with_none(self):
        """Тест расчета НМЦК с None значениями."""
        prices = [Decimal("100.50"), None, Decimal("200.75"), None, Decimal("150.25")]
        result = calc_nmc_avg(prices)
        expected = Decimal("150.50")  # Только 3 валидных значения
        assert result == expected
    
    def test_calc_nmc_avg_rounding(self):
        """Тест округления НМЦК."""
        prices = [Decimal("100.555"), Decimal("200.444"), Decimal("150.333")]
        result = calc_nmc_avg(prices)
        # (100.555 + 200.444 + 150.333) / 3 = 150.444
        # Округление до 2 знаков: 150.44
        assert result == Decimal("150.44")
    
    def test_calc_nmc_avg_invalid_values(self):
        """Тест с невалидными значениями."""
        prices = ["invalid", "not_a_number", Decimal("100.50")]
        result = calc_nmc_avg(prices)
        # Только одно валидное значение
        assert result == Decimal("100.50")
    
    def test_calc_nmc_avg_currency_symbols(self):
        """Тест с символами валют."""
        prices = ["100,50 руб.", "200.75$", "150.25 €"]
        result = calc_nmc_avg(prices)
        expected = Decimal("150.50")  # (100.50 + 200.75 + 150.25) / 3
        assert result == expected


class TestSearchSchemas:
    """Тесты схем поиска."""
    
    def test_search_create_request_validation(self):
        """Тест валидации запроса создания поиска."""
        # Корректные данные
        data = {
            "ktru": "31.20.11.110",
            "region": "Москва",
            "date_from": date(2024, 1, 1),
            "date_to": date(2024, 12, 31),
            "contract_limit": 100
        }
        
        request = SearchCreateRequest(**data)
        assert request.ktru == data["ktru"]
        assert request.region == data["region"]
        assert request.date_from == data["date_from"]
        assert request.date_to == data["date_to"]
        assert request.contract_limit == data["contract_limit"]
    
    def test_search_create_request_invalid_dates(self):
        """Тест невалидных дат."""
        # date_to раньше date_from
        with pytest.raises(ValueError):
            SearchCreateRequest(
                ktru="31.20.11.110",
                region="Москва",
                date_from=date(2024, 12, 31),
                date_to=date(2024, 1, 1),
                contract_limit=100
            )
    
    def test_search_create_request_invalid_limit(self):
        """Тест невалидного лимита."""
        # Лимит должен быть > 0
        with pytest.raises(ValueError):
            SearchCreateRequest(
                ktru="31.20.11.110",
                region="Москва",
                date_from=date(2024, 1, 1),
                date_to=date(2024, 12, 31),
                contract_limit=0
            )
        
        # Лимит должен быть <= 1000
        with pytest.raises(ValueError):
            SearchCreateRequest(
                ktru="31.20.11.110",
                region="Москва",
                date_from=date(2024, 1, 1),
                date_to=date(2024, 12, 31),
                contract_limit=1001
            )


class TestAIService:
    """Тесты AI сервиса."""
    
    @patch("app.services.ai.deepseek.DeepSeekClient")
    def test_deepseek_client_initialization(self, mock_client_class):
        """Тест инициализации DeepSeek клиента."""
        from app.services.ai.deepseek import DeepSeekClient
        
        client = DeepSeekClient(api_key="test_key", base_url="http://test.com")
        assert client.api_key == "test_key"
        assert client.base_url == "http://test.com"
    
    @patch("app.services.ai.deepseek.aiohttp.ClientSession")
    def test_deepseek_extract_contract_info(self, mock_session_class):
        """Тест извлечения информации о контракте."""
        from app.services.ai.deepseek import DeepSeekClient
        
        mock_session = AsyncMock()
        mock_response = AsyncMock()
        mock_response.status = 200
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": '{"match_type": "IDENTICAL", "ai_score": 95, "reason": "Полное совпадение"}'
                }
            }]
        }
        mock_session.post.return_value.__aenter__.return_value = mock_response
        mock_session_class.return_value.__aenter__.return_value = mock_session
        
        client = DeepSeekClient(api_key="test_key")
        
        # Мокаем асинхронный контекст
        import asyncio
        result = asyncio.run(client.extract_contract_info(
            contract_text="Текст контракта",
            spec_text="Текст спецификации"
        ))
        
        assert result["match_type"] == "IDENTICAL"
        assert result["ai_score"] == 95
        assert result["reason"] == "Полное совпадение"
