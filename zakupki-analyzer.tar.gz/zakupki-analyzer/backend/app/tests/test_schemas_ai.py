from __future__ import annotations

import pytest
from pydantic import ValidationError

from app.services.ai.deepseek import CompareResult


def test_compare_schema_validation_ok():
    obj = CompareResult.model_validate({
        "score": 80,
        "match_type": "HOMOGENEOUS",
        "manufacturer_found": "X",
        "manufacturer_match": True,
        "rows": [{"name":"A","target":"1","actual":"1","status":"MATCH","reason":"","weight":1}],
        "decision": "ACCEPT",
    })
    assert obj.score == 80


def test_compare_schema_validation_fail():
    with pytest.raises(ValidationError):
        CompareResult.model_validate({"score": 999})