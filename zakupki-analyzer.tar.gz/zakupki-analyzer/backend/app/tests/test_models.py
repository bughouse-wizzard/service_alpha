"""
Тесты для моделей базы данных.
"""
import pytest
from datetime import datetime, date
from decimal import Decimal
from uuid import uuid4

from app.infra.db.models import (
    Base, SearchRequest, ContractResult, SpecComparisonRow
)
from app.infra.db.enums import SearchStatus, MatchType


class TestModels:
    """Тесты моделей базы данных."""
    
    def test_search_request_model(self):
        """Тест модели поискового запроса."""
        search_id = uuid4()
        search = SearchRequest(
            id=search_id,
            ktru_code="31.20.11.110",
            customer_region="Москва",
            date_from=date(2024, 1, 1),
            date_to=date(2024, 12, 31),
            limit_contracts=100,
            status=SearchStatus.PENDING.value,
            input_source="manual",
            object_name="Тестовый объект",
            okpd2_code="31.20.11",
            manufacturer_target="Производитель",
            law="44-ФЗ",
            execution_statuses=["COMPLETED"],
            found_total=0,
            processed_count=0,
            nmc_value=None,
            selected_contract_ids=[],
            target_specs={}
        )
        
        assert search.id == search_id
        assert search.ktru_code == "31.20.11.110"
        assert search.customer_region == "Москва"
        assert search.date_from == date(2024, 1, 1)
        assert search.date_to == date(2024, 12, 31)
        assert search.limit_contracts == 100
        assert search.status == SearchStatus.PENDING.value
        assert search.found_total == 0
        assert search.processed_count == 0
        assert search.nmc_value is None
        assert search.selected_contract_ids == []
    
    def test_search_request_status_transitions(self):
        """Тест переходов статусов поиска."""
        search = SearchRequest(
            id=uuid4(),
            ktru_code="31.20.11.110",
            customer_region="Москва",
            input_source="manual",
            law="44-ФЗ",
            date_from=date(2024, 1, 1),
            date_to=date(2024, 12, 31),
            execution_statuses=["COMPLETED"],
            limit_contracts=100,
            status=SearchStatus.PENDING.value
        )
        
        # Начальный статус
        assert search.status == SearchStatus.PENDING.value
        
        # Можно установить любой статус
        search.status = SearchStatus.RUNNING.value
        assert search.status == SearchStatus.RUNNING.value
        
        search.status = SearchStatus.COMPLETED.value
        assert search.status == SearchStatus.COMPLETED.value
        
        search.status = SearchStatus.FAILED.value
        assert search.status == SearchStatus.FAILED.value
        
        search.status = SearchStatus.STOPPED.value
        assert search.status == SearchStatus.STOPPED.value
    
    def test_contract_result_model(self):
        """Тест модели результата контракта."""
        search_id = uuid4()
        contract_id = uuid4()
        
        contract = ContractResult(
            id=contract_id,
            search_id=search_id,
            contract_number="123456",
            contract_date=date(2024, 6, 15),
            customer_name="ООО 'Заказчик'",
            supplier_name="ООО 'Поставщик'",
            contract_price=Decimal("1500000.50"),
            unit_price=Decimal("1500.75"),
            match_type=MatchType.IDENTICAL,
            ai_score=95,
            reason="Полное совпадение характеристик",
            is_2025_plus=True,
            manufacturer_match=True,
            accepted_for_nmc=True,
            created_at=datetime.now()
        )
        
        assert contract.id == contract_id
        assert contract.search_id == search_id
        assert contract.contract_number == "123456"
        assert contract.contract_date == date(2024, 6, 15)
        assert contract.customer_name == "ООО 'Заказчик'"
        assert contract.supplier_name == "ООО 'Поставщик'"
        assert contract.contract_price == Decimal("1500000.50")
        assert contract.unit_price == Decimal("1500.75")
        assert contract.match_type == MatchType.IDENTICAL
        assert contract.ai_score == 95
        assert contract.reason == "Полное совпадение характеристик"
        assert contract.is_2025_plus is True
        assert contract.manufacturer_match is True
        assert contract.accepted_for_nmc is True
    
    def test_contract_result_match_types(self):
        """Тест типов совпадения контракта."""
        contract = ContractResult(
            id=uuid4(),
            search_id=uuid4(),
            contract_number="123456"
        )
        
        # Проверяем все типы совпадения
        contract.match_type = MatchType.IDENTICAL
        assert contract.match_type == MatchType.IDENTICAL
        
        contract.match_type = MatchType.HOMOGENEOUS
        assert contract.match_type == MatchType.HOMOGENEOUS
        
        contract.match_type = MatchType.NO_MATCH
        assert contract.match_type == MatchType.NO_MATCH
        
        contract.match_type = MatchType.UNKNOWN
        assert contract.match_type == MatchType.UNKNOWN
    
    def test_spec_comparison_row_model(self):
        """Тест модели строки сравнения спецификаций."""
        contract_id = uuid4()
        
        comparison = SpecComparisonRow(
            id=uuid4(),
            contract_id=contract_id,
            spec_name="Наименование",
            requested_value="Требуемое значение",
            contract_value="Значение в контракте",
            match_status="MATCH",
            notes="Примечания"
        )
        
        assert comparison.contract_id == contract_id
        assert comparison.spec_name == "Наименование"
        assert comparison.requested_value == "Требуемое значение"
        assert comparison.contract_value == "Значение в контракте"
        assert comparison.match_status == "MATCH"
        assert comparison.notes == "Примечания"
    
    def test_relationships(self):
        """Тест связей между моделями."""
        search_id = uuid4()
        contract_id = uuid4()
        
        # Создаем поиск
        search = SearchRequest(
            id=search_id,
            ktru="31.20.11.110",
            region="Москва"
        )
        
        # Создаем контракт
        contract = ContractResult(
            id=contract_id,
            search_id=search_id,
            contract_number="123456"
        )
        
        # Создаем строку сравнения
        comparison = SpecComparisonRow(
            id=uuid4(),
            contract_id=contract_id,
            spec_name="Наименование"
        )
        
        # Проверяем связи
        assert contract.search_id == search.id
        assert comparison.contract_id == contract.id
        
        # В реальном SQLAlchemy были бы backrefs
        # assert contract in search.contracts
        # assert comparison in contract.spec_comparisons


class TestEnums:
    """Тесты перечислений."""
    
    def test_search_status_enum(self):
        """Тест перечисления статусов поиска."""
        assert SearchStatus.PENDING == "pending"
        assert SearchStatus.RUNNING == "running"
        assert SearchStatus.COMPLETED == "completed"
        assert SearchStatus.FAILED == "failed"
        assert SearchStatus.STOPPED == "stopped"
        
        # Проверяем все значения
        all_statuses = {status.value for status in SearchStatus}
        expected = {"pending", "running", "completed", "failed", "stopped"}
        assert all_statuses == expected
    
    def test_match_type_enum(self):
        """Тест перечисления типов совпадения."""
        assert MatchType.IDENTICAL.value == "identical"
        assert MatchType.HOMOGENEOUS.value == "homogeneous"
        assert MatchType.NO_MATCH.value == "no_match"
        assert MatchType.UNKNOWN.value == "unknown"
        
        # Проверяем все значения
        all_types = {match_type.value for match_type in MatchType}
        expected = {"identical", "homogeneous", "no_match", "unknown"}
        assert all_types == expected
