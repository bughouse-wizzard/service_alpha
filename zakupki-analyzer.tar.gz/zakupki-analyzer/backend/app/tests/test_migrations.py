"""
Smoke-тест миграций базы данных.
Проверяет, что миграции применяются корректно и таблицы существуют.
"""
import pytest
import asyncio
from sqlalchemy import text
from alembic.config import Config
from alembic import command

from app.infra.db.session import AsyncSessionLocal, engine


class TestMigrationsSmoke:
    """Smoke-тесты для миграций базы данных."""
    
    @pytest.mark.asyncio
    async def test_alembic_upgrade_head(self):
        """Тест применения миграций до head."""
        # Создаем конфиг alembic
        alembic_cfg = Config("alembic.ini")
        
        # Применяем миграции
        command.upgrade(alembic_cfg, "head")
        
        print("✅ Миграции успешно применены до head")
    
    @pytest.mark.asyncio
    async def test_all_tables_exist(self):
        """Тест проверяет, что все необходимые таблицы существуют."""
        async with AsyncSessionLocal() as session:
            # Список обязательных таблиц
            required_tables = [
                "search_request",
                "contract_result", 
                "spec_comparison_row",
                "alembic_version"  # Таблица версий alembic
            ]
            
            for table_name in required_tables:
                # Проверяем через information_schema
                result = await session.execute(
                    text("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = 'public' 
                        AND table_name = :table_name
                    )
                    """),
                    {"table_name": table_name}
                )
                exists = result.scalar()
                assert exists, f"Таблица {table_name} должна существовать после миграций"
                print(f"✅ Таблица {table_name} существует")
    
    @pytest.mark.asyncio
    async def test_table_columns_exist(self):
        """Тест проверяет, что у таблиц есть необходимые колонки."""
        async with AsyncSessionLocal() as session:
            # Проверяем основные колонки для search_request
            result = await session.execute(
                text("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_schema = 'public' 
                AND table_name = 'search_request'
                """)
            )
            columns = {row[0] for row in result.fetchall()}
            
            required_columns = {"id", "status", "ktru", "created_at", "found_total", "processed_count"}
            missing_columns = required_columns - columns
            
            assert not missing_columns, f"Отсутствуют колонки в search_request: {missing_columns}"
            print(f"✅ Все необходимые колонки в search_request присутствуют: {columns}")
    
    @pytest.mark.asyncio
    async def test_alembic_downgrade_and_upgrade(self):
        """Тест отката и повторного применения миграций."""
        alembic_cfg = Config("alembic.ini")
        
        # Получаем текущую ревизию
        result = await AsyncSessionLocal().execute(text("SELECT version_num FROM alembic_version"))
        current_revision = result.scalar()
        print(f"Текущая ревизия: {current_revision}")
        
        # Находим базовую ревизию (первую после base)
        # В реальном тесте нужно найти конкретную ревизию для отката
        # Для smoke-теста просто проверяем, что можем получить историю
        try:
            # Пытаемся откатить на одну ревизию назад
            command.downgrade(alembic_cfg, "-1")
            print("✅ Откат на одну ревизию выполнен")
            
            # Возвращаем обратно
            command.upgrade(alembic_cfg, "+1")
            print("✅ Возврат на текущую ревизию выполнен")
        except Exception as e:
            print(f"⚠️  Откат/возврат не выполнен (может быть только одна ревизия): {e}")
            # Если есть только одна ревизия, просто применяем head
            command.upgrade(alembic_cfg, "head")
            print("✅ Миграции применены до head")
    
    @pytest.mark.asyncio
    async def test_database_connection(self):
        """Тест подключения к базе данных."""
        try:
            async with AsyncSessionLocal() as session:
                # Простой запрос для проверки подключения
                result = await session.execute(text("SELECT 1"))
                value = result.scalar()
                assert value == 1
                print("✅ Подключение к базе данных работает")
        except Exception as e:
            pytest.fail(f"Не удалось подключиться к базе данных: {e}")


async def run_smoke_tests():
    """Запуск всех smoke-тестов."""
    print("🚀 Запуск smoke-тестов миграций...")
    
    tester = TestMigrationsSmoke()
    
    tests = [
        ("test_database_connection", tester.test_database_connection),
        ("test_alembic_upgrade_head", tester.test_alembic_upgrade_head),
        ("test_all_tables_exist", tester.test_all_tables_exist),
        ("test_table_columns_exist", tester.test_table_columns_exist),
        ("test_alembic_downgrade_and_upgrade", tester.test_alembic_downgrade_and_upgrade),
    ]
    
    for test_name, test_func in tests:
        try:
            print(f"\n🔍 Запуск теста: {test_name}")
            await test_func()
            print(f"✅ {test_name} пройден")
        except Exception as e:
            print(f"❌ {test_name} не пройден: {e}")
            raise
    
    print("\n🎉 Все smoke-тесты миграций пройдены успешно!")


if __name__ == "__main__":
    """Запуск smoke-тестов напрямую."""
    asyncio.run(run_smoke_tests())