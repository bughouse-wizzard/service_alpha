from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError

from app.core.settings import settings
from app.core.logging import configure_logging
from app.core.middleware import CorrelationIdMiddleware
from app.api.router import api_router
from app.api.system import router as system_router
from app.api.exceptions import (
    ApiException,
    api_exception_handler,
    http_exception_handler,
    validation_exception_handler,
    generic_exception_handler,
)

configure_logging()

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="MVP backend для поиска контрактов ЕИС и расчета НМЦК",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(CorrelationIdMiddleware)

# Регистрация обработчиков исключений
app.add_exception_handler(ApiException, api_exception_handler)
app.add_exception_handler(HTTPException, http_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(Exception, generic_exception_handler)

app.include_router(system_router)
app.include_router(api_router, prefix="/api")