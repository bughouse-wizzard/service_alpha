from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from redis.asyncio import Redis
from redis.asyncio.client import Redis as RedisType


@dataclass(frozen=True)
class StreamEvent:
    type: str
    data: dict[str, Any]


class RedisEventBroker:
    """
    Redis Streams: nmck:events:{search_id}
    """

    def __init__(self, redis_url: str) -> None:
        self._redis_url = redis_url
        self._client: RedisType | None = None

    async def _get(self) -> RedisType:
        if self._client is None:
            self._client = Redis.from_url(self._redis_url, decode_responses=True)
        return self._client

    def _key(self, search_id: str) -> str:
        return f"nmck:events:{search_id}"

    async def emit(self, search_id: str, ev: StreamEvent) -> str:
        r = await self._get()
        payload = {"type": ev.type, "data": json.dumps(ev.data, ensure_ascii=False)}
        event_id = await r.xadd(self._key(search_id), payload, maxlen=2000, approximate=True)
        return str(event_id)

    async def read_stream(self, search_id: str, *, last_id: str, block_ms: int, count: int) -> list[tuple[str, dict]]:
        r = await self._get()
        resp = await r.xread({self._key(search_id): last_id}, block=block_ms, count=count)
        if not resp:
            return []
        # resp: [(stream, [(id, {field: value})...])]
        _stream, items = resp[0]
        out: list[tuple[str, dict]] = []
        for ev_id, fields in items:
            ev_type = fields.get("type", "message")
            raw_data = fields.get("data", "{}")
            try:
                data = json.loads(raw_data)
            except Exception:
                data = {"raw": raw_data}
            out.append((str(ev_id), {"type": ev_type, "data": data}))
        return out