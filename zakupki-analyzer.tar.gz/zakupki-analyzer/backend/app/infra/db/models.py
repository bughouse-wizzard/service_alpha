from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Any

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class SearchRequest(Base):
    __tablename__ = "search_request"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now())
    updated_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now())

    status: Mapped[str] = mapped_column(sa.String(32), index=True)

    input_source: Mapped[str] = mapped_column(sa.String(16))

    object_name: Mapped[str | None] = mapped_column(sa.String(512), nullable=True)
    ktru_code: Mapped[str] = mapped_column(sa.String(64), index=True)
    okpd2_code: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)

    manufacturer_target: Mapped[str | None] = mapped_column(sa.String(256), nullable=True)

    customer_region: Mapped[str] = mapped_column(sa.String(64))
    law: Mapped[str] = mapped_column(sa.String(16))

    date_from: Mapped[date] = mapped_column(sa.Date)
    date_to: Mapped[date] = mapped_column(sa.Date)

    execution_statuses: Mapped[list[str]] = mapped_column(ARRAY(sa.String(8)))
    limit_contracts: Mapped[int] = mapped_column(sa.Integer)

    found_total: Mapped[int] = mapped_column(sa.Integer, default=0)
    processed_count: Mapped[int] = mapped_column(sa.Integer, default=0)

    nmc_value: Mapped[Decimal | None] = mapped_column(sa.Numeric(18, 2), nullable=True)
    selected_contract_ids: Mapped[list[uuid.UUID]] = mapped_column(ARRAY(UUID(as_uuid=True)), default=list)

    target_specs: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)

    error_code: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(sa.Text, nullable=True)

    runtime_ms: Mapped[int | None] = mapped_column(sa.Integer, nullable=True)

    stop_requested: Mapped[bool] = mapped_column(sa.Boolean, default=False)
    celery_task_id: Mapped[str | None] = mapped_column(sa.String(128), nullable=True, index=True)

    results: Mapped[list["ContractResult"]] = relationship(
        back_populates="search",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class ContractResult(Base):
    __tablename__ = "contract_result"
    __table_args__ = (sa.UniqueConstraint("search_id", "reestr_number", name="uq_search_contract"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now())
    updated_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now())

    search_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), sa.ForeignKey("search_request.id", ondelete="CASCADE"), index=True)
    reestr_number: Mapped[str] = mapped_column(sa.String(64), index=True)
    contract_url: Mapped[str] = mapped_column(sa.Text)

    sign_date: Mapped[date | None] = mapped_column(sa.Date, nullable=True)
    unit_price: Mapped[Decimal | None] = mapped_column(sa.Numeric(18, 2), nullable=True)
    currency: Mapped[str] = mapped_column(sa.String(8), default="RUB")

    match_type: Mapped[str] = mapped_column(sa.String(16), index=True)  # IDENTICAL/HOMOGENEOUS/NO_MATCH
    ai_score: Mapped[int] = mapped_column(sa.Integer, default=0, index=True)

    manufacturer_found: Mapped[str | None] = mapped_column(sa.String(256), nullable=True)
    manufacturer_match: Mapped[bool | None] = mapped_column(sa.Boolean, nullable=True)

    is_2025_plus: Mapped[bool] = mapped_column(sa.Boolean, default=False)

    accepted_for_nmc: Mapped[bool] = mapped_column(sa.Boolean, default=False)

    specs_raw: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    raw_data_json: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    ai_analysis: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)

    error_code: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(sa.Text, nullable=True)

    search: Mapped["SearchRequest"] = relationship(back_populates="results")
    comparison_rows: Mapped[list["SpecComparisonRow"]] = relationship(
        back_populates="contract",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class SpecComparisonRow(Base):
    __tablename__ = "spec_comparison_row"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    contract_result_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), sa.ForeignKey("contract_result.id", ondelete="CASCADE"), index=True)

    name: Mapped[str] = mapped_column(sa.String(256))
    target_value: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    actual_value: Mapped[str | None] = mapped_column(sa.Text, nullable=True)

    match_status: Mapped[str] = mapped_column(sa.String(16))  # MATCH/DIFF/UNKNOWN
    reason: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    weight: Mapped[int] = mapped_column(sa.Integer, default=1)

    contract: Mapped["ContractResult"] = relationship(back_populates="comparison_rows")