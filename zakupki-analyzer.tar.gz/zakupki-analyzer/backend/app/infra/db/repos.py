from __future__ import annotations

import uuid
from datetime import date
from typing import Iterable

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.infra.db.models import ContractResult, SearchRequest, SpecComparisonRow


class SearchRepo:
    async def get(self, db: AsyncSession, search_id: uuid.UUID) -> SearchRequest | None:
        res = await db.execute(sa.select(SearchRequest).where(SearchRequest.id == search_id))
        return res.scalar_one_or_none()

    async def list(
        self,
        db: AsyncSession,
        *,
        page: int,
        page_size: int,
        ktru: str | None,
        status: str | None,
        date_from: date | None,
        date_to: date | None,
    ) -> tuple[int, list[SearchRequest]]:
        q = sa.select(SearchRequest)
        cq = sa.select(sa.func.count(SearchRequest.id))

        if ktru:
            q = q.where(SearchRequest.ktru_code.ilike(f"%{ktru}%"))
            cq = cq.where(SearchRequest.ktru_code.ilike(f"%{ktru}%"))
        if status:
            q = q.where(SearchRequest.status == status)
            cq = cq.where(SearchRequest.status == status)
        if date_from:
            q = q.where(SearchRequest.created_at >= sa.func.date_trunc("day", date_from))
            cq = cq.where(SearchRequest.created_at >= sa.func.date_trunc("day", date_from))
        if date_to:
            q = q.where(SearchRequest.created_at <= sa.func.date_trunc("day", date_to) + sa.text("interval '1 day'"))
            cq = cq.where(SearchRequest.created_at <= sa.func.date_trunc("day", date_to) + sa.text("interval '1 day'"))

        q = q.order_by(SearchRequest.created_at.desc()).offset((page - 1) * page_size).limit(page_size)

        total = (await db.execute(cq)).scalar_one()
        items = (await db.execute(q)).scalars().all()
        return int(total), list(items)

    async def create(self, db: AsyncSession, obj: SearchRequest) -> SearchRequest:
        db.add(obj)
        await db.flush()
        return obj

    async def update(self, db: AsyncSession, obj: SearchRequest) -> SearchRequest:
        db.add(obj)
        await db.flush()
        return obj


class ResultRepo:
    async def list_results(
        self,
        db: AsyncSession,
        *,
        search_id: uuid.UUID,
        page: int = 1,
        page_size: int = 50,
        reestr_q: str | None = None,
        match_type: str | None = None,
        min_score: int | None = None,
        accepted_for_nmc: bool | None = None,
        is_2025_plus: bool | None = None,
        manufacturer_match: bool | None = None,
    ) -> tuple[int, list[ContractResult]]:
        q = sa.select(ContractResult).where(ContractResult.search_id == search_id)
        cq = sa.select(sa.func.count(ContractResult.id)).where(ContractResult.search_id == search_id)

        if reestr_q:
            q = q.where(ContractResult.reestr_number.ilike(f"%{reestr_q}%"))
            cq = cq.where(ContractResult.reestr_number.ilike(f"%{reestr_q}%"))
        if match_type:
            q = q.where(ContractResult.match_type == match_type)
            cq = cq.where(ContractResult.match_type == match_type)
        if min_score is not None:
            q = q.where(ContractResult.ai_score >= min_score)
            cq = cq.where(ContractResult.ai_score >= min_score)
        if accepted_for_nmc is not None:
            q = q.where(ContractResult.accepted_for_nmc == accepted_for_nmc)
            cq = cq.where(ContractResult.accepted_for_nmc == accepted_for_nmc)
        if is_2025_plus is not None:
            q = q.where(ContractResult.is_2025_plus == is_2025_plus)
            cq = cq.where(ContractResult.is_2025_plus == is_2025_plus)
        if manufacturer_match is not None:
            q = q.where(ContractResult.manufacturer_match == manufacturer_match)
            cq = cq.where(ContractResult.manufacturer_match == manufacturer_match)

        # по требованиям: сначала выбранные/accepted + по score
        q = q.order_by(ContractResult.accepted_for_nmc.desc(), ContractResult.ai_score.desc(), ContractResult.created_at.desc())
        q = q.offset((page - 1) * page_size).limit(page_size)

        total = (await db.execute(cq)).scalar_one()
        items = (await db.execute(q)).scalars().all()
        return int(total), list(items)

    async def upsert_contract_result(self, db: AsyncSession, *, values: dict) -> uuid.UUID:
        """
        UPSERT по uq_search_contract (search_id, reestr_number).
        Возвращает id записи.
        """
        stmt = insert(ContractResult).values(**values)
        update_cols = {k: stmt.excluded[k] for k in values.keys() if k not in {"id"}}
        stmt = stmt.on_conflict_do_update(
            constraint="uq_search_contract",
            set_=update_cols,
        ).returning(ContractResult.id)
        res = await db.execute(stmt)
        cid = res.scalar_one()
        return cid

    async def replace_comparison_rows(
        self,
        db: AsyncSession,
        *,
        contract_id: uuid.UUID,
        rows: Iterable[SpecComparisonRow],
    ) -> None:
        await db.execute(sa.delete(SpecComparisonRow).where(SpecComparisonRow.contract_result_id == contract_id))
        for r in rows:
            db.add(r)
        await db.flush()

    async def mark_accepted(self, db: AsyncSession, *, search_id: uuid.UUID, accepted_ids: set[uuid.UUID]) -> None:
        # Сброс
        await db.execute(
            sa.update(ContractResult)
            .where(ContractResult.search_id == search_id)
            .values(accepted_for_nmc=False)
        )
        if accepted_ids:
            await db.execute(
                sa.update(ContractResult)
                .where(ContractResult.search_id == search_id)
                .where(ContractResult.id.in_(list(accepted_ids)))
                .values(accepted_for_nmc=True)
            )
        await db.flush()
    
    async def list_for_search(self, db: AsyncSession, search_id: uuid.UUID) -> list[ContractResult]:
        """Получает все результаты для поиска (без пагинации)."""
        q = sa.select(ContractResult).where(ContractResult.search_id == search_id)
        q = q.order_by(ContractResult.accepted_for_nmc.desc(), ContractResult.ai_score.desc())
        result = await db.execute(q)
        return list(result.scalars().all())
    
    async def get(self, db: AsyncSession, result_id: uuid.UUID) -> ContractResult | None:
        """Получает результат по ID."""
        res = await db.execute(sa.select(ContractResult).where(ContractResult.id == result_id))
        return res.scalar_one_or_none()