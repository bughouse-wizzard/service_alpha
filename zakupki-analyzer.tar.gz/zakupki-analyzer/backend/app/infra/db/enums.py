"""
Перечисления для моделей базы данных.
"""
from enum import Enum


class SearchStatus(str, Enum):
    """Статусы поиска."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    STOPPED = "stopped"
    FAILED = "failed"


class MatchType(str, Enum):
    """Типы совпадения."""
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    NO_MATCH = "no_match"
    UNKNOWN = "unknown"
