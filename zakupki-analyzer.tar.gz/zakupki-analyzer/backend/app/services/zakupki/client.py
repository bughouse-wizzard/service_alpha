from __future__ import annotations

import asyncio
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
import json

import httpx
from bs4 import BeautifulSoup

from app.core.errors import AppError, ErrorCode
from app.core.settings import settings


@dataclass(frozen=True)
class FoundContractCard:
    reestr_number: str
    contract_url: str
    sign_date: Optional[str] = None
    price_total: Optional[str] = None


class ZakupkiClient:
    """
    Клиент для публичных HTML страниц zakupki.gov.ru
    В MVP используем URL-инжиниринг (results.html?...) и парсинг DOM.
    """

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(settings.zakupki_timeout_sec),
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Encoding": "gzip, deflate, br",
            },
            follow_redirects=True,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def _sleep_human(self) -> None:
        """Случайная задержка между запросами для соблюдения robots.txt"""
        await asyncio.sleep(random.uniform(settings.zakupki_min_delay_sec, settings.zakupki_max_delay_sec))

    async def _save_debug_html(self, html: str, url: str, prefix: str = "search") -> str:
        """Сохраняет сырой HTML для отладки (требование ТЗ)"""
        try:
            debug_dir = Path(tempfile.gettempdir()) / "zakupki_debug"
            debug_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{prefix}_{timestamp}_{hash(url) % 10000:04d}.html"
            filepath = debug_dir / filename
            
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"<!-- URL: {url} -->\n")
                f.write(f"<!-- Timestamp: {datetime.now().isoformat()} -->\n")
                f.write(html)
            
            # Также сохраняем метаданные
            meta_file = debug_dir / f"{prefix}_{timestamp}_{hash(url) % 10000:04d}.json"
            with open(meta_file, "w", encoding="utf-8") as f:
                json.dump({
                    "url": url,
                    "timestamp": datetime.now().isoformat(),
                    "filename": filename,
                    "size_bytes": len(html)
                }, f, indent=2, ensure_ascii=False)
            
            return str(filepath)
        except Exception:
            # Не падаем, если не удалось сохранить для отладки
            return ""

    async def fetch_results_html(self, params: Dict[str, Any]) -> Tuple[str, str]:
        """
        Получает HTML результатов поиска с заданными параметрами.
        
        Args:
            params: Параметры поиска (КТРУ, регион, даты и т.д.)
            
        Returns:
            Tuple[html: str, url: str] - HTML страницы и использованный URL
            
        Raises:
            AppError: Если не удалось получить результаты после всех попыток
        """
        # Строим URL из параметров
        url = self.build_results_url(**params)
        
        last_exc: Optional[Exception] = None
        for attempt in range(1, settings.zakupki_max_retries + 1):
            try:
                # Случайная задержка между запросами (требование ТЗ)
                await self._sleep_human()
                
                # Выполняем запрос
                response = await self._client.get(url)
                
                # Обрабатываем коды ошибок с backoff
                if response.status_code in (403, 503):
                    wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                    await asyncio.sleep(wait_time)
                    continue
                    
                # Проверяем успешность
                response.raise_for_status()
                
                html = response.text
                
                # Сохраняем сырой HTML для отладки (требование ТЗ)
                debug_path = await self._save_debug_html(html, url, "results")
                if debug_path:
                    print(f"Debug HTML saved to: {debug_path}")
                
                return html, url
                
            except httpx.TimeoutException as e:
                last_exc = e
                wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                await asyncio.sleep(wait_time)
            except httpx.HTTPStatusError as e:
                last_exc = e
                if e.response.status_code >= 500:
                    wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                    await asyncio.sleep(wait_time)
                else:
                    raise AppError(
                        ErrorCode.ZAKUPKI_FETCH_ERROR,
                        f"HTTP error {e.response.status_code} for {url}",
                        details={"status_code": e.response.status_code}
                    )
            except Exception as e:
                last_exc = e
                wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                await asyncio.sleep(wait_time)
        
        # Если все попытки не удались
        raise AppError(
            ErrorCode.ZAKUPKI_FETCH_TIMEOUT,
            f"Failed to fetch results after {settings.zakupki_max_retries} attempts: {url}",
            details={"cause": str(last_exc) if last_exc else "Unknown"}
        )

    def parse_results(self, html: str) -> Tuple[int, list[FoundContractCard]]:
        """
        Парсит HTML страницы результатов поиска.
        
        Args:
            html: HTML страницы результатов
            
        Returns:
            Tuple[found_total: int, cards: list[FoundContractCard]] - 
            общее количество найденных контрактов и список карточек
            
        Raises:
            AppError: Если не удалось распарсить HTML
        """
        try:
            soup = BeautifulSoup(html, "lxml")
            
            # 1. Извлекаем общее количество найденных контрактов
            found_total = 0
            # Ищем элемент с информацией о количестве результатов
            total_elements = soup.find_all(string=lambda s: s and any(
                keyword in s.lower() for keyword in ["найдено", "записей", "результат"]
            ))
            
            for element in total_elements:
                text = element.strip()
                # Пытаемся извлечь число из текста
                import re
                numbers = re.findall(r'\d+', text.replace(' ', '').replace(',', ''))
                if numbers:
                    found_total = max(found_total, int(numbers[0]))
                    break
            
            # 2. Извлекаем карточки контрактов
            cards: list[FoundContractCard] = []
            
            # Пробуем разные селекторы для карточек контрактов
            card_selectors = [
                "div.search-registry-entry-block",
                "div.registry-entry",
                "div.search-result-item",
                "div.contract-card"
            ]
            
            cards_container = None
            for selector in card_selectors:
                cards_container = soup.select(selector)
                if cards_container:
                    break
            
            if not cards_container:
                # Если не нашли стандартные селекторы, ищем по структуре
                cards_container = soup.find_all("div", class_=lambda x: x and "block" in x.lower())
            
            for card in cards_container:
                try:
                    # Извлекаем реестровый номер и ссылку
                    link_elem = card.find("a", href=True)
                    if not link_elem:
                        continue
                    
                    reestr_number = link_elem.get_text(strip=True)
                    contract_url = link_elem["href"]
                    
                    # Делаем URL абсолютным, если нужно
                    if contract_url.startswith("/"):
                        contract_url = f"{settings.zakupki_base}{contract_url}"
                    elif not contract_url.startswith("http"):
                        contract_url = f"{settings.zakupki_base}/epz/contract/contractCard/common-info.html?reestrNumber={reestr_number}"
                    
                    # Извлекаем дату подписания
                    sign_date = None
                    date_elem = card.find("span", class_=lambda x: x and "date" in x.lower() if x else False)
                    if not date_elem:
                        date_elem = card.find("div", class_=lambda x: x and "date" in x.lower() if x else False)
                    if date_elem:
                        sign_date = date_elem.get_text(strip=True)
                    
                    # Извлекаем общую цену
                    price_total = None
                    price_elem = card.find("span", class_=lambda x: x and "price" in x.lower() if x else False)
                    if not price_elem:
                        price_elem = card.find("div", class_=lambda x: x and "price" in x.lower() if x else False)
                    if price_elem:
                        price_total = price_elem.get_text(strip=True)
                    
                    cards.append(FoundContractCard(
                        reestr_number=reestr_number,
                        contract_url=contract_url,
                        sign_date=sign_date,
                        price_total=price_total
                    ))
                    
                except Exception as card_error:
                    # Пропускаем карточку с ошибкой, продолжаем парсинг остальных
                    continue
            
            return found_total, cards
            
        except Exception as e:
            raise AppError(
                ErrorCode.ZAKUPKI_PARSE_ERROR,
                "Failed to parse search results HTML",
                details={"cause": str(e)}
            )

    def build_results_url(
        self,
        *,
        ktru: str,
        region: str,
        date_from: str,
        date_to: str,
        statuses: list[str],
        fz44: bool = True,
        limit: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """
        Строит URL для поиска контрактов на zakupki.gov.ru.
        
        Args:
            ktru: Код КТРУ
            region: Регион/округ заказчика
            date_from: Дата начала периода (формат ДД.ММ.ГГГГ)
            date_to: Дата окончания периода (формат ДД.ММ.ГГГГ)
            statuses: Список статусов исполнения
            fz44: Использовать 44-ФЗ
            limit: Лимит результатов (опционально)
            **kwargs: Дополнительные параметры
            
        Returns:
            URL для поиска контрактов
        """
        base_url = f"{settings.zakupki_base}/epz/contract/search/results.html"
        
        params: list[tuple[str, str]] = [
            ("searchString", ktru),
            ("contractDateFrom", date_from),
            ("contractDateTo", date_to),
            ("customerPlace", region),
        ]
        
        if fz44:
            params.append(("fz44", "on"))
        
        # Статусы исполнения
        for i, status in enumerate(statuses):
            params.append((f"contractStageList_{i}", status))
        
        # Сортировка по дате (сначала свежие)
        params.append(("sortBy", "UPDATE_DATE"))
        params.append(("sortDirection", "false"))
        
        # Лимит результатов
        if limit:
            params.append(("recordsPerPage", "_50"))  # Максимум на странице
        
        # Дополнительные параметры
        for key, value in kwargs.items():
            if value is not None:
                params.append((key, str(value)))
        
        from urllib.parse import urlencode
        return f"{base_url}?{urlencode(params)}"

    async def fetch_contract_page(self, contract_url: str) -> str:
        """Получает HTML страницы карточки контракта по полному URL."""
        # Делаем запрос страницы карточки контракта
        response = await self._client.get(contract_url)
        response.raise_for_status()
        html = response.text
        # Сохраняем HTML для отладки
        await self._save_debug_html(html, contract_url, prefix="contract")
        return html

    def parse_contract_common(self, html: str) -> dict:
        """Парсит общую информацию из HTML карточки контракта (общая вкладка)."""
        soup = BeautifulSoup(html, "lxml")
        # Извлекаем наименование заказчика
        customer = None
        customer_label = soup.find(string=lambda s: s and "Заказчик" in s)
        if customer_label:
            customer_cell = customer_label.find_next("td") or customer_label.find_next("div")
            if customer_cell:
                customer = customer_cell.get_text(strip=True)
        # Можно извлечь другие поля при необходимости (номер, даты, др.)
        return {"customer": customer}

    async def fetch_contract_items(self, reestr_number: str) -> str:
        """Получает HTML вкладки 'Платежи и объекты закупки' по реестровому номеру."""
        items_url = f"{settings.zakupki_base}/epz/contract/contractCard/contractItems.html?reestrNumber={reestr_number}"
        response = await self._client.get(items_url)
        response.raise_for_status()
        html = response.text
        await self._save_debug_html(html, items_url, prefix="items")
        return html

    def parse_contract_items(self, html: str) -> dict:
        """Парсит HTML вкладки 'Платежи и объекты закупки' для извлечения спецификации и цены за единицу."""
        soup = BeautifulSoup(html, "lxml")
        # Ищем цену за единицу товара (если указана структурированно)
        unit_price = None
        price_elem = soup.find(string=lambda s: s and "Цена за единицу" in s)
        if price_elem:
            # Извлекаем числовое значение цены
            import re
            match = re.search(r"([\d\s,\.]+)", price_elem)
            if match:
                price_str = match.group(1).replace(" ", "").replace(",", ".")
                try:
                    unit_price = Decimal(price_str)
                except Exception:
                    unit_price = None
        # Извлекаем текст спецификации (характеристики)
        spec_text = soup.get_text(separator=" ").strip()
        return {"unit_price": unit_price, "spec_text": spec_text}

    async def fetch_attachments(self, reestr_number: str) -> str:
        """Получает HTML вкладки 'Вложения' по реестровому номеру (список документов)."""
        docs_url = f"{settings.zakupki_base}/epz/contract/contractCard/contractDocuments.html?reestrNumber={reestr_number}"
        response = await self._client.get(docs_url)
        response.raise_for_status()
        html = response.text
        await self._save_debug_html(html, docs_url, prefix="docs")
        return html

    def parse_attachments(self, html: str) -> Optional[str]:
        """Находит ссылку на файл 'Печатная форма' в HTML списка вложений."""
        soup = BeautifulSoup(html, "lxml")
        link_elem = soup.find("a", string=lambda s: s and "Печатная форма" in s)
        if link_elem:
            file_url = link_elem.get("href")
            # Если ссылка относительная, добавляем базовый домен
            if file_url and file_url.startswith("/"):
                file_url = f"{settings.zakupki_base}{file_url}"
            return file_url
        return None

    async def download_file(self, url: str) -> bytes:
        """Скачивает файл по URL и возвращает его содержимое в виде байт."""
        response = await self._client.get(url)
        response.raise_for_status()
        return response.content