## Важное про парсинг zakupki.gov.ru
В этом MVP-каркасе:
- реализован клиент для results.html (URL-инжиниринг) + DOM parse.
- глубокий парсинг карточки/вкладок/вложений (в т.ч. 2025+ “Печатная форма”) подключается следующим шагом в worker pipeline:
  FetchContractCard -> ParseCommonInfo -> ParsePaymentsAndObjects -> FetchAttachments -> DownloadPrintForm -> ExtractText