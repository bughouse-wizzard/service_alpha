from __future__ import annotations

import io

import pdfplumber
from docx import Document

from app.core.errors import AppError, ErrorCode


def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    try:
        out: list[str] = []
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for page in pdf.pages:
                txt = page.extract_text() or ""
                out.append(txt)
        return "\n".join(out).strip()
    except Exception as e:
        raise AppError(ErrorCode.DOC_TEXT_EXTRACT_ERROR, "PDF text extract failed", details={"cause": str(e)})


def extract_text_from_docx(docx_bytes: bytes) -> str:
    try:
        doc = Document(io.BytesIO(docx_bytes))
        out: list[str] = []
        for p in doc.paragraphs:
            if p.text:
                out.append(p.text)
        for t in doc.tables:
            for row in t.rows:
                out.append(" | ".join(cell.text.strip() for cell in row.cells))
        return "\n".join(out).strip()
    except Exception as e:
        raise AppError(ErrorCode.DOC_TEXT_EXTRACT_ERROR, "DOCX text extract failed", details={"cause": str(e)})