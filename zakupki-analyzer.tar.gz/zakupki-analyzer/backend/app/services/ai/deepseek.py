from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import httpx
import yaml
from pydantic import BaseModel, Field, ValidationError

from app.core.errors import AppError, ErrorCode
from app.core.settings import settings


class NormalizedAttributes(BaseModel):
    product_name: str | None = None
    ktru: str | None = None
    manufacturer: str | None = None
    attributes: list[dict[str, Any]] = Field(default_factory=list)


class CompareRow(BaseModel):
    name: str
    target: str | None = None
    actual: str | None = None
    status: str  # MATCH|DIFF|UNKNOWN
    reason: str | None = None
    weight: int = 1


class CompareResult(BaseModel):
    score: int = Field(..., ge=0, le=100)
    match_type: str  # IDENTICAL|HOMOGENEOUS|NO_MATCH
    manufacturer_found: str | None = None
    manufacturer_match: bool | None = None
    rows: list[CompareRow] = Field(default_factory=list)
    decision: str  # ACCEPT|REJECT|REVIEW


@dataclass(frozen=True)
class AiConfig:
    base_url: str
    timeout: int
    model_extraction: str
    model_reasoning: str
    prompts: dict[str, Any]
    gen_params: dict[str, Any]


def load_ai_config() -> AiConfig:
    with open(settings.ai_config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return AiConfig(
        base_url=cfg["deepseek_api"]["base_url"],
        timeout=int(cfg["deepseek_api"]["timeout"]),
        model_extraction=cfg["deepseek_api"]["models"]["extraction"],
        model_reasoning=cfg["deepseek_api"]["models"]["reasoning"],
        prompts=cfg["prompts"],
        gen_params=cfg["generation_params"],
    )


class DeepSeekClient:
    def __init__(self) -> None:
        if not settings.deepseek_api_key:
            # в тестах/без ключа позволяем поднимать систему, но AI будет падать controlled-ошибкой
            pass
        self.cfg = load_ai_config()
        self.client = httpx.AsyncClient(
            base_url=self.cfg.base_url,
            timeout=httpx.Timeout(self.cfg.timeout),
            headers={"Authorization": f"Bearer {settings.deepseek_api_key or ''}"},
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def _chat_json(self, *, model: str, system: str, user: str, params: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            **params,
        }
        try:
            r = await self.client.post("/v1/chat/completions", json=payload)
            r.raise_for_status()
            data = r.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)
        except httpx.TimeoutException as e:
            raise AppError(ErrorCode.LLM_TIMEOUT, "LLM timeout", details={"cause": str(e)})
        except json.JSONDecodeError as e:
            # self-correction
            fixed = await self._self_correct(model=model, bad_text=content, err=str(e))
            return fixed
        except Exception as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "LLM call failed", details={"cause": str(e)})

    async def _self_correct(self, *, model: str, bad_text: str, err: str) -> dict[str, Any]:
        system = "Ты исправляешь JSON. Верни только валидный JSON без комментариев."
        user = f"Ты вернул невалидный JSON. Ошибка: {err}\n\nТекст:\n{bad_text}\n\nИсправь и верни только JSON."
        r = await self.client.post(
            "/v1/chat/completions",
            json={
                "model": model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "temperature": 0.0,
                "max_tokens": 1500,
            },
        )
        r.raise_for_status()
        data = r.json()
        content = data["choices"][0]["message"]["content"]
        return json.loads(content)

    async def normalize(self, raw_text: str) -> NormalizedAttributes:
        p = self.cfg.prompts["normalization"]
        user = p["user_template"].format(raw_text=raw_text)
        res = await self._chat_json(
            model=self.cfg.model_extraction,
            system=p["system"],
            user=user,
            params=self.cfg.gen_params["extraction"],
        )
        try:
            return NormalizedAttributes.model_validate(res)
        except ValidationError as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "Normalization schema invalid", details={"cause": str(e)})

    async def compare(self, *, target_json: dict, found_json: dict, target_manufacturer: str | None) -> CompareResult:
        p = self.cfg.prompts["comparison"]
        user = p["user_template"].format(
            target_json=json.dumps(target_json, ensure_ascii=False),
            found_json=json.dumps(found_json, ensure_ascii=False),
            target_manufacturer=target_manufacturer or "null",
        )
        res = await self._chat_json(
            model=self.cfg.model_reasoning,
            system=p["system"],
            user=user,
            params=self.cfg.gen_params["scoring"],
        )
        try:
            return CompareResult.model_validate(res)
        except ValidationError as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "Compare schema invalid", details={"cause": str(e)})

    async def extract_contract_specs(self, doc_text: str, ktru: str, object_name: str) -> NormalizedAttributes:
        """Извлекает характеристики из текста печатной формы контракта с помощью AI."""
        p = self.cfg.prompts.get("extract_specs_from_contract_doc") or self.cfg.prompts.get("normalization")
        user_prompt = p["user_template"].format(doc_text=doc_text, ktru=ktru, object_name=object_name)
        res = await self._chat_json(
            model=self.cfg.model_extraction,
            system=p["system"],
            user=user_prompt,
            params=self.cfg.gen_params["extraction"],
        )
        try:
            return NormalizedAttributes.model_validate(res)
        except ValidationError as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "Contract spec extraction schema invalid", details={"cause": str(e)})