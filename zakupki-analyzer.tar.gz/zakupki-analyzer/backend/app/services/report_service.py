from __future__ import annotations

import io
import json
import uuid
import zipfile
from decimal import Decimal

import sqlalchemy as sa
from openpyxl import Workbook
from sqlalchemy.ext.asyncio import AsyncSession

from app.infra.db.models import ContractResult, SearchRequest, SpecComparisonRow


class ReportService:
    def __init__(self, *, db: AsyncSession) -> None:
        self.db = db

    async def build_zip_report(self, search_id: str, *, request_id: str) -> tuple[bytes, str]:
        sid = uuid.UUID(search_id)

        search = (await self.db.execute(sa.select(SearchRequest).where(SearchRequest.id == sid))).scalar_one_or_none()
        if not search:
            raise ValueError("search not found")

        results = (
            (await self.db.execute(sa.select(ContractResult).where(ContractResult.search_id == sid).order_by(ContractResult.accepted_for_nmc.desc(), ContractResult.ai_score.desc())))
            .scalars()
            .all()
        )

        # JSON
        payload = {
            "search": {
                "id": str(search.id),
                "created_at": search.created_at.isoformat(),
                "status": search.status,
                "object_name": search.object_name,
                "ktru_code": search.ktru_code,
                "manufacturer_target": search.manufacturer_target,
                "date_from": str(search.date_from),
                "date_to": str(search.date_to),
                "found_total": search.found_total,
                "processed_count": search.processed_count,
                "nmc_value": str(search.nmc_value) if search.nmc_value is not None else None,
                "selected_contract_ids": [str(x) for x in search.selected_contract_ids],
                "target_specs": search.target_specs,
            },
            "results": [
                {
                    "id": str(r.id),
                    "reestr_number": r.reestr_number,
                    "contract_url": r.contract_url,
                    "sign_date": str(r.sign_date) if r.sign_date else None,
                    "unit_price": str(r.unit_price) if r.unit_price is not None else None,
                    "match_type": r.match_type,
                    "ai_score": r.ai_score,
                    "manufacturer_found": r.manufacturer_found,
                    "manufacturer_match": r.manufacturer_match,
                    "accepted_for_nmc": r.accepted_for_nmc,
                    "ai_analysis": r.ai_analysis,
                }
                for r in results
            ],
        }
        json_bytes = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")

        # XLSX
        wb = Workbook()
        ws = wb.active
        ws.title = "Results"

        ws.append(["Search ID", str(search.id)])
        ws.append(["Object", search.object_name or ""])
        ws.append(["KTRU", search.ktru_code])
        ws.append(["Status", search.status])
        ws.append(["Found total", search.found_total])
        ws.append(["Processed", search.processed_count])
        ws.append(["NMC", float(search.nmc_value) if search.nmc_value is not None else ""])
        ws.append([])

        ws.append([
            "Accepted",
            "Reestr number",
            "Sign date",
            "Unit price",
            "Match type",
            "AI score",
            "Manufacturer found",
            "Manufacturer match",
            "URL",
        ])

        for r in results:
            ws.append([
                "YES" if r.accepted_for_nmc else "",
                r.reestr_number,
                str(r.sign_date) if r.sign_date else "",
                float(r.unit_price) if r.unit_price is not None else "",
                r.match_type,
                r.ai_score,
                r.manufacturer_found or "",
                "" if r.manufacturer_match is None else ("YES" if r.manufacturer_match else "NO"),
                r.contract_url,
            ])

        bio = io.BytesIO()
        wb.save(bio)
        xlsx_bytes = bio.getvalue()

        # ZIP
        zbio = io.BytesIO()
        with zipfile.ZipFile(zbio, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("report.json", json_bytes)
            zf.writestr("report.xlsx", xlsx_bytes)

        return zbio.getvalue(), f"nmck_report_{search_id}.zip"