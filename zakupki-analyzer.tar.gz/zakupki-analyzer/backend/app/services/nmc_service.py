from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Iterable, Union, Optional, List, Any
import logging

logger = logging.getLogger(__name__)


def calc_nmc_avg(unit_prices: Iterable[Union[Decimal, float, str, int, None]]) -> Optional[Decimal]:
    """
    Рассчитывает среднее значение НМЦК из списка цен.
    
    Args:
        unit_prices: Итерируемый объект с ценами (Decimal, float, str, int или None)
        
    Returns:
        Decimal: Среднее значение, округленное до 2 знаков после запятой
        None: Если нет валидных цен или произошла ошибка
        
    Raises:
        ValueError: Если входные данные некорректны
    """
    prices: List[Decimal] = []
    
    for price in unit_prices:
        if price is None:
            continue
            
        try:
            if isinstance(price, Decimal):
                prices.append(price)
            elif isinstance(price, (int, float)):
                # Преобразуем float в Decimal через строку для точности
                prices.append(Decimal(str(price)))
            elif isinstance(price, str):
                # Убираем пробелы и заменяем запятые на точки
                cleaned = price.strip().replace(',', '.')
                # Убираем валютные символы и пробелы
                cleaned = ''.join(ch for ch in cleaned if ch.isdigit() or ch in '.-')
                if cleaned:
                    prices.append(Decimal(cleaned))
            else:
                logger.warning(f"calc_nmc_avg: неподдерживаемый тип цены: {type(price)}")
                continue
        except (InvalidOperation, ValueError) as e:
            logger.warning(f"calc_nmc_avg: ошибка преобразования цены {price}: {e}")
            continue
    
    if not prices:
        logger.debug("calc_nmc_avg: нет валидных цен для расчета")
        return None
    
    try:
        # Суммируем все цены
        total = sum(prices, start=Decimal("0"))
        
        # Вычисляем среднее
        count = Decimal(len(prices))
        average = total / count
        
        # Округляем до 2 знаков после запятой (копеек)
        rounded = average.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        
        logger.debug(
            f"calc_nmc_avg: рассчитано среднее из {len(prices)} цен: "
            f"total={total}, count={count}, avg={average}, rounded={rounded}"
        )
        
        return rounded
    except (InvalidOperation, ZeroDivisionError) as e:
        logger.error(f"calc_nmc_avg: ошибка расчета среднего: {e}")
        return None


def calc_nmc_avg_safe(unit_prices: Iterable[Any]) -> Optional[Decimal]:
    """
    Безопасная версия calc_nmc_avg, которая никогда не выбрасывает исключений.
    
    Args:
        unit_prices: Итерируемый объект с ценами любого типа
        
    Returns:
        Decimal: Среднее значение или None при любой ошибке
    """
    try:
        return calc_nmc_avg(unit_prices)
    except Exception as e:
        logger.error(f"calc_nmc_avg_safe: непредвиденная ошибка: {e}")
        return None