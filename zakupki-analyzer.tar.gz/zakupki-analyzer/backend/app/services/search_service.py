from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional, Set, List

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import ErrorCode
from app.core.logging import log
from app.core.settings import settings
from app.infra.db.models import SearchRequest, ContractResult
from app.infra.db.repos import ResultRepo, SearchRepo
from app.infra.events.event_broker import RedisEventBroker, StreamEvent
from app.schemas.search import (
    SearchBrief,
    SearchCreateRequest,
    SearchDetailsResponse,
    SearchListResponse,
    SearchResultListResponse,
    SelectionPatchRequest,
)
from app.workers.tasks import run_search_pipeline  # celery task


class SearchService:
    def __init__(self, *, db: AsyncSession, broker: RedisEventBroker) -> None:
        self.db = db
        self.broker = broker
        self.search_repo = SearchRepo()
        self.result_repo = ResultRepo()
    
    async def create_search(self, request: SearchCreateRequest) -> SearchBrief:
        """Создает новый поиск и запускает фоновую задачу."""
        from datetime import datetime
        
        # Создаем запись в БД
        search = SearchRequest(
            id=uuid.uuid4(),
            object_name=request.object_name,
            ktru_code=request.ktru_code,
            manufacturer_target=request.manufacturer_target,
            customer_region=request.customer_region,
            law=request.law,
            execution_statuses=request.execution_statuses or ["Исполнение завершено", "Исполнение прекращено"],
            date_from=request.date_from,
            date_to=request.date_to,
            limit_contracts=request.limit_contracts,
            target_specs_text=request.target_specs_text,
            status="pending",
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        
        await self.search_repo.create(self.db, search)
        await self.db.commit()
        
        # Запускаем фоновую задачу
        run_search_pipeline.delay(str(search.id))
        
        # Обновляем статус на running
        search.status = "running"
        await self.search_repo.update(self.db, search)
        await self.db.commit()
        
        return SearchBrief(
            id=search.id,
            ktru=search.ktru_code,
            object_name=search.object_name,
            status=search.status,
            created_at=search.created_at,
            updated_at=search.updated_at,
            contracts_found=search.found_total,
            contracts_processed=search.processed_count,
        )
    
    async def stop_search(self, search_id: uuid.UUID) -> bool:
        """Останавливает выполняющийся поиск."""
        search = await self.search_repo.get(self.db, search_id)
        if not search:
            return False
        
        if search.status not in ["running", "pending"]:
            return False
        
        # Устанавливаем флаг остановки
        search.stop_requested = True
        search.status = "stopped"
        search.updated_at = datetime.utcnow()
        
        await self.search_repo.update(self.db, search)
        await self.db.commit()
        
        # Отправляем событие об остановке
        await self.broker.emit(str(search_id), StreamEvent("status", {"status": "stopped"}))
        
        return True
    
    async def auto_select_top_3(self, search_id: uuid.UUID) -> tuple[Set[uuid.UUID], Optional[Decimal]]:
        """
        Автоматически выбирает top-3 контракта для расчёта НМЦК.
        
        Правила выбора (MVP):
        1. Приоритет по match_type: IDENTICAL > HOMOGENEOUS > NO_MATCH
        2. При одинаковом match_type: сортировка по ai_score DESC
        3. При одинаковом ai_score: сортировка по дате создания DESC (сначала свежие)
        
        Args:
            search_id: ID поиска
            
        Returns:
            Tuple[selected_ids, nmc_value]: 
            - selected_ids: Set выбранных ID контрактов (до 3)
            - nmc_value: Рассчитанное значение НМЦК или None
        """
        # Создаем case выражение для приоритизации match_type
        match_type_priority = sa.case(
            (ContractResult.match_type == "IDENTICAL", 3),
            (ContractResult.match_type == "HOMOGENEOUS", 2),
            else_=1,
        )
        
        # Запрос для получения top-3 контрактов
        query = (
            sa.select(
                ContractResult.id,
                ContractResult.unit_price,
                ContractResult.match_type,
                ContractResult.ai_score,
                ContractResult.created_at,
            )
            .where(ContractResult.search_id == search_id)
            .order_by(
                match_type_priority.desc(),
                ContractResult.ai_score.desc(),
                ContractResult.created_at.desc(),
            )
            .limit(3)
        )
        
        result = await self.db.execute(query)
        rows = result.all()
        
        selected_ids: Set[uuid.UUID] = set()
        prices: List[Decimal] = []
        
        for row in rows:
            if row.id:
                selected_ids.add(row.id)
            
            if row.unit_price is not None:
                prices.append(row.unit_price)
        
        # Помечаем выбранные контракты как accepted_for_nmc
        if selected_ids:
            await self.result_repo.mark_accepted(self.db, search_id=search_id, accepted_ids=selected_ids)
        
        # Рассчитываем НМЦК
        nmc_value = calc_nmc_avg(prices) if prices else None
        
        # Обновляем поиск с выбранными ID и НМЦК
        if selected_ids or nmc_value is not None:
            update_values = {}
            if selected_ids:
                update_values["selected_contract_ids"] = list(selected_ids)
            if nmc_value is not None:
                update_values["nmc_value"] = nmc_value
            
            if update_values:
                await self.db.execute(
                    sa.update(SearchRequest)
                    .where(SearchRequest.id == search_id)
                    .values(**update_values)
                )
                await self.db.commit()
        
        # Эмитим событие с результатами автовыбора
        await self.broker.emit(
            str(search_id),
            StreamEvent("selection", {
                "selected_count": len(selected_ids),
                "nmc_value": str(nmc_value) if nmc_value else None,
                "search_id": str(search_id),
                "auto_selected": True,
            })
        )
        
        log().info(
            "auto_select_top_3_completed",
            search_id=str(search_id),
            selected_count=len(selected_ids),
            nmc_value=str(nmc_value) if nmc_value else None,
        )
        
        return selected_ids, nmc_value

    async def create_and_start(self, payload: SearchCreateRequest, *, request_id: str) -> SearchDetailsResponse:
        # defaults: 3 years window
        today = date.today()
        date_to = payload.date_to or today
        date_from = payload.date_from or (today - timedelta(days=365 * 3))

        if not payload.ktru_code.strip():
            raise ValueError("ktru_code empty")

        obj = SearchRequest(
            status="CREATED",
            input_source=payload.input_source,
            object_name=payload.object_name,
            ktru_code=payload.ktru_code.strip(),
            okpd2_code=payload.okpd2_code,
            manufacturer_target=payload.manufacturer_target,
            customer_region=payload.customer_region,
            law=payload.law,
            date_from=date_from,
            date_to=date_to,
            execution_statuses=payload.execution_statuses,
            limit_contracts=payload.limit_contracts,
            target_specs={"raw_text": payload.target_specs_text or "", "normalized": {}},
            selected_contract_ids=[],
        )

        async with self.db.begin():
            await self.search_repo.create(self.db, obj)

        search_id = str(obj.id)
        await self.broker.emit(search_id, StreamEvent("progress", {"status": "CREATED", "processed": 0, "limit": obj.limit_contracts}))
        await self.broker.emit(search_id, StreamEvent("log", {"msg": "Search created", "request_id": request_id}))

        # стартуем Celery
        task = run_search_pipeline.apply_async(
            args=[search_id],
            queue="nmck",
            kwargs={"request_id": request_id},
        )
        async with self.db.begin():
            obj.status = "RUNNING"
            obj.celery_task_id = task.id
            await self.search_repo.update(self.db, obj)

        await self.broker.emit(search_id, StreamEvent("progress", {"status": "RUNNING", "processed": 0, "limit": obj.limit_contracts}))
        return self._to_details(obj)

    async def request_stop(self, search_id: str, *, request_id: str) -> bool:
        sid = uuid.UUID(search_id)
        obj = await self.search_repo.get(self.db, sid)
        if not obj:
            return False

        async with self.db.begin():
            obj.stop_requested = True
            # статус обновит worker на STOPPED, но UI должен видеть stop flag сразу
            await self.search_repo.update(self.db, obj)

        await self.broker.emit(search_id, StreamEvent("log", {"msg": "Stop requested", "request_id": request_id}))
        await self.broker.emit(search_id, StreamEvent("progress", {"status": "STOP_REQUESTED"}))

        # revoke (best-effort)
        try:
            if obj.celery_task_id:
                from app.workers.celery_app import celery_app
                celery_app.control.revoke(obj.celery_task_id, terminate=False)
        except Exception:
            log().exception("celery_revoke_failed", search_id=search_id, request_id=request_id)

        return True

    async def list_searches(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        ktru: str | None = None,
        status: str | None = None,
        date_from: date | None = None,
        date_to: date | None = None,
        object_name: str | None = None,
        manufacturer_target: str | None = None,
        request_id: str,
    ) -> SearchListResponse:
        total, items = await self.search_repo.list(
            self.db, 
            page=page, 
            page_size=page_size, 
            ktru=ktru, 
            status=status, 
            date_from=date_from, 
            date_to=date_to,
            object_name=object_name,
            manufacturer_target=manufacturer_target,
        )
        return SearchListResponse(
            page=page,
            page_size=page_size,
            total=total,
            items=[
                {
                    "id": it.id,
                    "created_at": it.created_at.isoformat(),
                    "status": it.status,
                    "object_name": it.object_name,
                    "ktru_code": it.ktru_code,
                    "found_total": it.found_total,
                    "processed_count": it.processed_count,
                    "nmc_value": it.nmc_value,
                }
                for it in items
            ],
        )

    async def get_search(self, search_id: str, *, request_id: str) -> SearchDetailsResponse | None:
        sid = uuid.UUID(search_id)
        obj = await self.search_repo.get(self.db, sid)
        return self._to_details(obj) if obj else None

    async def list_results(
        self,
        *,
        search_id: str,
        page: int,
        page_size: int,
        reestr_q: str | None,
        match_type: str | None,
        min_score: int | None,
        request_id: str,
    ) -> SearchResultListResponse:
        sid = uuid.UUID(search_id)
        total, items = await self.result_repo.list_results(
            self.db,
            search_id=sid,
            page=page,
            page_size=page_size,
            reestr_q=reestr_q,
            match_type=match_type,
            min_score=min_score,
        )
        return SearchResultListResponse(
            search_id=sid,
            page=page,
            page_size=page_size,
            total=total,
            items=[
                {
                    "id": it.id,
                    "reestr_number": it.reestr_number,
                    "contract_url": it.contract_url,
                    "sign_date": it.sign_date,
                    "unit_price": it.unit_price,
                    "currency": it.currency,
                    "match_type": it.match_type,
                    "ai_score": it.ai_score,
                    "manufacturer_found": it.manufacturer_found,
                    "manufacturer_match": it.manufacturer_match,
                    "is_2025_plus": it.is_2025_plus,
                    "accepted_for_nmc": it.accepted_for_nmc,
                }
                for it in items
            ],
        )

    async def get_search_results(
        self,
        search_id: uuid.UUID,
        accepted_for_nmc: Optional[bool] = None,
        is_2025_plus: Optional[bool] = None,
        manufacturer_match: Optional[bool] = None,
        page: int = 1,
        page_size: int = 50,
    ) -> SearchResultListResponse:
        """Получает результаты поиска с фильтрацией."""
        # Преобразуем фильтры для репозитория
        filters = {}
        if accepted_for_nmc is not None:
            filters["accepted_for_nmc"] = accepted_for_nmc
        if is_2025_plus is not None:
            filters["is_2025_plus"] = is_2025_plus
        if manufacturer_match is not None:
            filters["manufacturer_match"] = manufacturer_match
        
        # Получаем результаты с фильтрацией
        total, items = await self.result_repo.list_results(
            self.db,
            search_id=search_id,
            page=page,
            page_size=page_size,
            **filters
        )
        
        return SearchResultListResponse(
            search_id=search_id,
            page=page,
            page_size=page_size,
            total=total,
            items=[
                {
                    "id": it.id,
                    "reestr_number": it.reestr_number,
                    "contract_url": it.contract_url,
                    "sign_date": it.sign_date,
                    "unit_price": it.unit_price,
                    "currency": it.currency,
                    "match_type": it.match_type,
                    "ai_score": it.ai_score,
                    "manufacturer_found": it.manufacturer_found,
                    "manufacturer_match": it.manufacturer_match,
                    "is_2025_plus": it.is_2025_plus,
                    "accepted_for_nmc": it.accepted_for_nmc,
                }
                for it in items
            ],
        )

    async def update_selection(
        self, search_id: str, payload: SelectionPatchRequest, *, request_id: str
    ) -> SearchDetailsResponse | None:
        sid = uuid.UUID(search_id)
        obj = await self.search_repo.get(self.db, sid)
        if not obj:
            return None

        selected_set = set(payload.selected_contract_ids)
        
        # Валидация: проверяем, что все выбранные контракты принадлежат этому поиску
        if selected_set:
            # Получаем ID контрактов, которые принадлежат этому поиску
            valid_contracts_query = sa.select(ContractResult.id).where(
                ContractResult.search_id == sid,
                ContractResult.id.in_(selected_set)
            )
            valid_contracts_result = await self.db.execute(valid_contracts_query)
            valid_contracts = {row[0] for row in valid_contracts_result.all()}
            
            # Проверяем, что все выбранные контракты валидны
            invalid_contracts = selected_set - valid_contracts
            if invalid_contracts:
                raise ValueError(
                    f"Некоторые контракты не принадлежат этому поиску или не существуют: "
                    f"{[str(cid) for cid in invalid_contracts]}"
                )
            
            # Получаем цены выбранных контрактов
            prices_query = sa.select(ContractResult.unit_price).where(
                ContractResult.search_id == sid,
                ContractResult.id.in_(selected_set)
            )
            prices_result = await self.db.execute(prices_query)
            prices = [row[0] for row in prices_result.all() if row[0] is not None]
            
            # Рассчитываем НМЦК с использованием единого источника истины
            nmc_value = calc_nmc_avg(prices)
        else:
            nmc_value = None
        
        # Обновляем accepted_for_nmc для всех контрактов этого поиска
        # Сначала сбрасываем все флаги
        reset_query = sa.update(ContractResult).where(
            ContractResult.search_id == sid
        ).values(accepted_for_nmc=False)
        await self.db.execute(reset_query)
        
        # Затем устанавливаем флаги для выбранных контрактов
        if selected_set:
            update_query = sa.update(ContractResult).where(
                ContractResult.search_id == sid,
                ContractResult.id.in_(selected_set)
            ).values(accepted_for_nmc=True)
            await self.db.execute(update_query)

        async with self.db.begin():
            obj.selected_contract_ids = list(selected_set)
            obj.nmc_value = nmc_value
            await self.search_repo.update(self.db, obj)

        # Эмитим событие с обновлённым НМЦК
        await self.broker.emit(
            search_id, 
            StreamEvent("selection", {
                "selected_count": len(selected_set), 
                "nmc_value": str(nmc_value) if nmc_value else None,
                "search_id": search_id
            })
        )
        
        log().info(
            "selection_updated",
            search_id=search_id,
            selected_count=len(selected_set),
            nmc_value=str(nmc_value) if nmc_value else None,
            request_id=request_id,
        )
        
        return self._to_details(obj)

    def _to_details(self, obj: SearchRequest) -> SearchDetailsResponse:
        return SearchDetailsResponse(
            id=obj.id,
            created_at=obj.created_at.isoformat(),
            updated_at=obj.updated_at.isoformat(),
            status=obj.status,
            input_source=obj.input_source,
            object_name=obj.object_name,
            ktru_code=obj.ktru_code,
            okpd2_code=obj.okpd2_code,
            manufacturer_target=obj.manufacturer_target,
            customer_region=obj.customer_region,
            law=obj.law,
            date_from=obj.date_from,
            date_to=obj.date_to,
            execution_statuses=list(obj.execution_statuses),
            limit_contracts=obj.limit_contracts,
            found_total=obj.found_total,
            processed_count=obj.processed_count,
            nmc_value=obj.nmc_value,
            selected_contract_ids=list(obj.selected_contract_ids),
            target_specs=obj.target_specs,
            error_code=obj.error_code,
            error_message=obj.error_message,
        )
    
    async def generate_report(self, search_id: uuid.UUID) -> dict:
        """Генерирует отчет по поиску в формате ZIP с Excel и JSON."""
        from datetime import datetime
        import json
        import zipfile
        import tempfile
        import os
        
        # Получаем данные поиска
        search = await self.search_repo.get(self.db, search_id)
        if not search:
            raise ValueError(f"Поиск с ID {search_id} не найден")
        
        # Получаем результаты поиска
        results = await self.result_repo.list_for_search(self.db, search_id)
        
        # Создаем временный файл для ZIP
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp_zip:
            zip_path = tmp_zip.name
        
        try:
            # Создаем ZIP архив
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # 1. JSON файл с полными данными
                report_data = {
                    "search_info": {
                        "id": str(search.id),
                        "object_name": search.object_name,
                        "ktru_code": search.ktru_code,
                        "manufacturer_target": search.manufacturer_target,
                        "created_at": search.created_at.isoformat(),
                        "status": search.status,
                        "found_total": search.found_total,
                        "processed_count": search.processed_count,
                        "nmc_value": str(search.nmc_value) if search.nmc_value else None,
                        "selected_contract_ids": [str(id) for id in search.selected_contract_ids]
                    },
                    "results": [
                        {
                            "id": str(r.id),
                            "reestr_number": r.reestr_number,
                            "contract_url": r.contract_url,
                            "sign_date": r.sign_date.isoformat() if r.sign_date else None,
                            "unit_price": str(r.unit_price) if r.unit_price else None,
                            "currency": r.currency,
                            "match_type": r.match_type,
                            "ai_score": r.ai_score,
                            "manufacturer_found": r.manufacturer_found,
                            "manufacturer_match": r.manufacturer_match,
                            "is_2025_plus": r.is_2025_plus,
                            "accepted_for_nmc": r.accepted_for_nmc,
                            "created_at": r.created_at.isoformat() if r.created_at else None
                        }
                        for r in results
                    ]
                }
                
                # Добавляем JSON в ZIP
                json_data = json.dumps(report_data, ensure_ascii=False, indent=2)
                zipf.writestr(f"report_{search_id}.json", json_data)
                
                # 2. Excel файл (упрощенный CSV формат)
                import csv
                from io import StringIO
                
                # Создаем CSV для Excel
                csv_buffer = StringIO()
                csv_writer = csv.writer(csv_buffer)
                
                # Заголовки
                headers = [
                    "Номер реестра", "Дата подписания", "Цена", "Валюта",
                    "Тип соответствия", "AI оценка", "Производитель",
                    "Совпадение производителя", "Контракт 2025+", "Включен в НМЦК"
                ]
                csv_writer.writerow(headers)
                
                # Данные
                for r in results:
                    row = [
                        r.reestr_number or "",
                        r.sign_date.strftime("%Y-%m-%d") if r.sign_date else "",
                        str(r.unit_price) if r.unit_price else "",
                        r.currency or "",
                        r.match_type or "",
                        str(r.ai_score) if r.ai_score else "",
                        r.manufacturer_found or "",
                        "Да" if r.manufacturer_match else "Нет",
                        "Да" if r.is_2025_plus else "Нет",
                        "Да" if r.accepted_for_nmc else "Нет"
                    ]
                    csv_writer.writerow(row)
                
                # Добавляем CSV в ZIP
                zipf.writestr(f"report_{search_id}.csv", csv_buffer.getvalue())
            
            # Читаем ZIP файл в байты
            with open(zip_path, 'rb') as f:
                zip_bytes = f.read()
            
            return {
                "filename": f"report_{search_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
                "content": zip_bytes,
                "content_type": "application/zip"
            }
            
        finally:
            # Удаляем временный файл
            if os.path.exists(zip_path):
                os.unlink(zip_path)
    
    async def get_comparison_data(self, result_id: uuid.UUID) -> dict:
        """Получает данные сравнения для конкретного результата."""
        result = await self.result_repo.get(self.db, result_id)
        if not result:
            raise ValueError(f"Результат с ID {result_id} не найден")
        
        # Извлекаем данные сравнения из raw_data_json
        comparison_data = {
            "result_id": str(result.id),
            "contract_id": result.reestr_number,
            "rows": []
        }
        
        if result.raw_data_json and "comparison" in result.raw_data_json:
            comparison_data["rows"] = result.raw_data_json["comparison"]
        
        return comparison_data
    
    async def stream_search_events(self, search_id: str):
        """Поток событий для поиска."""
        from app.infra.events.event_broker import StreamEvent
        
        # Создаем генератор событий
        async for event in self.broker.subscribe(search_id):
            yield event


def calc_nmc_avg(prices: list[Decimal]) -> Decimal:
    """Рассчитывает среднюю цену для НМЦК."""
    if not prices:
        return Decimal("0")
    
    # Исключаем нулевые и отрицательные цены
    valid_prices = [p for p in prices if p and p > Decimal("0")]
    if not valid_prices:
        return Decimal("0")
    
    # Рассчитываем среднее
    total = sum(valid_prices)
    avg = total / len(valid_prices)
    
    # Округляем до 2 знаков после запятой
    return avg.quantize(Decimal("0.01"))