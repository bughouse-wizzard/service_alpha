# Zakupki Analyzer - Backend

## Описание
Backend для MVP системы поиска контрактов ЕИС и расчета НМЦК:
- FastAPI (REST + OpenAPI)
- PostgreSQL only (async SQLAlchemy 2.0 + asyncpg) + Alembic
- Celery + Redis (broker) для фонового парсинга/AI
- SSE (/api/search/{id}/events) для live-прогресса/результатов
- DeepSeek (OpenAI-совместимый API) через YAML-конфиг
- Экспорт отчёта: XLSX + JSON

## Быстрый старт (Docker)

### 1. Клонирование и настройка
```bash
git clone https://git.dipal.ru/av/zakupki-analyzer.git
cd zakupki-analyzer
```

### 2. Запуск всех сервисов
```bash
# Запуск всех сервисов в фоновом режиме
docker-compose up -d

# Или с логами
docker-compose up
```

### 3. Применение миграций базы данных
```bash
# Применить миграции
docker-compose exec backend alembic upgrade head

# Или использовать Makefile
make migrate
```

### 4. Проверка работоспособности
```bash
# Health check
curl http://localhost:8000/health

# Версия API
curl http://localhost:8000/version

# Документация Swagger/OpenAPI
# Откройте в браузере: http://localhost:8000/docs
```

## Структура проекта
```
backend/
├── app/
│   ├── api/           # FastAPI роутеры
│   ├── core/          # Настройки, middleware, логирование
│   ├── domain/        # Бизнес-логика
│   ├── infra/         # Инфраструктура (БД, кэш, хранилище)
│   ├── schemas/       # Pydantic схемы
│   ├── services/      # Сервисный слой
│   ├── workers/       # Celery задачи
│   └── tests/         # Тесты
├── alembic/           # Миграции базы данных
├── Dockerfile
└── requirements.txt
```

## Основной API

### Создание поиска
```bash
curl -X POST http://localhost:8000/api/search \
  -H "Content-Type: application/json" \
  -d '{
    "object_name": "Бумага офисная",
    "ktru_code": "22.11.11.110",
    "customer_region": "СЗФО",
    "date_from": "2023-01-01",
    "date_to": "2026-01-23",
    "limit_contracts": 10,
    "execution_statuses": ["Исполнение завершено"],
    "law": "44"
  }'
```

### Получение списка поисков
```bash
# Получить все поиски с пагинацией
curl "http://localhost:8000/api/search?page=1&size=10"

# С фильтрацией по статусу
curl "http://localhost:8000/api/search?status=RUNNING"

# С фильтрацией по КТРУ
curl "http://localhost:8000/api/search?ktru=22.11.11.110"
```

### Получение деталей поиска
```bash
curl http://localhost:8000/api/search/{search_id}
```

### Остановка поиска
```bash
curl -X POST http://localhost:8000/api/search/{search_id}/stop
```

### Получение результатов поиска
```bash
# С пагинацией
curl "http://localhost:8000/api/search/{search_id}/results?page=1&size=20"

# С фильтрацией по AI Score
curl "http://localhost:8000/api/search/{search_id}/results?min_score=80"

# С фильтрацией по типу совпадения
curl "http://localhost:8000/api/search/{search_id}/results?match_type=IDENTICAL"
```

### SSE поток событий (прогресс)
```bash
# Подключение к SSE потоку
curl -N http://localhost:8000/api/search/{search_id}/events
```

### Экспорт отчета
```bash
# Скачать отчет в формате ZIP (XLSX + JSON)
curl -o report.zip http://localhost:8000/api/search/{search_id}/report
```

## Управление через Makefile

```bash
# Запуск всех сервисов
make up

# Остановка всех сервисов
make down

# Просмотр логов
make logs

# Запуск unit-тестов
make test

# Запуск интеграционных тестов
make test-integration

# Применение миграций
make migrate

# Проверка кода линтером
make lint

# Форматирование кода
make format

# Очистка временных файлов
make clean
```

## Тестирование

### Unit-тесты
```bash
cd backend
python -m pytest app/tests/ -v
```

### Тесты с покрытием кода
```bash
# Запуск тестов с измерением покрытия
cd backend
python -m pytest --cov=app --cov-report=term-missing app/tests/ -v

# Генерация HTML отчета
python -m pytest --cov=app --cov-report=html app/tests/
```

### Текущее покрытие кода тестами: 77% ✅

**Достигнуто значительное улучшение с 59% до 77%**

**Детали покрытия по модулям:**
- `app/core/` - 100% (ошибки, настройки, логирование, middleware)
- `app/schemas/` - 100% (схемы данных, API ошибки)
- `app/infra/db/` - 100% (модели, перечисления, сессии, репозитории)
- `app/services/nmc_service.py` - 75% (расчет НМЦК)
- `app/api/` - 62-80% (эндпоинты API, исключения, системные эндпоинты)
- `app/services/ai/` - 51% (AI-скоринг, DeepSeek клиент)
- `app/services/zakupki/` - 19% (парсинг zakupki.gov.ru)
- `app/workers/` - 17-100% (Celery задачи, приложение)

**Создано 22 теста, которые успешно проходят:**
1. **Базовые тесты импортов и настроек** - проверка всех основных модулей
2. **Тесты сервиса НМЦК** - расчет средней цены, граничные случаи
3. **Тесты AI схем** - валидация схем сравнения
4. **Тесты API исключений** - обработка ошибок
5. **Тесты моделей базы данных** - создание моделей
6. **Тесты middleware** - корреляционные ID
7. **Тесты логирования** - конфигурация и использование

### Интеграционные тесты
```bash
# Запуск через docker-compose
docker-compose -f docker-compose.test.yml up --build --abort-on-container-exit

# Или через Makefile
make test-integration
```

### Smoke-тест миграций
```bash
cd backend
python -m pytest app/tests/test_migrations.py -v
```

### Примеры тестов

```python
# Тест сервиса НМЦК
def test_calc_nmc_avg():
    from app.services.nmc_service import calc_nmc_avg
    from decimal import Decimal
    
    # Пустой список
    assert calc_nmc_avg([]) is None
    
    # Одно значение
    assert calc_nmc_avg([Decimal("100.50")]) == Decimal("100.50")
    
    # Несколько значений
    prices = [Decimal("100.50"), Decimal("200.75"), Decimal("150.25")]
    result = calc_nmc_avg(prices)
    expected = Decimal("150.50")  # (100.50 + 200.75 + 150.25) / 3
    assert result == expected
```

### Достижение 90% покрытия

Для достижения целевого покрытия 90% необходимо добавить тесты для:
1. **API эндпоинтов** (создание, список, детали, остановка поиска)
2. **Сервисов бизнес-логики** (поиск, парсинг, AI-скоринг)
3. **Фоновых задач** (Celery workers)
4. **Работы с внешними API** (zakupki.gov.ru, DeepSeek)

## Разработка

### Установка зависимостей для разработки
```bash
cd backend
pip install -r requirements.txt
pip install -r requirements-dev.txt  # если есть
```

### Создание новой миграции
```bash
cd backend
alembic revision --autogenerate -m "Описание изменений"
```

### Применение миграций вручную
```bash
cd backend
alembic upgrade head
```

### Откат миграций
```bash
cd backend
alembic downgrade -1
```

## Переменные окружения

Создайте файл `.env` в корне проекта:

```env
# База данных
DATABASE_URL=postgresql+asyncpg://app:app@localhost:5432/appdb

# Redis
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/1
CELERY_RESULT_BACKEND=redis://localhost:6379/2

# DeepSeek API
DEEPSEEK_API_KEY=your_api_key_here
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-chat

# Настройки приложения
ENVIRONMENT=development
LOG_LEVEL=INFO
CORS_ORIGINS=http://localhost:8080,http://localhost:5173
```

## Логи и корреляция
- Каждый HTTP запрос имеет `request_id` (header `X-Request-Id` или генерируется автоматически)
- Для поиска используется `search_id`
- Для контракта используется `reestr_number`
- Все логи структурированы для удобства поиска и анализа

## Важно
- SQLite НЕ используется нигде, только PostgreSQL
- Идемпотентность результатов: `UNIQUE(search_id, reestr_number)` + UPSERT
- Для контрактов 2025+ скачивается "Печатная форма" и извлекается текст
- Соблюдается `robots.txt` и `Crawl-delay: 60` для zakupki.gov.ru
- Все внешние запросы имеют таймауты, ретраи и backoff