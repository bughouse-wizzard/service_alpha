#!/bin/bash

# Создаем файл с кодом бекенда
echo "# Код бекенда системы zakupki-analyzer" > codemd/backend_code.md
echo "" >> codemd/backend_code.md
echo "## Содержание" >> codemd/backend_code.md
echo "" >> codemd/backend_code.md

# Получаем список файлов бекенда
backend_files=$(find backend/app -name "*.py" ! -path "*/__pycache__/*" ! -path "*/tests/*" | sort)

# Добавляем оглавление
echo "### 1. Основные модули приложения" >> codemd/backend_code.md
echo "### 2. API эндпоинты" >> codemd/backend_code.md
echo "### 3. Core модули (ошибки, настройки, логирование)" >> codemd/backend_code.md
echo "### 4. Модели базы данных и репозитории" >> codemd/backend_code.md
echo "### 5. Схемы данных (Pydantic модели)" >> codemd/backend_code.md
echo "### 6. Сервисы бизнес-логики" >> codemd/backend_code.md
echo "### 7. Фоновые задачи (Celery workers)" >> codemd/backend_code.md
echo "" >> codemd/backend_code.md
echo "---" >> codemd/backend_code.md
echo "" >> codemd/backend_code.md

# Объединяем все файлы
for file in $backend_files; do
    echo "### Файл: \`$file\`" >> codemd/backend_code.md
    echo "" >> codemd/backend_code.md
    echo "\`\`\`python" >> codemd/backend_code.md
    cat "$file" >> codemd/backend_code.md
    echo "\`\`\`" >> codemd/backend_code.md
    echo "" >> codemd/backend_code.md
    echo "---" >> codemd/backend_code.md
    echo "" >> codemd/backend_code.md
done

echo "Создан файл: codemd/backend_code.md"
echo "Количество файлов: $(echo "$backend_files" | wc -l)"
