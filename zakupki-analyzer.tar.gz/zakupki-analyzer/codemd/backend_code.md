# Код бекенда системы zakupki-analyzer

## Содержание

### 1. Основные модули приложения
### 2. API эндпоинты
### 3. Core модули (ошибки, настройки, логирование)
### 4. Модели базы данных и репозитории
### 5. Схемы данных (Pydantic модели)
### 6. Сервисы бизнес-логики
### 7. Фоновые задачи (Celery workers)

---

### Файл: `backend/app/__init__.py`

```python
"""Backend application for zakupki analyzer."""```

---

### Файл: `backend/app/api/deps.py`

```python
from __future__ import annotations

from typing import AsyncGenerator

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.infra.db.session import async_sessionmaker


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with async_sessionmaker() as session:
        yield session


def get_request_id(request: Request) -> str:
    rid = getattr(request.state, "request_id", None)
    return str(rid) if rid else "unknown"```

---

### Файл: `backend/app/api/exceptions.py`

```python
from fastapi import HTTPException, status
from fastapi.responses import JSONResponse
from fastapi.requests import Request
from fastapi.exceptions import RequestValidationError
from typing import Union

from app.schemas.search import ApiError


class ApiException(HTTPException):
    """Базовое исключение API с единым форматом ошибок."""
    
    def __init__(
        self,
        status_code: int,
        error_code: str,
        message: str,
        details: dict = None
    ):
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        
        super().__init__(
            status_code=status_code,
            detail={
                "error_code": error_code,
                "message": message,
                "details": details or {}
            }
        )


async def api_exception_handler(request: Request, exc: ApiException) -> JSONResponse:
    """Обработчик для ApiException."""
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.detail
    )


async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Обработчик для HTTPException с преобразованием в единый формат."""
    if isinstance(exc.detail, dict) and "error_code" in exc.detail:
        # Уже в правильном формате
        detail = exc.detail
    else:
        # Преобразуем в единый формат
        detail = {
            "error_code": "HTTP_ERROR",
            "message": str(exc.detail) if exc.detail else "HTTP error occurred",
            "details": {}
        }
    
    return JSONResponse(
        status_code=exc.status_code,
        content=detail
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Обработчик для ошибок валидации Pydantic."""
    errors = []
    for error in exc.errors():
        errors.append({
            "loc": error["loc"],
            "msg": error["msg"],
            "type": error["type"]
        })
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "error_code": "VALIDATION_ERROR",
            "message": "Validation error",
            "details": {"errors": errors}
        }
    )


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Обработчик для всех остальных исключений."""
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error_code": "INTERNAL_ERROR",
            "message": "Internal server error",
            "details": {"error": str(exc)}
        }
    )```

---

### Файл: `backend/app/api/router.py`

```python
from __future__ import annotations

from fastapi import APIRouter

from app.api.search import router as search_router

api_router = APIRouter()
api_router.include_router(search_router, prefix="/search", tags=["search"])```

---

### Файл: `backend/app/api/search.py`

```python
from datetime import datetime
from typing import Optional, List
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from fastapi.responses import StreamingResponse

from app.api.exceptions import ApiException
from app.schemas.search import (
    SearchCreateRequest,
    SearchBrief,
    SearchDetailsResponse,
    SearchResultItem,
    SearchSelectionUpdate,
    ApiError,
)
from app.services.search import SearchService

router = APIRouter(prefix="/api/search", tags=["search"])


@router.post(
    "/",
    response_model=SearchBrief,
    status_code=status.HTTP_201_CREATED,
    responses={
        400: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def create_search(
    request: SearchCreateRequest,
    service: SearchService = Depends(),
) -> SearchBrief:
    """
    Создать новый поиск контрактов.
    """
    try:
        search = await service.create_search(request)
        return search
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_400_BAD_REQUEST,
            error_code="VALIDATION_ERROR",
            message=str(e),
            details={"field": "request"},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Internal server error",
            details={"error": str(e)},
        )


@router.post(
    "/{search_id}/stop",
    response_model=SearchBrief,
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def stop_search(
    search_id: UUID,
    service: SearchService = Depends(),
) -> SearchBrief:
    """
    Остановить выполнение поиска.
    """
    try:
        search = await service.stop_search(search_id)
        return search
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to stop search",
            details={"error": str(e)},
        )


@router.get(
    "/",
    response_model=List[SearchBrief],
    responses={
        500: {"model": ApiError},
    },
)
async def list_searches(
    ktru: Optional[str] = Query(None, description="Фильтр по КТРУ"),
    status: Optional[str] = Query(None, description="Фильтр по статусу"),
    date_from: Optional[datetime] = Query(None, description="Дата создания от"),
    date_to: Optional[datetime] = Query(None, description="Дата создания до"),
    service: SearchService = Depends(),
) -> List[SearchBrief]:
    """
    Получить список поисков с фильтрацией.
    """
    try:
        searches = await service.list_searches(
            ktru=ktru,
            status=status,
            date_from=date_from,
            date_to=date_to,
        )
        return searches
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to list searches",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}",
    response_model=SearchDetailsResponse,
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def get_search(
    search_id: UUID,
    service: SearchService = Depends(),
) -> SearchDetailsResponse:
    """
    Получить детальную информацию о поиске.
    """
    try:
        search = await service.get_search(search_id)
        return search
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to get search",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}/results",
    response_model=List[SearchResultItem],
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def get_search_results(
    search_id: UUID,
    accepted_for_nmc: Optional[bool] = Query(None, description="Принят для НМЦК"),
    is_2025_plus: Optional[bool] = Query(None, description="Контракт 2025+"),
    manufacturer_match: Optional[bool] = Query(None, description="Совпадение производителя"),
    service: SearchService = Depends(),
) -> List[SearchResultItem]:
    """
    Получить результаты поиска с фильтрацией.
    """
    try:
        results = await service.get_search_results(
            search_id=search_id,
            accepted_for_nmc=accepted_for_nmc,
            is_2025_plus=is_2025_plus,
            manufacturer_match=manufacturer_match,
        )
        return results
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to get search results",
            details={"error": str(e)},
        )


@router.patch(
    "/{search_id}/selection",
    response_model=List[SearchResultItem],
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def update_selection(
    search_id: UUID,
    selection: SearchSelectionUpdate,
    service: SearchService = Depends(),
) -> List[SearchResultItem]:
    """
    Обновить выбор контрактов для НМЦК.
    """
    try:
        results = await service.update_selection(search_id, selection)
        return results
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to update selection",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}/events",
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def stream_search_events(
    search_id: UUID,
    last_event_id: Optional[str] = Query("$", description="ID последнего полученного события"),
    service: SearchService = Depends(),
) -> StreamingResponse:
    """
    Поток событий SSE для отслеживания прогресса поиска.
    """
    try:
        event_stream = await service.stream_search_events(search_id, last_event_id)
        return StreamingResponse(
            event_stream,
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to stream events",
            details={"error": str(e)},
        )


@router.get(
    "/{search_id}/report",
    responses={
        404: {"model": ApiError},
        500: {"model": ApiError},
    },
)
async def download_report(
    search_id: UUID,
    service: SearchService = Depends(),
):
    """
    Скачать отчёт по поиску (ZIP с XLSX и JSON).
    """
    try:
        report_data = await service.generate_report(search_id)
        return report_data
    except ValueError as e:
        raise ApiException(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=str(e),
            details={"search_id": str(search_id)},
        )
    except Exception as e:
        raise ApiException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message="Failed to generate report",
            details={"error": str(e)},
        )```

---

### Файл: `backend/app/api/system.py`

```python
from __future__ import annotations

from fastapi import APIRouter

from app.core.settings import settings

router = APIRouter()


@router.get("/health", summary="Healthcheck")
async def health() -> dict:
    return {"status": "ok"}


@router.get("/version", summary="Build/version info")
async def version() -> dict:
    return {"name": settings.app_name, "version": settings.app_version, "env": settings.env}```

---

### Файл: `backend/app/core/errors.py`

```python
from __future__ import annotations

from enum import StrEnum


class ErrorCode(StrEnum):
    INPUT_VALIDATION_ERROR = "INPUT_VALIDATION_ERROR"
    ZAKUPKI_FETCH_TIMEOUT = "ZAKUPKI_FETCH_TIMEOUT"
    ZAKUPKI_PARSE_ERROR = "ZAKUPKI_PARSE_ERROR"
    DOC_DOWNLOAD_ERROR = "DOC_DOWNLOAD_ERROR"
    DOC_TEXT_EXTRACT_ERROR = "DOC_TEXT_EXTRACT_ERROR"
    LLM_TIMEOUT = "LLM_TIMEOUT"
    LLM_RESPONSE_INVALID = "LLM_RESPONSE_INVALID"
    DB_CONSTRAINT_VIOLATION = "DB_CONSTRAINT_VIOLATION"
    STOP_REQUESTED = "STOP_REQUESTED"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"


class AppError(Exception):
    def __init__(self, code: ErrorCode, message: str, *, details: dict | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.details = details or {}```

---

### Файл: `backend/app/core/logging.py`

```python
from __future__ import annotations

import logging
import sys

import structlog

from app.core.settings import settings


def configure_logging() -> None:
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
    )

    structlog.configure(
        processors=[
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.dict_tracebacks,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, settings.log_level.upper(), logging.INFO)
        ),
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def log() -> structlog.stdlib.BoundLogger:
    return structlog.get_logger()```

---

### Файл: `backend/app/core/middleware.py`

```python
from __future__ import annotations

import uuid
from typing import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = request.headers.get("X-Request-Id") or str(uuid.uuid4())
        request.state.request_id = request_id
        response: Response = await call_next(request)
        response.headers["X-Request-Id"] = request_id
        return response```

---

### Файл: `backend/app/core/settings.py`

```python
from __future__ import annotations

from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "nmck-mvp"
    app_version: str = "0.1.0"
    env: str = "dev"

    api_host: str = "0.0.0.0"
    api_port: int = 8000

    database_url: str
    redis_url: str

    celery_broker_url: str
    celery_result_backend: str

    deepseek_api_key: str | None = None

    cors_origins: List[str] = ["*"]

    log_level: str = "INFO"
    debug: bool = False

    zakupki_base: str = "https://zakupki.gov.ru"
    zakupki_timeout_sec: int = 30
    zakupki_min_delay_sec: float = 1.5
    zakupki_max_delay_sec: float = 3.5
    zakupki_max_retries: int = 3

    default_limit_contracts: int = 30
    default_region: str = "SZFO"

    ai_config_path: str = str(Path("config") / "ai_config.yaml")


settings = Settings()  # type: ignore[arg-type]```

---

### Файл: `backend/app/infra/db/enums.py`

```python
"""
Перечисления для моделей базы данных.
"""
from enum import Enum


class SearchStatus(str, Enum):
    """Статусы поиска."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    STOPPED = "stopped"
    FAILED = "failed"


class MatchType(str, Enum):
    """Типы совпадения."""
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    NO_MATCH = "no_match"
    UNKNOWN = "unknown"
```

---

### Файл: `backend/app/infra/db/models.py`

```python
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Any

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class SearchRequest(Base):
    __tablename__ = "search_request"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now())
    updated_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now())

    status: Mapped[str] = mapped_column(sa.String(32), index=True)

    input_source: Mapped[str] = mapped_column(sa.String(16))

    object_name: Mapped[str | None] = mapped_column(sa.String(512), nullable=True)
    ktru_code: Mapped[str] = mapped_column(sa.String(64), index=True)
    okpd2_code: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)

    manufacturer_target: Mapped[str | None] = mapped_column(sa.String(256), nullable=True)

    customer_region: Mapped[str] = mapped_column(sa.String(64))
    law: Mapped[str] = mapped_column(sa.String(16))

    date_from: Mapped[date] = mapped_column(sa.Date)
    date_to: Mapped[date] = mapped_column(sa.Date)

    execution_statuses: Mapped[list[str]] = mapped_column(ARRAY(sa.String(8)))
    limit_contracts: Mapped[int] = mapped_column(sa.Integer)

    found_total: Mapped[int] = mapped_column(sa.Integer, default=0)
    processed_count: Mapped[int] = mapped_column(sa.Integer, default=0)

    nmc_value: Mapped[Decimal | None] = mapped_column(sa.Numeric(18, 2), nullable=True)
    selected_contract_ids: Mapped[list[uuid.UUID]] = mapped_column(ARRAY(UUID(as_uuid=True)), default=list)

    target_specs: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)

    error_code: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(sa.Text, nullable=True)

    runtime_ms: Mapped[int | None] = mapped_column(sa.Integer, nullable=True)

    stop_requested: Mapped[bool] = mapped_column(sa.Boolean, default=False)
    celery_task_id: Mapped[str | None] = mapped_column(sa.String(128), nullable=True, index=True)

    results: Mapped[list["ContractResult"]] = relationship(
        back_populates="search",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class ContractResult(Base):
    __tablename__ = "contract_result"
    __table_args__ = (sa.UniqueConstraint("search_id", "reestr_number", name="uq_search_contract"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    created_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now())
    updated_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now())

    search_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), sa.ForeignKey("search_request.id", ondelete="CASCADE"), index=True)
    reestr_number: Mapped[str] = mapped_column(sa.String(64), index=True)
    contract_url: Mapped[str] = mapped_column(sa.Text)

    sign_date: Mapped[date | None] = mapped_column(sa.Date, nullable=True)
    unit_price: Mapped[Decimal | None] = mapped_column(sa.Numeric(18, 2), nullable=True)
    currency: Mapped[str] = mapped_column(sa.String(8), default="RUB")

    match_type: Mapped[str] = mapped_column(sa.String(16), index=True)  # IDENTICAL/HOMOGENEOUS/NO_MATCH
    ai_score: Mapped[int] = mapped_column(sa.Integer, default=0, index=True)

    manufacturer_found: Mapped[str | None] = mapped_column(sa.String(256), nullable=True)
    manufacturer_match: Mapped[bool | None] = mapped_column(sa.Boolean, nullable=True)

    is_2025_plus: Mapped[bool] = mapped_column(sa.Boolean, default=False)

    accepted_for_nmc: Mapped[bool] = mapped_column(sa.Boolean, default=False)

    specs_raw: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    raw_data_json: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    ai_analysis: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)

    error_code: Mapped[str | None] = mapped_column(sa.String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(sa.Text, nullable=True)

    search: Mapped["SearchRequest"] = relationship(back_populates="results")
    comparison_rows: Mapped[list["SpecComparisonRow"]] = relationship(
        back_populates="contract",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class SpecComparisonRow(Base):
    __tablename__ = "spec_comparison_row"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    contract_result_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), sa.ForeignKey("contract_result.id", ondelete="CASCADE"), index=True)

    name: Mapped[str] = mapped_column(sa.String(256))
    target_value: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    actual_value: Mapped[str | None] = mapped_column(sa.Text, nullable=True)

    match_status: Mapped[str] = mapped_column(sa.String(16))  # MATCH/DIFF/UNKNOWN
    reason: Mapped[str | None] = mapped_column(sa.Text, nullable=True)
    weight: Mapped[int] = mapped_column(sa.Integer, default=1)

    contract: Mapped["ContractResult"] = relationship(back_populates="comparison_rows")```

---

### Файл: `backend/app/infra/db/repos.py`

```python
from __future__ import annotations

import uuid
from datetime import date
from typing import Iterable

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.infra.db.models import ContractResult, SearchRequest, SpecComparisonRow


class SearchRepo:
    async def get(self, db: AsyncSession, search_id: uuid.UUID) -> SearchRequest | None:
        res = await db.execute(sa.select(SearchRequest).where(SearchRequest.id == search_id))
        return res.scalar_one_or_none()

    async def list(
        self,
        db: AsyncSession,
        *,
        page: int,
        page_size: int,
        ktru: str | None,
        status: str | None,
        date_from: date | None,
        date_to: date | None,
    ) -> tuple[int, list[SearchRequest]]:
        q = sa.select(SearchRequest)
        cq = sa.select(sa.func.count(SearchRequest.id))

        if ktru:
            q = q.where(SearchRequest.ktru_code.ilike(f"%{ktru}%"))
            cq = cq.where(SearchRequest.ktru_code.ilike(f"%{ktru}%"))
        if status:
            q = q.where(SearchRequest.status == status)
            cq = cq.where(SearchRequest.status == status)
        if date_from:
            q = q.where(SearchRequest.created_at >= sa.func.date_trunc("day", date_from))
            cq = cq.where(SearchRequest.created_at >= sa.func.date_trunc("day", date_from))
        if date_to:
            q = q.where(SearchRequest.created_at <= sa.func.date_trunc("day", date_to) + sa.text("interval '1 day'"))
            cq = cq.where(SearchRequest.created_at <= sa.func.date_trunc("day", date_to) + sa.text("interval '1 day'"))

        q = q.order_by(SearchRequest.created_at.desc()).offset((page - 1) * page_size).limit(page_size)

        total = (await db.execute(cq)).scalar_one()
        items = (await db.execute(q)).scalars().all()
        return int(total), list(items)

    async def create(self, db: AsyncSession, obj: SearchRequest) -> SearchRequest:
        db.add(obj)
        await db.flush()
        return obj

    async def update(self, db: AsyncSession, obj: SearchRequest) -> SearchRequest:
        db.add(obj)
        await db.flush()
        return obj


class ResultRepo:
    async def list_results(
        self,
        db: AsyncSession,
        *,
        search_id: uuid.UUID,
        page: int,
        page_size: int,
        reestr_q: str | None,
        match_type: str | None,
        min_score: int | None,
    ) -> tuple[int, list[ContractResult]]:
        q = sa.select(ContractResult).where(ContractResult.search_id == search_id)
        cq = sa.select(sa.func.count(ContractResult.id)).where(ContractResult.search_id == search_id)

        if reestr_q:
            q = q.where(ContractResult.reestr_number.ilike(f"%{reestr_q}%"))
            cq = cq.where(ContractResult.reestr_number.ilike(f"%{reestr_q}%"))
        if match_type:
            q = q.where(ContractResult.match_type == match_type)
            cq = cq.where(ContractResult.match_type == match_type)
        if min_score is not None:
            q = q.where(ContractResult.ai_score >= min_score)
            cq = cq.where(ContractResult.ai_score >= min_score)

        # по требованиям: сначала выбранные/accepted + по score
        q = q.order_by(ContractResult.accepted_for_nmc.desc(), ContractResult.ai_score.desc(), ContractResult.created_at.desc())
        q = q.offset((page - 1) * page_size).limit(page_size)

        total = (await db.execute(cq)).scalar_one()
        items = (await db.execute(q)).scalars().all()
        return int(total), list(items)

    async def upsert_contract_result(self, db: AsyncSession, *, values: dict) -> uuid.UUID:
        """
        UPSERT по uq_search_contract (search_id, reestr_number).
        Возвращает id записи.
        """
        stmt = insert(ContractResult).values(**values)
        update_cols = {k: stmt.excluded[k] for k in values.keys() if k not in {"id"}}
        stmt = stmt.on_conflict_do_update(
            constraint="uq_search_contract",
            set_=update_cols,
        ).returning(ContractResult.id)
        res = await db.execute(stmt)
        cid = res.scalar_one()
        return cid

    async def replace_comparison_rows(
        self,
        db: AsyncSession,
        *,
        contract_id: uuid.UUID,
        rows: Iterable[SpecComparisonRow],
    ) -> None:
        await db.execute(sa.delete(SpecComparisonRow).where(SpecComparisonRow.contract_result_id == contract_id))
        for r in rows:
            db.add(r)
        await db.flush()

    async def mark_accepted(self, db: AsyncSession, *, search_id: uuid.UUID, accepted_ids: set[uuid.UUID]) -> None:
        # Сброс
        await db.execute(
            sa.update(ContractResult)
            .where(ContractResult.search_id == search_id)
            .values(accepted_for_nmc=False)
        )
        if accepted_ids:
            await db.execute(
                sa.update(ContractResult)
                .where(ContractResult.search_id == search_id)
                .where(ContractResult.id.in_(list(accepted_ids)))
                .values(accepted_for_nmc=True)
            )
        await db.flush()```

---

### Файл: `backend/app/infra/db/session.py`

```python
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.core.settings import settings

engine = create_async_engine(
    settings.database_url,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
)

async_sessionmaker = sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

AsyncSessionLocal = async_sessionmaker```

---

### Файл: `backend/app/infra/events/event_broker.py`

```python
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from redis.asyncio import Redis
from redis.asyncio.client import Redis as RedisType


@dataclass(frozen=True)
class StreamEvent:
    type: str
    data: dict[str, Any]


class RedisEventBroker:
    """
    Redis Streams: nmck:events:{search_id}
    """

    def __init__(self, redis_url: str) -> None:
        self._redis_url = redis_url
        self._client: RedisType | None = None

    async def _get(self) -> RedisType:
        if self._client is None:
            self._client = Redis.from_url(self._redis_url, decode_responses=True)
        return self._client

    def _key(self, search_id: str) -> str:
        return f"nmck:events:{search_id}"

    async def emit(self, search_id: str, ev: StreamEvent) -> str:
        r = await self._get()
        payload = {"type": ev.type, "data": json.dumps(ev.data, ensure_ascii=False)}
        event_id = await r.xadd(self._key(search_id), payload, maxlen=2000, approximate=True)
        return str(event_id)

    async def read_stream(self, search_id: str, *, last_id: str, block_ms: int, count: int) -> list[tuple[str, dict]]:
        r = await self._get()
        resp = await r.xread({self._key(search_id): last_id}, block=block_ms, count=count)
        if not resp:
            return []
        # resp: [(stream, [(id, {field: value})...])]
        _stream, items = resp[0]
        out: list[tuple[str, dict]] = []
        for ev_id, fields in items:
            ev_type = fields.get("type", "message")
            raw_data = fields.get("data", "{}")
            try:
                data = json.loads(raw_data)
            except Exception:
                data = {"raw": raw_data}
            out.append((str(ev_id), {"type": ev_type, "data": data}))
        return out```

---

### Файл: `backend/app/main.py`

```python
from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError

from app.core.settings import settings
from app.core.logging import configure_logging
from app.core.middleware import CorrelationIdMiddleware
from app.api.router import api_router
from app.api.system import router as system_router
from app.api.exceptions import (
    ApiException,
    api_exception_handler,
    http_exception_handler,
    validation_exception_handler,
    generic_exception_handler,
)

configure_logging()

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="MVP backend для поиска контрактов ЕИС и расчета НМЦК",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(CorrelationIdMiddleware)

# Регистрация обработчиков исключений
app.add_exception_handler(ApiException, api_exception_handler)
app.add_exception_handler(HTTPException, http_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(Exception, generic_exception_handler)

app.include_router(system_router)
app.include_router(api_router, prefix="/api")```

---

### Файл: `backend/app/schemas/common.py`

```python
from __future__ import annotations

from pydantic import BaseModel, Field


class ApiError(BaseModel):
    error_code: str = Field(..., examples=["INPUT_VALIDATION_ERROR"])
    message: str
    details: dict = Field(default_factory=dict)```

---

### Файл: `backend/app/schemas/search.py`

```python
from datetime import datetime
from enum import Enum
from typing import Optional, List
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


class SearchStatus(str, Enum):
    """Статусы поиска."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    STOPPED = "stopped"
    FAILED = "failed"


class MatchType(str, Enum):
    """Типы совпадения."""
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    UNKNOWN = "unknown"


class ApiError(BaseModel):
    """Стандартный формат ошибки API."""
    error_code: str = Field(..., description="Код ошибки")
    message: str = Field(..., description="Сообщение об ошибке")
    details: Optional[dict] = Field(None, description="Дополнительные детали")


class SearchCreateRequest(BaseModel):
    """Запрос на создание поиска."""
    ktru: str = Field(..., description="КТРУ код", min_length=1, max_length=50)
    manufacturer: Optional[str] = Field(None, description="Производитель", max_length=200)
    region: Optional[str] = Field(None, description="Регион/округ", max_length=100)
    date_from: Optional[datetime] = Field(None, description="Дата начала периода")
    date_to: Optional[datetime] = Field(None, description="Дата окончания периода")
    contract_limit: int = Field(default=30, ge=1, le=1000, description="Лимит контрактов")
    characteristics: Optional[str] = Field(None, description="Текст характеристик")
    
    model_config = ConfigDict(from_attributes=True)


class SearchBrief(BaseModel):
    """Краткая информация о поиске."""
    id: UUID = Field(..., description="ID поиска")
    ktru: str = Field(..., description="КТРУ код")
    status: SearchStatus = Field(..., description="Статус поиска")
    created_at: datetime = Field(..., description="Дата создания")
    updated_at: datetime = Field(..., description="Дата обновления")
    contracts_found: Optional[int] = Field(None, description="Найдено контрактов")
    contracts_processed: Optional[int] = Field(None, description="Обработано контрактов")
    
    model_config = ConfigDict(from_attributes=True)


class SearchListResponse(BaseModel):
    """Список поисков."""
    searches: List[SearchBrief] = Field(..., description="Список поисков")
    total: int = Field(..., description="Общее количество поисков")
    
    model_config = ConfigDict(from_attributes=True)


class SearchDetailsResponse(BaseModel):
    """Детальная информация о поиске."""
    id: UUID = Field(..., description="ID поиска")
    ktru: str = Field(..., description="КТРУ код")
    manufacturer: Optional[str] = Field(None, description="Производитель")
    region: Optional[str] = Field(None, description="Регион/округ")
    date_from: Optional[datetime] = Field(None, description="Дата начала периода")
    date_to: Optional[datetime] = Field(None, description="Дата окончания периода")
    contract_limit: int = Field(..., description="Лимит контрактов")
    characteristics: Optional[str] = Field(None, description="Текст характеристик")
    status: SearchStatus = Field(..., description="Статус поиска")
    created_at: datetime = Field(..., description="Дата создания")
    updated_at: datetime = Field(..., description="Дата обновления")
    contracts_found: Optional[int] = Field(None, description="Найдено контрактов")
    contracts_processed: Optional[int] = Field(None, description="Обработано контрактов")
    nmck: Optional[float] = Field(None, description="Рассчитанная НМЦК")
    
    model_config = ConfigDict(from_attributes=True)


class SearchResultItem(BaseModel):
    """Элемент результата поиска."""
    reestr_number: str = Field(..., description="Реестровый номер контракта")
    contract_date: datetime = Field(..., description="Дата контракта")
    contract_price: float = Field(..., description="Цена контракта")
    unit_price: Optional[float] = Field(None, description="Цена за единицу")
    customer: str = Field(..., description="Заказчик")
    match_type: MatchType = Field(..., description="Тип совпадения")
    manufacturer_match: bool = Field(..., description="Совпадение производителя")
    is_2025_plus: bool = Field(..., description="Контракт 2025+")
    ai_score: float = Field(..., ge=0, le=1, description="AI оценка соответствия")
    accepted_for_nmc: bool = Field(..., description="Принят для НМЦК")
    selection_order: Optional[int] = Field(None, description="Порядок выбора (1-3)")
    
    model_config = ConfigDict(from_attributes=True)


class SearchResultListResponse(BaseModel):
    """Список результатов поиска."""
    results: List[SearchResultItem] = Field(..., description="Список результатов")
    total: int = Field(..., description="Общее количество результатов")
    
    model_config = ConfigDict(from_attributes=True)


class SearchSelectionUpdate(BaseModel):
    """Обновление выбора контрактов для НМЦК."""
    selected_reestr_numbers: List[str] = Field(
        ..., 
        description="Список реестровых номеров выбранных контрактов",
        min_items=1,
        max_items=3
    )


class SelectionPatchRequest(BaseModel):
    """Запрос на обновление выбора контрактов."""
    selected_contract_ids: List[str] = Field(
        ...,
        description="Список ID выбранных контрактов",
        min_items=1,
        max_items=3
    )


class SearchEvent(BaseModel):
    """Событие SSE для поиска."""
    id: str = Field(..., description="ID события")
    event: str = Field(..., description="Тип события")
    data: dict = Field(..., description="Данные события")```

---

### Файл: `backend/app/services/ai/deepseek.py`

```python
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import httpx
import yaml
from pydantic import BaseModel, Field, ValidationError

from app.core.errors import AppError, ErrorCode
from app.core.settings import settings


class NormalizedAttributes(BaseModel):
    product_name: str | None = None
    ktru: str | None = None
    manufacturer: str | None = None
    attributes: list[dict[str, Any]] = Field(default_factory=list)


class CompareRow(BaseModel):
    name: str
    target: str | None = None
    actual: str | None = None
    status: str  # MATCH|DIFF|UNKNOWN
    reason: str | None = None
    weight: int = 1


class CompareResult(BaseModel):
    score: int = Field(..., ge=0, le=100)
    match_type: str  # IDENTICAL|HOMOGENEOUS|NO_MATCH
    manufacturer_found: str | None = None
    manufacturer_match: bool | None = None
    rows: list[CompareRow] = Field(default_factory=list)
    decision: str  # ACCEPT|REJECT|REVIEW


@dataclass(frozen=True)
class AiConfig:
    base_url: str
    timeout: int
    model_extraction: str
    model_reasoning: str
    prompts: dict[str, Any]
    gen_params: dict[str, Any]


def load_ai_config() -> AiConfig:
    with open(settings.ai_config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return AiConfig(
        base_url=cfg["deepseek_api"]["base_url"],
        timeout=int(cfg["deepseek_api"]["timeout"]),
        model_extraction=cfg["deepseek_api"]["models"]["extraction"],
        model_reasoning=cfg["deepseek_api"]["models"]["reasoning"],
        prompts=cfg["prompts"],
        gen_params=cfg["generation_params"],
    )


class DeepSeekClient:
    def __init__(self) -> None:
        if not settings.deepseek_api_key:
            # в тестах/без ключа позволяем поднимать систему, но AI будет падать controlled-ошибкой
            pass
        self.cfg = load_ai_config()
        self.client = httpx.AsyncClient(
            base_url=self.cfg.base_url,
            timeout=httpx.Timeout(self.cfg.timeout),
            headers={"Authorization": f"Bearer {settings.deepseek_api_key or ''}"},
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def _chat_json(self, *, model: str, system: str, user: str, params: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            **params,
        }
        try:
            r = await self.client.post("/v1/chat/completions", json=payload)
            r.raise_for_status()
            data = r.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)
        except httpx.TimeoutException as e:
            raise AppError(ErrorCode.LLM_TIMEOUT, "LLM timeout", details={"cause": str(e)})
        except json.JSONDecodeError as e:
            # self-correction
            fixed = await self._self_correct(model=model, bad_text=content, err=str(e))
            return fixed
        except Exception as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "LLM call failed", details={"cause": str(e)})

    async def _self_correct(self, *, model: str, bad_text: str, err: str) -> dict[str, Any]:
        system = "Ты исправляешь JSON. Верни только валидный JSON без комментариев."
        user = f"Ты вернул невалидный JSON. Ошибка: {err}\n\nТекст:\n{bad_text}\n\nИсправь и верни только JSON."
        r = await self.client.post(
            "/v1/chat/completions",
            json={
                "model": model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "temperature": 0.0,
                "max_tokens": 1500,
            },
        )
        r.raise_for_status()
        data = r.json()
        content = data["choices"][0]["message"]["content"]
        return json.loads(content)

    async def normalize(self, raw_text: str) -> NormalizedAttributes:
        p = self.cfg.prompts["normalization"]
        user = p["user_template"].format(raw_text=raw_text)
        res = await self._chat_json(
            model=self.cfg.model_extraction,
            system=p["system"],
            user=user,
            params=self.cfg.gen_params["extraction"],
        )
        try:
            return NormalizedAttributes.model_validate(res)
        except ValidationError as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "Normalization schema invalid", details={"cause": str(e)})

    async def compare(self, *, target_json: dict, found_json: dict, target_manufacturer: str | None) -> CompareResult:
        p = self.cfg.prompts["comparison"]
        user = p["user_template"].format(
            target_json=json.dumps(target_json, ensure_ascii=False),
            found_json=json.dumps(found_json, ensure_ascii=False),
            target_manufacturer=target_manufacturer or "null",
        )
        res = await self._chat_json(
            model=self.cfg.model_reasoning,
            system=p["system"],
            user=user,
            params=self.cfg.gen_params["scoring"],
        )
        try:
            return CompareResult.model_validate(res)
        except ValidationError as e:
            raise AppError(ErrorCode.LLM_RESPONSE_INVALID, "Compare schema invalid", details={"cause": str(e)})```

---

### Файл: `backend/app/services/docs/extractors.py`

```python
from __future__ import annotations

import io

import pdfplumber
from docx import Document

from app.core.errors import AppError, ErrorCode


def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    try:
        out: list[str] = []
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for page in pdf.pages:
                txt = page.extract_text() or ""
                out.append(txt)
        return "\n".join(out).strip()
    except Exception as e:
        raise AppError(ErrorCode.DOC_TEXT_EXTRACT_ERROR, "PDF text extract failed", details={"cause": str(e)})


def extract_text_from_docx(docx_bytes: bytes) -> str:
    try:
        doc = Document(io.BytesIO(docx_bytes))
        out: list[str] = []
        for p in doc.paragraphs:
            if p.text:
                out.append(p.text)
        for t in doc.tables:
            for row in t.rows:
                out.append(" | ".join(cell.text.strip() for cell in row.cells))
        return "\n".join(out).strip()
    except Exception as e:
        raise AppError(ErrorCode.DOC_TEXT_EXTRACT_ERROR, "DOCX text extract failed", details={"cause": str(e)})```

---

### Файл: `backend/app/services/nmc_service.py`

```python
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Iterable, Union, Optional, List, Any
import logging

logger = logging.getLogger(__name__)


def calc_nmc_avg(unit_prices: Iterable[Union[Decimal, float, str, int, None]]) -> Optional[Decimal]:
    """
    Рассчитывает среднее значение НМЦК из списка цен.
    
    Args:
        unit_prices: Итерируемый объект с ценами (Decimal, float, str, int или None)
        
    Returns:
        Decimal: Среднее значение, округленное до 2 знаков после запятой
        None: Если нет валидных цен или произошла ошибка
        
    Raises:
        ValueError: Если входные данные некорректны
    """
    prices: List[Decimal] = []
    
    for price in unit_prices:
        if price is None:
            continue
            
        try:
            if isinstance(price, Decimal):
                prices.append(price)
            elif isinstance(price, (int, float)):
                # Преобразуем float в Decimal через строку для точности
                prices.append(Decimal(str(price)))
            elif isinstance(price, str):
                # Убираем пробелы и заменяем запятые на точки
                cleaned = price.strip().replace(',', '.')
                # Убираем валютные символы и пробелы
                cleaned = ''.join(ch for ch in cleaned if ch.isdigit() or ch in '.-')
                if cleaned:
                    prices.append(Decimal(cleaned))
            else:
                logger.warning(f"calc_nmc_avg: неподдерживаемый тип цены: {type(price)}")
                continue
        except (InvalidOperation, ValueError) as e:
            logger.warning(f"calc_nmc_avg: ошибка преобразования цены {price}: {e}")
            continue
    
    if not prices:
        logger.debug("calc_nmc_avg: нет валидных цен для расчета")
        return None
    
    try:
        # Суммируем все цены
        total = sum(prices, start=Decimal("0"))
        
        # Вычисляем среднее
        count = Decimal(len(prices))
        average = total / count
        
        # Округляем до 2 знаков после запятой (копеек)
        rounded = average.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        
        logger.debug(
            f"calc_nmc_avg: рассчитано среднее из {len(prices)} цен: "
            f"total={total}, count={count}, avg={average}, rounded={rounded}"
        )
        
        return rounded
    except (InvalidOperation, ZeroDivisionError) as e:
        logger.error(f"calc_nmc_avg: ошибка расчета среднего: {e}")
        return None


def calc_nmc_avg_safe(unit_prices: Iterable[Any]) -> Optional[Decimal]:
    """
    Безопасная версия calc_nmc_avg, которая никогда не выбрасывает исключений.
    
    Args:
        unit_prices: Итерируемый объект с ценами любого типа
        
    Returns:
        Decimal: Среднее значение или None при любой ошибке
    """
    try:
        return calc_nmc_avg(unit_prices)
    except Exception as e:
        logger.error(f"calc_nmc_avg_safe: непредвиденная ошибка: {e}")
        return None```

---

### Файл: `backend/app/services/report_service.py`

```python
from __future__ import annotations

import io
import json
import uuid
import zipfile
from decimal import Decimal

import sqlalchemy as sa
from openpyxl import Workbook
from sqlalchemy.ext.asyncio import AsyncSession

from app.infra.db.models import ContractResult, SearchRequest, SpecComparisonRow


class ReportService:
    def __init__(self, *, db: AsyncSession) -> None:
        self.db = db

    async def build_zip_report(self, search_id: str, *, request_id: str) -> tuple[bytes, str]:
        sid = uuid.UUID(search_id)

        search = (await self.db.execute(sa.select(SearchRequest).where(SearchRequest.id == sid))).scalar_one_or_none()
        if not search:
            raise ValueError("search not found")

        results = (
            (await self.db.execute(sa.select(ContractResult).where(ContractResult.search_id == sid).order_by(ContractResult.accepted_for_nmc.desc(), ContractResult.ai_score.desc())))
            .scalars()
            .all()
        )

        # JSON
        payload = {
            "search": {
                "id": str(search.id),
                "created_at": search.created_at.isoformat(),
                "status": search.status,
                "object_name": search.object_name,
                "ktru_code": search.ktru_code,
                "manufacturer_target": search.manufacturer_target,
                "date_from": str(search.date_from),
                "date_to": str(search.date_to),
                "found_total": search.found_total,
                "processed_count": search.processed_count,
                "nmc_value": str(search.nmc_value) if search.nmc_value is not None else None,
                "selected_contract_ids": [str(x) for x in search.selected_contract_ids],
                "target_specs": search.target_specs,
            },
            "results": [
                {
                    "id": str(r.id),
                    "reestr_number": r.reestr_number,
                    "contract_url": r.contract_url,
                    "sign_date": str(r.sign_date) if r.sign_date else None,
                    "unit_price": str(r.unit_price) if r.unit_price is not None else None,
                    "match_type": r.match_type,
                    "ai_score": r.ai_score,
                    "manufacturer_found": r.manufacturer_found,
                    "manufacturer_match": r.manufacturer_match,
                    "accepted_for_nmc": r.accepted_for_nmc,
                    "ai_analysis": r.ai_analysis,
                }
                for r in results
            ],
        }
        json_bytes = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")

        # XLSX
        wb = Workbook()
        ws = wb.active
        ws.title = "Results"

        ws.append(["Search ID", str(search.id)])
        ws.append(["Object", search.object_name or ""])
        ws.append(["KTRU", search.ktru_code])
        ws.append(["Status", search.status])
        ws.append(["Found total", search.found_total])
        ws.append(["Processed", search.processed_count])
        ws.append(["NMC", float(search.nmc_value) if search.nmc_value is not None else ""])
        ws.append([])

        ws.append([
            "Accepted",
            "Reestr number",
            "Sign date",
            "Unit price",
            "Match type",
            "AI score",
            "Manufacturer found",
            "Manufacturer match",
            "URL",
        ])

        for r in results:
            ws.append([
                "YES" if r.accepted_for_nmc else "",
                r.reestr_number,
                str(r.sign_date) if r.sign_date else "",
                float(r.unit_price) if r.unit_price is not None else "",
                r.match_type,
                r.ai_score,
                r.manufacturer_found or "",
                "" if r.manufacturer_match is None else ("YES" if r.manufacturer_match else "NO"),
                r.contract_url,
            ])

        bio = io.BytesIO()
        wb.save(bio)
        xlsx_bytes = bio.getvalue()

        # ZIP
        zbio = io.BytesIO()
        with zipfile.ZipFile(zbio, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("report.json", json_bytes)
            zf.writestr("report.xlsx", xlsx_bytes)

        return zbio.getvalue(), f"nmck_report_{search_id}.zip"```

---

### Файл: `backend/app/services/search.py`

```python
from datetime import datetime
from typing import Optional, List, AsyncGenerator
from uuid import UUID

from app.schemas.search import (
    SearchCreateRequest,
    SearchBrief,
    SearchDetailsResponse,
    SearchResultItem,
    SearchSelectionUpdate,
)


class SearchService:
    """Сервис для работы с поисками контрактов."""
    
    async def create_search(self, request: SearchCreateRequest) -> SearchBrief:
        """Создать новый поиск."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def stop_search(self, search_id: UUID) -> SearchBrief:
        """Остановить поиск."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def list_searches(
        self,
        ktru: Optional[str] = None,
        status: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
    ) -> List[SearchBrief]:
        """Получить список поисков с фильтрацией."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def get_search(self, search_id: UUID) -> SearchDetailsResponse:
        """Получить детальную информацию о поиске."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def get_search_results(
        self,
        search_id: UUID,
        accepted_for_nmc: Optional[bool] = None,
        is_2025_plus: Optional[bool] = None,
        manufacturer_match: Optional[bool] = None,
    ) -> List[SearchResultItem]:
        """Получить результаты поиска с фильтрацией."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def update_selection(
        self,
        search_id: UUID,
        selection: SearchSelectionUpdate,
    ) -> List[SearchResultItem]:
        """Обновить выбор контрактов для НМЦК."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def stream_search_events(
        self,
        search_id: UUID,
        last_event_id: str = "$",
    ) -> AsyncGenerator[str, None]:
        """Поток событий SSE для поиска."""
        # Заглушка для реализации
        raise NotImplementedError()
    
    async def generate_report(self, search_id: UUID):
        """Сгенерировать отчёт по поиску."""
        # Заглушка для реализации
        raise NotImplementedError()```

---

### Файл: `backend/app/services/search_service.py`

```python
from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import ErrorCode
from app.core.logging import log
from app.core.settings import settings
from app.infra.db.models import SearchRequest
from app.infra.db.repos import ResultRepo, SearchRepo
from app.infra.events.event_broker import RedisEventBroker, StreamEvent
from app.schemas.search import (
    SearchCreateRequest,
    SearchDetailsResponse,
    SearchListResponse,
    SearchResultListResponse,
    SelectionPatchRequest,
)
from app.workers.tasks import run_search_pipeline  # celery task


class SearchService:
    def __init__(self, *, db: AsyncSession, broker: RedisEventBroker) -> None:
        self.db = db
        self.broker = broker
        self.search_repo = SearchRepo()
        self.result_repo = ResultRepo()
    
    async def auto_select_top_3(self, search_id: uuid.UUID) -> tuple[Set[uuid.UUID], Optional[Decimal]]:
        """
        Автоматически выбирает top-3 контракта для расчёта НМЦК.
        
        Правила выбора (MVP):
        1. Приоритет по match_type: IDENTICAL > HOMOGENEOUS > NO_MATCH
        2. При одинаковом match_type: сортировка по ai_score DESC
        3. При одинаковом ai_score: сортировка по дате создания DESC (сначала свежие)
        
        Args:
            search_id: ID поиска
            
        Returns:
            Tuple[selected_ids, nmc_value]: 
            - selected_ids: Set выбранных ID контрактов (до 3)
            - nmc_value: Рассчитанное значение НМЦК или None
        """
        # Создаем case выражение для приоритизации match_type
        match_type_priority = sa.case(
            (ContractResult.match_type == "IDENTICAL", 3),
            (ContractResult.match_type == "HOMOGENEOUS", 2),
            else_=1,
        )
        
        # Запрос для получения top-3 контрактов
        query = (
            sa.select(
                ContractResult.id,
                ContractResult.unit_price,
                ContractResult.match_type,
                ContractResult.ai_score,
                ContractResult.created_at,
            )
            .where(ContractResult.search_id == search_id)
            .order_by(
                match_type_priority.desc(),
                ContractResult.ai_score.desc(),
                ContractResult.created_at.desc(),
            )
            .limit(3)
        )
        
        result = await self.db.execute(query)
        rows = result.all()
        
        selected_ids: Set[uuid.UUID] = set()
        prices: List[Decimal] = []
        
        for row in rows:
            if row.id:
                selected_ids.add(row.id)
            
            if row.unit_price is not None:
                prices.append(row.unit_price)
        
        # Помечаем выбранные контракты как accepted_for_nmc
        if selected_ids:
            await self.result_repo.mark_accepted(self.db, search_id=search_id, accepted_ids=selected_ids)
        
        # Рассчитываем НМЦК
        nmc_value = calc_nmc_avg(prices) if prices else None
        
        # Обновляем поиск с выбранными ID и НМЦК
        if selected_ids or nmc_value is not None:
            update_values = {}
            if selected_ids:
                update_values["selected_contract_ids"] = list(selected_ids)
            if nmc_value is not None:
                update_values["nmc_value"] = nmc_value
            
            if update_values:
                await self.db.execute(
                    sa.update(SearchRequest)
                    .where(SearchRequest.id == search_id)
                    .values(**update_values)
                )
                await self.db.commit()
        
        # Эмитим событие с результатами автовыбора
        await self.broker.emit(
            str(search_id),
            StreamEvent("selection", {
                "selected_count": len(selected_ids),
                "nmc_value": str(nmc_value) if nmc_value else None,
                "search_id": str(search_id),
                "auto_selected": True,
            })
        )
        
        log().info(
            "auto_select_top_3_completed",
            search_id=str(search_id),
            selected_count=len(selected_ids),
            nmc_value=str(nmc_value) if nmc_value else None,
        )
        
        return selected_ids, nmc_value

    async def create_and_start(self, payload: SearchCreateRequest, *, request_id: str) -> SearchDetailsResponse:
        # defaults: 3 years window
        today = date.today()
        date_to = payload.date_to or today
        date_from = payload.date_from or (today - timedelta(days=365 * 3))

        if not payload.ktru_code.strip():
            raise ValueError("ktru_code empty")

        obj = SearchRequest(
            status="CREATED",
            input_source=payload.input_source,
            object_name=payload.object_name,
            ktru_code=payload.ktru_code.strip(),
            okpd2_code=payload.okpd2_code,
            manufacturer_target=payload.manufacturer_target,
            customer_region=payload.customer_region,
            law=payload.law,
            date_from=date_from,
            date_to=date_to,
            execution_statuses=payload.execution_statuses,
            limit_contracts=payload.limit_contracts,
            target_specs={"raw_text": payload.target_specs_text or "", "normalized": {}},
            selected_contract_ids=[],
        )

        async with self.db.begin():
            await self.search_repo.create(self.db, obj)

        search_id = str(obj.id)
        await self.broker.emit(search_id, StreamEvent("progress", {"status": "CREATED", "processed": 0, "limit": obj.limit_contracts}))
        await self.broker.emit(search_id, StreamEvent("log", {"msg": "Search created", "request_id": request_id}))

        # стартуем Celery
        task = run_search_pipeline.apply_async(
            args=[search_id],
            queue="nmck",
            kwargs={"request_id": request_id},
        )
        async with self.db.begin():
            obj.status = "RUNNING"
            obj.celery_task_id = task.id
            await self.search_repo.update(self.db, obj)

        await self.broker.emit(search_id, StreamEvent("progress", {"status": "RUNNING", "processed": 0, "limit": obj.limit_contracts}))
        return self._to_details(obj)

    async def request_stop(self, search_id: str, *, request_id: str) -> bool:
        sid = uuid.UUID(search_id)
        obj = await self.search_repo.get(self.db, sid)
        if not obj:
            return False

        async with self.db.begin():
            obj.stop_requested = True
            # статус обновит worker на STOPPED, но UI должен видеть stop flag сразу
            await self.search_repo.update(self.db, obj)

        await self.broker.emit(search_id, StreamEvent("log", {"msg": "Stop requested", "request_id": request_id}))
        await self.broker.emit(search_id, StreamEvent("progress", {"status": "STOP_REQUESTED"}))

        # revoke (best-effort)
        try:
            if obj.celery_task_id:
                from app.workers.celery_app import celery_app
                celery_app.control.revoke(obj.celery_task_id, terminate=False)
        except Exception:
            log().exception("celery_revoke_failed", search_id=search_id, request_id=request_id)

        return True

    async def list_searches(
        self,
        *,
        page: int,
        page_size: int,
        ktru: str | None,
        status: str | None,
        date_from: date | None,
        date_to: date | None,
        request_id: str,
    ) -> SearchListResponse:
        total, items = await self.search_repo.list(
            self.db, page=page, page_size=page_size, ktru=ktru, status=status, date_from=date_from, date_to=date_to
        )
        return SearchListResponse(
            page=page,
            page_size=page_size,
            total=total,
            items=[
                {
                    "id": it.id,
                    "created_at": it.created_at.isoformat(),
                    "status": it.status,
                    "object_name": it.object_name,
                    "ktru_code": it.ktru_code,
                    "found_total": it.found_total,
                    "processed_count": it.processed_count,
                    "nmc_value": it.nmc_value,
                }
                for it in items
            ],
        )

    async def get_search(self, search_id: str, *, request_id: str) -> SearchDetailsResponse | None:
        sid = uuid.UUID(search_id)
        obj = await self.search_repo.get(self.db, sid)
        return self._to_details(obj) if obj else None

    async def list_results(
        self,
        *,
        search_id: str,
        page: int,
        page_size: int,
        reestr_q: str | None,
        match_type: str | None,
        min_score: int | None,
        request_id: str,
    ) -> SearchResultListResponse:
        sid = uuid.UUID(search_id)
        total, items = await self.result_repo.list_results(
            self.db,
            search_id=sid,
            page=page,
            page_size=page_size,
            reestr_q=reestr_q,
            match_type=match_type,
            min_score=min_score,
        )
        return SearchResultListResponse(
            search_id=sid,
            page=page,
            page_size=page_size,
            total=total,
            items=[
                {
                    "id": it.id,
                    "reestr_number": it.reestr_number,
                    "contract_url": it.contract_url,
                    "sign_date": it.sign_date,
                    "unit_price": it.unit_price,
                    "currency": it.currency,
                    "match_type": it.match_type,
                    "ai_score": it.ai_score,
                    "manufacturer_found": it.manufacturer_found,
                    "manufacturer_match": it.manufacturer_match,
                    "is_2025_plus": it.is_2025_plus,
                    "accepted_for_nmc": it.accepted_for_nmc,
                }
                for it in items
            ],
        )

    async def update_selection(
        self, search_id: str, payload: SelectionPatchRequest, *, request_id: str
    ) -> SearchDetailsResponse | None:
        sid = uuid.UUID(search_id)
        obj = await self.search_repo.get(self.db, sid)
        if not obj:
            return None

        selected_set = set(payload.selected_contract_ids)
        
        # Валидация: проверяем, что все выбранные контракты принадлежат этому поиску
        if selected_set:
            # Получаем ID контрактов, которые принадлежат этому поиску
            valid_contracts_query = sa.select(ContractResult.id).where(
                ContractResult.search_id == sid,
                ContractResult.id.in_(selected_set)
            )
            valid_contracts_result = await self.db.execute(valid_contracts_query)
            valid_contracts = {row[0] for row in valid_contracts_result.all()}
            
            # Проверяем, что все выбранные контракты валидны
            invalid_contracts = selected_set - valid_contracts
            if invalid_contracts:
                raise ValueError(
                    f"Некоторые контракты не принадлежат этому поиску или не существуют: "
                    f"{[str(cid) for cid in invalid_contracts]}"
                )
            
            # Получаем цены выбранных контрактов
            prices_query = sa.select(ContractResult.unit_price).where(
                ContractResult.search_id == sid,
                ContractResult.id.in_(selected_set)
            )
            prices_result = await self.db.execute(prices_query)
            prices = [row[0] for row in prices_result.all() if row[0] is not None]
            
            # Рассчитываем НМЦК с использованием единого источника истины
            nmc_value = calc_nmc_avg(prices)
        else:
            nmc_value = None
        
        # Обновляем accepted_for_nmc для всех контрактов этого поиска
        # Сначала сбрасываем все флаги
        reset_query = sa.update(ContractResult).where(
            ContractResult.search_id == sid
        ).values(accepted_for_nmc=False)
        await self.db.execute(reset_query)
        
        # Затем устанавливаем флаги для выбранных контрактов
        if selected_set:
            update_query = sa.update(ContractResult).where(
                ContractResult.search_id == sid,
                ContractResult.id.in_(selected_set)
            ).values(accepted_for_nmc=True)
            await self.db.execute(update_query)

        async with self.db.begin():
            obj.selected_contract_ids = list(selected_set)
            obj.nmc_value = nmc_value
            await self.search_repo.update(self.db, obj)

        # Эмитим событие с обновлённым НМЦК
        await self.broker.emit(
            search_id, 
            StreamEvent("selection", {
                "selected_count": len(selected_set), 
                "nmc_value": str(nmc_value) if nmc_value else None,
                "search_id": search_id
            })
        )
        
        log().info(
            "selection_updated",
            search_id=search_id,
            selected_count=len(selected_set),
            nmc_value=str(nmc_value) if nmc_value else None,
            request_id=request_id,
        )
        
        return self._to_details(obj)

    def _to_details(self, obj: SearchRequest) -> SearchDetailsResponse:
        return SearchDetailsResponse(
            id=obj.id,
            created_at=obj.created_at.isoformat(),
            updated_at=obj.updated_at.isoformat(),
            status=obj.status,
            input_source=obj.input_source,
            object_name=obj.object_name,
            ktru_code=obj.ktru_code,
            okpd2_code=obj.okpd2_code,
            manufacturer_target=obj.manufacturer_target,
            customer_region=obj.customer_region,
            law=obj.law,
            date_from=obj.date_from,
            date_to=obj.date_to,
            execution_statuses=list(obj.execution_statuses),
            limit_contracts=obj.limit_contracts,
            found_total=obj.found_total,
            processed_count=obj.processed_count,
            nmc_value=obj.nmc_value,
            selected_contract_ids=list(obj.selected_contract_ids),
            target_specs=obj.target_specs,
            error_code=obj.error_code,
            error_message=obj.error_message,
        )```

---

### Файл: `backend/app/services/zakupki/client.py`

```python
from __future__ import annotations

import asyncio
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
import json

import httpx
from bs4 import BeautifulSoup

from app.core.errors import AppError, ErrorCode
from app.core.settings import settings


@dataclass(frozen=True)
class FoundContractCard:
    reestr_number: str
    contract_url: str
    sign_date: Optional[str] = None
    price_total: Optional[str] = None


class ZakupkiClient:
    """
    Клиент для публичных HTML страниц zakupki.gov.ru
    В MVP используем URL-инжиниринг (results.html?...) и парсинг DOM.
    """

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(settings.zakupki_timeout_sec),
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Encoding": "gzip, deflate, br",
            },
            follow_redirects=True,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def _sleep_human(self) -> None:
        """Случайная задержка между запросами для соблюдения robots.txt"""
        await asyncio.sleep(random.uniform(settings.zakupki_min_delay_sec, settings.zakupki_max_delay_sec))

    async def _save_debug_html(self, html: str, url: str, prefix: str = "search") -> str:
        """Сохраняет сырой HTML для отладки (требование ТЗ)"""
        try:
            debug_dir = Path(tempfile.gettempdir()) / "zakupki_debug"
            debug_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{prefix}_{timestamp}_{hash(url) % 10000:04d}.html"
            filepath = debug_dir / filename
            
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"<!-- URL: {url} -->\n")
                f.write(f"<!-- Timestamp: {datetime.now().isoformat()} -->\n")
                f.write(html)
            
            # Также сохраняем метаданные
            meta_file = debug_dir / f"{prefix}_{timestamp}_{hash(url) % 10000:04d}.json"
            with open(meta_file, "w", encoding="utf-8") as f:
                json.dump({
                    "url": url,
                    "timestamp": datetime.now().isoformat(),
                    "filename": filename,
                    "size_bytes": len(html)
                }, f, indent=2, ensure_ascii=False)
            
            return str(filepath)
        except Exception:
            # Не падаем, если не удалось сохранить для отладки
            return ""

    async def fetch_results_html(self, params: Dict[str, Any]) -> Tuple[str, str]:
        """
        Получает HTML результатов поиска с заданными параметрами.
        
        Args:
            params: Параметры поиска (КТРУ, регион, даты и т.д.)
            
        Returns:
            Tuple[html: str, url: str] - HTML страницы и использованный URL
            
        Raises:
            AppError: Если не удалось получить результаты после всех попыток
        """
        # Строим URL из параметров
        url = self.build_results_url(**params)
        
        last_exc: Optional[Exception] = None
        for attempt in range(1, settings.zakupki_max_retries + 1):
            try:
                # Случайная задержка между запросами (требование ТЗ)
                await self._sleep_human()
                
                # Выполняем запрос
                response = await self._client.get(url)
                
                # Обрабатываем коды ошибок с backoff
                if response.status_code in (403, 503):
                    wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                    await asyncio.sleep(wait_time)
                    continue
                    
                # Проверяем успешность
                response.raise_for_status()
                
                html = response.text
                
                # Сохраняем сырой HTML для отладки (требование ТЗ)
                debug_path = await self._save_debug_html(html, url, "results")
                if debug_path:
                    print(f"Debug HTML saved to: {debug_path}")
                
                return html, url
                
            except httpx.TimeoutException as e:
                last_exc = e
                wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                await asyncio.sleep(wait_time)
            except httpx.HTTPStatusError as e:
                last_exc = e
                if e.response.status_code >= 500:
                    wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                    await asyncio.sleep(wait_time)
                else:
                    raise AppError(
                        ErrorCode.ZAKUPKI_FETCH_ERROR,
                        f"HTTP error {e.response.status_code} for {url}",
                        details={"status_code": e.response.status_code}
                    )
            except Exception as e:
                last_exc = e
                wait_time = 2 ** attempt + random.uniform(0.5, 1.5)
                await asyncio.sleep(wait_time)
        
        # Если все попытки не удались
        raise AppError(
            ErrorCode.ZAKUPKI_FETCH_TIMEOUT,
            f"Failed to fetch results after {settings.zakupki_max_retries} attempts: {url}",
            details={"cause": str(last_exc) if last_exc else "Unknown"}
        )

    def parse_results(self, html: str) -> Tuple[int, list[FoundContractCard]]:
        """
        Парсит HTML страницы результатов поиска.
        
        Args:
            html: HTML страницы результатов
            
        Returns:
            Tuple[found_total: int, cards: list[FoundContractCard]] - 
            общее количество найденных контрактов и список карточек
            
        Raises:
            AppError: Если не удалось распарсить HTML
        """
        try:
            soup = BeautifulSoup(html, "lxml")
            
            # 1. Извлекаем общее количество найденных контрактов
            found_total = 0
            # Ищем элемент с информацией о количестве результатов
            total_elements = soup.find_all(string=lambda s: s and any(
                keyword in s.lower() for keyword in ["найдено", "записей", "результат"]
            ))
            
            for element in total_elements:
                text = element.strip()
                # Пытаемся извлечь число из текста
                import re
                numbers = re.findall(r'\d+', text.replace(' ', '').replace(',', ''))
                if numbers:
                    found_total = max(found_total, int(numbers[0]))
                    break
            
            # 2. Извлекаем карточки контрактов
            cards: list[FoundContractCard] = []
            
            # Пробуем разные селекторы для карточек контрактов
            card_selectors = [
                "div.search-registry-entry-block",
                "div.registry-entry",
                "div.search-result-item",
                "div.contract-card"
            ]
            
            cards_container = None
            for selector in card_selectors:
                cards_container = soup.select(selector)
                if cards_container:
                    break
            
            if not cards_container:
                # Если не нашли стандартные селекторы, ищем по структуре
                cards_container = soup.find_all("div", class_=lambda x: x and "block" in x.lower())
            
            for card in cards_container:
                try:
                    # Извлекаем реестровый номер и ссылку
                    link_elem = card.find("a", href=True)
                    if not link_elem:
                        continue
                    
                    reestr_number = link_elem.get_text(strip=True)
                    contract_url = link_elem["href"]
                    
                    # Делаем URL абсолютным, если нужно
                    if contract_url.startswith("/"):
                        contract_url = f"{settings.zakupki_base}{contract_url}"
                    elif not contract_url.startswith("http"):
                        contract_url = f"{settings.zakupki_base}/epz/contract/contractCard/common-info.html?reestrNumber={reestr_number}"
                    
                    # Извлекаем дату подписания
                    sign_date = None
                    date_elem = card.find("span", class_=lambda x: x and "date" in x.lower() if x else False)
                    if not date_elem:
                        date_elem = card.find("div", class_=lambda x: x and "date" in x.lower() if x else False)
                    if date_elem:
                        sign_date = date_elem.get_text(strip=True)
                    
                    # Извлекаем общую цену
                    price_total = None
                    price_elem = card.find("span", class_=lambda x: x and "price" in x.lower() if x else False)
                    if not price_elem:
                        price_elem = card.find("div", class_=lambda x: x and "price" in x.lower() if x else False)
                    if price_elem:
                        price_total = price_elem.get_text(strip=True)
                    
                    cards.append(FoundContractCard(
                        reestr_number=reestr_number,
                        contract_url=contract_url,
                        sign_date=sign_date,
                        price_total=price_total
                    ))
                    
                except Exception as card_error:
                    # Пропускаем карточку с ошибкой, продолжаем парсинг остальных
                    continue
            
            return found_total, cards
            
        except Exception as e:
            raise AppError(
                ErrorCode.ZAKUPKI_PARSE_ERROR,
                "Failed to parse search results HTML",
                details={"cause": str(e)}
            )

    def build_results_url(
        self,
        *,
        ktru: str,
        region: str,
        date_from: str,
        date_to: str,
        statuses: list[str],
        fz44: bool = True,
        limit: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """
        Строит URL для поиска контрактов на zakupki.gov.ru.
        
        Args:
            ktru: Код КТРУ
            region: Регион/округ заказчика
            date_from: Дата начала периода (формат ДД.ММ.ГГГГ)
            date_to: Дата окончания периода (формат ДД.ММ.ГГГГ)
            statuses: Список статусов исполнения
            fz44: Использовать 44-ФЗ
            limit: Лимит результатов (опционально)
            **kwargs: Дополнительные параметры
            
        Returns:
            URL для поиска контрактов
        """
        base_url = f"{settings.zakupki_base}/epz/contract/search/results.html"
        
        params: list[tuple[str, str]] = [
            ("searchString", ktru),
            ("contractDateFrom", date_from),
            ("contractDateTo", date_to),
            ("customerPlace", region),
        ]
        
        if fz44:
            params.append(("fz44", "on"))
        
        # Статусы исполнения
        for i, status in enumerate(statuses):
            params.append((f"contractStageList_{i}", status))
        
        # Сортировка по дате (сначала свежие)
        params.append(("sortBy", "UPDATE_DATE"))
        params.append(("sortDirection", "false"))
        
        # Лимит результатов
        if limit:
            params.append(("recordsPerPage", "_50"))  # Максимум на странице
        
        # Дополнительные параметры
        for key, value in kwargs.items():
            if value is not None:
                params.append((key, str(value)))
        
        from urllib.parse import urlencode
        return f"{base_url}?{urlencode(params)}"```

---

### Файл: `backend/app/workers/celery_app.py`

```python
from __future__ import annotations

from celery import Celery

from app.core.settings import settings

celery_app = Celery(
    "nmck",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.update(
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={"app.workers.tasks.*": {"queue": "nmck"}},
)```

---

### Файл: `backend/app/workers/tasks.py`

```python
from __future__ import annotations

import time
import uuid
from datetime import date
from decimal import Decimal

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import AppError, ErrorCode
from app.core.logging import log
from app.core.settings import settings
from app.infra.db.models import SearchRequest, SpecComparisonRow
from app.infra.db.repos import ResultRepo, SearchRepo
from app.infra.db.session import async_sessionmaker
from app.infra.events.event_broker import RedisEventBroker, StreamEvent
from app.services.ai.deepseek import DeepSeekClient
from app.services.nmc_service import calc_nmc_avg
from app.services.zakupki.client import ZakupkiClient


def _now_ms() -> int:
    return int(time.time() * 1000)


async def _check_stop(db: AsyncSession, search_id: uuid.UUID) -> bool:
    obj = (await db.execute(sa.select(SearchRequest.stop_requested).where(SearchRequest.id == search_id))).scalar_one_or_none()
    return bool(obj)


async def _set_status(db: AsyncSession, search_id: uuid.UUID, status: str, *, error_code: str | None = None, error_message: str | None = None, runtime_ms: int | None = None) -> None:
    await db.execute(
        sa.update(SearchRequest)
        .where(SearchRequest.id == search_id)
        .values(status=status, error_code=error_code, error_message=error_message, runtime_ms=runtime_ms)
    )


async def _inc_processed(db: AsyncSession, search_id: uuid.UUID, inc: int = 1) -> int:
    await db.execute(
        sa.update(SearchRequest)
        .where(SearchRequest.id == search_id)
        .values(processed_count=SearchRequest.processed_count + inc)
    )
    res = await db.execute(sa.select(SearchRequest.processed_count).where(SearchRequest.id == search_id))
    return int(res.scalar_one())


async def _set_found_total(db: AsyncSession, search_id: uuid.UUID, found_total: int) -> None:
    await db.execute(sa.update(SearchRequest).where(SearchRequest.id == search_id).values(found_total=found_total))


async def _finalize(db: AsyncSession, search_id: uuid.UUID, repo: ResultRepo) -> None:
    # Используем SearchService для автовыбора top-3
    from app.services.search_service import SearchService
    from app.infra.events.event_broker import RedisEventBroker
    
    broker = RedisEventBroker(settings.redis_url)
    service = SearchService(db=db, broker=broker)
    
    selected_ids, nmc_value = await service.auto_select_top_3(search_id)
    
    logger = log().bind(service="worker", search_id=str(search_id))
    logger.info(
        "finalize_completed",
        selected_count=len(selected_ids),
        nmc_value=str(nmc_value) if nmc_value else None,
    )


# Celery task (sync wrapper) -> runs async pipeline
from app.workers.celery_app import celery_app


@celery_app.task(name="app.workers.tasks.run_search_pipeline")
def run_search_pipeline(search_id: str, request_id: str = "unknown") -> None:
    import asyncio
    asyncio.run(_run_search_pipeline_async(search_id, request_id=request_id))


async def _run_search_pipeline_async(search_id: str, *, request_id: str) -> None:
    started = _now_ms()
    broker = RedisEventBroker(settings.redis_url)
    sid = uuid.UUID(search_id)

    async with async_sessionmaker() as db:
        search_repo = SearchRepo()
        result_repo = ResultRepo()

        # Load search
        search = await search_repo.get(db, sid)
        if not search:
            return

        logger = log().bind(service="worker", search_id=search_id, request_id=request_id)

        try:
            await broker.emit(search_id, StreamEvent("log", {"step": "ValidateInput", "msg": "OK"}))
            async with db.begin():
                await _set_status(db, sid, "RUNNING")

            if await _check_stop(db, sid):
                raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before start")

            # FetchSearchResults
            zakupki = ZakupkiClient()
            try:
                # Проверяем stop перед сетевым действием
                if await _check_stop(db, sid):
                    raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before fetching results")
                
                # Подготавливаем параметры для поиска
                search_params = {
                    "ktru": search.ktru_code,
                    "region": search.customer_region,
                    "date_from": search.date_from.strftime("%d.%m.%Y") if search.date_from else "",
                    "date_to": search.date_to.strftime("%d.%m.%Y") if search.date_to else "",
                    "statuses": list(search.execution_statuses),
                    "fz44": True,
                    "limit": int(search.limit_contracts) if search.limit_contracts else settings.default_limit_contracts,
                }
                
                # Получаем результаты поиска
                html, url = await zakupki.fetch_results_html(search_params)
                found_total, cards = zakupki.parse_results(html)
                
                await broker.emit(search_id, StreamEvent("log", {
                    "step": "FetchSearchResults", 
                    "msg": f"URL: {url}, found_total: {found_total}, cards: {len(cards)}"
                }))
                
            finally:
                await zakupki.close()

            async with db.begin():
                await _set_found_total(db, sid, found_total)

            await broker.emit(search_id, StreamEvent("progress", {"step": "FetchSearchResults", "found_total": found_total}))
            await broker.emit(search_id, StreamEvent("log", {"step": "FetchSearchResults", "msg": f"found_total={found_total}"}))

            # IterateContracts (limit)
            limit = int(search.limit_contracts)
            cards = cards[:limit]

            ai = DeepSeekClient()

            try:
                # Нормализуем target_specs (из текста пользователя)
                target_text = (search.target_specs or {}).get("raw_text", "") or ""
                target_norm = None
                if target_text.strip() and settings.deepseek_api_key:
                    # Проверяем stop перед AI запросом
                    if await _check_stop(db, sid):
                        raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before target specs normalization")
                    
                    await broker.emit(search_id, StreamEvent("log", {"step": "NormalizeSpecs", "msg": "target"}))
                    target_norm = (await ai.normalize(target_text)).model_dump()
                    async with db.begin():
                        search.target_specs = {"raw_text": target_text, "normalized": target_norm}
                        await search_repo.update(db, search)

                for idx, card in enumerate(cards, start=1):
                    if await _check_stop(db, sid):
                        raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested during processing")

                    reestr = card.reestr_number
                    c_logger = logger.bind(reestr_number=reestr)

                    await broker.emit(search_id, StreamEvent("log", {"step": "FetchContractCard", "reestr_number": reestr}))

                    # MVP: глубокий парсинг карточки/вкладок/печатной формы реализуется поэтапно.
                    # Здесь — безопасный шаблон: сохраняем raw_data_json и выполняем AI на specs_raw (пока пусто/заглушка).
                    # В реальном внедрении сюда подключаются:
                    # - FetchContractCard
                    # - ParseCommonInfo
                    # - ParsePaymentsAndObjects
                    # - FetchAttachments + DownloadPrintForm (2025+)
                    # - ExtractText (pdf/docx)
                    
                    # Используем данные из карточки поиска
                    card_info = f"Контракт {reestr}"
                    if card.sign_date:
                        card_info += f", дата: {card.sign_date}"
                    if card.price_total:
                        card_info += f", цена: {card.price_total}"
                    
                    specs_raw = f"{card_info}. Требования: {search.object_name or ''}"
                    
                    # Определяем, является ли контракт 2025+ на основе даты подписания
                    is_2025_plus = False
                    if card.sign_date:
                        try:
                            # Пытаемся извлечь год из даты
                            import re
                            year_match = re.search(r'\b(20\d{2})\b', card.sign_date)
                            if year_match:
                                year = int(year_match.group(1))
                                is_2025_plus = year >= 2025
                        except:
                            pass
                    
                    # Пытаемся извлечь цену за единицу из общей цены (в реальном MVP будет парсинг спецификации)
                    unit_price = None
                    if card.price_total:
                        try:
                            # Упрощенная логика: если есть общая цена, используем её как unit_price для MVP
                            # В реальном проекте нужно парсить спецификацию
                            import re
                            price_match = re.search(r'[\d\s,\.]+', card.price_total.replace(' ', ''))
                            if price_match:
                                price_str = price_match.group(0).replace(',', '.')
                                unit_price = Decimal(price_str)
                        except:
                            pass
                    found_norm = None
                    compare_res = None

                    if settings.deepseek_api_key:
                        # Проверяем stop перед AI запросами
                        if await _check_stop(db, sid):
                            raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before AI processing")
                        
                        await broker.emit(search_id, StreamEvent("log", {"step": "NormalizeSpecs", "reestr_number": reestr}))
                        found_norm = (await ai.normalize(specs_raw)).model_dump()

                        if target_norm:
                            # Проверяем stop перед сравнением
                            if await _check_stop(db, sid):
                                raise AppError(ErrorCode.STOP_REQUESTED, "Stop requested before AI comparison")
                            
                            await broker.emit(search_id, StreamEvent("log", {"step": "LLMCompareAndScore", "reestr_number": reestr}))
                            compare_res = (await ai.compare(
                                target_json=target_norm,
                                found_json=found_norm,
                                target_manufacturer=search.manufacturer_target,
                            )).model_dump()

                    match_type = (compare_res or {}).get("match_type", "NO_MATCH")
                    ai_score = int((compare_res or {}).get("score", 0))
                    manufacturer_found = (compare_res or {}).get("manufacturer_found")
                    manufacturer_match = (compare_res or {}).get("manufacturer_match")

                    # PersistResult (UPSERT)
                    values = {
                        "id": uuid.uuid4(),
                        "search_id": sid,
                        "reestr_number": reestr,
                        "contract_url": card.contract_url,
                        "sign_date": None,
                        "unit_price": unit_price,
                        "currency": "RUB",
                        "match_type": match_type,
                        "ai_score": ai_score,
                        "manufacturer_found": manufacturer_found,
                        "manufacturer_match": manufacturer_match,
                        "is_2025_plus": is_2025_plus,
                        "accepted_for_nmc": False,
                        "specs_raw": specs_raw,
                        "raw_data_json": {
                            "search_card": {
                                "reestr_number": card.reestr_number,
                                "contract_url": card.contract_url,
                                "sign_date": card.sign_date,
                                "price_total": card.price_total
                            },
                            "parsed_data": {
                                "is_2025_plus": is_2025_plus,
                                "unit_price": str(unit_price) if unit_price else None
                            }
                        },
                        "ai_analysis": compare_res or {},
                        "error_code": None,
                        "error_message": None,
                    }

                    async with db.begin():
                        contract_id = await result_repo.upsert_contract_result(db, values=values)

                        # сравнение (rows)
                        rows_payload = (compare_res or {}).get("rows", [])
                        rows = [
                            SpecComparisonRow(
                                contract_result_id=contract_id,
                                name=r.get("name", ""),
                                target_value=r.get("target"),
                                actual_value=r.get("actual"),
                                match_status=r.get("status", "UNKNOWN"),
                                reason=r.get("reason"),
                                weight=int(r.get("weight", 1) or 1),
                            )
                            for r in rows_payload
                            if r.get("name")
                        ]
                        if rows:
                            await result_repo.replace_comparison_rows(db, contract_id=contract_id, rows=rows)

                        processed = await _inc_processed(db, sid, 1)

                    # EmitProgressEvent + result_added
                    await broker.emit(search_id, StreamEvent("result_added", {
                        "id": str(contract_id),
                        "reestr_number": reestr,
                        "contract_url": card.contract_url,
                        "unit_price": str(unit_price) if unit_price is not None else None,
                        "match_type": match_type,
                        "ai_score": ai_score,
                        "manufacturer_found": manufacturer_found,
                        "manufacturer_match": manufacturer_match,
                        "is_2025_plus": is_2025_plus,
                    }))
                    await broker.emit(search_id, StreamEvent("progress", {"processed": processed, "limit": limit}))

            finally:
                await ai.close()

            # FinalizeSearch (top-3 + NMC)
            async with db.begin():
                await _finalize(db, sid, result_repo)
                await _set_status(db, sid, "DONE", runtime_ms=_now_ms() - started)

            await broker.emit(search_id, StreamEvent("done", {"status": "DONE"}))

        except AppError as e:
            # STOP or ERROR
            status = "STOPPED" if e.code == ErrorCode.STOP_REQUESTED else "ERROR"
            async with db.begin():
                await _set_status(db, sid, status, error_code=e.code, error_message=str(e), runtime_ms=_now_ms() - started)
            await broker.emit(search_id, StreamEvent("error" if status == "ERROR" else "done", {"status": status, "error_code": e.code, "message": str(e)}))
            logger.warning("pipeline_finished_with_app_error", status=status, error_code=e.code, msg=str(e))
        except Exception as e:
            async with db.begin():
                await _set_status(db, sid, "ERROR", error_code=ErrorCode.UNKNOWN_ERROR, error_message=str(e), runtime_ms=_now_ms() - started)
            await broker.emit(search_id, StreamEvent("error", {"status": "ERROR", "error_code": ErrorCode.UNKNOWN_ERROR, "message": str(e)}))
            logger.exception("pipeline_crashed", msg=str(e))```

---

