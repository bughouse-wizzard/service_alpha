# Код фронтенда системы zakupki-analyzer

## Содержание

### 1. HTML структура (`frontend/index.html`)
### 2. CSS стили (встроенные в HTML)
### 3. JavaScript логика (встроенная в HTML)
### 4. Мок данные для тестирования (встроенные в JavaScript)

---

## 1. HTML структура

### Файл: `frontend/index.html`

```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск НМЦК - ЕИС Госзакупки</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { font-family: 'Inter', system-ui, -apple-system, sans-serif; background-color: #f3f4f6; color: #1f2937; }
        
        /* Скроллбары */
        .table-container::-webkit-scrollbar { height: 8px; width: 8px; }
        .table-container::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 4px; }
        .table-container::-webkit-scrollbar-track { background-color: #f1f5f9; }
        .sidebar-scroll::-webkit-scrollbar { width: 4px; }
        .sidebar-scroll::-webkit-scrollbar-thumb { background-color: #d1d5db; border-radius: 2px; }

        /* Таблица */
        .clickable-row { cursor: pointer; transition: background-color 0.15s ease; }
        .clickable-row:hover { background-color: #eff6ff; }
        
        /* Фильтры */
        .th-filter-wrapper { display: flex; flex-direction: column; gap: 4px; margin-top: 6px; }
        .th-input { 
            font-size: 0.75rem; padding: 5px 8px; border: 1px solid #d1d5db; 
            border-radius: 6px; width: 100%; outline: none; transition: all 0.2s; background-color: #fff;
        }
        .th-input:focus { border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1); }

        /* Анимации */
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fadeIn 0.3s ease-out forwards; }
        
        /* Модальные окна */
        .modal-backdrop {
            position: fixed; inset: 0; background-color: rgba(0,0,0,0.5); 
            backdrop-filter: blur(2px); z-index: 50; display: none;
            align-items: center; justify-content: center; opacity: 0; transition: opacity 0.2s;
        }
        .modal-backdrop.open { display: flex; opacity: 1; }
        .modal-content {
            background: white; border-radius: 12px; max-width: 800px; width: 95%; 
            max-height: 90vh; display: flex; flex-direction: column;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            transform: scale(0.95); transition: transform 0.2s;
        }
        .modal-backdrop.open .modal-content { transform: scale(1); }

        /* Уведомления */
        #notification-area { position: fixed; bottom: 20px; right: 20px; z-index: 100; display: flex; flex-direction: column; gap: 10px; }
        .toast { 
            background: white; padding: 12px 16px; border-radius: 8px; 
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); 
            border-left: 4px solid #3b82f6; display: flex; align-items: center; gap: 12px;
            transform: translateX(120%); transition: transform 0.3s ease-out; min-width: 300px;
        }
        .toast.show { transform: translateX(0); }

        /* Вкладки */
        .tab-btn { color: #6b7280; font-weight: 500; padding: 8px 16px; border-bottom: 2px solid transparent; transition: all 0.2s; }
        .tab-btn:hover { color: #1f2937; background-color: #f9fafb; border-radius: 6px 6px 0 0; }
        .tab-btn.active { color: #2563eb; border-bottom-color: #2563eb; font-weight: 600; }
    </style>
</head>
<body class="h-screen flex flex-col overflow-hidden">

    <header class="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-4 lg:px-6 shrink-0 z-20">
        <div class="flex items-center gap-3">
            <div class="bg-blue-600 text-white w-8 h-8 rounded-lg flex items-center justify-center shadow-md">
                <i class="fas fa-search"></i>
            </div>
            <div>
                <h1 class="text-lg lg:text-xl font-bold text-gray-800 leading-tight">Поиск НМЦК</h1>
                <div class="text-[10px] text-gray-500 uppercase tracking-wider">ЕИС Госзакупки РФ</div>
            </div>
        </div>
        
        <div class="flex items-center gap-4">
            <div class="hidden md:block text-right">
                <div class="text-sm font-medium text-gray-700">Иванов И.И.</div>
                <div class="text-xs text-gray-400">СЗФО • 44-ФЗ</div>
            </div>
            <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200">
                <i class="fas fa-user"></i>
            </button>
            <button class="lg:hidden text-gray-600 text-xl ml-2" onclick="toggleSidebar()">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>

    <div class="flex flex-1 overflow-hidden relative">
        
        <main class="flex-1 flex flex-col min-w-0 bg-gray-50 relative overflow-hidden">
            
            <div class="bg-white border-b border-gray-200 px-4 pt-2 flex gap-4 shrink-0">
                <button onclick="switchTab('history')" id="tab-history" class="tab-btn active">
                    <i class="fas fa-history mr-2"></i>История поисков
                </button>
                <button onclick="switchTab('results')" id="tab-results" class="tab-btn">
                    <i class="fas fa-list-check mr-2"></i>Результаты поиска
                    <span id="badge-new" class="hidden ml-1 px-1.5 py-0.5 bg-red-500 text-white text-[10px] rounded-full">New</span>
                </button>
            </div>

            <div class="flex-1 overflow-y-auto p-4 lg:p-6" id="main-scroll">
                
                <div id="view-history" class="animate-fade-in block h-full pb-10">
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-full max-h-[calc(100vh-140px)]">
                        <div class="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50 shrink-0">
                            <h2 class="font-semibold text-gray-700">Реестр запросов</h2>
                            <button onclick="refreshHistory()" class="text-xs text-blue-600 hover:underline"><i class="fas fa-sync-alt mr-1"></i>Обновить</button>
                        </div>
                        
                        <div class="table-container overflow-x-auto flex-1">
                            <table class="w-full text-left text-sm whitespace-nowrap">
                                <thead class="bg-gray-50 text-gray-600 border-b border-gray-200 sticky top-0 z-10">
                                    <tr>
                                        <th class="p-3 font-semibold w-32 bg-gray-50">
                                            Дата
                                            <div class="th-filter-wrapper"><input type="date" class="th-input" onchange="updateHistoryFilter('date', this.value)"></div>
                                        </th>
                                        <th class="p-3 font-semibold min-w-[200px] bg-gray-50">
                                            Объект закупки
                                            <div class="th-filter-wrapper"><input type="text" class="th-input" placeholder="Поиск..." oninput="updateHistoryFilter('name', this.value)"></div>
                                        </th>
                                        <th class="p-3 font-semibold min-w-[120px] bg-gray-50">КТРУ</th>
                                        <th class="p-3 font-semibold w-32 bg-gray-50">
                                            Статус
                                            <div class="th-filter-wrapper">
                                                <select class="th-input" onchange="updateHistoryFilter('status', this.value)">
                                                    <option value="">Все</option>
                                                    <option value="Завершен">Завершен</option>
                                                    <option value="В работе">В работе</option>
                                                    <option value="Остановлен">Остановлен</option>
                                                </select>
                                            </div>
                                        </th>
                                        <th class="p-3 font-semibold w-24 bg-gray-50">Найдено</th>
                                        <th class="p-3 font-semibold bg-gray-50">Средняя цена</th>
                                        <th class="p-3 font-semibold w-32 text-center bg-gray-50">Действие</th>
                                    </tr>
                                </thead>
                                <tbody id="history-body" class="divide-y divide-gray-100"></tbody>
                            </table>
                        </div>

                        <div class="border-t border-gray-200 p-3 bg-gray-50 flex flex-col sm:flex-row justify-between items-center gap-3 shrink-0">
                            <div class="text-xs text-gray-500">
                                Показано <span id="hist-pg-start">0</span>-<span id="hist-pg-end">0</span> из <span id="hist-pg-total">0</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <button onclick="changeHistoryPage(-1)" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100 text-sm disabled:opacity-50" id="hist-btn-prev">Назад</button>
                                <span class="text-sm font-medium px-2">Стр. <span id="hist-pg-current">1</span></span>
                                <button onclick="changeHistoryPage(1)" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100 text-sm disabled:opacity-50" id="hist-btn-next">Вперед</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="view-results" class="hidden animate-fade-in pb-20">
                    <div class="bg-white border border-blue-100 rounded-xl p-4 mb-4 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <h2 class="text-lg font-bold text-gray-800" id="res-title">Результаты поиска</h2>
                            <div class="text-sm text-gray-500 mt-1" id="res-meta">Выберите поиск из истории</div>
                        </div>
                        <div class="bg-blue-50 px-4 py-2 rounded-lg border border-blue-200 text-right min-w-[180px]">
                            <div class="text-xs text-blue-600 font-bold uppercase">Расчетная НМЦ</div>
                            <div class="text-2xl font-bold text-gray-800 leading-none mt-1" id="nmc-value">0.00 ₽</div>
                            <div class="text-[10px] text-gray-500 mt-1">по <span id="selected-count" class="font-bold">0</span> контрактам (Цель: 3)</div>
                        </div>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-[calc(100vh-280px)]">
                        <div class="table-container overflow-x-auto flex-1 relative">
                            <table class="w-full text-left text-sm whitespace-nowrap relative" id="results-table">
                                <thead class="bg-gray-50 text-gray-600 border-b border-gray-200 sticky top-0 z-10 shadow-sm">
                                    <tr>
                                        <th class="p-3 text-center w-10 bg-gray-50">✓</th>
                                        <th class="p-3 font-semibold min-w-[140px] bg-gray-50">
                                            № Контракта
                                            <div class="th-filter-wrapper">
                                                <input type="text" id="filter-id" class="th-input" placeholder="Поиск..." oninput="applyAllFilters()">
                                            </div>
                                        </th>
                                        <th class="p-3 font-semibold bg-gray-50">Год</th>
                                        <th class="p-3 font-semibold bg-gray-50">Цена ед.</th>
                                        <th class="p-3 font-semibold bg-gray-50">
                                            Тип
                                            <div class="th-filter-wrapper">
                                                <select id="filter-type" class="th-input" onchange="applyAllFilters()">
                                                    <option value="">Все</option>
                                                    <option value="Идентичный">Идентичный</option>
                                                    <option value="Однородный">Однородный</option>
                                                </select>
                                            </div>
                                        </th>
                                        <th class="p-3 font-semibold min-w-[150px] bg-gray-50">Производитель</th>
                                        <th class="p-3 font-semibold bg-gray-50 w-28">
                                            AI Score
                                            <div class="th-filter-wrapper">
                                                <input type="number" id="filter-score" class="th-input" placeholder="Min %" min="0" max="100" oninput="applyAllFilters()">
                                            </div>
                                        </th>
                                        <th class="p-3 font-semibold bg-gray-50 text-center">Сравнение</th>
                                    </tr>
                                </thead>
                                <tbody id="results-body" class="divide-y divide-gray-100"></tbody>
                            </table>
                        </div>
                        
                        <div class="border-t border-gray-200 p-3 bg-gray-50 flex flex-col sm:flex-row justify-between items-center gap-3 shrink-0">
                            <div class="text-xs text-gray-500">
                                Показано <span id="pg-start">0</span>-<span id="pg-end">0</span> из <span id="pg-total">0</span>
                            </div>
                            <div class="flex items-center gap-2" id="pagination-controls">
                                <button onclick="changePage(-1)" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100 text-sm disabled:opacity-50" id="btn-prev">Назад</button>
                                <span class="text-sm font-medium px-2">Стр. <span id="pg-current">1</span></span>
                                <button onclick="changePage(1)" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100 text-sm disabled:opacity-50" id="btn-next">Вперед</button>
                            </div>
                        </div>
                    </div>

                    <div class="fixed bottom-0 left-0 right-0 lg:left-[calc(25%-1rem)] lg:ml-[25%] bg-white border-t border-gray-200 p-4 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] flex justify-between items-center z-30 transition-transform duration-300" id="results-footer">
                        <button class="text-gray-500 hover:text-gray-800 text-sm font-medium" onclick="switchTab('history')">
                            ← Назад
                        </button>
                        <div class="flex gap-3">
                            <button class="hidden sm:flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50" onclick="exportReport()">
                                <i class="fas fa-file-excel text-green-600 mr-2"></i>Скачать отчет
                            </button>
                            <button class="px-6 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 shadow-lg shadow-blue-200" onclick="showToast('Расчет НМЦК сохранен', 'success')">
                                Сохранить расчет
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <aside class="fixed inset-y-0 right-0 w-80 bg-white border-l border-gray-200 shadow-2xl transform translate-x-full lg:translate-x-0 lg:static lg:w-96 lg:shadow-none transition-transform duration-300 z-40 flex flex-col" id="sidebar">
            <div class="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <h3 class="font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-search-plus text-blue-600"></i> Новый поиск
                </h3>
                <button class="lg:hidden text-gray-500 hover:text-red-500" onclick="toggleSidebar()">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            <div class="flex-1 overflow-y-auto p-5 sidebar-scroll">
                <form id="search-form" onsubmit="startSearch(event)" class="space-y-5">
                    
                    <div>
                        <div class="flex justify-between items-center mb-2">
                            <label class="block text-xs font-bold text-gray-500 uppercase">1. Загрузка ТЗ <span class="text-[10px] font-normal text-gray-400">(Опц.)</span></label>
                        </div>
                        <div class="border-2 border-dashed border-gray-300 rounded-xl p-3 text-center hover:bg-blue-50 hover:border-blue-400 transition cursor-pointer relative group mb-2" id="drop-zone">
                            <input type="file" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept=".doc,.docx,.pdf,.html" onchange="handleFile(this)">
                            <div id="file-label">
                                <i class="fas fa-cloud-upload-alt text-xl text-gray-300 mb-1 group-hover:text-blue-500 transition"></i>
                                <p class="text-[10px] text-gray-500">Нажмите или перетащите файл<br>(Docx, PDF, HTML)</p>
                            </div>
                        </div>
                        
                        <div id="file-items-wrapper" class="hidden mt-3 animate-fade-in bg-gray-50 p-3 rounded border border-gray-200">
                            <label class="block text-[10px] text-gray-500 font-bold mb-1 uppercase">Выберите номер позиции (товара)</label>
                            <select id="file-item-select" class="w-full p-2 bg-white border border-gray-300 rounded text-sm text-gray-700 outline-none focus:border-blue-500" onchange="autoFillFromTz()">
                                <option value="">-- Не выбрано --</option>
                                <option value="paper">Лот 1. Бумага офисная (Стр. 2)</option>
                                <option value="pc">Лот 2. Моноблок офисный (Стр. 5)</option>
                                <option value="generic">Лот 3. Картридж черный (Стр. 8)</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-3">2. Параметры поиска</label>
                        <div class="space-y-3">
                            <div>
                                <label class="block text-[10px] text-gray-400 mb-1 font-medium">Наименование объекта закупки</label>
                                <input type="text" id="obj-name-input" class="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:bg-white focus:border-blue-500 outline-none transition" placeholder="Напр. Бумага для офисной техники">
                            </div>
                            <div>
                                <label class="block text-[10px] text-gray-400 mb-1 font-medium">Код КТРУ (ОКПД2)</label>
                                <input type="text" id="ktru-input" class="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:bg-white focus:border-blue-500 outline-none transition" placeholder="Напр. 17.12.14.110">
                            </div>
                            <div>
                                <label class="block text-[10px] text-gray-400 mb-1 font-medium">Производитель (для сверки)</label>
                                <input type="text" id="mfr-input" class="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:bg-white focus:border-blue-500 outline-none transition" placeholder="Напр. SvetoCopy">
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2 mt-3">
                             <select class="w-full p-2 bg-gray-50 border border-gray-200 rounded text-sm text-gray-700 outline-none focus:border-blue-500"><option>СЗФО</option><option>ЦФО</option></select>
                             <select class="w-full p-2 bg-gray-50 border border-gray-200 rounded text-sm text-gray-700 outline-none focus:border-blue-500"><option>3 года</option><option>1 год</option></select>
                        </div>
                        
                        <div class="mt-3">
                            <label class="block text-[10px] text-gray-400 mb-1 font-medium">Лимит контрактов (шт)</label>
                            <input type="number" id="limit-input" value="30" min="1" max="1000" class="w-full p-2 bg-gray-50 border border-gray-200 rounded text-sm text-gray-700 outline-none focus:border-blue-500">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-2">3. Характеристики товара</label>
                        <textarea id="specs-text" rows="4" class="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:bg-white focus:border-blue-500 outline-none transition resize-none" placeholder="Введите характеристики товара в свободной форме..."></textarea>
                    </div>

                    <button type="submit" id="btn-search" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200 transition transform active:scale-[0.98] flex items-center justify-center gap-2">
                        <i class="fas fa-rocket"></i> Начать поиск
                    </button>
                </form>

                <div id="progress-panel" class="hidden mt-6 bg-white rounded-lg border border-gray-200 p-4 shadow-sm animate-fade-in">
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-xs font-bold text-blue-600 uppercase flex items-center gap-2">
                            <i class="fas fa-spinner fa-spin"></i> Выполнение...
                        </span>
                        <span class="text-xs font-bold text-gray-500" id="proc-count">0/30</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2 mb-4 overflow-hidden">
                        <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" style="width: 0%" id="proc-bar"></div>
                    </div>
                    <button onclick="stopActiveSearch()" class="w-full py-2 border border-red-200 text-red-600 text-xs font-bold rounded hover:bg-red-50 transition flex items-center justify-center gap-2">
                        <i class="fas fa-stop-circle"></i> Остановить процедуру
                    </button>
                </div>
            </div>
        </aside>

        <button class="lg:hidden fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-2xl z-50 hover:bg-blue-700 transition" onclick="toggleSidebar()">
            <i class="fas fa-plus text-xl"></i>
        </button>

    </div>

    <div id="comparison-modal" class="modal-backdrop">
        <div class="modal-content">
            <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl">
                <div>
                    <h3 class="font-bold text-gray-800 text-lg">Сравнение характеристик</h3>
                    <p class="text-sm text-gray-500" id="comp-contract-id">Контракт № ...</p>
                </div>
                <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
            </div>
            <div class="p-6 overflow-y-auto max-h-[60vh]">
                <table class="w-full text-sm text-left border-collapse">
                    <thead class="text-xs text-gray-500 uppercase bg-gray-50 border-b">
                        <tr>
                            <th class="px-4 py-3">Характеристика</th>
                            <th class="px-4 py-3">Требование</th>
                            <th class="px-4 py-3">В контракте</th>
                            <th class="px-4 py-3 text-center">Статус</th>
                        </tr>
                    </thead>
                    <tbody id="comp-table-body" class="divide-y divide-gray-100"></tbody>
                </table>
            </div>
            <div class="px-6 py-4 border-t border-gray-100 bg-gray-50 rounded-b-xl flex justify-end">
                <button onclick="closeModal()" class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-sm font-medium">Закрыть</button>
            </div>
        </div>
    </div>

    <div id="notification-area"></div>

    <script>
        // --- API CONFIG ---
        const API_BASE = "http://localhost:8000/api";
        
        // Генератор requestId для корреляции
        function generateRequestId() {
            return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }
        
        // Обёртка для fetch с заголовками
        async function apiFetch(endpoint, options = {}) {
            const requestId = generateRequestId();
            const headers = {
                'Content-Type': 'application/json',
                'X-Request-Id': requestId,
                ...options.headers
            };
            
            const response = await fetch(`${API_BASE}${endpoint}`, {
                ...options,
                headers
            });
            
            if (!response.ok) {
                const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
                throw new Error(error.detail || `HTTP ${response.status}`);
            }
            
            return response.json();
        }
        
        // API функции
        const apiClient = {
            // Создать поиск
            createSearch: async (payload) => {
                return apiFetch('/search', {
                    method: 'POST',
                    body: JSON.stringify(payload)
                });
            },
            
            // Остановить поиск
            stopSearch: async (id) => {
                return apiFetch(`/search/${id}/stop`, {
                    method: 'POST'
                });
            },
            
            // Получить список поисков
            listSearches: async (params = {}) => {
                const query = new URLSearchParams(params).toString();
                return apiFetch(`/search${query ? '?' + query : ''}`);
            },
            
            // Получить результаты поиска
            listResults: async (searchId, params = {}) => {
                const query = new URLSearchParams(params).toString();
                return apiFetch(`/search/${searchId}/results${query ? '?' + query : ''}`);
            },
            
            // Обновить выбранные контракты
            patchSelection: async (searchId, ids) => {
                return apiFetch(`/search/${searchId}/selection`, {
                    method: 'PATCH',
                    body: JSON.stringify({ selected_contract_ids: ids })
                });
            }
        };

        // --- DATA & CONFIG ---
        const MOCK_SCENARIOS = {
            paper: { basePrice: 350, specs: [{name: "Белизна", target: "160%", options: ["160%"]}, {name: "Плотность", target: "80 г/м2", options: ["80 г/м2"]}], mfrs: ["SvetoCopy", "Xerox"] },
            pc: { basePrice: 55000, specs: [{name: "CPU", target: "Core i5", options: ["i5", "i3"]}, {name: "RAM", target: "16GB", options: ["16GB", "8GB"]}], mfrs: ["HP", "Lenovo"] },
            generic: { basePrice: 1500, specs: [{name: "Стандарт", target: "ГОСТ", options: ["ГОСТ", "ТУ"]}], mfrs: ["Завод №1", "ПромТех"] }
        };

        let MOCK_HISTORY = []; // Будет заполнено в init
        
        // --- History Pagination State ---
        let currentHistoryPage = 1;
        const historyRowsPerPage = 10;
        let activeHistoryFilters = { name: '', status: '', date: '' };

        // --- Results Pagination State ---
        let currentContracts = [];
        let filteredContracts = [];
        let selectedContractIds = new Set();
        let currentPage = 1;
        const rowsPerPage = 10;
        
        let searchIntervals = {}; 
        let activeSidebarSearchId = null;
        let eventSource = null;

        document.addEventListener('DOMContentLoaded', () => {
            initMockHistory(); // Generate dummy data to show pagination
            renderHistory();
            document.getElementById('results-footer').classList.add('translate-y-full'); 
        });

        // Generate some history data so pagination is visible
        function initMockHistory() {
            MOCK_HISTORY = [
                { id: 101, date: "2026-01-21", name: "Бумага офисная A4", ktru: "17.12.14.110", status: "Завершен", found: 45, avg: 420.50, type: "paper" },
                { id: 102, date: "2026-01-20", name: "АРМ (Компьютеры)", ktru: "26.20.15.000", status: "Завершен", found: 15, avg: 54400.00, type: "pc" }
            ];
            // Add filler data
            for(let i=0; i<25; i++) {
                const day = 1 + Math.floor(Math.random() * 20);
                MOCK_HISTORY.push({
                    id: 200 + i,
                    date: `2025-12-${day < 10 ? '0'+day : day}`,
                    name: i % 3 === 0 ? "Картридж лазерный" : (i % 2 === 0 ? "Стул офисный" : "Папка-регистратор"),
                    ktru: "00.00.00.000",
                    status: Math.random() > 0.8 ? "Остановлен" : "Завершен",
                    found: Math.floor(Math.random() * 50),
                    avg: Math.random() * 5000,
                    type: "generic"
                });
            }
            // Sort by date desc
            MOCK_HISTORY.sort((a,b) => b.id - a.id);
        }

        // --- SEARCH LOGIC ---
        function handleFile(input) {
            if(input.files[0]) {
                document.getElementById('file-label').innerHTML = `<span class="text-gray-800 font-bold">${input.files[0].name}</span>`;
                document.getElementById('file-items-wrapper').classList.remove('hidden');
                showToast('Файл обработан. Выберите позицию из списка.', 'success');
            }
        }

        function autoFillFromTz() {
            const val = document.getElementById('file-item-select').value;
            if(val === "paper") {
                document.getElementById('obj-name-input').value = "Бумага офисная A4";
                document.getElementById('ktru-input').value = "17.12.14.110";
            } else if(val === "pc") {
                document.getElementById('obj-name-input').value = "Моноблок офисный";
                document.getElementById('ktru-input').value = "26.20.15";
            } else {
                document.getElementById('obj-name-input').value = "";
                document.getElementById('ktru-input').value = "";
            }
        }

        async function startSearch(e) {
            e.preventDefault();
            
            const nameInput = document.getElementById('obj-name-input').value;
            const fileSelect = document.getElementById('file-item-select');
            const limitVal = parseInt(document.getElementById('limit-input').value) || 30;
            const specsText = document.getElementById('specs-text').value;
            const ktruCode = document.getElementById('ktru-input').value;
            const manufacturerTarget = document.getElementById('mfr-input').value || null;

            let searchName = nameInput;
            let type = "generic";
            if(fileSelect && fileSelect.value) {
                const opt = fileSelect.options[fileSelect.selectedIndex];
                if(fileSelect.value !== "") {
                    searchName = opt.text;
                    type = fileSelect.value;
                }
            }
            if(!searchName) searchName = "Объект закупки";
            if(type === "generic") type = detectType(searchName);

            document.getElementById('btn-search').classList.add('hidden');
            document.getElementById('progress-panel').classList.remove('hidden');
            showToast('Поиск запущен...', 'info');

            try {
                // Создаем payload согласно схеме из ТЗ
                const payload = {
                    object_name: searchName,
                    ktru_code: ktruCode,
                    manufacturer_target: manufacturerTarget,
                    customer_region: "SZFO", // По умолчанию СЗФО
                    limit_contracts: limitVal,
                    execution_statuses: ["EC", "ET"], // Исполнение завершено/прекращено
                    law: "44", // 44-ФЗ
                    date_from: new Date(Date.now() - 3 * 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 3 года назад
                    date_to: new Date().toISOString().split('T')[0], // Сегодня
                    specs_text: specsText
                };

                const response = await apiClient.createSearch(payload);
                const searchId = response.id;
                
                activeSidebarSearchId = searchId;

                const newHistoryItem = { 
                    id: searchId, 
                    date: new Date().toISOString().split('T')[0], 
                    name: searchName,
                    ktru: ktruCode || "---",
                    status: "В работе", 
                    found: 0, 
                    avg: 0,
                    targetMfr: manufacturerTarget, 
                    type: type,
                    limit: limitVal, 
                    specsText: specsText 
                };
                
                MOCK_HISTORY.unshift(newHistoryItem);
                currentHistoryPage = 1; // Reset to page 1 on new search
                renderHistory();

                // Запускаем SSE для получения прогресса
                setupSSE(searchId);

            } catch (error) {
                showToast(`Ошибка создания поиска: ${error.message}`, 'error');
                resetSidebarUI();
            }
        }

        function setupSSE(searchId) {
            // Закрываем предыдущее соединение, если есть
            if (eventSource) {
                eventSource.close();
            }
            
            eventSource = new EventSource(`${API_BASE}/search/${searchId}/events`);
            
            eventSource.onopen = () => {
                console.log(`SSE подключен для поиска ${searchId}`);
            };
            
            eventSource.addEventListener('progress', (event) => {
                const data = JSON.parse(event.data);
                const item = MOCK_HISTORY.find(i => i.id === searchId);
                if (item) {
                    item.found = data.found_total || 0;
                    item.processed_count = data.processed_count || 0;
                    
                    // Обновляем прогресс в UI
                    if (activeSidebarSearchId === searchId) {
                        const progress = item.limit > 0 ? Math.min(100, (item.processed_count / item.limit) * 100) : 0;
                        document.getElementById('proc-bar').style.width = `${progress}%`;
                        document.getElementById('proc-count').innerText = `${item.processed_count}/${item.limit}`;
                    }
                    
                    renderHistory();
                }
            });
            
            eventSource.addEventListener('result_added', async (event) => {
                const data = JSON.parse(event.data);
                console.log('Новый результат:', data);
                
                // Если мы на вкладке результатов этого поиска, обновляем таблицу
                const currentSearch = MOCK_HISTORY.find(i => i.id === searchId);
                if (currentSearch && document.getElementById('tab-results').classList.contains('active')) {
                    // Загружаем свежие результаты
                    await loadResultsFromAPI(searchId);
                }
            });
            
            eventSource.addEventListener('done', async (event) => {
                const data = JSON.parse(event.data);
                const item = MOCK_HISTORY.find(i => i.id === searchId);
                if (item) {
                    item.status = "Завершен";
                    item.found = data.found_total || 0;
                    item.avg = data.nmc_value || 0;
                    
                    showToast(`Поиск завершен. Найдено ${item.found} контрактов`, 'success');
                    document.getElementById('badge-new').classList.remove('hidden');
                    
                    if (activeSidebarSearchId === searchId) {
                        resetSidebarUI();
                    }
                    
                    renderHistory();
                    
                    // Закрываем SSE соединение
                    if (eventSource) {
                        eventSource.close();
                        eventSource = null;
                    }
                }
            });
            
            eventSource.addEventListener('error', (event) => {
                console.error('SSE ошибка:', event);
                showToast('Ошибка подключения к серверу событий', 'error');
                
                if (eventSource) {
                    eventSource.close();
                    eventSource = null;
                }
            });
            
            eventSource.onerror = (error) => {
                console.error('SSE соединение разорвано:', error);
                if (eventSource) {
                    eventSource.close();
                    eventSource = null;
                }
            };
        }

        function stopActiveSearch() {
            if(activeSidebarSearchId) stopSearch(activeSidebarSearchId);
        }

        async function stopSearch(id) {
            try {
                await apiClient.stopSearch(id);
                
                const item = MOCK_HISTORY.find(i => i.id === id);
                if(item && item.status === "В работе") {
                    item.status = "Остановлен";
                    showToast('Поиск остановлен пользователем', 'error');
                    if(activeSidebarSearchId === id) {
                        resetSidebarUI();
                    }
                    renderHistory();
                }
            } catch (error) {
                showToast(`Ошибка остановки поиска: ${error.message}`, 'error');
            }
        }

        function finishSearch(id, limitVal) {
            if(searchIntervals[id]) {
                clearInterval(searchIntervals[id]);
                delete searchIntervals[id];
            }

            const item = MOCK_HISTORY.find(i => i.id === id);
            if(item) {
                item.status = "Завершен";
                const baseFound = Math.floor(limitVal * 0.9);
                item.found = Math.max(1, baseFound + Math.floor(Math.random() * (limitVal * 0.2)));
            }

            if(activeSidebarSearchId === id) {
                resetSidebarUI();
            }

            showToast(`Поиск завершен. Найдено ${item.found}`, 'success');
            document.getElementById('badge-new').classList.remove('hidden');
            renderHistory();
            // Optional: Auto load results not annoying user
            // loadResults(item); 
        }

        function resetSidebarUI() {
            document.getElementById('progress-panel').classList.add('hidden');
            document.getElementById('btn-search').classList.remove('hidden');
            activeSidebarSearchId = null;
        }

        function detectType(name) {
            const n = name.toLowerCase();
            if(n.includes("бумаг")) return "paper";
            if(n.includes("комп") || n.includes("моноблок")) return "pc";
            return "generic";
        }

        // --- HISTORY TABLE & PAGINATION ---
        function updateHistoryFilter(key, value) {
            activeHistoryFilters[key] = value;
            currentHistoryPage = 1; // Reset to first page on filter change
            renderHistory();
        }

        function changeHistoryPage(delta) {
            currentHistoryPage += delta;
            renderHistory();
        }

        function refreshHistory() {
            renderHistory();
            showToast('История обновлена', 'info');
        }

        function renderHistory() {
            const tbody = document.getElementById('history-body');
            tbody.innerHTML = '';
            
            // 1. Filter Data
            let filteredData = MOCK_HISTORY.filter(item => {
                const matchName = item.name.toLowerCase().includes(activeHistoryFilters.name.toLowerCase());
                const matchStatus = activeHistoryFilters.status === '' || item.status === activeHistoryFilters.status;
                const matchDate = activeHistoryFilters.date === '' || item.date === activeHistoryFilters.date;
                return matchName && matchStatus && matchDate;
            });

            // 2. Paginate Data
            const total = filteredData.length;
            const totalPages = Math.ceil(total / historyRowsPerPage);
            
            // Bound checking
            if(currentHistoryPage < 1) currentHistoryPage = 1;
            if(currentHistoryPage > totalPages && totalPages > 0) currentHistoryPage = totalPages;
            
            const start = (currentHistoryPage - 1) * historyRowsPerPage;
            const end = start + historyRowsPerPage;
            const pageData = filteredData.slice(start, end);

            // 3. Render Rows
            pageData.forEach(item => {
                const tr = document.createElement('tr');
                tr.className = 'clickable-row border-b border-gray-50 group';
                tr.onclick = (e) => {
                    if(['BUTTON', 'I', 'SELECT'].includes(e.target.tagName)) return;
                    if(item.status === 'Завершен') loadResults(item);
                };

                let statusHtml = '';
                let actionHtml = '';

                if(item.status === 'В работе') {
                    statusHtml = `<span class="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full font-bold animate-pulse">В работе</span>`;
                    actionHtml = `<button onclick="stopSearch(${item.id}); event.stopPropagation()" class="text-white bg-red-500 hover:bg-red-600 text-xs px-3 py-1 rounded shadow transition">Остановить</button>`;
                } else if (item.status === 'Завершен') {
                    statusHtml = `<span class="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-bold">Завершен</span>`;
                    actionHtml = `<button class="text-gray-400 hover:text-blue-600"><i class="fas fa-chevron-right"></i></button>`;
                } else {
                    statusHtml = `<span class="bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded-full font-bold">Остановлен</span>`;
                    actionHtml = `<span class="text-gray-300">-</span>`;
                }

                tr.innerHTML = `
                    <td class="p-3 text-gray-500 text-xs">${item.date}</td>
                    <td class="p-3 font-medium text-gray-900 group-hover:text-blue-600 transition-colors">${item.name}</td>
                    <td class="p-3 text-xs text-gray-500">${item.ktru}</td>
                    <td class="p-3">${statusHtml}</td>
                    <td class="p-3 text-center">${item.found}</td>
                    <td class="p-3 font-mono text-sm">${item.avg ? item.avg.toFixed(2) + ' ₽' : '-'}</td>
                    <td class="p-3 text-center text-xs">${actionHtml}</td>
                `;
                tbody.appendChild(tr);
            });

            // 4. Update Controls
            document.getElementById('hist-pg-start').innerText = total > 0 ? start + 1 : 0;
            document.getElementById('hist-pg-end').innerText = Math.min(end, total);
            document.getElementById('hist-pg-total').innerText = total;
            document.getElementById('hist-pg-current').innerText = currentHistoryPage;
            
            document.getElementById('hist-btn-prev').disabled = currentHistoryPage <= 1;
            document.getElementById('hist-btn-next').disabled = currentHistoryPage >= totalPages || total === 0;
        }

        // --- RESULTS LOGIC ---
        async function loadResults(historyItem) {
            try {
                await loadResultsFromAPI(historyItem.id);
                switchTab('results');
                if(window.innerWidth < 1024) document.getElementById('sidebar').classList.add('translate-x-full');
            } catch (error) {
                showToast(`Ошибка загрузки результатов: ${error.message}`, 'error');
            }
        }

        async function loadResultsFromAPI(searchId) {
            try {
                const response = await apiClient.listResults(searchId, { page: 1, per_page: 100 });
                const historyItem = MOCK_HISTORY.find(i => i.id === searchId);
                
                if (!historyItem) return;
                
                currentContracts = response.results.map(result => ({
                    id: result.reestr_number,
                    date: result.sign_date,
                    price: result.unit_price || 0,
                    type: result.match_type === 'IDENTICAL' ? 'Идентичный' : 'Однородный',
                    manufacturer: result.manufacturer_found || '',
                    score: result.ai_score || 0,
                    is2025: result.is_2025_plus || false,
                    targetMfr: historyItem.targetMfr,
                    accepted_for_nmc: result.accepted_for_nmc || false,
                    raw_data: result.raw_data_json || {}
                }));
                
                // Получаем выбранные контракты
                if (historyItem.selected_contract_ids) {
                    selectedContractIds = new Set(historyItem.selected_contract_ids);
                } else {
                    // Автовыбор топ-3 по score
                    currentContracts.sort((a,b) => b.score - a.score);
                    selectedContractIds = new Set(currentContracts.slice(0, 3).map(c => c.id));
                }

                document.getElementById('res-title').innerText = historyItem.name;
                document.getElementById('res-meta').innerText = `Найдено: ${historyItem.found} | ${historyItem.ktru}`;
                
                document.getElementById('filter-id').value = '';
                document.getElementById('filter-score').value = '';
                
                filteredContracts = [...currentContracts];
                currentPage = 1;
                applyAllFilters();
                
            } catch (error) {
                console.error('Ошибка загрузки результатов:', error);
                // Fallback на мок данные
                loadMockResults(searchId);
            }
        }

        function loadMockResults(searchId) {
            const historyItem = MOCK_HISTORY.find(i => i.id === searchId);
            if (!historyItem) return;
            
            const count = historyItem.found || 10;
            const scenario = MOCK_SCENARIOS[historyItem.type] || MOCK_SCENARIOS.generic;
            currentContracts = [];
            selectedContractIds.clear();

            for(let i=0; i<count; i++) {
                const year = 2023 + Math.floor(Math.random() * 4);
                let score = Math.floor(60 + Math.random()*40);
                let mfr = scenario.mfrs[0];
                
                currentContracts.push({
                    id: 2700000000 + i + Math.floor(Math.random()*9000),
                    date: `${year}-05-20`,
                    price: scenario.basePrice * (0.8 + Math.random() * 0.4),
                    type: score > 90 ? "Идентичный" : "Однородный",
                    manufacturer: mfr,
                    score: score,
                    is2025: year >= 2025,
                    targetMfr: historyItem.targetMfr,
                    specs: scenario.specs.map(s => ({name: s.name, target: s.target, actual: s.target, match: true}))
                });
            }
            
            currentContracts.sort((a,b) => b.score - a.score);
            currentContracts.slice(0, 3).forEach(c => selectedContractIds.add(c.id));

            document.getElementById('res-title').innerText = historyItem.name;
            document.getElementById('res-meta').innerText = `Найдено: ${count} | ${historyItem.ktru}`;
            
            document.getElementById('filter-id').value = '';
            document.getElementById('filter-score').value = '';
            
            filteredContracts = [...currentContracts];
            currentPage = 1;
            applyAllFilters();
        }

        // --- UI HELPERS ---
        function switchTab(tab) {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.getElementById(`tab-${tab}`).classList.add('active');
            document.getElementById('view-history').classList.toggle('hidden', tab !== 'history');
            document.getElementById('view-results').classList.toggle('hidden', tab !== 'results');
            
            const footer = document.getElementById('results-footer');
            if(tab === 'results') footer.classList.remove('translate-y-full'); else footer.classList.add('translate-y-full');
        }

        function toggleSidebar() { document.getElementById('sidebar').classList.toggle('translate-x-full'); }
        
        function applyAllFilters() {
            const idVal = document.getElementById('filter-id').value.toLowerCase();
            const typeVal = document.getElementById('filter-type').value;
            const scoreVal = parseInt(document.getElementById('filter-score').value) || 0;
            
            filteredContracts = currentContracts.filter(c => {
                return c.id.toString().includes(idVal) && 
                       (typeVal === "" || c.type === typeVal) && 
                       (c.score >= scoreVal);
            });
            renderResultsTable();
        }

        function renderResultsTable() {
            const tbody = document.getElementById('results-body');
            tbody.innerHTML = '';
            
            filteredContracts.sort((a,b) => (selectedContractIds.has(b.id) - selectedContractIds.has(a.id)) || b.score - a.score);
            
            const start = (currentPage - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            const pageData = filteredContracts.slice(start, end);
            
            document.getElementById('pg-start').innerText = filteredContracts.length ? start + 1 : 0;
            document.getElementById('pg-end').innerText = Math.min(end, filteredContracts.length);
            document.getElementById('pg-total').innerText = filteredContracts.length;
            document.getElementById('pg-current').innerText = currentPage;
            document.getElementById('btn-prev').disabled = currentPage === 1;
            document.getElementById('btn-next').disabled = end >= filteredContracts.length;

            pageData.forEach(c => {
                const isSel = selectedContractIds.has(c.id);
                const tr = document.createElement('tr');
                tr.className = isSel ? 'bg-blue-50 border-l-4 border-blue-500' : 'hover:bg-gray-50 border-l-4 border-transparent';
                
                let mfrHtml = `<span>${c.manufacturer}</span>`;
                if(c.is2025 && c.targetMfr && !c.manufacturer.toLowerCase().includes(c.targetMfr.toLowerCase())) {
                     mfrHtml += ` <i class="fas fa-exclamation-triangle text-red-500 ml-1"></i>`;
                }

                tr.innerHTML = `
                    <td class="p-3 text-center"><input type="checkbox" ${isSel ? 'checked' : ''} onchange="toggleSelect('${c.id}')"></td>
                    <td class="p-3 text-blue-600 font-mono text-xs cursor-pointer hover:underline">${c.id}</td>
                    <td class="p-3 text-sm">${c.date ? c.date.substring(0,4) : 'N/A'}</td>
                    <td class="p-3 font-bold text-sm">${c.price ? c.price.toLocaleString('ru-RU') + ' ₽' : 'N/A'}</td>
                    <td class="p-3 text-xs font-bold uppercase text-gray-500">${c.type}</td>
                    <td class="p-3 text-xs">${mfrHtml}</td>
                    <td class="p-3 text-xs font-bold">${c.score}%</td>
                    <td class="p-3 text-center"><button onclick="openComparison('${c.id}')" class="text-gray-400 hover:text-blue-600 p-2"><i class="fas fa-eye"></i></button></td>
                `;
                tbody.appendChild(tr);
            });
            calcNMC();
        }

        async function toggleSelect(id) {
            const wasSelected = selectedContractIds.has(id);
            
            if (wasSelected) {
                selectedContractIds.delete(id);
            } else {
                selectedContractIds.add(id);
            }
            
            renderResultsTable();
            
            // Отправляем обновление на сервер
            const activeSearch = MOCK_HISTORY.find(i => i.status === "Завершен" && document.getElementById('tab-results').classList.contains('active'));
            if (activeSearch) {
                try {
                    await apiClient.patchSelection(activeSearch.id, Array.from(selectedContractIds));
                    
                    // Обновляем историю
                    const historyItem = MOCK_HISTORY.find(i => i.id === activeSearch.id);
                    if (historyItem) {
                        historyItem.selected_contract_ids = Array.from(selectedContractIds);
                        // Пересчитываем среднюю цену
                        calcNMC();
                    }
                } catch (error) {
                    showToast(`Ошибка обновления выбора: ${error.message}`, 'error');
                    // Откатываем изменение
                    if (wasSelected) {
                        selectedContractIds.add(id);
                    } else {
                        selectedContractIds.delete(id);
                    }
                    renderResultsTable();
                }
            }
        }

        function calcNMC() {
            let sum=0, count=0;
            currentContracts.forEach(c => { 
                if(selectedContractIds.has(c.id)) { 
                    sum+=c.price; 
                    count++; 
                } 
            });
            
            const nmcValue = count ? sum/count : 0;
            document.getElementById('nmc-value').innerText = nmcValue.toLocaleString('ru-RU', {style:'currency', currency:'RUB'});
            
            const cnt = document.getElementById('selected-count');
            cnt.innerText = count;
            cnt.className = count === 3 ? "font-bold text-green-600" : "font-bold text-red-500";
            
            // Обновляем среднюю цену в истории поиска
            const activeSearch = MOCK_HISTORY.find(i => i.status === "Завершен" && document.getElementById('tab-results').classList.contains('active'));
            if (activeSearch) {
                activeSearch.avg = nmcValue;
                renderHistory();
            }
        }
        
        function changePage(d) { currentPage += d; renderResultsTable(); }
        function openComparison(id) { document.getElementById('comparison-modal').classList.add('open'); }
        function closeModal() { document.getElementById('comparison-modal').classList.remove('open'); }
        function showToast(msg, type) { 
            const el = document.createElement('div'); el.className = `toast border-${type==='success'?'green':type==='error'?'red':'blue'}-500`; 
            el.innerHTML = `<span>${msg}</span>`; document.getElementById('notification-area').appendChild(el);
            setTimeout(() => el.classList.add('show'), 10); setTimeout(() => el.remove(), 3000); 
        }
        function exportReport() { showToast('Отчет скачан', 'success'); }
    </script>
</body>
</html>
```
