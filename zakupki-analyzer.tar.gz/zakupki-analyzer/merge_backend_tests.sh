#!/bin/bash

# Создаем файл с тестами бекенда
echo "# Тесты бекенда системы zakupki-analyzer" > codemd/backend_tests.md
echo "" >> codemd/backend_tests.md
echo "## Содержание" >> codemd/backend_tests.md
echo "" >> codemd/backend_tests.md

# Получаем список файлов тестов
test_files=$(find backend/app/tests -name "*.py" ! -path "*/__pycache__/*" | sort)

# Добавляем оглавление
echo "### 1. Базовые тесты импортов и функций" >> codemd/backend_tests.md
echo "### 2. Тесты сервиса НМЦК" >> codemd/backend_tests.md
echo "### 3. Тесты AI схем" >> codemd/backend_tests.md
echo "### 4. Тесты API эндпоинтов" >> codemd/backend_tests.md
echo "### 5. Тесты моделей базы данных" >> codemd/backend_tests.md
echo "### 6. Тесты сервисов бизнес-логики" >> codemd/backend_tests.md
echo "### 7. Интеграционные тесты" >> codemd/backend_tests.md
echo "### 8. Тесты миграций" >> codemd/backend_tests.md
echo "### 9. Тесты фоновых задач (Celery workers)" >> codemd/backend_tests.md
echo "" >> codemd/backend_tests.md
echo "---" >> codemd/backend_tests.md
echo "" >> codemd/backend_tests.md

# Объединяем все файлы тестов
for file in $test_files; do
    echo "### Файл: \`$file\`" >> codemd/backend_tests.md
    echo "" >> codemd/backend_tests.md
    echo "\`\`\`python" >> codemd/backend_tests.md
    cat "$file" >> codemd/backend_tests.md
    echo "\`\`\`" >> codemd/backend_tests.md
    echo "" >> codemd/backend_tests.md
    echo "---" >> codemd/backend_tests.md
    echo "" >> codemd/backend_tests.md
done

echo "Создан файл: codemd/backend_tests.md"
echo "Количество тестовых файлов: $(echo "$test_files" | wc -l)"
