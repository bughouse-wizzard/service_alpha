#!/bin/bash

# Скрипт для тестирования API zakupki-analyzer
# Перед запуском убедитесь, что сервисы запущены: docker-compose up -d

set -e

API_BASE="http://localhost:8000"
echo "Тестирование API на ${API_BASE}"

# Функция для выполнения запросов с проверкой
make_request() {
    local method=$1
    local url=$2
    local data=$3
    
    echo -e "\n=== $method $url ==="
    
    if [ -n "$data" ]; then
        response=$(curl -s -X "$method" \
            -H "Content-Type: application/json" \
            -d "$data" \
            -w " HTTP %{http_code}" \
            "$url")
    else
        response=$(curl -s -X "$method" \
            -w " HTTP %{http_code}" \
            "$url")
    fi
    
    echo "$response"
    
    # Проверяем код ответа
    http_code=$(echo "$response" | grep -o 'HTTP [0-9]*' | awk '{print $2}')
    if [ "$http_code" -ge 400 ]; then
        echo "❌ Ошибка: HTTP $http_code"
        return 1
    else
        echo "✅ Успешно: HTTP $http_code"
        return 0
    fi
}

# 1. Проверка health
make_request "GET" "${API_BASE}/health"

# 2. Проверка версии
make_request "GET" "${API_BASE}/version"

# 3. Получение списка поисков (должен быть пустым)
make_request "GET" "${API_BASE}/api/search"

# 4. Создание тестового поиска
SEARCH_DATA='{
    "object_name": "Бумага офисная А4",
    "ktru_code": "22.11.11.110",
    "customer_region": "СЗФО",
    "date_from": "2023-01-01",
    "date_to": "2026-01-23",
    "limit_contracts": 5,
    "execution_statuses": ["Исполнение завершено"],
    "law": "44"
}'

make_request "POST" "${API_BASE}/api/search" "$SEARCH_DATA"

# Извлекаем ID созданного поиска из ответа
if response=$(curl -s -X POST -H "Content-Type: application/json" -d "$SEARCH_DATA" "${API_BASE}/api/search"); then
    SEARCH_ID=$(echo "$response" | grep -o '"id":"[^"]*"' | cut -d'"' -f4)
    if [ -n "$SEARCH_ID" ]; then
        echo -e "\n📋 Создан поиск с ID: $SEARCH_ID"
        
        # 5. Получение деталей поиска
        make_request "GET" "${API_BASE}/api/search/${SEARCH_ID}"
        
        # 6. Получение результатов поиска (может быть пустым)
        make_request "GET" "${API_BASE}/api/search/${SEARCH_ID}/results"
        
        # 7. Проверка SSE эндпоинта (только заголовки)
        echo -e "\n=== Проверка SSE эндпоинта ==="
        curl -s -I "${API_BASE}/api/search/${SEARCH_ID}/events" | grep -E "(HTTP|Content-Type|Cache-Control)"
        
        # 8. Остановка поиска (если он еще работает)
        echo -e "\n=== Попытка остановки поиска ==="
        make_request "POST" "${API_BASE}/api/search/${SEARCH_ID}/stop"
        
        # 9. Проверка статуса после остановки
        make_request "GET" "${API_BASE}/api/search/${SEARCH_ID}"
    else
        echo "❌ Не удалось извлечь ID поиска из ответа"
    fi
else
    echo "❌ Не удалось создать поиск"
fi

# 10. Создание еще одного поиска для тестирования пагинации
SEARCH_DATA2='{
    "object_name": "Принтер лазерный",
    "ktru_code": "30.23.14.110",
    "customer_region": "СЗФО",
    "date_from": "2023-01-01",
    "date_to": "2026-01-23",
    "limit_contracts": 3,
    "execution_statuses": ["Исполнение завершено"],
    "law": "44"
}'

make_request "POST" "${API_BASE}/api/search" "$SEARCH_DATA2"

# 11. Получение списка поисков с пагинацией
make_request "GET" "${API_BASE}/api/search?page=1&size=5"

# 12. Получение списка поисков с фильтром по статусу
make_request "GET" "${API_BASE}/api/search?status=RUNNING"

echo -e "\n🎉 Тестирование API завершено!"
echo "Документация API доступна по адресу: ${API_BASE}/docs"