#!/usr/bin/env python3
"""Тестовый скрипт для проверки API."""
import asyncio
import httpx
import json

API_BASE = "http://localhost:8000/api"

async def test_health():
    """Проверка health endpoint."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_BASE}/health")
        print(f"Health check: {response.status_code}")
        print(f"Response: {response.json()}")

async def test_version():
    """Проверка version endpoint."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_BASE}/version")
        print(f"Version check: {response.status_code}")
        print(f"Response: {response.json()}")

async def test_search_api():
    """Проверка API поиска."""
    async with httpx.AsyncClient() as client:
        # Тестовый payload
        payload = {
            "object_name": "Бумага офисная",
            "ktru_code": "22.11.11.110",
            "manufacturer_target": "SvetoCopy",
            "customer_region": "SZFO",
            "limit_contracts": 10,
            "execution_statuses": ["EC", "ET"],
            "law": "44",
            "date_from": "2023-01-01",
            "date_to": "2024-12-31",
            "specs_text": "Белизна 160%, плотность 80 г/м2"
        }
        
        try:
            response = await client.post(
                f"{API_BASE}/search",
                json=payload,
                headers={"X-Request-Id": "test_123"}
            )
            print(f"Create search: {response.status_code}")
            if response.status_code == 200:
                print(f"Response: {response.json()}")
            else:
                print(f"Error: {response.text}")
        except Exception as e:
            print(f"Error creating search: {e}")

async def main():
    """Основная функция тестирования."""
    print("=== Тестирование API ===")
    
    await test_health()
    print()
    
    await test_version()
    print()
    
    print("=== Тестирование поиска ===")
    await test_search_api()

if __name__ == "__main__":
    asyncio.run(main())