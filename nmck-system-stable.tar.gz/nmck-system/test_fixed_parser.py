#!/usr/bin/env python3
"""
Исправленный парсер для тестирования
"""
import asyncio
import httpx
from bs4 import BeautifulSoup
import re
from datetime import datetime

class FixedEISParser:
    """Исправленный парсер ЕИС"""
    
    def __init__(self):
        self.base_url = "https://zakupki.gov.ru"
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            },
        )
    
    async def search_contracts(self, search_string: str, max_results: int = 10):
        """Поиск контрактов"""
        url = f"{self.base_url}/epz/order/extendedsearch/results.html"
        params = {
            "searchString": search_string,
            "pageNumber": 1,
            "recordsPerPage": "_50",
            "fz44": "on",  # Только 44-ФЗ
            "fz223": "off",
            "contractStage": "EXECUTION_COMPLETED",
        }
        
        try:
            response = await self.client.get(url, params=params)
            response.raise_for_status()
            
            return await self._parse_search_results(response.text, max_results)
            
        except Exception as e:
            print(f"Ошибка при поиске: {e}")
            return []
    
    async def _parse_search_results(self, html: str, max_results: int):
        """Парсинг результатов поиска (исправленная версия)"""
        soup = BeautifulSoup(html, "lxml")
        contracts = []
        
        # Ищем блоки с результатами
        result_blocks = soup.find_all("div", class_="search-registry-entry-block")
        
        for block in result_blocks[:max_results]:
            try:
                # Ищем div с классом registry-entry__header-mid__number
                number_div = block.find("div", class_="registry-entry__header-mid__number")
                if not number_div:
                    continue
                
                # Внутри div ищем ссылку
                link_tag = number_div.find("a")
                if not link_tag:
                    continue
                
                contract_url = link_tag.get("href")
                if not contract_url.startswith("http"):
                    contract_url = self.base_url + contract_url
                
                # Извлекаем номер контракта из текста ссылки
                contract_number = link_tag.text.strip()
                # Очищаем номер от лишних символов
                contract_number = re.sub(r'[№\s]+', '', contract_number)
                
                # Извлекаем поставщика
                supplier_div = block.find("div", class_="registry-entry__body-href")
                supplier_name = ""
                if supplier_div:
                    supplier_link = supplier_div.find("a")
                    if supplier_link:
                        supplier_name = supplier_link.text.strip()
                
                # Извлекаем дату
                date_div = block.find("div", class_="data-block__value")
                date_str = date_div.text.strip() if date_div else ""
                
                # Извлекаем цену
                price_div = block.find("div", class_="price-block__value")
                price_text = price_div.text.strip() if price_div else ""
                # Парсим цену
                price = 0.0
                if price_text:
                    # Убираем пробелы и символ валюты, заменяем запятую на точку
                    price_clean = price_text.replace(' ', '').replace('₽', '').replace(',', '.')
                    try:
                        price = float(price_clean)
                    except ValueError:
                        pass
                
                contracts.append({
                    "url": contract_url,
                    "reg_number": contract_number,
                    "supplier_name": supplier_name,
                    "date": date_str,
                    "price": price,
                    "currency": "RUB",
                })
                
            except Exception as e:
                print(f"Ошибка при парсинге блока: {e}")
                continue
        
        return contracts

async def test_fixed_parser():
    """Тестирование исправленного парсера"""
    print("=== Тестирование исправленного парсера ===")
    
    parser = FixedEISParser()
    
    # Тест 1: Поиск ноутбуков по 44-ФЗ
    print("\n1. Поиск 'ноутбук' по 44-ФЗ:")
    contracts = await parser.search_contracts("ноутбук", max_results=5)
    
    print(f"Найдено контрактов: {len(contracts)}")
    for i, contract in enumerate(contracts, 1):
        print(f"  {i}. №{contract['reg_number']}")
        print(f"     Поставщик: {contract['supplier_name'][:50]}...")
        print(f"     Дата: {contract['date']}")
        print(f"     Цена: {contract['price']} {contract['currency']}")
        print(f"     URL: {contract['url'][:80]}...")
    
    # Тест 2: Поиск компьютеров
    print("\n2. Поиск 'компьютер' по 44-ФЗ:")
    contracts = await parser.search_contracts("компьютер", max_results=3)
    
    print(f"Найдено контрактов: {len(contracts)}")
    for i, contract in enumerate(contracts, 1):
        print(f"  {i}. №{contract['reg_number']} - {contract['supplier_name'][:30]}...")
    
    # Тест 3: Поиск по КТРУ (если поддерживается)
    print("\n3. Поиск по КТРУ 26.20.16.110:")
    contracts = await parser.search_contracts("26.20.16.110", max_results=3)
    
    print(f"Найдено контрактов: {len(contracts)}")
    for i, contract in enumerate(contracts, 1):
        print(f"  {i}. №{contract['reg_number']}")

if __name__ == "__main__":
    asyncio.run(test_fixed_parser())