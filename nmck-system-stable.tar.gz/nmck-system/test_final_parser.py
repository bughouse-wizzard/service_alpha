#!/usr/bin/env python3
"""
Финальный тест парсера с исправлениями
"""
import asyncio
import httpx
from bs4 import BeautifulSoup
import re
from datetime import datetime, timedelta

class FinalEISParser:
    """Финальная версия парсера ЕИС"""
    
    def __init__(self):
        self.base_url = "https://zakupki.gov.ru"
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            },
        )
    
    async def search_contracts_44fz(self, search_string: str = "", ktru_code: str = "", 
                                   region: str = "Северо-Западный ФО", 
                                   period_days: int = 365, max_results: int = 10):
        """Поиск контрактов по 44-ФЗ с фильтрами"""
        url = f"{self.base_url}/epz/order/extendedsearch/results.html"
        
        # Рассчитываем даты
        date_to = datetime.now()
        date_from = date_to - timedelta(days=period_days)
        
        params = {
            "searchString": search_string,
            "pageNumber": 1,
            "recordsPerPage": "_50",
            "fz44": "on",
            "fz223": "off",
            "contractStage": "EXECUTION_COMPLETED",
            "contractDateFrom": date_from.strftime("%d.%m.%Y"),
            "contractDateTo": date_to.strftime("%d.%m.%Y"),
            "sortBy": "UPDATE_DATE",
            "sortDirection": "false",
        }
        
        # Добавляем КТРУ если указан
        if ktru_code:
            params["ktruCodes"] = ktru_code
        
        # Добавляем регион (упрощенно)
        if region == "Северо-Западный ФО":
            params["regions"] = "78000000000"
        elif region == "Центральный ФО":
            params["regions"] = "77000000000"
        
        print(f"Параметры поиска: {params}")
        
        try:
            response = await self.client.get(url, params=params)
            response.raise_for_status()
            
            # Сохраним для отладки
            with open("debug_search.html", "w", encoding="utf-8") as f:
                f.write(response.text[:10000])
            
            return await self._parse_search_results(response.text, max_results)
            
        except Exception as e:
            print(f"Ошибка при поиске: {e}")
            return []
    
    async def _parse_search_results(self, html: str, max_results: int):
        """Парсинг результатов поиска"""
        soup = BeautifulSoup(html, "lxml")
        contracts = []
        
        # Ищем блоки с результатами
        result_blocks = soup.find_all("div", class_="search-registry-entry-block")
        print(f"Всего блоков найдено: {len(result_blocks)}")
        
        for block in result_blocks[:max_results]:
            try:
                # Проверяем, что это 44-ФЗ (а не 223-ФЗ)
                header_title = block.find("div", class_="registry-entry__header-top__title")
                if header_title and "223-ФЗ" in header_title.text:
                    print("  Пропускаем 223-ФЗ контракт")
                    continue
                
                # Ищем номер контракта
                number_div = block.find("div", class_="registry-entry__header-mid__number")
                if not number_div:
                    continue
                
                link_tag = number_div.find("a")
                if not link_tag:
                    continue
                
                contract_url = link_tag.get("href")
                if not contract_url.startswith("http"):
                    contract_url = self.base_url + contract_url
                
                # Извлекаем номер контракта
                contract_number = link_tag.text.strip()
                contract_number = re.sub(r'[№\s]+', '', contract_number)
                
                # Извлекаем поставщика
                supplier_name = ""
                supplier_div = block.find("div", class_="registry-entry__body-href")
                if supplier_div:
                    supplier_link = supplier_div.find("a")
                    if supplier_link:
                        supplier_name = supplier_link.text.strip()
                
                # Извлекаем дату
                date_str = ""
                date_div = block.find("div", class_="data-block__value")
                if date_div:
                    date_str = date_div.text.strip()
                
                # Извлекаем цену (исправленная версия)
                price = 0.0
                price_div = block.find("div", class_="price-block__value")
                if price_div:
                    price_text = price_div.text.strip()
                    # Убираем все нецифровые символы кроме точки и запятой
                    price_clean = re.sub(r'[^\d,.]', '', price_text)
                    # Заменяем запятую на точку
                    price_clean = price_clean.replace(',', '.')
                    try:
                        price = float(price_clean)
                    except ValueError:
                        # Пробуем другой подход - ищем числа в тексте
                        numbers = re.findall(r'[\d\s,]+', price_text)
                        if numbers:
                            try:
                                num = numbers[0].replace(' ', '').replace(',', '.')
                                price = float(num)
                            except:
                                pass
                
                # Извлекаем объект закупки
                purchase_object = ""
                object_div = block.find("div", class_="registry-entry__body-value")
                if object_div:
                    purchase_object = object_div.text.strip()[:100]
                
                contracts.append({
                    "url": contract_url,
                    "reg_number": contract_number,
                    "supplier_name": supplier_name,
                    "date": date_str,
                    "price": price,
                    "currency": "RUB",
                    "purchase_object": purchase_object,
                    "is_44fz": True,
                })
                
                print(f"  Найден контракт: №{contract_number}, цена: {price} RUB")
                
            except Exception as e:
                print(f"  Ошибка при парсинге блока: {e}")
                continue
        
        return contracts
    
    async def get_contract_details(self, contract_url: str):
        """Получить детали контракта"""
        try:
            response = await self.client.get(contract_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, "lxml")
            
            # Извлекаем основную информацию
            details = {
                "url": contract_url,
                "specification_found": False,
                "characteristics": [],
            }
            
            # Ищем спецификацию
            spec_link = soup.find("a", href=re.compile(r"specification"))
            if spec_link:
                spec_url = spec_link.get("href")
                if not spec_url.startswith("http"):
                    spec_url = self.base_url + spec_url
                
                try:
                    spec_response = await self.client.get(spec_url)
                    if spec_response.status_code == 200:
                        details["specification_found"] = True
                        # Здесь можно парсить спецификацию
                except:
                    pass
            
            return details
            
        except Exception as e:
            print(f"Ошибка при получении деталей: {e}")
            return {}

async def test_comprehensive():
    """Комплексное тестирование парсера"""
    print("=== КОМПЛЕКСНОЕ ТЕСТИРОВАНИЕ ПАРСЕРА ZAKUPKI.GOV.RU ===\n")
    
    parser = FinalEISParser()
    
    # Тест 1: Базовый поиск по 44-ФЗ
    print("1. БАЗОВЫЙ ПОИСК ПО 44-ФЗ (ноутбуки, последние 90 дней):")
    contracts = await parser.search_contracts_44fz(
        search_string="ноутбук",
        period_days=90,
        max_results=5
    )
    
    print(f"   Найдено контрактов 44-ФЗ: {len(contracts)}")
    for i, contract in enumerate(contracts, 1):
        print(f"   {i}. №{contract['reg_number']}")
        print(f"      Поставщик: {contract['supplier_name'][:40]}...")
        print(f"      Дата: {contract['date']}")
        print(f"      Цена: {contract['price']:,.2f} {contract['currency']}")
        print(f"      Объект: {contract['purchase_object'][:50]}...")
    
    # Тест 2: Поиск с фильтром по региону
    print("\n2. ПОИСК С ФИЛЬТРОМ ПО РЕГИОНУ (компьютеры, СЗФО):")
    contracts = await parser.search_contracts_44fz(
        search_string="компьютер",
        region="Северо-Западный ФО",
        period_days=180,
        max_results=3
    )
    
    print(f"   Найдено контрактов в СЗФО: {len(contracts)}")
    
    # Тест 3: Поиск по КТРУ (если работает)
    print("\n3. ПОИСК ПО КТРУ (26.20.16.110 - ноутбуки):")
    contracts = await parser.search_contracts_44fz(
        ktru_code="26.20.16.110",
        period_days=365,
        max_results=3
    )
    
    print(f"   Найдено контрактов по КТРУ: {len(contracts)}")
    if contracts:
        for contract in contracts:
            print(f"   - №{contract['reg_number']}")
    
    # Тест 4: Проверка деталей контракта
    print("\n4. ПРОВЕРКА ДЕТАЛЕЙ КОНТРАКТА:")
    if contracts:
        first_contract = contracts[0]
        details = await parser.get_contract_details(first_contract["url"])
        print(f"   URL: {first_contract['url']}")
        print(f"   Спецификация найдена: {details.get('specification_found', False)}")
    
    # Тест 5: Проверка разных типов поиска
    print("\n5. ПРОВЕРКА РАЗНЫХ ТИПОВ ПОИСКА:")
    search_terms = ["принтер", "монитор", "сервер"]
    
    for term in search_terms:
        contracts = await parser.search_contracts_44fz(
            search_string=term,
            period_days=60,
            max_results=2
        )
        print(f"   '{term}': найдено {len(contracts)} контрактов")
    
    print("\n=== ТЕСТИРОВАНИЕ ЗАВЕРШЕНО ===")
    
    # Вывод итогов
    print("\n=== ИТОГИ ТЕСТИРОВАНИЯ ===")
    print("1. Парсер успешно получает данные с zakupki.gov.ru")
    print("2. Поддерживается фильтрация по:")
    print("   - Текстовому поиску (работает)")
    print("   - 44-ФЗ (работает, но нужно проверять фильтрацию)")
    print("   - Периоду (работает)")
    print("   - Региону (требует доработки маппинга регионов)")
    print("3. Проблемные области:")
    print("   - Поиск по КТРУ кодам может не работать через веб-интерфейс")
    print("   - Извлечение характеристик требует доработки")
    print("   - Нужна обработка капчи при частых запросах")
    print("   - Требуется нормализация цен и дат")

if __name__ == "__main__":
    asyncio.run(test_comprehensive())