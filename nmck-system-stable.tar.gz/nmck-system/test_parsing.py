#!/usr/bin/env python3
"""
Тестирование парсинга HTML ответа
"""
import asyncio
import httpx
from bs4 import BeautifulSoup
import re

async def test_parsing():
    """Тестирование парсинга HTML"""
    print("=== Тестирование парсинга HTML ===")
    
    # URL для тестирования
    url = "https://zakupki.gov.ru/epz/order/extendedsearch/results.html?searchString=ноутбук&pageNumber=1"
    
    async with httpx.AsyncClient(
        timeout=30.0,
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
    ) as client:
        try:
            response = await client.get(url)
            print(f"Статус: {response.status_code}")
            print(f"Размер: {len(response.text)} байт")
            
            # Парсим HTML
            soup = BeautifulSoup(response.text, "lxml")
            
            # 1. Ищем блоки результатов
            result_blocks = soup.find_all("div", class_="search-registry-entry-block")
            print(f"\n1. Найдено блоков результатов: {len(result_blocks)}")
            
            if result_blocks:
                # Берем первый блок для анализа
                block = result_blocks[0]
                
                # 2. Ищем ссылку на контракт
                link_tag = block.find("a", class_="registry-entry__header-mid__number")
                if link_tag:
                    print(f"2. Ссылка на контракт найдена:")
                    print(f"   Текст: {link_tag.text.strip()}")
                    print(f"   Href: {link_tag.get('href', 'N/A')}")
                else:
                    print("2. Ссылка на контракт не найдена")
                    # Попробуем другие возможные селекторы
                    links = block.find_all("a")
                    print(f"   Всего ссылок в блоке: {len(links)}")
                    for i, link in enumerate(links[:3]):
                        print(f"   Ссылка {i+1}: {link.text.strip()[:50]}... -> {link.get('href', 'N/A')[:100]}")
                
                # 3. Ищем поставщика
                supplier_tag = block.find("div", class_="registry-entry__body-href")
                if supplier_tag:
                    print(f"3. Поставщик найден: {supplier_tag.text.strip()[:100]}")
                else:
                    print("3. Поставщик не найден (класс registry-entry__body-href)")
                    # Попробуем другие селекторы
                    supplier_divs = block.find_all("div", class_=re.compile(r"supplier|поставщик", re.IGNORECASE))
                    print(f"   Альтернативных div с supplier: {len(supplier_divs)}")
                
                # 4. Ищем дату
                date_tag = block.find("div", class_="data-block__value")
                if date_tag:
                    print(f"4. Дата найдена: {date_tag.text.strip()}")
                else:
                    print("4. Дата не найдена (класс data-block__value)")
                    # Посмотрим все div с классом data-block
                    data_blocks = block.find_all("div", class_=re.compile(r"data-block"))
                    print(f"   Всего data-block div: {len(data_blocks)}")
                    for i, db in enumerate(data_blocks[:3]):
                        print(f"   Data-block {i+1}: {db.text.strip()[:100]}")
            
            # 5. Проверим структуру всего документа
            print("\n5. Структура документа:")
            
            # Найдем все уникальные классы в документе
            all_classes = set()
            for tag in soup.find_all(class_=True):
                all_classes.update(tag.get("class", []))
            
            # Отфильтруем классы связанные с результатами
            result_classes = [c for c in all_classes if "registry" in c or "search" in c or "result" in c]
            print(f"   Классы связанные с результатами: {len(result_classes)}")
            for cls in sorted(result_classes)[:20]:
                print(f"   - {cls}")
            
            # 6. Сохраним пример HTML блока для анализа
            if result_blocks:
                with open("test_block.html", "w", encoding="utf-8") as f:
                    f.write(str(result_blocks[0]))
                print("\n6. Пример блока сохранен в test_block.html")
            
        except Exception as e:
            print(f"Ошибка: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_parsing())