#!/usr/bin/env python3
"""
Упрощенный тест парсера zakupki.gov.ru
"""
import asyncio
import httpx
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime, timedelta
from urllib.parse import urlencode

async def test_search_url():
    """Тестирование формирования URL поиска"""
    print("=== Тестирование формирования URL поиска ===")
    
    # Параметры поиска
    params = {
        "morphology": "on",
        "search-filter": "Поиск",
        "sortBy": "PUBLISH_DATE",
        "pageNumber": 1,
        "sortDirection": "false",
        "recordsPerPage": "_50",
        "showLotsInfoHidden": "false",
        "fz44": "on",
        "fz223": "off",
        "contractStage": "EXECUTION_COMPLETED",
        "contractDateFrom": (datetime.now() - timedelta(days=365)).strftime("%d.%m.%Y"),
        "contractDateTo": datetime.now().strftime("%d.%m.%Y"),
        "regionDeleted": "false",
        "searchString": "ноутбук",
        "regions": "78000000000",  # Северо-Западный ФО
    }
    
    base_url = "https://zakupki.gov.ru"
    search_url = f"{base_url}/epz/order/extendedsearch/results.html"
    
    print(f"URL: {search_url}")
    print(f"Параметры: {params}")
    
    # Пробуем выполнить запрос
    async with httpx.AsyncClient(
        timeout=30.0,
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
        },
        follow_redirects=True,
    ) as client:
        try:
            response = await client.get(search_url, params=params)
            print(f"\nСтатус ответа: {response.status_code}")
            print(f"Размер ответа: {len(response.text)} байт")
            
            # Сохраним ответ для анализа
            with open("test_response.html", "w", encoding="utf-8") as f:
                f.write(response.text[:5000])  # Первые 5000 символов
            
            print("\nПервые 1000 символов ответа:")
            print(response.text[:1000])
            
            # Проверим, есть ли в ответе ожидаемые элементы
            if "search-registry-entry-block" in response.text:
                print("\n✓ Найдены блоки результатов (search-registry-entry-block)")
            else:
                print("\n✗ Блоки результатов не найдены")
                
            if "registry-entry__header-mid__number" in response.text:
                print("✓ Найдены ссылки на контракты (registry-entry__header-mid__number)")
            else:
                print("✗ Ссылки на контракты не найдены")
                
            # Проверим наличие капчи или блокировки
            if "captcha" in response.text.lower() or "робот" in response.text.lower():
                print("⚠ Обнаружена возможная капча или блокировка")
            
        except Exception as e:
            print(f"\nОшибка при запросе: {e}")
            import traceback
            traceback.print_exc()

async def test_direct_search():
    """Прямой поиск без параметров"""
    print("\n=== Прямой поиск без параметров ===")
    
    url = "https://zakupki.gov.ru/epz/order/extendedsearch/results.html?searchString=ноутбук&pageNumber=1"
    
    async with httpx.AsyncClient(
        timeout=30.0,
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
    ) as client:
        try:
            response = await client.get(url)
            print(f"Статус: {response.status_code}")
            print(f"Размер: {len(response.text)} байт")
            
            # Сохраним для анализа
            with open("test_direct_response.html", "w", encoding="utf-8") as f:
                f.write(response.text[:10000])
            
            # Поиск ключевых элементов
            import re
            contract_numbers = re.findall(r'№\s*[\w-]+', response.text[:5000])
            if contract_numbers:
                print(f"Найдены номера контрактов: {contract_numbers[:5]}")
            else:
                print("Номера контрактов не найдены")
                
        except Exception as e:
            print(f"Ошибка: {e}")

if __name__ == "__main__":
    asyncio.run(test_search_url())
    asyncio.run(test_direct_search())