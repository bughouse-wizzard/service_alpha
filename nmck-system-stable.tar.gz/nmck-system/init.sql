-- Создание расширений
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Создание таблицы сессий
CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Создание таблицы загрузок
CREATE TABLE IF NOT EXISTS uploads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100),
    storage_url TEXT NOT NULL,
    extracted_json JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Создание таблицы задач
CREATE TABLE IF NOT EXISTS tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    upload_id UUID NOT NULL REFERENCES uploads(id) ON DELETE CASCADE,
    status VARCHAR(50) NOT NULL DEFAULT 'queued',
    stage VARCHAR(50) NOT NULL DEFAULT 'queued',
    progress INTEGER NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    region VARCHAR(100),
    period_from TIMESTAMP WITH TIME ZONE,
    period_to TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    finished_at TIMESTAMP WITH TIME ZONE,
    error_code VARCHAR(100),
    error_detail TEXT
);

-- Создание таблицы контрактов
CREATE TABLE IF NOT EXISTS contracts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    reg_number VARCHAR(100) NOT NULL,
    eis_url TEXT NOT NULL,
    supplier_name VARCHAR(255),
    supplier_inn VARCHAR(20),
    sign_date TIMESTAMP WITH TIME ZONE,
    unit_price DECIMAL(15, 2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) NOT NULL DEFAULT 'RUB',
    match_percent INTEGER NOT NULL DEFAULT 0 CHECK (match_percent >= 0 AND match_percent <= 100),
    match_type VARCHAR(50) NOT NULL DEFAULT 'different',
    vendor_status VARCHAR(50) NOT NULL DEFAULT 'unknown',
    raw_payload_json JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Создание таблицы лога сверки
CREATE TABLE IF NOT EXISTS contract_audit_rows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,
    key VARCHAR(255) NOT NULL,
    expected_value TEXT,
    found_value TEXT,
    is_diff BOOLEAN NOT NULL DEFAULT FALSE,
    diff_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Создание таблицы выбора контрактов
CREATE TABLE IF NOT EXISTS task_selection (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,
    selected_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    UNIQUE(task_id, contract_id)
);

-- Создание таблицы расчетов НМЦК
CREATE TABLE IF NOT EXISTS task_calculations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    method VARCHAR(50) NOT NULL DEFAULT 'average',
    nmck_value DECIMAL(15, 2) NOT NULL,
    computed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    details_json JSONB
);

-- Создание индексов для улучшения производительности
CREATE INDEX IF NOT EXISTS idx_sessions_last_seen ON sessions(last_seen_at);
CREATE INDEX IF NOT EXISTS idx_uploads_session_id ON uploads(session_id);
CREATE INDEX IF NOT EXISTS idx_tasks_session_id ON tasks(session_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_created_at ON tasks(created_at);
CREATE INDEX IF NOT EXISTS idx_contracts_task_id ON contracts(task_id);
CREATE INDEX IF NOT EXISTS idx_contracts_match_percent ON contracts(match_percent);
CREATE INDEX IF NOT EXISTS idx_contract_audit_rows_contract_id ON contract_audit_rows(contract_id);
CREATE INDEX IF NOT EXISTS idx_task_selection_task_id ON task_selection(task_id);
CREATE INDEX IF NOT EXISTS idx_task_calculations_task_id ON task_calculations(task_id);
