#!/usr/bin/env python3
"""
Тестирование парсера zakupki.gov.ru
"""
import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime, timedelta
from app.adapters.eis.parser import EISParser

async def test_parser():
    """Тестирование парсера ЕИС"""
    print("=== Тестирование парсера zakupki.gov.ru ===")
    
    # Создаем парсер
    parser = EISParser()
    
    # Тест 1: Поиск контрактов по КТРУ (ноутбуки)
    print("\n1. Поиск контрактов по КТРУ 26.20.16.110-00000001 (ноутбуки):")
    try:
        contracts = await parser.search_contracts(
            ktru_code="26.20.16.110-00000001",
            product_name="ноутбук",
            region="Северо-Западный ФО",
            period_from=datetime.now() - timedelta(days=365*3),  # 3 года
            period_to=datetime.now(),
            max_results=10
        )
        
        print(f"Найдено контрактов: {len(contracts)}")
        for i, contract in enumerate(contracts[:3], 1):
            print(f"  {i}. {contract.get('reg_number', 'N/A')} - {contract.get('supplier_name', 'N/A')}")
        
        if contracts:
            # Тест 2: Получение деталей первого контракта
            print("\n2. Получение деталей первого контракта:")
            contract_url = contracts[0].get('url')
            if contract_url:
                details = await parser.get_contract_details(contract_url)
                print(f"   Номер: {details.get('reg_number', 'N/A')}")
                print(f"   Поставщик: {details.get('supplier_name', 'N/A')}")
                print(f"   ИНН: {details.get('supplier_inn', 'N/A')}")
                print(f"   Дата: {details.get('sign_date', 'N/A')}")
                print(f"   Цена: {details.get('unit_price', 'N/A')}")
                print(f"   Вендор: {details.get('vendor', 'N/A')}")
                
                characteristics = details.get('characteristics', [])
                print(f"   Характеристик найдено: {len(characteristics)}")
                for char in characteristics[:5]:
                    print(f"     - {char.get('key', 'N/A')}: {char.get('value', 'N/A')}")
    
    except Exception as e:
        print(f"Ошибка при поиске контрактов: {e}")
        import traceback
        traceback.print_exc()
    
    # Тест 3: Поиск без КТРУ (только по названию)
    print("\n3. Поиск по названию 'компьютер':")
    try:
        contracts = await parser.search_contracts(
            product_name="компьютер",
            region="Центральный ФО",
            period_from=datetime.now() - timedelta(days=365*2),  # 2 года
            period_to=datetime.now(),
            max_results=5
        )
        
        print(f"Найдено контрактов: {len(contracts)}")
        for i, contract in enumerate(contracts[:3], 1):
            print(f"  {i}. {contract.get('reg_number', 'N/A')} - {contract.get('supplier_name', 'N/A')}")
    
    except Exception as e:
        print(f"Ошибка при поиске по названию: {e}")
    
    # Тест 4: Проверка фильтрации по региону
    print("\n4. Проверка фильтрации по разным регионам:")
    regions = ["Северо-Западный ФО", "Центральный ФО", "Южный ФО"]
    
    for region in regions:
        try:
            contracts = await parser.search_contracts(
                product_name="принтер",
                region=region,
                period_from=datetime.now() - timedelta(days=365),
                period_to=datetime.now(),
                max_results=3
            )
            print(f"  {region}: найдено {len(contracts)} контрактов")
        except Exception as e:
            print(f"  {region}: ошибка - {e}")
    
    print("\n=== Тестирование завершено ===")

if __name__ == "__main__":
    asyncio.run(test_parser())