#!/bin/bash

echo "=== Тестирование API системы НМЦК ==="
echo

# 1. Создаем сессию
echo "1. Создание сессии..."
SESSION_RESPONSE=$(curl -s -c test_cookies.txt "http://localhost:8000/api/session")
SESSION_ID=$(echo $SESSION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['id'])")
echo "   Сессия создана: $SESSION_ID"
echo

# 2. Создаем загрузку
echo "2. Создание загрузки..."
echo "test" > /tmp/test_upload.txt
UPLOAD_RESPONSE=$(curl -s -b test_cookies.txt -X POST "http://localhost:8000/api/uploads" \
  -F "file=@/tmp/test_upload.txt" \
  -F "source_type=freeform")
UPLOAD_ID=$(echo $UPLOAD_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['upload_id'])")
echo "   Загрузка создана: $UPLOAD_ID"
echo

# 3. Создаем задачу поиска
echo "3. Создание задачи поиска..."
TASK_RESPONSE=$(curl -s -b test_cookies.txt -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d "{
    \"ktru_code\": \"17.12.14.110-00000019\",
    \"product_name\": \"Бумага для офисной техники\",
    \"max_results\": 50,
    \"upload_id\": \"$UPLOAD_ID\"
  }")
TASK_ID=$(echo $TASK_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['id'])")
echo "   Задача создана: $TASK_ID"
echo

# 4. Ждем выполнения задачи
echo "4. Ожидание выполнения задачи..."
for i in {1..30}; do
  STATUS_RESPONSE=$(curl -s -b test_cookies.txt "http://localhost:8000/api/tasks/$TASK_ID")
  STATUS=$(echo $STATUS_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['status'])")
  PROGRESS=$(echo $STATUS_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['progress'])")
  echo "   Попытка $i: статус=$STATUS, прогресс=$PROGRESS%"
  
  if [ "$STATUS" = "done" ]; then
    echo "   Задача выполнена!"
    break
  fi
  
  sleep 2
done
echo

# 5. Проверяем историю
echo "5. Проверка истории поиска..."
HISTORY_RESPONSE=$(curl -s -b test_cookies.txt "http://localhost:8000/api/tasks?page=1&page_size=10")
echo "   История: $HISTORY_RESPONSE"
echo

# 6. Проверяем результаты
echo "6. Проверка результатов поиска..."
CONTRACTS_RESPONSE=$(curl -s -b test_cookies.txt "http://localhost:8000/api/tasks/$TASK_ID/contracts?page=1&page_size=10")
TOTAL=$(echo $CONTRACTS_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['total'])")
echo "   Найдено контрактов: $TOTAL"
echo

# 7. Проверяем пагинацию
echo "7. Проверка пагинации..."
PAGINATION_RESPONSE=$(curl -s -b test_cookies.txt "http://localhost:8000/api/tasks/$TASK_ID/contracts?page=1&page_size=2")
PAGE=$(echo $PAGINATION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['page'])")
TOTAL_PAGES=$(echo $PAGINATION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['total_pages'])")
HAS_NEXT=$(echo $PAGINATION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['has_next'])")
echo "   Пагинация: страница $PAGE из $TOTAL_PAGES, следующая страница: $HAS_NEXT"
echo

echo "=== Тестирование завершено ==="
