#!/bin/bash

echo "=== Тестирование поиска с ограничением 50 контрактов ==="
echo

# 1. Создаем сессию
echo "1. Создание сессии..."
SESSION_RESPONSE=$(curl -s -c test_cookies_50.txt "http://localhost:8000/api/session")
SESSION_ID=$(echo $SESSION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['id'])")
echo "   Сессия создана: $SESSION_ID"
echo

# 2. Создаем загрузку
echo "2. Создание загрузки..."
echo "КТРУ: 17.12.14.110-00000019" > /tmp/test_ktru.txt
echo "Наименование: Бумага для офисной техники" >> /tmp/test_ktru.txt
UPLOAD_RESPONSE=$(curl -s -b test_cookies_50.txt -X POST "http://localhost:8000/api/uploads" \
  -F "file=@/tmp/test_ktru.txt" \
  -F "source_type=freeform")
UPLOAD_ID=$(echo $UPLOAD_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['upload_id'])")
echo "   Загрузка создана: $UPLOAD_ID"
echo

# 3. Создаем задачу поиска с max_results=50
echo "3. Создание задачи поиска с max_results=50..."
TASK_RESPONSE=$(curl -s -b test_cookies_50.txt -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d "{
    \"ktru_code\": \"17.12.14.110-00000019\",
    \"product_name\": \"Бумага для офисной техники\",
    \"max_results\": 50,
    \"upload_id\": \"$UPLOAD_ID\"
  }")
TASK_ID=$(echo $TASK_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['id'])")
echo "   Задача создана: $TASK_ID"
echo

# 4. Ждем выполнения задачи
echo "4. Ожидание выполнения задачи..."
for i in {1..40}; do
  STATUS_RESPONSE=$(curl -s -b test_cookies_50.txt "http://localhost:8000/api/tasks/$TASK_ID")
  STATUS=$(echo $STATUS_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['status'])")
  PROGRESS=$(echo $STATUS_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['progress'])")
  echo "   Попытка $i: статус=$STATUS, прогресс=$PROGRESS%"
  
  if [ "$STATUS" = "done" ]; then
    echo "   Задача выполнена!"
    break
  fi
  
  sleep 2
done
echo

# 5. Проверяем результаты
echo "5. Проверка результатов поиска..."
CONTRACTS_RESPONSE=$(curl -s -b test_cookies_50.txt "http://localhost:8000/api/tasks/$TASK_ID/contracts?page=1&page_size=100")
TOTAL=$(echo $CONTRACTS_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['total'])")
echo "   Найдено контрактов: $TOTAL"
echo

# 6. Проверяем, что контрактов действительно 50
if [ "$TOTAL" -eq 50 ]; then
    echo "   ✓ Успешно! Найдено 50 контрактов, как и требовалось."
else
    echo "   ✗ Ошибка! Ожидалось 50 контрактов, найдено $TOTAL"
fi
echo

# 7. Проверяем пагинацию
echo "7. Проверка пагинации..."
PAGINATION_RESPONSE=$(curl -s -b test_cookies_50.txt "http://localhost:8000/api/tasks/$TASK_ID/contracts?page=1&page_size=10")
PAGE=$(echo $PAGINATION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['page'])")
TOTAL_PAGES=$(echo $PAGINATION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['total_pages'])")
HAS_NEXT=$(echo $PAGINATION_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['has_next'])")
echo "   Пагинация: страница $PAGE из $TOTAL_PAGES, следующая страница: $HAS_NEXT"
echo

# 8. Проверяем данные контрактов
echo "8. Проверка данных контрактов..."
FIRST_CONTRACT=$(echo $CONTRACTS_RESPONSE | python3 -c "
import sys, json
data = json.load(sys.stdin)
if data['items'] and len(data['items']) > 0:
    contract = data['items'][0]
    print(f'    Первый контракт:')
    print(f'    - Рег. номер: {contract[\"reg_number\"]}')
    print(f'    - Поставщик: {contract[\"supplier_name\"]}')
    print(f'    - Цена: {contract[\"unit_price\"]:.2f} руб.')
    print(f'    - Совпадение: {contract[\"match_percent\"]}%')
else:
    print('    Нет контрактов')
")
echo "$FIRST_CONTRACT"
echo

echo "=== Тестирование завершено ==="
