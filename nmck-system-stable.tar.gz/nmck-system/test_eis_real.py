"""
Тестирование парсера ЕИС с реальными данными
"""
import asyncio
import sys
from datetime import datetime, timedelta

sys.path.insert(0, '/workspace/nmck-system')

from app.adapters.eis.parser import EISParser

async def test_real_search():
    """Тестирование реального поиска контрактов"""
    print("=" * 60)
    print("ТЕСТИРОВАНИЕ ПАРСЕРА ЕИС")
    print("=" * 60)
    
    parser = EISParser()
    
    # Тестовые параметры поиска
    test_cases = [
        {
            "name": "Ноутбуки по КТРУ",
            "ktru_code": "26.20.16.110-00000001",
            "product_name": "ноутбук",
            "region": "Северо-Западный ФО",
            "period_years": 3
        },
        {
            "name": "Мониторы",
            "ktru_code": "26.20.16.120-00000001",
            "product_name": "монитор",
            "region": "Северо-Западный ФО",
            "period_years": 2
        }
    ]
    
    for test_case in test_cases:
        print(f"\n{'='*40}")
        print(f"Тест: {test_case['name']}")
        print(f"КТРУ: {test_case['ktru_code']}")
        print(f"Товар: {test_case['product_name']}")
        print(f"Регион: {test_case['region']}")
        print(f"Период: {test_case['period_years']} года")
        print(f"{'='*40}")
        
        try:
            contracts = await parser.search_contracts(
                ktru_code=test_case['ktru_code'],
                product_name=test_case['product_name'],
                region=test_case['region'],
                period_from=datetime.now() - timedelta(days=365 * test_case['period_years']),
                period_to=datetime.now(),
                law_type='44-ФЗ',
                max_results=5
            )
            
            print(f"Найдено контрактов: {len(contracts)}")
            
            if contracts:
                print("\nПервые 3 контракта:")
                for i, contract in enumerate(contracts[:3]):
                    print(f"{i+1}. Рег. номер: {contract.get('reg_number', 'Нет данных')}")
                    print(f"   Поставщик: {contract.get('supplier_name', 'Нет данных')}")
                    print(f"   Ссылка: {contract.get('url', 'Нет ссылки')}")
                    
                    # Проверим детали для первого контракта
                    if i == 0 and contract.get('url'):
                        print(f"   Получение деталей...")
                        try:
                            details = await parser.get_contract_details(contract['url'])
                            if details:
                                print(f"   - Цена: {details.get('unit_price', 'Нет данных')} {details.get('currency', '')}")
                                print(f"   - Дата: {details.get('sign_date', 'Нет данных')}")
                                print(f"   - Характеристики: {len(details.get('characteristics', []))}")
                            else:
                                print(f"   - Детали не получены")
                        except Exception as e:
                            print(f"   - Ошибка получения деталей: {e}")
                    print()
            else:
                print("Контракты не найдены")
                
        except Exception as e:
            print(f"Ошибка при поиске: {e}")
            import traceback
            traceback.print_exc()
    
    await parser.client.aclose()
    print("\n" + "=" * 60)
    print("ТЕСТИРОВАНИЕ ЗАВЕРШЕНО")
    print("=" * 60)

async def test_contract_details():
    """Тестирование получения деталей контракта"""
    print("\n" + "=" * 60)
    print("ТЕСТИРОВАНИЕ ПОЛУЧЕНИЯ ДЕТАЛЕЙ КОНТРАКТА")
    print("=" * 60)
    
    parser = EISParser()
    
    # Тестовые URL контрактов (могут потребоваться актуальные)
    test_urls = [
        "https://zakupki.gov.ru/epz/order/notice/ea44/view/common-info.html?regNumber=0373200045924000010",
        "https://zakupki.gov.ru/epz/order/notice/ea44/view/common-info.html?regNumber=0373200045924000009",
    ]
    
    for url in test_urls:
        print(f"\nТестирование URL: {url}")
        try:
            details = await parser.get_contract_details(url)
            
            if details:
                print(f"  Рег. номер: {details.get('reg_number', 'Нет данных')}")
                print(f"  Поставщик: {details.get('supplier_name', 'Нет данных')}")
                print(f"  ИНН: {details.get('supplier_inn', 'Нет данных')}")
                print(f"  Дата: {details.get('sign_date', 'Нет данных')}")
                print(f"  Цена: {details.get('unit_price', 'Нет данных')} {details.get('currency', '')}")
                print(f"  Производитель: {details.get('vendor', 'Нет данных')}")
                
                characteristics = details.get('characteristics', [])
                print(f"  Характеристики: {len(characteristics)}")
                for char in characteristics[:3]:
                    print(f"    - {char.get('key', '?')}: {char.get('value', '?')} {char.get('unit', '')}")
            else:
                print("  Детали не получены")
                
        except Exception as e:
            print(f"  Ошибка: {e}")
    
    await parser.client.aclose()

if __name__ == "__main__":
    print("Запуск тестов парсера ЕИС...")
    asyncio.run(test_real_search())
    # asyncio.run(test_contract_details())
