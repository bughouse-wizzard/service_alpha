"""
Детальное тестирование парсера ЕИС
"""
import asyncio
import sys
from datetime import datetime

sys.path.insert(0, '/workspace/nmck-system')

from app.adapters.eis.parser import EISParser

async def test_detailed_analysis():
    """Детальный анализ работы парсера"""
    print("=" * 70)
    print("ДЕТАЛЬНЫЙ АНАЛИЗ РАБОТЫ ПАРСЕРА ЕИС")
    print("=" * 70)
    
    parser = EISParser()
    
    # Тестовые контракты
    test_contracts = [
        {
            "name": "Контракт 1 (ноутбуки)",
            "url": "https://zakupki.gov.ru/epz/order/notice/notice223/common-info.html?noticeInfoId=19282023"
        },
        {
            "name": "Контракт 2 (мониторы)",
            "url": "https://zakupki.gov.ru/epz/order/notice/zk20/view/common-info.html?regNumber=0387200006826000010"
        }
    ]
    
    for contract in test_contracts:
        print(f"\n{'='*50}")
        print(f"Анализ: {contract['name']}")
        print(f"URL: {contract['url']}")
        print(f"{'='*50}")
        
        try:
            details = await parser.get_contract_details(contract['url'])
            
            if not details:
                print("  ❌ Детали не получены")
                continue
            
            # Проверяем наличие ключевых полей
            required_fields = ['reg_number', 'supplier_name', 'unit_price', 'sign_date', 'characteristics']
            
            print("\n  📊 Результаты парсинга:")
            print(f"  {'─'*40}")
            
            for field in required_fields:
                value = details.get(field)
                if value:
                    if field == 'sign_date' and isinstance(value, datetime):
                        status = "✅"
                        display_value = value.strftime("%d.%m.%Y")
                    elif field == 'characteristics':
                        status = "✅" if len(value) > 0 else "⚠️"
                        display_value = f"{len(value)} характеристик"
                    else:
                        status = "✅"
                        display_value = str(value)[:50] + ("..." if len(str(value)) > 50 else "")
                else:
                    status = "❌"
                    display_value = "Нет данных"
                
                print(f"  {status} {field:20} : {display_value}")
            
            # Показываем характеристики
            characteristics = details.get('characteristics', [])
            if characteristics:
                print(f"\n  📋 Характеристики ({len(characteristics)}):")
                print(f"  {'─'*40}")
                for i, char in enumerate(characteristics[:5], 1):
                    print(f"  {i:2}. {char.get('key', '?'):20} : {char.get('value', '?')} {char.get('unit', '')}")
                if len(characteristics) > 5:
                    print(f"  ... и еще {len(characteristics) - 5} характеристик")
            
            # Показываем все поля для отладки
            print(f"\n  🔍 Все поля (для отладки):")
            print(f"  {'─'*40}")
            for key, value in details.items():
                if key not in ['characteristics', 'url']:
                    print(f"  {key:20} : {str(value)[:80]}")
                    
        except Exception as e:
            print(f"  ❌ Ошибка: {e}")
            import traceback
            traceback.print_exc()
    
    await parser.client.aclose()
    print("\n" + "=" * 70)
    print("АНАЛИЗ ЗАВЕРШЕН")
    print("=" * 70)

if __name__ == "__main__":
    print("Запуск детального анализа парсера ЕИС...")
    asyncio.run(test_detailed_analysis())
