// Основной JavaScript для фронтенда системы НМЦК - обновленный по демо-интерфейсу

class NMCKSystem {
    constructor() {
        this.apiBaseUrl = "/api";
        this.wsBaseUrl = window.location.origin.replace("http", "ws") + "/api/ws";
        this.sessionToken = null;
        this.wsConnection = null;
        this.currentTaskId = null;
        this.selectedContracts = new Set();
        this.currentTaskResults = null;
        
        this.initialize();
    }

    async initialize() {
        // Инициализация сессии
        await this.initializeSession();
        
        // Инициализация WebSocket
        await this.initializeWebSocket();
        
        // Загрузка истории задач
        await this.loadTaskHistory();
        
        // Настройка обработчиков событий
        this.setupEventHandlers();
        
        // Обновление статистики
        await this.updateStats();
        
        // Показываем уведомление о готовности
        this.showToast("Система готова к работе", "success");
    }

    async initializeSession() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/session`);
            const data = await response.json();
            this.sessionToken = data.token;
            console.log("Сессия инициализирована:", this.sessionToken);
        } catch (error) {
            console.error("Ошибка инициализации сессии:", error);
            this.showToast("Ошибка инициализации сессии", "error");
        }
    }

    async initializeWebSocket() {
        if (!this.sessionToken) {
            console.warn("Нет токена сессии для WebSocket");
            return;
        }
        
        try {
            this.wsConnection = new WebSocket(`${this.wsBaseUrl}?session_token=${this.sessionToken}`);
            
            this.wsConnection.onopen = () => {
                console.log("WebSocket подключен");
            };
            
            this.wsConnection.onmessage = (event) => {
                this.handleWebSocketMessage(event.data);
            };
            
            this.wsConnection.onclose = () => {
                console.log("WebSocket отключен, переподключение через 5 секунд...");
                setTimeout(() => this.initializeWebSocket(), 5000);
            };
            
            this.wsConnection.onerror = (error) => {
                console.error("WebSocket ошибка:", error);
            };
            
        } catch (error) {
            console.error("Ошибка подключения WebSocket:", error);
        }
    }

    handleWebSocketMessage(message) {
        try {
            const data = JSON.parse(message);
            
            switch (data.type) {
                case "task.progress":
                    this.updateTaskProgress(data.data);
                    break;
                    
                case "task.completed":
                    this.handleTaskCompleted(data.data);
                    break;
                    
                case "task.error":
                    this.handleTaskError(data.data);
                    break;
                    
                case "pong":
                    // Ответ на ping, ничего не делаем
                    break;
                    
                default:
                    console.log("Неизвестное сообщение WebSocket:", data);
            }
        } catch (error) {
            console.error("Ошибка обработки WebSocket сообщения:", error, message);
        }
    }

    async loadTaskHistory() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/tasks?limit=20`);
            const tasks = await response.json();
            
            this.renderTaskHistory(tasks);
        } catch (error) {
            console.error("Ошибка загрузки истории задач:", error);
            this.showToast("Ошибка загрузки истории", "error");
        }
    }

    renderTaskHistory(tasks) {
        const tbody = document.getElementById("historyTbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        
        tasks.forEach(task => {
            const row = document.createElement("tr");
            row.className = "rowlink";
            row.dataset.taskId = task.id;
            
            // Форматируем дату
            const createdDate = new Date(task.created_at);
            const dateStr = createdDate.toLocaleDateString("ru-RU") + " " + 
                           createdDate.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
            
            // Форматируем время поиска
            let durationStr = "-";
            if (task.search_duration) {
                const minutes = Math.floor(task.search_duration / 60);
                const seconds = Math.floor(task.search_duration % 60);
                durationStr = `${minutes}м ${seconds}с`;
            }
            
            // Определяем статус
            const statusMap = {
                "queued": { text: "В очереди", class: "tag blue" },
                "searching": { text: "Идет поиск", class: "tag blue" },
                "downloading": { text: "Загрузка", class: "tag blue" },
                "analyzing": { text: "Анализ", class: "tag blue" },
                "done": { text: "Готово", class: "tag ok" },
                "error": { text: "Ошибка", class: "tag bad" },
                "cancelled": { text: "Отменено", class: "tag warn" },
            };
            
            const statusInfo = statusMap[task.status] || { text: task.status, class: "tag" };
            
            // Краткий итог
            let summary = "-";
            if (task.status === "done" && task.total_found > 0) {
                summary = `Найдено: ${task.total_found}, НМЦК: ${task.nmck_value ? task.nmck_value.toLocaleString("ru-RU") + " ₽" : "-"}`;
            } else if (task.status === "error") {
                summary = "Ошибка при выполнении";
            }
            
            row.innerHTML = `
                <td class="nowrap">${dateStr}</td>
                <td>
                    <div>${task.product_name || "Не указано"}</div>
                    <div class="mono" style="font-size:11px; color:var(--muted); margin-top:2px">
                        ${task.ktru_code || "КТРУ не указан"}
                    </div>
                </td>
                <td class="nowrap">
                    <span class="${statusInfo.class}">
                        <span class="p"></span>
                        ${statusInfo.text}
                    </span>
                </td>
                <td>${summary}</td>
                <td class="nowrap">${durationStr}</td>
            `;
            
            // Добавляем обработчик клика для готовых задач
            if (task.status === "done") {
                row.style.cursor = "pointer";
                row.addEventListener("click", () => {
                    this.showTaskResults(task.id);
                });
            }
            
            tbody.appendChild(row);
        });
    }
    setupEventHandlers() {
        // Обработчик загрузки файла
        const fileInput = document.getElementById("fileInput");
        const uploadBtn = document.getElementById("uploadBtn");
        
        if (uploadBtn) {
            uploadBtn.addEventListener("click", () => {
                fileInput.click();
            });
        }
        
        if (fileInput) {
            fileInput.addEventListener("change", (e) => {
                this.handleFileUpload(e.target.files[0]);
            });
        }
        
        // Обработчик кнопки запуска поиска
        const startSearchBtn = document.getElementById("startSearchBtn");
        if (startSearchBtn) {
            startSearchBtn.addEventListener("click", () => {
                this.startSearch();
            });
        }
        
        // Обработчики навигации
        document.querySelectorAll(".navbtn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                this.handleNavigation(e.target.id);
            });
        });
        
        // Обработчик закрытия модального окна
        const closeModalBtn = document.getElementById("closeAuditLog");
        if (closeModalBtn) {
            closeModalBtn.addEventListener("click", () => {
                this.closeAuditLogModal();
            });
        }
        
        // Обработчик клика вне модального окна
        const modal = document.getElementById("auditLogModal");
        if (modal) {
            modal.addEventListener("click", (e) => {
                if (e.target === modal) {
                    this.closeAuditLogModal();
                }
            });
        }
        
        // Обработчик кнопки обновления истории
        const refreshBtn = document.getElementById("refreshHistory");
        if (refreshBtn) {
            refreshBtn.addEventListener("click", () => {
                this.loadTaskHistory();
                this.showToast("История обновлена", "success");
            });
        }
    }

    async handleFileUpload(file) {
        if (!file) return;
        
        // Показываем индикатор загрузки
        this.showToast(`Загрузка файла: ${file.name}`, "info");
        
        const formData = new FormData();
        formData.append("file", file);
        
        try {
            const response = await fetch(`${this.apiBaseUrl}/uploads`, {
                method: "POST",
                body: formData,
            });
            
            if (response.ok) {
                const uploadData = await response.json();
                this.showToast("Файл успешно загружен", "success");
                
                // Сохраняем upload_id для использования при запуске поиска
                this.currentUploadId = uploadData.upload_id;
                
                // Показываем распознанные данные
                this.showUploadDetails(uploadData);
                
            } else {
                const error = await response.json();
                this.showToast(`Ошибка загрузки: ${error.message}`, "error");
            }
            
        } catch (error) {
            console.error("Ошибка загрузки файла:", error);
            this.showToast("Ошибка загрузки файла", "error");
        }
    }

    showUploadDetails(uploadData) {
        const container = document.getElementById("uploadDetails");
        if (!container) return;
        
        const detected = uploadData.detected;
        
        let html = `
            <div class="upload-summary">
                <h3>Распознанные данные</h3>
                <div class="upload-details">
                    <div class="detail-row">
                        <span class="label">Код КТРУ:</span>
                        <span class="value mono">${detected.ktru_code || "Не распознан"}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Наименование:</span>
                        <span class="value">${detected.name || "Не распознано"}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Производитель:</span>
                        <span class="value">${detected.vendor || "Не указан"}</span>
                    </div>
                </div>
        `;
        
        // Характеристики
        if (detected.characteristics && detected.characteristics.length > 0) {
            html += `
                <div class="characteristics">
                    <h4>Характеристики:</h4>
                    <table class="compact">
                        <thead>
                            <tr>
                                <th>Параметр</th>
                                <th>Значение</th>
                                <th>Ед. изм.</th>
                                <th>Оператор</th>
                            </tr>
                        </thead>
                        <tbody>
            `;
            
            detected.characteristics.forEach(char => {
                html += `
                    <tr>
                        <td>${char.key}</td>
                        <td>${char.value}</td>
                        <td>${char.unit || "-"}</td>
                        <td>${char.operator || "="}</td>
                    </tr>
                `;
            });
            
            html += `
                        </tbody>
                    </table>
                </div>
            `;
        }
        
        // Предупреждения
        if (uploadData.warnings && uploadData.warnings.length > 0) {
            html += `
                <div class="warnings">
                    <h4>Предупреждения:</h4>
                    <ul>
            `;
            
            uploadData.warnings.forEach(warning => {
                html += `<li>${warning}</li>`;
            });
            
            html += `
                    </ul>
                </div>
            `;
        }
        
        html += `</div>`;
        
        container.innerHTML = html;
        container.style.display = "block";
        
        // Активируем кнопку запуска поиска
        const startSearchBtn = document.getElementById("startSearchBtn");
        if (startSearchBtn) {
            startSearchBtn.disabled = false;
        }
    }

    async startSearch() {
        if (!this.currentUploadId) {
            this.showToast("Сначала загрузите файл с требованиями", "warning");
            return;
        }
        
        // Получаем параметры поиска из формы
        const region = document.getElementById("regionSelect").value;
        const period = document.getElementById("periodSelect").value;
        
        try {
            const response = await fetch(`${this.apiBaseUrl}/tasks`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    upload_id: this.currentUploadId,
                    region: region,
                    period_years: parseInt(period),
                }),
            });
            
            if (response.ok) {
                const taskData = await response.json();
                this.showToast("Задача поиска создана", "success");
                
                // Переключаемся на вкладку истории
                document.getElementById("navHistory").click();
                
                // Обновляем историю задач
                await this.loadTaskHistory();
                
            } else {
                const error = await response.json();
                this.showToast(`Ошибка создания задачи: ${error.message}`, "error");
            }
            
        } catch (error) {
            console.error("Ошибка запуска поиска:", error);
            this.showToast("Ошибка запуска поиска", "error");
        }
    }

    handleNavigation(navId) {
        // Скрываем все секции
        document.querySelectorAll(".section").forEach(section => {
            section.style.display = "none";
        });
        
        // Убираем активный класс со всех кнопок
        document.querySelectorAll(".navbtn").forEach(btn => {
            btn.classList.remove("active");
        });
        
        // Показываем нужную секцию и активируем кнопку
        const targetSection = document.getElementById(navId.replace("nav", ""));
        const targetBtn = document.getElementById(navId);
        
        if (targetSection) {
            targetSection.style.display = "block";
        }
        
        if (targetBtn) {
            targetBtn.classList.add("active");
        }
    }

    closeAuditLogModal() {
        const modal = document.getElementById("auditLogModal");
        if (modal) {
            modal.classList.remove("open");
            setTimeout(() => {
                modal.style.display = "none";
            }, 300);
        }
    }

    showToast(message, type = "info") {
        const toastContainer = document.getElementById("toastContainer");
        if (!toastContainer) return;
        
        const toast = document.createElement("div");
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        toastContainer.appendChild(toast);
        
        // Автоматическое удаление через 5 секунд
        setTimeout(() => {
            toast.classList.add("fade-out");
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 5000);
    }

    // Вспомогательные методы
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString("ru-RU") + " " + 
               date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
    }
    
    formatCurrency(amount, currency = "RUB") {
        const formatter = new Intl.NumberFormat("ru-RU", {
            style: "currency",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
        return formatter.format(amount);
    }
}

// Инициализация системы при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
    window.nmckSystem = new NMCKSystem();
});
