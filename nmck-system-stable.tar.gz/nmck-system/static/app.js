// Основной JavaScript для фронтенда системы НМЦК - обновленный по демо-интерфейсу

class NMCKSystem {
    constructor() {
        this.apiBaseUrl = "/api";
        this.wsBaseUrl = window.location.origin.replace("http", "ws") + "/api/ws";
        this.sessionToken = null;
        this.wsConnection = null;
        // Восстанавливаем currentTaskId из localStorage
        this.currentTaskId = localStorage.getItem('nmck_current_task_id') || null;
        this.selectedContracts = new Set();
        this.currentTaskResults = null;
        this.currentFile = null;
        
        // Фильтры
        this.statusFilter = new Set(['all']); // По умолчанию показываем все
        this.allTasks = []; // Все задачи для фильтрации
        
        this.initialize();
    }

    async initialize() {
        // Инициализация сессии
        await this.initializeSession();
        
        // Инициализация WebSocket
        await this.initializeWebSocket();
        
        // Загрузка истории задач
        await this.loadTaskHistory();
        
        // Настройка обработчиков событий
        this.setupEventHandlers();
        
        // Обновление статистики
        await this.updateStats();
        
        // Восстанавливаем результаты задачи, если есть сохраненный ID
        if (this.currentTaskId) {
            try {
                await this.showTaskResults(this.currentTaskId);
                this.showView("detail");
            } catch (error) {
                console.warn("Не удалось восстановить результаты задачи:", error);
                // Очищаем невалидный ID
                this.currentTaskId = null;
                localStorage.removeItem('nmck_current_task_id');
            }
        }
        
        // Запускаем периодическое обновление статистики каждые 10 секунд
        setInterval(() => {
            this.updateStats();
        }, 10000);
        
        // Показываем уведомление о готовности
        this.showToast("Система готова к работе", "success");
    }

    async initializeSession() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/session`, {
                credentials: 'include'
            });
            const data = await response.json();
            this.sessionToken = data.token;
            console.log("Сессия инициализирована:", this.sessionToken);
        } catch (error) {
            console.error("Ошибка инициализации сессии:", error);
            this.showToast("Ошибка инициализации сессии", "error");
        }
    }

    async initializeWebSocket() {
        if (!this.sessionToken) {
            console.warn("Нет токена сессии для WebSocket");
            return;
        }
        
        try {
            this.wsConnection = new WebSocket(`${this.wsBaseUrl}?session_token=${this.sessionToken}`);
            
            this.wsConnection.onopen = () => {
                console.log("WebSocket соединение установлено");
            };
            
            this.wsConnection.onmessage = (event) => {
                this.handleWebSocketMessage(event);
            };
            
            this.wsConnection.onerror = (error) => {
                console.error("WebSocket ошибка:", error);
            };
            
            this.wsConnection.onclose = () => {
                console.log("WebSocket соединение закрыто");
                // Пытаемся переподключиться через 5 секунд
                setTimeout(() => this.initializeWebSocket(), 5000);
            };
        } catch (error) {
            console.error("Ошибка инициализации WebSocket:", error);
        }
    }

    handleWebSocketMessage(event) {
        try {
            const message = JSON.parse(event.data);
            console.log("WebSocket сообщение:", message);
            
            switch (message.type) {
                case "task.created":
                    this.showToast(`Задача создана: ${message.data.product_name}`, "success");
                    this.loadTaskHistory();
                    break;
                    
                case "task.progress":
                    this.updateTaskProgress(message.data);
                    break;
                    
                case "task.done":
                    this.showToast(`Поиск завершен: ${message.data.summary}`, "success");
                    this.loadTaskHistory();
                    this.updateStats();
                    break;
                    
                case "task.failed":
                    this.showToast(`Ошибка поиска: ${message.data.human_message}`, "error");
                    this.loadTaskHistory();
                    break;
                    
                case "task.stopped":
                    this.showToast(`Поиск остановлен: ${message.data.message}`, "warn");
                    this.loadTaskHistory();
                    this.updateStats();
                    break;
                    
                default:
                    console.log("Неизвестное сообщение WebSocket:", message);
            }
        } catch (error) {
            console.error("Ошибка обработки WebSocket сообщения:", error, event.data);
        }
    }

    async loadTaskHistory() {
        try {
            console.log("loadTaskHistory: Загрузка истории задач...");
            const response = await fetch(`${this.apiBaseUrl}/tasks?limit=50`, {
                credentials: 'include'  // Включаем cookies
            });
            console.log("loadTaskHistory: Статус ответа:", response.status);
            const tasks = await response.json();
            console.log("loadTaskHistory: Получено задач:", tasks.length, "задачи:", tasks);
            
            // Сохраняем все задачи для фильтрации
            this.allTasks = tasks;
            
            // Применяем фильтры
            const filteredTasks = this.applyFilters(tasks);
            
            this.renderTaskHistory(filteredTasks);
        } catch (error) {
            console.error("Ошибка загрузки истории задач:", error);
            this.showToast("Ошибка загрузки истории", "error");
        }
    }
    
    setupStatusFilter() {
        const filterBtn = document.getElementById("statusFilterBtn");
        const filterDropdown = document.getElementById("statusFilterDropdown");
        const applyBtn = document.getElementById("applyStatusFilter");
        const clearBtn = document.getElementById("clearStatusFilter");
        
        if (!filterBtn || !filterDropdown) return;
        
        // Открытие/закрытие выпадающего списка
        filterBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isVisible = filterDropdown.style.display === "block";
            filterDropdown.style.display = isVisible ? "none" : "block";
            filterBtn.classList.toggle("active", !isVisible);
        });
        
        // Закрытие при клике вне
        document.addEventListener("click", (e) => {
            if (!filterDropdown.contains(e.target) && e.target !== filterBtn) {
                filterDropdown.style.display = "none";
                filterBtn.classList.remove("active");
            }
        });
        
        // Обработка выбора "Все статусы"
        const allCheckbox = filterDropdown.querySelector('.status-filter[value="all"]');
        const otherCheckboxes = filterDropdown.querySelectorAll('.status-filter:not([value="all"])');
        
        allCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                otherCheckboxes.forEach(cb => cb.checked = false);
            }
        });
        
        otherCheckboxes.forEach(cb => {
            cb.addEventListener('change', (e) => {
                if (e.target.checked) {
                    allCheckbox.checked = false;
                }
            });
        });
        
        // Применить фильтр
        applyBtn.addEventListener('click', () => {
            this.statusFilter.clear();
            
            if (allCheckbox.checked) {
                this.statusFilter.add('all');
            } else {
                otherCheckboxes.forEach(cb => {
                    if (cb.checked) {
                        this.statusFilter.add(cb.value);
                    }
                });
            }
            
            // Обновляем таблицу с фильтрами
            const filteredTasks = this.applyFilters(this.allTasks);
            this.renderTaskHistory(filteredTasks);
            
            // Закрываем выпадающий список
            filterDropdown.style.display = "none";
            filterBtn.classList.remove("active");
            
            // Показываем уведомление
            const selectedCount = this.statusFilter.has('all') ? 'Все статусы' : `${this.statusFilter.size} статус(ов)`;
            this.showToast(`Применен фильтр: ${selectedCount}`, "success");
        });
        
        // Сбросить фильтр
        clearBtn.addEventListener('click', () => {
            allCheckbox.checked = true;
            otherCheckboxes.forEach(cb => cb.checked = false);
            this.statusFilter.clear();
            this.statusFilter.add('all');
            
            // Обновляем таблицу
            this.renderTaskHistory(this.allTasks);
            
            // Закрываем выпадающий список
            filterDropdown.style.display = "none";
            filterBtn.classList.remove("active");
            
            this.showToast("Фильтр сброшен", "success");
        });
    }
    
    applyFilters(tasks) {
        if (this.statusFilter.has('all') || this.statusFilter.size === 0) {
            return tasks;
        }
        
        return tasks.filter(task => this.statusFilter.has(task.status));
    }

    renderTaskHistory(tasks) {
        const tbody = document.getElementById("historyTbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        
        tasks.forEach(task => {
            const row = document.createElement("tr");
            row.className = "rowlink";
            row.dataset.taskId = task.id;
            
            // Форматируем дату
            const createdDate = new Date(task.created_at);
            const dateStr = createdDate.toLocaleDateString("ru-RU") + " " + 
                           createdDate.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
            
            // Форматируем время поиска
            let durationStr = "-";
            if (task.search_time) {
                const minutes = Math.floor(task.search_time / 60);
                const seconds = Math.floor(task.search_time % 60);
                if (minutes > 0) {
                    durationStr = `${minutes}м ${seconds}с`;
                } else {
                    durationStr = `${seconds}с`;
                }
            }
            
            // Определяем статус
            const statusMap = {
                "queued": { text: "В очереди", class: "tag blue" },
                "searching": { text: "Идет поиск", class: "tag blue" },
                "downloading": { text: "Загрузка", class: "tag blue" },
                "analyzing": { text: "Анализ", class: "tag blue" },
                "done": { text: "Готово", class: "tag ok" },
                "error": { text: "Ошибка", class: "tag bad" },
                "cancelled": { text: "Отменено", class: "tag warn" },
                "stopped": { text: "Остановлен", class: "tag warn" },
            };
            
            const statusInfo = statusMap[task.status] || { text: task.status, class: "tag" };
            
            // Краткий итог - используем summary из API или генерируем свой
            let summary = task.summary || "-";
            
            row.innerHTML = `
                <td class="nowrap">${dateStr}</td>
                <td>
                    <div>${task.product_name || "Не указано"}</div>
                    <div class="mono" style="font-size:11px; color:var(--muted); margin-top:2px">
                        ${task.ktru_code || "КТРУ не указан"}
                    </div>
                </td>
                <td class="nowrap">
                    <span class="${statusInfo.class}">
                        <span class="p"></span>
                        ${statusInfo.text}
                    </span>
                </td>
                <td>${summary}</td>
                <td class="nowrap">${durationStr}</td>
                <td class="nowrap">
                    ${task.status === "queued" || task.status === "searching" || task.status === "downloading" || task.status === "analyzing" ? 
                    `<button class="btn btn-sm btn-danger" onclick="app.stopTask('${task.id}')" title="Остановить поиск">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="6" y="6" width="12" height="12" rx="1"></rect>
                        </svg>
                    </button>` : 
                    ""}
                </td>
            `;
            
            // Добавляем обработчик клика для готовых задач
            if (task.status === "done") {
                row.style.cursor = "pointer";
                row.addEventListener("click", () => {
                    this.showTaskResults(task.id);
                });
            }
            
            tbody.appendChild(row);
        });
    }

    setupEventHandlers() {
        // Навигация
        document.getElementById("navHistory").addEventListener("click", () => {
            this.showView("history");
        });
        
        document.getElementById("navDetail").addEventListener("click", () => {
            if (this.currentTaskId) {
                this.showView("detail");
            } else {
                this.showToast("Сначала выберите задачу из истории", "warn");
            }
        });
        
        // Кнопка "Новый поиск"
        document.getElementById("btnNewSearch").addEventListener("click", () => {
            this.showView("history");
        });
        
        // Кнопка "Правила"
        document.getElementById("btnHelp").addEventListener("click", () => {
            document.getElementById("helpModal").classList.add("open");
        });
        
        document.getElementById("btnCloseHelp").addEventListener("click", () => {
            document.getElementById("helpModal").classList.remove("open");
        });
        
        document.getElementById("btnGotIt").addEventListener("click", () => {
            document.getElementById("helpModal").classList.remove("open");
        });
        
        // Фильтр по статусу
        this.setupStatusFilter();
        
        // Форма поиска
        document.getElementById("searchForm").addEventListener("submit", (e) => {
            e.preventDefault();
            this.startNewSearch();
        });
        
        // Загрузка файла
        const fileInput = document.getElementById("fileInput");
        const dropZone = document.getElementById("dropZone");
        const btnBrowse = document.getElementById("btnBrowse");
        
        btnBrowse.addEventListener("click", () => {
            fileInput.click();
        });
        
        fileInput.addEventListener("change", (e) => {
            if (e.target.files.length > 0) {
                this.handleFileUpload(e.target.files[0]);
            }
        });
        
        // Drag & drop
        dropZone.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropZone.classList.add("drag");
        });
        
        dropZone.addEventListener("dragleave", () => {
            dropZone.classList.remove("drag");
        });
        
        dropZone.addEventListener("drop", (e) => {
            e.preventDefault();
            dropZone.classList.remove("drag");
            
            if (e.dataTransfer.files.length > 0) {
                this.handleFileUpload(e.dataTransfer.files[0]);
            }
        });
        
        // Кнопка "Назад к истории"
        document.getElementById("btnBack").addEventListener("click", () => {
            this.showView("history");
        });
        
        // Кнопка "Пересчитать НМЦК"
        document.getElementById("btnRecalc").addEventListener("click", () => {
            this.recalculateNMCK();
        });
        
        // Выбор всех контрактов
        document.getElementById("selectAll").addEventListener("change", (e) => {
            this.toggleAllContracts(e.target.checked);
        });
        
        // Закрытие модального окна аудита
        document.getElementById("btnCloseAudit").addEventListener("click", () => {
            document.getElementById("auditModal").classList.remove("open");
        });
        
        document.getElementById("btnCloseAudit2").addEventListener("click", () => {
            document.getElementById("auditModal").classList.remove("open");
        });
        
        // Горячие клавиши
        document.addEventListener("keydown", (e) => {
            if (e.altKey) {
                switch (e.key) {
                    case "1":
                        e.preventDefault();
                        this.showView("history");
                        break;
                    case "2":
                        e.preventDefault();
                        if (this.currentTaskId) {
                            this.showView("detail");
                        }
                        break;
                }
            }
        });
    }    async startNewSearch() {
        const ktru = document.getElementById("ktru").value.trim();
        const title = document.getElementById("title").value.trim();
        const vendor = document.getElementById("vendor").value.trim();
        const region = document.getElementById("region").value;
        const period = document.getElementById("period").value;
        const characteristics = document.getElementById("characteristics").value;
        
        if (!ktru || !title) {
            this.showToast("Заполните обязательные поля: КТРУ и Наименование", "error");
            return;
        }
        
        try {
            // Создаем задачу через прямой endpoint
            const response = await fetch(`${this.apiBaseUrl}/tasks/direct`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                credentials: 'include',
                body: JSON.stringify({
                    ktru_code: ktru,
                    product_name: title,
                    vendor: vendor || null,
                    region: region,
                    period_years: parseInt(period),
                    characteristics: this.parseCharacteristics(characteristics)
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const task = await response.json();
            
            this.showToast(`Задача создана: ${title}`, "success");
            
            // Сбрасываем форму
            document.getElementById("searchForm").reset();
            this.clearFileUpload();
            
            // Обновляем историю
            await this.loadTaskHistory();
            
        } catch (error) {
            console.error("Ошибка создания задачи:", error);
            this.showToast("Ошибка создания задачи", "error");
        }
    }

    parseCharacteristics(text) {
        if (!text.trim()) return [];
        
        const lines = text.split("\n");
        const characteristics = [];
        
        lines.forEach(line => {
            line = line.trim();
            if (!line) return;
            
            const match = line.match(/^([^:]+):\s*(.+)$/);
            if (match) {
                characteristics.push({
                    key: match[1].trim(),
                    value: match[2].trim()
                });
            }
        });
        
        return characteristics;
    }

    async handleFileUpload(file) {
        if (!file) return;
        
        // Проверяем формат файла
        const allowedTypes = [".txt", ".xlsx", ".docx", ".pdf"];
        const fileExt = "." + file.name.split(".").pop().toLowerCase();
        
        if (!allowedTypes.includes(fileExt)) {
            this.showToast("Неподдерживаемый формат файла", "error");
            return;
        }
        
        try {
            const formData = new FormData();
            formData.append("file", file);
            
            const response = await fetch(`${this.apiBaseUrl}/uploads`, {
                method: "POST",
                credentials: 'include',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const upload = await response.json();
            
            this.currentFile = upload;
            
            // Показываем файл в списке
            this.renderUploadedFile(file, upload);
            
            // Заполняем поля формы из распознанных данных
            if (upload.detected) {
                if (upload.detected.ktru_code) {
                    document.getElementById("ktru").value = upload.detected.ktru_code;
                }
                if (upload.detected.name) {
                    document.getElementById("title").value = upload.detected.name;
                }
                if (upload.detected.vendor) {
                    document.getElementById("vendor").value = upload.detected.vendor;
                }
                if (upload.detected.characteristics && upload.detected.characteristics.length > 0) {
                    const charText = upload.detected.characteristics
                        .map(c => `${c.key}: ${c.value}${c.unit ? " " + c.unit : ""}`)
                        .join("\n");
                    document.getElementById("characteristics").value = charText;
                }
            }
            
            this.showToast(`Файл загружен: ${file.name}`, "success");
            
        } catch (error) {
            console.error("Ошибка загрузки файла:", error);
            this.showToast("Ошибка загрузки файла", "error");
        }
    }

    renderUploadedFile(file, upload) {
        const fileList = document.getElementById("fileList");
        fileList.innerHTML = "";
        
        const fileItem = document.createElement("div");
        fileItem.className = "fileitem";
        
        const fileSize = (file.size / 1024).toFixed(1);
        
        fileItem.innerHTML = `
            <div>
                <div class="name">${file.name}</div>
                <div class="meta">${fileSize} KB • ${upload.detected ? "Распознано" : "Не распознано"}</div>
            </div>
            <button class="btn rm" type="button" title="Удалить файл">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        fileItem.querySelector(".rm").addEventListener("click", () => {
            this.clearFileUpload();
        });
        
        fileList.appendChild(fileItem);
    }

    clearFileUpload() {
        this.currentFile = null;
        document.getElementById("fileList").innerHTML = "";
        document.getElementById("fileInput").value = "";
    }

    async showTaskResults(taskId) {
        try {
            this.currentTaskId = taskId;
            // Сохраняем в localStorage
            localStorage.setItem('nmck_current_task_id', taskId);
            
            // Загружаем результаты
            const response = await fetch(`${this.apiBaseUrl}/tasks/${taskId}/result`, {
                credentials: 'include'
            });
            const result = await response.json();
            
            this.currentTaskResults = result;
            
            // Рендерим результаты
            this.renderTaskResults(result);
            
            // Показываем детальный вид
            this.showView("detail");
            
        } catch (error) {
            console.error("Ошибка загрузки результатов:", error);
            this.showToast("Ошибка загрузки результатов", "error");
        }
    }

    renderTaskResults(result) {
        // Обновляем заголовок
        document.getElementById("resultSub").textContent = 
            `${result.summary.product_name} • ${result.summary.ktru_code} • Найдено: ${result.summary.total_found}`;
        
        // Рендерим контракты
        this.renderContracts(result.contracts);
        
        // Обновляем статистику задачи
        document.getElementById("taskStatus").textContent = "Готово";
        document.getElementById("taskProgress").textContent = "100%";
        
        if (result.summary.search_duration) {
            const minutes = Math.floor(result.summary.search_duration / 60);
            const seconds = Math.floor(result.summary.search_duration % 60);
            document.getElementById("taskDuration").textContent = `${minutes}м ${seconds}с`;
        }
        
        // Автоматически выбираем 3 лучших контракта
        this.autoSelectBestContracts(result.contracts);
    }

    renderContracts(contracts) {
        const tbody = document.getElementById("contractsTbody");
        tbody.innerHTML = "";
        
        this.selectedContracts.clear();
        
        contracts.forEach((contract, index) => {
            const row = document.createElement("tr");
            row.dataset.contractId = contract.id;
            
            // Форматируем дату
            const dateStr = contract.sign_date ? 
                new Date(contract.sign_date).toLocaleDateString("ru-RU") : "-";
            
            // Форматируем цену
            const priceStr = contract.unit_price ? 
                contract.unit_price.toLocaleString("ru-RU") + " ₽" : "-";
            
            // Процент совпадения
            const matchPercent = contract.match_percent ? 
                Math.round(contract.match_percent) + "%" : "-";
            
            // Статус производителя
            let vendorStatus = "";
            if (contract.vendor_status === "match") {
                vendorStatus = `<span class="tag ok"><span class="p"></span>Совпадает</span>`;
            } else if (contract.vendor_status === "mismatch") {
                vendorStatus = `<span class="tag bad"><span class="p"></span>Отличается</span>`;
            } else {
                vendorStatus = `<span class="tag"><span class="p"></span>Не указан</span>`;
            }
            
            // Тип совпадения
            let matchType = "";
            if (contract.match_type === "identical") {
                matchType = `<span class="tag ok"><span class="p"></span>Идентичный</span>`;
            } else if (contract.match_type === "homogeneous") {
                matchType = `<span class="tag warn"><span class="p"></span>Однородный</span>`;
            } else {
                matchType = `<span class="tag"><span class="p"></span>Разный</span>`;
            }
            
            row.innerHTML = `
                <td>
                    <input type="checkbox" class="contract-checkbox" data-contract-id="${contract.id}" />
                </td>
                <td>
                    <a href="${contract.eis_url}" target="_blank" class="mono">
                        ${contract.reg_number || "Без номера"}
                    </a>
                </td>
                <td>${contract.supplier_name || "-"}</td>
                <td class="nowrap">${dateStr}</td>
                <td class="nowrap">${priceStr}</td>
                <td>
                    <div class="minirow">
                        <span>${matchPercent}</span>
                        ${matchType}
                    </div>
                </td>
                <td>${vendorStatus}</td>
                <td>
                    <button class="btn" data-contract-id="${contract.id}" title="Показать лог сверки">
                        <i class="fas fa-search"></i>
                    </button>
                </td>
            `;
            
            // Обработчик выбора контракта
            const checkbox = row.querySelector(".contract-checkbox");
            checkbox.addEventListener("change", (e) => {
                this.toggleContractSelection(contract.id, e.target.checked);
            });
            
            // Обработчик кнопки деталей
            const detailsBtn = row.querySelector("button[data-contract-id]");
            detailsBtn.addEventListener("click", () => {
                this.showAuditLog(contract.id);
            });
            
            tbody.appendChild(row);
        });
        
        // Обновляем счетчик выбранных
        this.updateSelectedCount();
    }

    autoSelectBestContracts(contracts) {
        // Сортируем контракты по проценту совпадения (по убыванию)
        const sortedContracts = [...contracts].sort((a, b) => {
            return (b.match_percent || 0) - (a.match_percent || 0);
        });
        
        // Выбираем 3 лучших контракта от разных поставщиков
        const selected = [];
        const selectedSuppliers = new Set();
        
        for (const contract of sortedContracts) {
            if (selected.length >= 3) break;
            
            const supplier = contract.supplier_name || "unknown";
            if (!selectedSuppliers.has(supplier) || selectedSuppliers.size >= 2) {
                selected.push(contract.id);
                selectedSuppliers.add(supplier);
            }
        }
        
        // Если не набрали 3 контракта, добавляем еще
        if (selected.length < 3) {
            for (const contract of sortedContracts) {
                if (selected.length >= 3) break;
                if (!selected.includes(contract.id)) {
                    selected.push(contract.id);
                }
            }
        }
        
        // Выбираем контракты
        selected.forEach(contractId => {
            this.selectedContracts.add(contractId);
            const checkbox = document.querySelector(`.contract-checkbox[data-contract-id="${contractId}"]`);
            if (checkbox) {
                checkbox.checked = true;
            }
        });
        
        // Обновляем счетчик и пересчитываем НМЦК
        this.updateSelectedCount();
        this.recalculateNMCK();
    }

    toggleContractSelection(contractId, isSelected) {
        if (isSelected) {
            this.selectedContracts.add(contractId);
        } else {
            this.selectedContracts.delete(contractId);
        }
        
        this.updateSelectedCount();
        this.recalculateNMCK();
    }

    toggleAllContracts(selectAll) {
        const checkboxes = document.querySelectorAll(".contract-checkbox");
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAll;
            const contractId = checkbox.dataset.contractId;
            if (selectAll) {
                this.selectedContracts.add(contractId);
            } else {
                this.selectedContracts.delete(contractId);
            }
        });
        
        this.updateSelectedCount();
        this.recalculateNMCK();
    }

    updateSelectedCount() {
        const count = this.selectedContracts.size;
        document.getElementById("selectedCount").textContent = count;
        
        // Проверяем правило поставщиков
        this.checkSupplierRule();
        
        // Обновляем чекбокс "Выбрать все"
        const totalCheckboxes = document.querySelectorAll(".contract-checkbox").length;
        const selectAllCheckbox = document.getElementById("selectAll");
        if (totalCheckboxes > 0) {
            selectAllCheckbox.checked = count === totalCheckboxes;
            selectAllCheckbox.indeterminate = count > 0 && count < totalCheckboxes;
        }
    }

    checkSupplierRule() {
        if (this.selectedContracts.size !== 3) {
            document.getElementById("supplierWarning").style.display = "none";
            return;
        }
        
        // Получаем информацию о поставщиках выбранных контрактов
        const selectedContracts = Array.from(this.selectedContracts);
        const suppliers = new Set();
        
        selectedContracts.forEach(contractId => {
            const contract = this.currentTaskResults?.contracts?.find(c => c.id === contractId);
            if (contract?.supplier_name) {
                suppliers.add(contract.supplier_name);
            }
        });
        
        // Проверяем правило: нельзя 3 контракта от одного поставщика
        if (suppliers.size === 1) {
            document.getElementById("supplierWarning").style.display = "block";
        } else {
            document.getElementById("supplierWarning").style.display = "none";
        }
    }    async recalculateNMCK() {
        if (this.selectedContracts.size === 0) {
            document.getElementById("nmckValue").textContent = "—";
            document.getElementById("nmckInfo").textContent = "выберите контракты";
            return;
        }
        
        try {
            const selectedIds = Array.from(this.selectedContracts);
            
            const response = await fetch(`${this.apiBaseUrl}/tasks/${this.currentTaskId}/selection`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                credentials: 'include',
                body: JSON.stringify({
                    contract_ids: selectedIds
                })
            });
            
            if (!response.ok) {
                if (response.status === 409) {
                    const error = await response.json();
                    this.showToast(error.human_message || "Нарушено правило поставщиков", "error");
                    return;
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            
            // Обновляем отображение НМЦК
            document.getElementById("nmckValue").textContent = 
                result.nmck_value ? result.nmck_value.toLocaleString("ru-RU") + " ₽" : "—";
            document.getElementById("nmckInfo").textContent = 
                `средняя цена ${this.selectedContracts.size} контрактов`;
            
            this.showToast("НМЦК пересчитана", "success");
            
        } catch (error) {
            console.error("Ошибка пересчета НМЦК:", error);
            this.showToast("Ошибка пересчета НМЦК", "error");
        }
    }

    async showAuditLog(contractId) {
        try {
            const response = await fetch(`${this.apiBaseUrl}/contracts/${contractId}/audit-log`, {
                credentials: 'include'
            });
            const auditLog = await response.json();
            
            this.renderAuditLog(auditLog);
            
            // Показываем модальное окно
            document.getElementById("auditModal").classList.add("open");
            
        } catch (error) {
            console.error("Ошибка загрузки лога сверки:", error);
            this.showToast("Ошибка загрузки лога сверки", "error");
        }
    }

    renderAuditLog(auditLog) {
        const tbody = document.getElementById("auditTbody");
        tbody.innerHTML = "";
        
        auditLog.forEach(item => {
            const row = document.createElement("tr");
            
            // Определяем статус
            let status = "";
            if (item.is_diff) {
                status = `<span class="tag bad"><span class="p"></span>Отличается</span>`;
            } else {
                status = `<span class="tag ok"><span class="p"></span>Совпадает</span>`;
            }
            
            // Подсветка различий
            const expected = item.is_diff ? 
                `<span class="diff">${item.expected_value || "-"}</span>` : 
                (item.expected_value || "-");
            
            const found = item.is_diff ? 
                `<span class="diff">${item.found_value || "-"}</span>` : 
                (item.found_value || "-");
            
            row.innerHTML = `
                <td>${item.key || "-"}</td>
                <td>${expected}</td>
                <td>${found}</td>
                <td>${status}</td>
            `;
            
            tbody.appendChild(row);
        });
    }

    showView(viewName) {
        // Скрываем все виды
        document.getElementById("viewHistory").style.display = "none";
        document.getElementById("viewDetail").style.display = "none";
        
        // Обновляем навигацию
        document.getElementById("navHistory").setAttribute("aria-pressed", "false");
        document.getElementById("navDetail").setAttribute("aria-pressed", "false");
        
        // Показываем выбранный вид
        if (viewName === "history") {
            document.getElementById("viewHistory").style.display = "block";
            document.getElementById("navHistory").setAttribute("aria-pressed", "true");
            // Очищаем currentTaskId при переходе к истории
            this.currentTaskId = null;
            localStorage.removeItem('nmck_current_task_id');
        } else if (viewName === "detail") {
            document.getElementById("viewDetail").style.display = "block";
            document.getElementById("navDetail").setAttribute("aria-pressed", "true");
        }
    }

    async updateStats() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/tasks/stats`, {
                credentials: 'include'  // Включаем cookies
            });
            const stats = await response.json();
            
            // Обновляем статистику
            document.getElementById("statQueue").textContent = stats.queued_tasks || 0;
            document.getElementById("statRunning").textContent = stats.searching_tasks || 0;
            document.getElementById("statDone").textContent = stats.done_tasks || 0;
            
            // Среднее время поиска
            if (stats.avg_search_time) {
                document.getElementById("statAvg").textContent = `${Math.round(stats.avg_search_time)}с`;
            } else {
                document.getElementById("statAvg").textContent = "—";
            }
            
        } catch (error) {
            console.error("Ошибка обновления статистики:", error);
        }
    }

    updateTaskProgress(data) {
        if (data.task_id === this.currentTaskId) {
            // Обновляем прогресс в детальном виде
            document.getElementById("taskStatus").textContent = data.stage || "В процессе";
            document.getElementById("taskProgress").textContent = 
                data.progress ? `${data.progress}%` : "—";
        }
    }

    showToast(message, type = "info") {
        const toastsContainer = document.getElementById("toasts");
        if (!toastsContainer) return;
        
        const toast = document.createElement("div");
        toast.className = `toast ${type}`;
        
        // Иконка в зависимости от типа
        let icon = "ℹ️";
        if (type === "success") icon = "✓";
        if (type === "error") icon = "✗";
        if (type === "warn") icon = "⚠";
        
        toast.innerHTML = `
            <div class="ico">${icon}</div>
            <div>
                <div class="t">${message}</div>
                <div class="d">${new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}</div>
            </div>
            <button class="x" title="Закрыть">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Обработчик закрытия
        toast.querySelector(".x").addEventListener("click", () => {
            toast.remove();
        });
        
        // Автоматическое закрытие через 5 секунд
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 5000);
        
        toastsContainer.appendChild(toast);
    }

    async stopTask(taskId) {
        if (!confirm("Вы уверены, что хотите остановить поиск? Найденные данные будут сохранены.")) {
            return;
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/tasks/${taskId}/stop`, {
                method: "POST",
                credentials: 'include'
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.detail || "Ошибка при остановке задачи");
            }

            const task = await response.json();
            this.showToast("Поиск остановлен", "success");
            
            // Обновляем список задач
            this.loadTasks();
            
        } catch (error) {
            console.error("Ошибка остановки задачи:", error);
            this.showToast(error.message, "error");
        }
    }
}

// Инициализация при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
    window.nmckSystem = new NMCKSystem();
});