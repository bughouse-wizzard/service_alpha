"""
Тесты для парсера ЕИС
"""
import pytest
import asyncio
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, AsyncMock
import sys
import os

# Добавляем путь к проекту
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.adapters.eis.parser_with_retry import EISParserWithRetry
from app.adapters.eis.normalizer import DataNormalizer
from app.adapters.eis.regions import get_region_code, get_all_regions, get_federal_districts
from app.adapters.eis.match_engine import MatchEngine


class TestEISParser:
    """Тесты парсера ЕИС"""
    
    @pytest.fixture
    def parser(self):
        """Фикстура парсера"""
        return EISParserWithRetry(max_concurrent=1, max_retries=1, use_cache=False)
    
    @pytest.mark.asyncio
    async def test_parser_initialization(self, parser):
        """Тест инициализации парсера"""
        assert parser.base_url == "https://zakupki.gov.ru"
        assert parser.max_retries == 1
        assert parser.use_cache == False
        assert parser.cache is None
    
    def test_build_search_params(self, parser):
        """Тест построения параметров поиска"""
        # Тест с минимальными параметрами
        params = parser._build_search_params()
        assert params["searchString"] == ""
        assert params["fz44"] == "on"
        assert params["fz223"] == "off"
        assert params["contractStage"] == "EXECUTION_COMPLETED"
        assert params["regions"] == "78000000000"  # Северо-Западный ФО по умолчанию
        
        # Тест с КТРУ кодом
        params = parser._build_search_params(ktru_code="26.20.16.110-00000001")
        assert params["ktruCodes"] == "26.20.16.110-00000001"
        
        # Тест с названием товара
        params = parser._build_search_params(product_name="ноутбук")
        assert params["searchString"] == "ноутбук"
        
        # Тест с регионом
        params = parser._build_search_params(region="Центральный ФО")
        assert params["regions"] == "77000000000"
        
        # Тест с периодом
        date_from = datetime(2023, 1, 1)
        date_to = datetime(2023, 12, 31)
        params = parser._build_search_params(period_from=date_from, period_to=date_to)
        assert params["contractDateFrom"] == "01.01.2023"
        assert params["contractDateTo"] == "31.12.2023"
        
        # Тест с 223-ФЗ
        params = parser._build_search_params(law_type="223-ФЗ")
        assert params["fz44"] == "off"
        assert params["fz223"] == "on"
    
    def test_get_region_code(self, parser):
        """Тест получения кода региона"""
        # Федеральные округа
        assert parser._get_region_code("Северо-Западный ФО") == "78000000000"
        assert parser._get_region_code("Центральный ФО") == "77000000000"
        assert parser._get_region_code("Южный ФО") == "79000000000"
        
        # Субъекты РФ
        assert parser._get_region_code("Москва") == "77000000000"
        assert parser._get_region_code("Санкт-Петербург") == "78000000000"
        assert parser._get_region_code("Краснодарский край") == "79000000000"
        
        # Неизвестный регион (должен вернуть СЗФО по умолчанию)
        assert parser._get_region_code("Неизвестный регион") == "78000000000"
    
    def test_parse_search_results(self, parser):
        """Тест парсинга результатов поиска"""
        # Пример HTML с результатами поиска
        html = """
        <div class="search-registry-entry-block">
            <div class="registry-entry__header-mid__number">
                <a href="/epz/contract/contractCard/common-info.html?reestrNumber=123456">№ 123456</a>
            </div>
            <div class="registry-entry__body-href">
                <a href="#">ООО "Поставщик"</a>
            </div>
            <div class="data-block__value">01.01.2023</div>
            <div class="price-block__value">100 000,00 руб.</div>
            <div class="registry-entry__body-value">Ноутбук Dell Latitude 5420</div>
        </div>
        """
        
        contracts = asyncio.run(parser._parse_search_results(html))
        
        assert len(contracts) == 1
        contract = contracts[0]
        
        assert contract["reg_number"] == "123456"
        assert contract["supplier_name"] == 'ООО "Поставщик"'
        assert contract["date"] == "01.01.2023"
        assert contract["price"] == 100000.0
        assert contract["currency"] == "RUB"
        assert contract["purchase_object"] == "Ноутбук Dell Latitude 5420"
        assert "zakupki.gov.ru" in contract["url"]
    
    def test_has_next_page(self, parser):
        """Тест проверки следующей страницы"""
        # HTML без следующей страницы
        html_no_next = "<div>Результаты поиска</div>"
        assert parser._has_next_page(html_no_next) == False
        
        # HTML со следующей страницей
        html_with_next = """
        <div>
            <a href="#">Следующая</a>
        </div>
        """
        assert parser._has_next_page(html_with_next) == True
        
        # HTML с символом >
        html_with_gt = """
        <div>
            <a href="#">&gt;</a>
        </div>
        """
        assert parser._has_next_page(html_with_gt) == True


class TestDataNormalizer:
    """Тесты нормализатора данных"""
    
    def test_normalize_price(self):
        """Тест нормализации цены"""
        # Цена с пробелами и запятой
        result = DataNormalizer.normalize_price("100 000,50 руб.")
        assert result["value"] == 100000.5
        assert result["currency"] == "RUB"
        assert result["normalized"] == True
        
        # Цена с точкой
        result = DataNormalizer.normalize_price("50000.75")
        assert result["value"] == 50000.75
        
        # Цена без десятичных
        result = DataNormalizer.normalize_price("75000")
        assert result["value"] == 75000.0
        
        # Невалидная цена
        result = DataNormalizer.normalize_price("не число")
        assert result["value"] == 0.0
        assert result["normalized"] == False
    
    def test_normalize_date(self):
        """Тест нормализации даты"""
        # Дата в формате DD.MM.YYYY
        date = DataNormalizer.normalize_date("15.01.2023")
        assert date == datetime(2023, 1, 15)
        
        # Дата в формате DD/MM/YYYY
        date = DataNormalizer.normalize_date("15/01/2023")
        assert date == datetime(2023, 1, 15)
        
        # Дата в формате YYYY-MM-DD
        date = DataNormalizer.normalize_date("2023-01-15")
        assert date == datetime(2023, 1, 15)
        
        # Дата с текстом
        date = DataNormalizer.normalize_date("15 января 2023")
        assert date == datetime(2023, 1, 15)
        
        # Невалидная дата
        date = DataNormalizer.normalize_date("не дата")
        assert date is None
    
    def test_normalize_characteristic_value(self):
        """Тест нормализации значения характеристики"""
        # Числовое значение
        result = DataNormalizer.normalize_characteristic_value("16")
        assert result["normalized"] == 16.0
        assert result["type"] == "number"
        
        # Значение с единицами измерения
        result = DataNormalizer.normalize_characteristic_value("512 GB")
        assert result["normalized"] == 512.0
        assert result["unit"] == "GB"
        assert result["type"] == "storage"
        
        # Булево значение
        result = DataNormalizer.normalize_characteristic_value("да")
        assert result["normalized"] == True
        assert result["type"] == "boolean"
        
        # Строковое значение
        result = DataNormalizer.normalize_characteristic_value("Windows 10 Pro")
        assert result["normalized"] == "Windows 10 Pro"
        assert result["type"] == "string"
    
    def test_normalize_characteristic_key(self):
        """Тест нормализации ключа характеристики"""
        # RAM синонимы
        assert DataNormalizer.normalize_characteristic_key("ОЗУ") == "ram"
        assert DataNormalizer.normalize_characteristic_key("оперативная память") == "ram"
        assert DataNormalizer.normalize_characteristic_key("RAM") == "ram"
        
        # Storage синонимы
        assert DataNormalizer.normalize_characteristic_key("SSD") == "storage"
        assert DataNormalizer.normalize_characteristic_key("жесткий диск") == "storage"
        
        # CPU синонимы
        assert DataNormalizer.normalize_characteristic_key("процессор") == "cpu"
        assert DataNormalizer.normalize_characteristic_key("CPU") == "cpu"
        
        # Неизвестный ключ
        # "характеристика" содержит "вес", поэтому возвращается "weight"
        assert DataNormalizer.normalize_characteristic_key("неизвестная характеристика") == "weight"
    
    def test_normalize_contract_data(self):
        """Тест нормализации данных контракта"""
        contract_data = {
            "reg_number": "№ 123456",
            "supplier_name": '  ООО "ПОСТАВЩИК"  ',
            "date": "01.01.2023",
            "price": "100 000,50",
            "characteristics": [
                {"key": "ОЗУ", "value": "16 GB"},
                {"key": "SSD", "value": "512"},
            ]
        }
        
        normalized = DataNormalizer.normalize_contract_data(contract_data)
        
        assert normalized["reg_number_normalized"] == "123456"
        assert normalized["supplier_name_normalized"] == 'ООО ПОСТАВЩИК'
        assert normalized["date_normalized"] == datetime(2023, 1, 1)
        assert normalized["price_normalized"]["value"] == 100000.5
        
        # Проверяем нормализованные характеристики
        assert len(normalized["characteristics_normalized"]) == 2
        
        char1 = normalized["characteristics_normalized"][0]
        assert char1["key_normalized"] == "ram"
        assert char1["value_normalized"]["normalized"] == 16.0
        assert char1["value_normalized"]["unit"] == "GB"
        
        char2 = normalized["characteristics_normalized"][1]
        assert char2["key_normalized"] == "storage"
        assert char2["value_normalized"]["normalized"] == 512.0


class TestRegions:
    """Тесты регионов"""
    
    def test_get_region_code(self):
        """Тест получения кода региона"""
        # Федеральные округа
        assert get_region_code("Северо-Западный ФО") == "78000000000"
        assert get_region_code("Центральный ФО") == "77000000000"
        
        # Субъекты РФ
        assert get_region_code("Москва") == "77000000000"
        assert get_region_code("Санкт-Петербург") == "78000000000"
        
        # Частичное совпадение
        assert get_region_code("северо-западный") == "78000000000"
        assert get_region_code("Московская область") == "77000000000"
        
        # Неизвестный регион
        assert get_region_code("Неизвестный") == "78000000000"
    
    def test_get_all_regions(self):
        """Тест получения всех регионов"""
        regions = get_all_regions()
        assert len(regions) > 0
        assert "Северо-Западный ФО" in regions
        assert "Москва" in regions
    
    def test_get_federal_districts(self):
        """Тест получения федеральных округов"""
        districts = get_federal_districts()
        assert len(districts) == 7
        assert "Северо-Западный ФО" in districts
        assert "Центральный ФО" in districts
        assert "Южный ФО" in districts


class TestMatchEngine:
    """Тесты Match Engine"""
    
    @pytest.fixture
    def match_engine(self):
        """Фикстура Match Engine"""
        return MatchEngine()
    
    def test_calculate_match_score(self, match_engine):
        """Тест расчета процента совпадения"""
        required = [
            {"key": "ram", "value": "16 GB"},
            {"key": "storage", "value": "512 GB"},
            {"key": "cpu", "value": "Intel Core i7"},
        ]
        
        found = [
            {"key": "ОЗУ", "value": "16 GB"},
            {"key": "SSD", "value": "512 GB"},
            {"key": "Процессор", "value": "Intel Core i7"},
        ]
        
        result = match_engine.calculate_match_score(required, found)
        
        assert "match_percent" in result
        assert "match_type" in result
        assert "matched_characteristics" in result
        assert "missing_characteristics" in result
        assert "vendor_match" in result
        
        # Все характеристики должны совпасть
        assert result["match_percent"] > 90
        assert result["match_type"] in ["identical", "homogeneous"]
        assert len(result["matched_characteristics"]) == 3
        assert len(result["missing_characteristics"]) == 0
    
    def test_vendor_match(self, match_engine):
        """Тест сравнения вендоров"""
        required = [
            {"key": "vendor", "value": "Dell"},
        ]
        
        found = [
            {"key": "Производитель", "value": "Dell Inc."},
        ]
        
        result = match_engine.calculate_match_score(required, found)
        assert result["vendor_match"] == "match"
        
        # Несовпадающие вендоры
        found2 = [
            {"key": "Производитель", "value": "HP"},
        ]
        
        result2 = match_engine.calculate_match_score(required, found2)
        assert result2["vendor_match"] == "mismatch"
    
    def test_create_audit_log(self, match_engine):
        """Тест создания лога сверки"""
        required = [
            {"key": "ram", "value": "16 GB"},
            {"key": "storage", "value": "512 GB"},
        ]
        
        found = [
            {"key": "ОЗУ", "value": "16 GB"},
            {"key": "SSD", "value": "256 GB"},  # Не совпадает
        ]
        
        match_result = match_engine.calculate_match_score(required, found)
        audit_log = match_engine.create_audit_log(required, found, match_result)
        
        assert len(audit_log) >= 2  # Характеристики + возможно вендор
        
        # Проверяем структуру лога
        for item in audit_log:
            assert "key" in item
            assert "expected_value" in item
            assert "found_value" in item
            assert "is_diff" in item
            assert "diff_reason" in item
            assert "match_type" in item


if __name__ == "__main__":
    # Запуск тестов
    import unittest
    unittest.main()