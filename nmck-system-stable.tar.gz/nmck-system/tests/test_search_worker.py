"""
Интеграционные тесты для search_worker
"""
import pytest
import sys
import os
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

# Добавляем путь к проекту
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.workers.search_worker import run_search_task
from app.domain.entities.task import TaskEntity, TaskStatus
from app.domain.entities.upload import UploadEntity
from app.domain.entities.contract import ContractEntity, MatchType, VendorStatus


class TestSearchWorker:
    """Тесты search_worker"""
    
    @pytest.fixture
    def mock_db(self):
        """Фикстура мока базы данных"""
        db = Mock()
        
        # Мок задачи
        task = Mock(spec=TaskEntity)
        task.id = "test-task-id"
        task.upload_id = "test-upload-id"
        task.status = TaskStatus.QUEUED
        task.stage = None
        task.progress = 0
        task.started_at = None
        task.finished_at = None
        task.error_code = None
        task.error_detail = None
        
        # Мок загрузки
        upload = Mock(spec=UploadEntity)
        upload.id = "test-upload-id"
        upload.extracted_json = {
            "ktru_code": "26.20.16.110-00000001",
            "name": "Ноутбук",
            "characteristics": [
                {"key": "RAM", "value": "16 GB"},
                {"key": "SSD", "value": "512 GB"},
            ]
        }
        
        # Настройка моков
        db.query.return_value.filter.return_value.first.side_effect = [
            task,  # При запросе задачи
            upload,  # При запросе загрузки
            None,  # При запросе контрактов (пока нет)
        ]
        
        return db
    
    @pytest.fixture
    def mock_parser(self):
        """Фикстура мока парсера"""
        parser = Mock()
        
        # Мок результатов поиска
        mock_contracts = [
            {
                "url": "https://zakupki.gov.ru/epz/contract/contractCard/common-info.html?reestrNumber=123456",
                "reg_number": "123456",
                "supplier_name": "ООО Поставщик 1",
                "date": "01.01.2023",
                "price": 100000.0,
                "currency": "RUB",
                "purchase_object": "Ноутбук Dell Latitude 5420",
            },
            {
                "url": "https://zakupki.gov.ru/epz/contract/contractCard/common-info.html?reestrNumber=789012",
                "reg_number": "789012",
                "supplier_name": "ООО Поставщик 2",
                "date": "15.02.2023",
                "price": 120000.0,
                "currency": "RUB",
                "purchase_object": "Ноутбук HP EliteBook 840",
            }
        ]
        
        # Мок деталей контракта
        mock_details = {
            "reg_number": "123456",
            "supplier_name": "ООО Поставщик 1",
            "supplier_inn": "1234567890",
            "sign_date": datetime(2023, 1, 1),
            "unit_price": 100000.0,
            "currency": "RUB",
            "vendor": "Dell",
            "characteristics": [
                {"key": "ОЗУ", "value": "16 GB", "source": "specification"},
                {"key": "SSD", "value": "512 GB", "source": "specification"},
                {"key": "Процессор", "value": "Intel Core i7", "source": "specification"},
            ],
            "characteristics_normalized": [
                {
                    "key": "ОЗУ",
                    "value": "16 GB",
                    "key_normalized": "ram",
                    "value_normalized": {"normalized": 16.0, "unit": "GB", "type": "storage"}
                }
            ]
        }
        
        parser.search_contracts.return_value = mock_contracts
        parser.get_contract_details.return_value = mock_details
        
        return parser
    
    @patch('app.workers.search_worker.SessionLocal')
    @patch('app.workers.search_worker.SyncEISParser')
    def test_run_search_task_success(self, mock_parser_class, mock_session_local, mock_db):
        """Тест успешного выполнения задачи поиска"""
        # Настройка моков
        mock_session_local.return_value = mock_db
        mock_parser = Mock()
        mock_parser_class.return_value = mock_parser
        
        # Мок результатов парсера
        mock_parser.search_contracts.return_value = [
            {
                "url": "https://zakupki.gov.ru/epz/contract/contractCard/common-info.html?reestrNumber=123456",
                "reg_number": "123456",
                "supplier_name": "ООО Поставщик",
                "date": "01.01.2023",
                "price": 100000.0,
                "currency": "RUB",
                "purchase_object": "Ноутбук",
            }
        ]
        
        mock_parser.get_contract_details.return_value = {
            "reg_number": "123456",
            "supplier_name": "ООО Поставщик",
            "supplier_inn": "1234567890",
            "sign_date": datetime(2023, 1, 1),
            "unit_price": 100000.0,
            "currency": "RUB",
            "vendor": "Dell",
            "characteristics": [
                {"key": "ОЗУ", "value": "16 GB"},
                {"key": "SSD", "value": "512 GB"},
            ],
        }
        
        # Выполняем задачу
        run_search_task("test-task-id")
        
        # Проверяем вызовы
        mock_parser.search_contracts.assert_called_once()
        mock_parser.get_contract_details.assert_called_once()
        
        # Проверяем обновление статуса задачи
        assert mock_db.commit.call_count >= 2
        task = mock_db.query.return_value.filter.return_value.first()
        assert task.status == TaskStatus.DONE
        assert task.finished_at is not None
    
    @patch('app.workers.search_worker.SessionLocal')
    @patch('app.workers.search_worker.SyncEISParser')
    def test_run_search_task_no_upload(self, mock_parser_class, mock_session_local):
        """Тест выполнения задачи без загрузки"""
        # Настройка моков
        db = Mock()
        mock_session_local.return_value = db
        
        # Задача найдена, но загрузка нет
        task = Mock(spec=TaskEntity)
        task.id = "test-task-id"
        task.upload_id = "non-existent-upload-id"
        
        db.query.return_value.filter.return_value.first.side_effect = [
            task,  # Задача
            None,  # Загрузка (не найдена)
        ]
        
        # Выполняем задачу
        run_search_task("test-task-id")
        
        # Проверяем, что задача перешла в статус ERROR
        assert task.status == TaskStatus.ERROR
        assert task.error_code == "UPLOAD_NOT_FOUND"
        db.commit.assert_called_once()
    
    @patch('app.workers.search_worker.SessionLocal')
    @patch('app.workers.search_worker.SyncEISParser')
    def test_run_search_task_parser_error(self, mock_parser_class, mock_session_local, mock_db):
        """Тест ошибки парсера"""
        # Настройка моков
        mock_session_local.return_value = mock_db
        mock_parser = Mock()
        mock_parser_class.return_value = mock_parser
        
        # Парсер выбрасывает исключение
        mock_parser.search_contracts.side_effect = Exception("Ошибка сети")
        
        # Выполняем задачу
        run_search_task("test-task-id")
        
        # Проверяем, что задача перешла в статус ERROR
        task = mock_db.query.return_value.filter.return_value.first()
        assert task.status == TaskStatus.ERROR
        assert task.error_code == "PARSER_ERROR"
        assert "Ошибка сети" in task.error_detail
    
    def test_task_stages_progression(self, mock_db, mock_parser):
        """Тест прогрессии стадий задачи"""
        # Этот тест проверяет, что задача проходит через все стадии
        # В реальном тесте нужно мокировать все зависимости
        
        # Пока просто проверяем, что тестовая структура работает
        assert mock_db is not None
        assert mock_parser is not None
        
        # Проверяем, что мок парсера возвращает данные
        contracts = mock_parser.search_contracts()
        assert len(contracts) == 2
        assert contracts[0]["reg_number"] == "123456"
        
        details = mock_parser.get_contract_details("test-url")
        assert details["reg_number"] == "123456"
        assert len(details["characteristics"]) == 3
    
    @patch('app.workers.search_worker.SessionLocal')
    def test_match_engine_integration(self, mock_session_local):
        """Тест интеграции с Match Engine"""
        # Этот тест проверяет работу Match Engine в контексте воркера
        # В реальном тесте нужно создать полную цепочку моков
        
        # Пока просто проверяем импорты
        from app.adapters.match_engine import MatchEngine, MatchType, VendorStatus
        
        engine = MatchEngine()
        
        # Тестовые данные
        expected = {
            "ram": "16 GB",
            "storage": "512 GB",
        }
        
        found = {
            "ОЗУ": "16 GB",
            "SSD": "512 GB",
        }
        
        # Проверяем работу Match Engine
        match_percent, match_type, audit_log = engine.calculate_match(
            expected, found, "Dell", "Dell Inc."
        )
        
        assert isinstance(match_percent, int)
        assert match_type in [MatchType.IDENTICAL, MatchType.HOMOGENEOUS, MatchType.DIFFERENT]
        assert isinstance(audit_log, list)
        
        # Проверяем структуру лога
        if audit_log:
            item = audit_log[0]
            assert "key" in item
            assert "expected_value" in item
            assert "found_value" in item
            assert "is_diff" in item
            assert "match_percent" in item


class TestContractProcessing:
    """Тесты обработки контрактов"""
    
    def test_contract_entity_creation(self):
        """Тест создания сущности контракта"""
        # Тестовые данные
        contract_data = {
            "reg_number": "123456",
            "supplier_name": "ООО Поставщик",
            "supplier_inn": "1234567890",
            "sign_date": datetime(2023, 1, 1),
            "unit_price": 100000.0,
            "currency": "RUB",
            "match_percent": 95.5,
            "match_type": MatchType.IDENTICAL,
            "vendor_status": VendorStatus.MATCH,
        }
        
        # Проверяем, что данные валидны
        assert contract_data["reg_number"] == "123456"
        assert contract_data["supplier_name"] == "ООО Поставщик"
        assert contract_data["match_percent"] == 95.5
        assert contract_data["match_type"] == MatchType.IDENTICAL
        assert contract_data["vendor_status"] == VendorStatus.MATCH
    
    def test_audit_log_creation(self):
        """Тест создания лога сверки"""
        # Тестовые данные аудита
        audit_data = {
            "key": "RAM",
            "expected_value": "16 GB",
            "found_value": "16 GB",
            "is_diff": False,
            "diff_reason": None,
            "match_percent": 100,
        }
        
        # Проверяем структуру
        assert audit_data["key"] == "RAM"
        assert audit_data["expected_value"] == "16 GB"
        assert audit_data["found_value"] == "16 GB"
        assert audit_data["is_diff"] == False
        assert audit_data["match_percent"] == 100
        
        # Тест с различиями
        audit_diff = {
            "key": "SSD",
            "expected_value": "512 GB",
            "found_value": "256 GB",
            "is_diff": True,
            "diff_reason": "Значения отличаются: 512 GB vs 256 GB",
            "match_percent": 50,
        }
        
        assert audit_diff["is_diff"] == True
        assert "отличаются" in audit_diff["diff_reason"]
        assert audit_diff["match_percent"] == 50


if __name__ == "__main__":
    # Запуск тестов
    import unittest
    unittest.main()