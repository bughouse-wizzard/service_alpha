"""
Базовые схемы Pydantic
"""
from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Optional, Any
import enum

class BaseSchema(BaseModel):
    """Базовая схема с конфигурацией"""
    model_config = ConfigDict(
        from_attributes=True,
        arbitrary_types_allowed=True
    )

class TimestampMixin(BaseSchema):
    """Миксин для временных меток"""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class PaginationParams(BaseSchema):
    """Параметры пагинации"""
    page: int = 1
    page_size: int = 20
    sort_by: Optional[str] = None
    sort_order: str = "desc"

class PaginatedResponse(BaseSchema):
    """Ответ с пагинацией"""
    items: list[Any]
    total: int
    page: int
    page_size: int
    total_pages: int
