"""
Схемы для загрузок файлов
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from uuid import UUID

from app.schemas.base import BaseSchema, TimestampMixin

class UploadCreate(BaseSchema):
    """Создание загрузки"""
    filename: str
    mime_type: Optional[str] = None

class UploadResponse(TimestampMixin):
    """Ответ с информацией о загрузке"""
    id: UUID
    session_id: UUID
    filename: str
    mime_type: Optional[str] = None
    storage_url: str
    extracted_json: Optional[Dict[str, Any]] = None
    created_at: datetime

class CharacteristicSchema(BaseSchema):
    """Схема характеристики"""
    key: str
    value: str
    unit: Optional[str] = None
    operator: str = "="
    source: Optional[str] = None

class UploadDetectionResponse(BaseSchema):
    """Результат распознавания файла"""
    upload_id: UUID
    detected: Dict[str, Any]
    warnings: List[str] = []
