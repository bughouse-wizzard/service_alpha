"""
Схемы для выбора контрактов
"""
from typing import List, Dict, Optional

from app.schemas.base import BaseSchema

class SelectionUpdate(BaseSchema):
    """Обновление выбора контрактов"""
    contract_ids: List[str]

class SelectionResponse(BaseSchema):
    """Ответ с информацией о выборе"""
    task_id: str
    selected_contracts: List[str]
    nmck_value: Optional[float] = None
    calculation_method: Optional[str] = None
    supplier_counts: Dict[str, int] = {}
