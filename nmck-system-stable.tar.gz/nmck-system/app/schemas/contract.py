"""
Схемы для контрактов
"""
from datetime import datetime
from typing import Optional, List
from enum import Enum

from app.schemas.base import BaseSchema

class MatchType(str, Enum):
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    DIFFERENT = "different"

class VendorStatus(str, Enum):
    MATCH = "match"
    MISMATCH = "mismatch"
    UNKNOWN = "unknown"

class ContractResponse(BaseSchema):
    """Ответ с информацией о контракте"""
    id: str
    task_id: str
    reg_number: str
    eis_url: str
    supplier_name: Optional[str] = None
    supplier_inn: Optional[str] = None
    sign_date: Optional[datetime] = None
    unit_price: float
    currency: str = "RUB"
    match_percent: int
    match_type: MatchType
    vendor_status: VendorStatus
    selected: bool = False

class AuditLogResponse(BaseSchema):
    """Лог сверки характеристик"""
    key: str
    expected_value: Optional[str] = None
    found_value: Optional[str] = None
    is_diff: bool = False
    diff_reason: Optional[str] = None
