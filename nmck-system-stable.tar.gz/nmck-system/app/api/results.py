from typing import List, Dict
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload

from app.models.database import get_db
from app.dependencies.session import get_or_create_session
from app.domain.entities.session import SessionEntity
from app.domain.entities.task import TaskEntityEntity, TaskStatus
from app.domain.entities.contract import ContractEntity, MatchType
from app.domain.entities.audit import ContractAuditEntity
from app.domain.entities.selection import TaskSelectionEntity
from app.schemas.contract import TaskResultResponse, TaskResultSummary, ContractResponse, ContractAuditResponse
from app.schemas.task import TaskResponse

router = APIRouter(prefix="/tasks", tags=["results"])


@router.get("/{task_id}/result", response_model=TaskResultResponse)
async def get_task_result(
    task_id: UUID,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Получить результаты задачи"""
    
    # Получаем задачу
    stmt = select(TaskEntity).where(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session.id,
        TaskEntity.status == TaskStatus.DONE,
    )
    result = await db.execute(stmt)
    task = result.scalar_one_or_none()
    
    if not task:
        raise HTTPException(
            status_code=404,
            detail="Задача не найдена или еще не завершена",
        )
    
    # Получаем контракты
    contracts_stmt = select(ContractEntity).where(
        ContractEntity.task_id == task_id
    ).order_by(
        ContractEntity.match_percent.desc(),
        ContractEntity.unit_price.asc(),
    )
    contracts_result = await db.execute(contracts_stmt)
    contracts = contracts_result.scalars().all()
    
    # Получаем выбранные контракты
    selection_stmt = select(TaskSelectionEntity).where(
        TaskSelectionEntity.task_id == task_id
    )
    selection_result = await db.execute(selection_stmt)
    selections = selection_result.scalars().all()
    selected_contract_ids = {sel.contract_id for sel in selections}
    
    # Подготавливаем контракты для ответа
    contract_responses = []
    for contract in contracts:
        # Определяем метку производителя
        vendor_mark = ""
        if contract.vendor_status == "mismatch":
            vendor_mark = "Производитель отличается"
        
        contract_response = ContractResponse(
            id=contract.id,
            created_at=contract.created_at,
            updated_at=contract.updated_at,
            task_id=contract.task_id,
            reg_number=contract.reg_number,
            eis_url=contract.eis_url,
            supplier_name=contract.supplier_name,
            supplier_inn=contract.supplier_inn,
            sign_date=contract.sign_date,
            unit_price=contract.unit_price,
            currency=contract.currency,
            match_percent=contract.match_percent,
            match_type=contract.match_type,
            vendor_status=contract.vendor_status,
            is_selected=contract.id in selected_contract_ids,
            vendor_mark=vendor_mark,
        )
        contract_responses.append(contract_response)
    
    # Получаем лог сверки для выбранных контрактов
    audit_logs = {}
    if selected_contract_ids:
        audit_stmt = select(ContractAuditEntity).where(
            ContractAuditEntity.contract_id.in_(selected_contract_ids)
        )
        audit_result = await db.execute(audit_stmt)
        audits = audit_result.scalars().all()
        
        for audit in audits:
            if audit.contract_id not in audit_logs:
                audit_logs[audit.contract_id] = []
            
            audit_response = ContractAuditResponse(
                id=audit.id,
                created_at=audit.created_at,
                updated_at=audit.updated_at,
                contract_id=audit.contract_id,
                key=audit.key,
                expected_value=audit.expected_value,
                found_value=audit.found_value,
                is_diff=audit.is_diff,
                diff_reason=audit.diff_reason,
            )
            audit_logs[audit.contract_id].append(audit_response)
    
    # Подсчитываем статистику
    identical_count = sum(1 for c in contracts if c.match_type == MatchType.IDENTICAL)
    homogeneous_count = sum(1 for c in contracts if c.match_type == MatchType.HOMOGENEOUS)
    different_count = sum(1 for c in contracts if c.match_type == MatchType.DIFFERENT)
    
    # Формируем сводку
    summary = TaskResultSummary(
        total_contracts=len(contracts),
        identical_matches=identical_count,
        homogeneous_matches=homogeneous_count,
        different_matches=different_count,
        nmck_value=task.nmck_value,
        nmck_currency=task.nmck_currency or "RUB",
        selected_contracts=list(selected_contract_ids),
    )
    
    return TaskResultResponse(
        summary=summary,
        contracts=contract_responses,
        audit_logs=audit_logs,
    )


@router.get("/contracts/{contract_id}/audit-log", response_model=List[ContractAuditResponse])
async def get_contract_audit_log(
    contract_id: UUID,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Получить лог сверки для контракта"""
    
    # Проверяем доступ к контракту
    stmt = select(ContractEntity).join(TaskEntity).where(
        ContractEntity.id == contract_id,
        TaskEntity.session_id == session.id,
    )
    result = await db.execute(stmt)
    contract = result.scalar_one_or_none()
    
    if not contract:
        raise HTTPException(
            status_code=404,
            detail="Контракт не найден",
        )
    
    # Получаем лог сверки
    audit_stmt = select(ContractAuditEntity).where(
        ContractAuditEntity.contract_id == contract_id
    ).order_by(ContractAuditEntity.key)
    
    audit_result = await db.execute(audit_stmt)
    audits = audit_result.scalars().all()
    
    return [
        ContractAuditResponse.from_orm(audit) for audit in audits
    ]