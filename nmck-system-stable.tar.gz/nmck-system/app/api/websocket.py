import asyncio
import json
from datetime import datetime
from typing import Dict, Set
from uuid import UUID
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.infra.database import get_db
from app.domain.entities.session import SessionEntity
from app.domain.entities.task import TaskEntity
from app.schemas.task import TaskProgressEvent

router = APIRouter()


class ConnectionManager:
    """Менеджер WebSocket соединений"""
    
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, session_token: str):
        """Подключить клиента"""
        await websocket.accept()
        
        if session_token not in self.active_connections:
            self.active_connections[session_token] = set()
        
        self.active_connections[session_token].add(websocket)
    
    def disconnect(self, websocket: WebSocket, session_token: str):
        """Отключить клиента"""
        if session_token in self.active_connections:
            self.active_connections[session_token].discard(websocket)
            if not self.active_connections[session_token]:
                del self.active_connections[session_token]
    
    async def send_personal_message(self, message: str, session_token: str):
        """Отправить сообщение конкретному клиенту"""
        if session_token in self.active_connections:
            for connection in self.active_connections[session_token]:
                try:
                    await connection.send_text(message)
                except Exception:
                    pass
    
    async def broadcast(self, message: str):
        """Отправить сообщение всем клиентам"""
        for connections in self.active_connections.values():
            for connection in connections:
                try:
                    await connection.send_text(message)
                except Exception:
                    pass


manager = ConnectionManager()


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    db: AsyncSession = Depends(get_db),
):
    """WebSocket endpoint для обновлений статуса"""
    
    # Получаем токен сессии из query параметров
    session_token = websocket.query_params.get("session_token")
    
    if not session_token:
        await websocket.close(code=1008, reason="Session token required")
        return
    
    # Проверяем сессию
    stmt = select(SessionEntity).where(SessionEntity.token == session_token)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    
    if not session:
        await websocket.close(code=1008, reason="Invalid session token")
        return
    
    # Подключаем клиента
    await manager.connect(websocket, session_token)
    
    try:
        while True:
            # Клиент может отправлять ping сообщения
            data = await websocket.receive_text()
            
            try:
                message = json.loads(data)
                if message.get("type") == "ping":
                    await websocket.send_text(json.dumps({
                        "type": "pong",
                        "timestamp": datetime.utcnow().isoformat(),
                    }))
            except json.JSONDecodeError:
                pass
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, session_token)


async def send_task_progress(task_id: UUID, session_token: str, status: str, stage: str, progress: int, message: str = None):
    """Отправить обновление прогресса задачи"""
    
    event = TaskProgressEvent(
        task_id=task_id,
        status=status,
        stage=stage,
        progress=progress,
        message=message,
    )
    
    await manager.send_personal_message(
        json.dumps({
            "type": "task.progress",
            "data": event.dict(),
        }),
        session_token,
    )


async def send_task_completed(task_id: UUID, session_token: str, result: Dict):
    """Отправить уведомление о завершении задачи"""
    
    await manager.send_personal_message(
        json.dumps({
            "type": "task.completed",
            "data": {
                "task_id": str(task_id),
                "result": result,
                "timestamp": datetime.utcnow().isoformat(),
            },
        }),
        session_token,
    )


async def send_task_error(task_id: UUID, session_token: str, error_code: str, error_message: str):
    """Отправить уведомление об ошибке задачи"""
    
    await manager.send_personal_message(
        json.dumps({
            "type": "task.error",
            "data": {
                "task_id": str(task_id),
                "error_code": error_code,
                "error_message": error_message,
                "timestamp": datetime.utcnow().isoformat(),
            },
        }),
        session_token,
    )