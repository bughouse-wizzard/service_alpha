"""
Роутер для остановки задач
"""
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.infra.database import get_db
from app.domain.entities.task import TaskEntity, TaskStatus
from app.schemas.task import TaskResponse

router = APIRouter()

@router.post("/tasks/{task_id}/stop", response_model=TaskResponse)
async def stop_task(
    task_id: str,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Остановить выполнение задачи.
    """
    # Получаем session_token из куков
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Сессия не найдена")
    
    # Получаем задачу
    task = db.query(TaskEntity).filter(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session_token
    ).first()
    
    if not task:
        raise HTTPException(status_code=404, detail="Задача не найдена")
    
    # Проверяем, можно ли остановить задачу
    if task.status not in [TaskStatus.QUEUED, TaskStatus.SEARCHING, TaskStatus.DOWNLOADING, TaskStatus.ANALYZING]:
        raise HTTPException(
            status_code=400, 
            detail=f"Задачу со статусом {task.status} нельзя остановить"
        )
    
    # Обновляем статус задачи
    task.status = TaskStatus.STOPPED
    task.finished_at = datetime.utcnow()
    task.stage = "stopped"
    task.progress = 100
    
    db.commit()
    db.refresh(task)
    
    return TaskResponse(
        id=str(task.id),
        session_id=str(task.session_id),
        upload_id=str(task.upload_id),
        status=task.status,
        stage=task.stage,
        progress=task.progress,
        region=task.region,
        period_from=task.period_from,
        period_to=task.period_to,
        created_at=task.created_at,
        started_at=task.started_at,
        finished_at=task.finished_at,
        error_code=task.error_code,
        error_detail=task.error_detail
    )