import os
from datetime import datetime
from uuid import uuid4
from fastapi import APIRouter, Depends, File, UploadFile, Form, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models.database import get_db
from app.dependencies.session import get_or_create_session
from app.domain.entities.session import SessionEntity
from app.domain.entities.upload import UploadEntityEntity
from app.schemas.upload import UploadCreate, UploadResponse, UploadDetailResponse
from app.adapters.storage.minio_client import MinioClient
from app.adapters.parsers.file_parser import FileParser
from app.infra.config import settings

router = APIRouter(prefix="/uploads", tags=["uploads"])

# Инициализация клиентов
minio_client = MinioClient()
file_parser = FileParser()


@router.post("", response_model=UploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    source_type: str = Form("freeform"),
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Загрузить файл с требованиями"""
    
    # Проверяем размер файла (максимум 50MB)
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    file.file.seek(0, 2)  # Перемещаемся в конец файла
    file_size = file.file.tell()
    file.file.seek(0)  # Возвращаемся в начало
    
    if file_size > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"Файл слишком большой. Максимальный размер: {MAX_FILE_SIZE // (1024*1024)}MB",
        )
    
    # Проверяем тип файла
    allowed_extensions = {'.txt', '.xlsx', '.docx', '.pdf'}
    file_extension = os.path.splitext(file.filename)[1].lower()
    
    if file_extension not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Неподдерживаемый формат файла. Поддерживаются: {', '.join(allowed_extensions)}",
        )
    
    # Генерируем уникальное имя файла
    file_id = str(uuid4())
    storage_filename = f"{file_id}{file_extension}"
    
    try:
        # Сохраняем файл в MinIO
        file_content = await file.read()
        storage_url = await minio_client.upload_file(
            bucket_name=settings.minio_bucket,
            filename=storage_filename,
            content=file_content,
            content_type=file.content_type,
        )
        
        # Создаем запись в БД
        upload = UploadEntity(
            session_id=session.id,
            filename=file.filename,
            mime_type=file.content_type or "application/octet-stream",
            storage_url=storage_url,
        )
        
        db.add(upload)
        await db.commit()
        await db.refresh(upload)
        
        # Запускаем асинхронный парсинг файла
        # В реальной системе это можно сделать через Celery
        try:
            detected_data, warnings = await file_parser.parse_file(
                file_content=file_content,
                filename=file.filename,
                mime_type=file.content_type,
            )
            
            upload.extracted_data = detected_data
            upload.warnings = warnings
            await db.commit()
            await db.refresh(upload)
            
        except Exception as parse_error:
            # Если парсинг не удался, сохраняем предупреждение
            upload.warnings = [f"Ошибка при разборе файла: {str(parse_error)}"]
            await db.commit()
            await db.refresh(upload)
        
        # Формируем ответ
        response_data = {
            "id": upload.id,
            "created_at": upload.created_at,
            "updated_at": upload.updated_at,
            "filename": upload.filename,
            "mime_type": upload.mime_type,
        }
        
        if upload.extracted_data:
            response_data["detected"] = upload.extracted_data
        
        if upload.warnings:
            response_data["warnings"] = upload.warnings
        
        return UploadResponse(**response_data)
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Ошибка при загрузке файла: {str(e)}",
        )


@router.get("/{upload_id}", response_model=UploadDetailResponse)
async def get_upload(
    upload_id: str,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Получить информацию о загруженном файле"""
    
    stmt = select(UploadEntity).where(
        UploadEntity.id == upload_id,
        UploadEntity.session_id == session.id,
    )
    result = await db.execute(stmt)
    upload = result.scalar_one_or_none()
    
    if not upload:
        raise HTTPException(
            status_code=404,
            detail="Файл не найден",
        )
    
    return UploadDetailResponse.from_orm(upload)


@router.delete("/{upload_id}")
async def delete_upload(
    upload_id: str,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Удалить загруженный файл"""
    
    stmt = select(UploadEntity).where(
        UploadEntity.id == upload_id,
        UploadEntity.session_id == session.id,
    )
    result = await db.execute(stmt)
    upload = result.scalar_one_or_none()
    
    if not upload:
        raise HTTPException(
            status_code=404,
            detail="Файл не найден",
        )
    
    try:
        # Удаляем файл из MinIO
        await minio_client.delete_file(
            bucket_name=settings.minio_bucket,
            filename=os.path.basename(upload.storage_url),
        )
        
        # Удаляем запись из БД
        await db.delete(upload)
        await db.commit()
        
        return {"message": "Файл удален"}
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Ошибка при удалении файла: {str(e)}",
        )