from datetime import datetime, timedelta
from typing import List, Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func
from sqlalchemy.orm import selectinload

from app.models.database import get_db
from app.dependencies.session import get_or_create_session
from app.domain.entities.session import SessionEntity
from app.domain.entities.upload import UploadEntityEntity
from app.domain.entities.task import TaskEntityEntity, TaskStatus
from app.schemas.task import TaskCreate, TaskResponse, TaskListResponse
from app.infra.celery.tasks import run_search_task
from app.infra.config import settings

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.post("", response_model=TaskResponse)
async def create_task(
    task_data: TaskCreate,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Создать задачу поиска"""
    
    # Проверяем существование загрузки
    stmt = select(UploadEntity).where(
        UploadEntity.id == task_data.upload_id,
        UploadEntity.session_id == session.id,
    )
    result = await db.execute(stmt)
    upload = result.scalar_one_or_none()
    
    if not upload:
        raise HTTPException(
            status_code=404,
            detail="Загрузка не найдена",
        )
    
    # Проверяем лимит одновременных задач
    active_tasks_stmt = select(func.count(TaskEntity.id)).where(
        TaskEntity.session_id == session.id,
        TaskEntity.status.in_([TaskStatus.QUEUED, TaskStatus.SEARCHING, TaskStatus.DOWNLOADING, TaskStatus.ANALYZING]),
    )
    active_tasks_result = await db.execute(active_tasks_stmt)
    active_tasks_count = active_tasks_result.scalar()
    
    if active_tasks_count >= 5:  # Максимум 5 одновременных задач
        raise HTTPException(
            status_code=429,
            detail="Превышен лимит одновременных задач. Максимум 5 задач одновременно.",
        )
    
    # Рассчитываем период поиска
    period_to = datetime.utcnow()
    period_from = period_to - timedelta(days=task_data.period_years * 365)
    
    # Создаем задачу
    task = TaskEntity(
        session_id=session.id,
        upload_id=upload.id,
        status=TaskStatus.QUEUED,
        region=task_data.region,
        period_from=period_from,
        period_to=period_to,
        law_type=task_data.law_type,
    )
    
    db.add(task)
    await db.commit()
    await db.refresh(task)
    
    # Запускаем задачу в Celery
    run_search_task.delay(str(task.id))
    
    # Формируем ответ
    response_data = TaskResponse.from_orm(task)
    if upload.extracted_data:
        response_data.detected_data = upload.extracted_data
    
    return response_data


@router.get("", response_model=List[TaskListResponse])
async def list_tasks(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    status: Optional[TaskStatus] = None,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Получить список задач"""
    
    # Базовый запрос
    stmt = select(TaskEntity).where(TaskEntity.session_id == session.id)
    
    # Фильтр по статусу
    if status:
        stmt = stmt.where(TaskEntity.status == status)
    
    # Сортировка и пагинация
    stmt = stmt.order_by(desc(TaskEntity.created_at)).offset(skip).limit(limit)
    
    # Загружаем связанные данные
    stmt = stmt.options(selectinload(TaskEntity.upload))
    
    result = await db.execute(stmt)
    tasks = result.scalars().all()
    
    responses = []
    for task in tasks:
        # Рассчитываем время поиска
        search_duration = None
        if task.started_at and task.finished_at:
            search_duration = (task.finished_at - task.started_at).total_seconds()
        elif task.started_at:
            search_duration = (datetime.utcnow() - task.started_at).total_seconds()
        
        # Получаем данные из загрузки
        ktru_code = None
        product_name = None
        if task.upload and task.upload.extracted_data:
            ktru_code = task.upload.extracted_data.get("ktru_code")
            product_name = task.upload.extracted_data.get("name")
        
        response_data = {
            "id": task.id,
            "created_at": task.created_at,
            "updated_at": task.updated_at,
            "upload_id": task.upload_id,
            "status": task.status,
            "stage": task.stage,
            "progress": task.progress,
            "ktru_code": ktru_code,
            "product_name": product_name,
            "total_found": task.total_found,
            "nmck_value": task.nmck_value,
            "started_at": task.started_at,
            "finished_at": task.finished_at,
            "search_duration": search_duration,
        }
        
        responses.append(TaskListResponse(**response_data))
    
    return responses


@router.get("/{task_id}", response_model=TaskResponse)
async def get_task(
    task_id: UUID,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Получить информацию о задаче"""
    
    stmt = select(TaskEntity).where(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session.id,
    ).options(selectinload(TaskEntity.upload))
    
    result = await db.execute(stmt)
    task = result.scalar_one_or_none()
    
    if not task:
        raise HTTPException(
            status_code=404,
            detail="Задача не найдена",
        )
    
    # Формируем ответ
    response_data = TaskResponse.from_orm(task)
    if task.upload and task.upload.extracted_data:
        response_data.detected_data = task.upload.extracted_data
    
    return response_data


@router.post("/{task_id}/cancel")
async def cancel_task(
    task_id: UUID,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Отменить задачу"""
    
    stmt = select(TaskEntity).where(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session.id,
        TaskEntity.status.in_([TaskStatus.QUEUED, TaskStatus.SEARCHING, TaskStatus.DOWNLOADING, TaskStatus.ANALYZING]),
    )
    
    result = await db.execute(stmt)
    task = result.scalar_one_or_none()
    
    if not task:
        raise HTTPException(
            status_code=404,
            detail="Задача не найдена или не может быть отменена",
        )
    
    # Обновляем статус задачи
    task.status = TaskStatus.CANCELLED
    task.finished_at = datetime.utcnow()
    task.message = "Задача отменена пользователем"
    
    await db.commit()
    await db.refresh(task)
    
    # TODO: Отменить задачу в Celery
    
    return {"message": "Задача отменена"}


@router.get("/{task_id}/progress")
async def get_task_progress(
    task_id: UUID,
    session: SessionEntity = Depends(get_or_create_session),
    db: AsyncSession = Depends(get_db),
):
    """Получить прогресс выполнения задачи"""
    
    stmt = select(TaskEntity).where(
        TaskEntity.id == task_id,
        TaskEntity.session_id == session.id,
    )
    
    result = await db.execute(stmt)
    task = result.scalar_one_or_none()
    
    if not task:
        raise HTTPException(
            status_code=404,
            detail="Задача не найдена",
        )
    
    return {
        "task_id": task.id,
        "status": task.status,
        "stage": task.stage,
        "progress": task.progress,
        "message": task.message,
        "total_found": task.total_found,
        "total_analyzed": task.total_analyzed,
        "timestamp": datetime.utcnow().isoformat(),
    }