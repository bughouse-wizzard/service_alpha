from typing import Optional
from fastapi import Depends, Request, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models.database import get_db
from app.domain.entities.session import SessionEntity
from app.infra.config import settings


async def get_current_session(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> Optional[SessionEntity]:
    """Получить текущую сессию из куки"""
    
    session_token = request.cookies.get(settings.session_cookie_name)
    
    if not session_token:
        return None
    
    stmt = select(SessionEntity).where(SessionEntity.token == session_token)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    
    if session:
        # Обновляем время последнего визита
        session.last_seen_at = datetime.utcnow()
        await db.commit()
        await db.refresh(session)
    
    return session


async def require_session(
    session: Optional[SessionEntity] = Depends(get_current_session),
) -> SessionEntity:
    """Требовать наличие сессии (для защищенных эндпоинтов)"""
    
    if not session:
        raise HTTPException(
            status_code=401,
            detail="Требуется сессия",
        )
    
    return session


async def get_or_create_session(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> SessionEntity:
    """Получить существующую сессию или создать новую"""
    
    session_token = request.cookies.get(settings.session_cookie_name)
    
    if session_token:
        stmt = select(SessionEntity).where(SessionEntity.token == session_token)
        result = await db.execute(stmt)
        session = result.scalar_one_or_none()
        
        if session:
            # Обновляем время последнего визита
            session.last_seen_at = datetime.utcnow()
            await db.commit()
            await db.refresh(session)
            return session
    
    # Создаем новую сессию
    from uuid import uuid4
    from datetime import datetime
    
    session_token = str(uuid4())
    session = SessionEntity(
        token=session_token,
        user_agent=request.headers.get("user-agent"),
        ip_address=request.client.host if request.client else None,
    )
    
    db.add(session)
    await db.commit()
    await db.refresh(session)
    
    return session