from celery import Celery
from app.infra.config import settings

# Создаем экземпляр Celery
celery_app = Celery(
    "nmck_system",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=[
        "app.infra.celery.tasks",
    ]
)

# Конфигурация Celery
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=30 * 60,  # 30 минут
    task_soft_time_limit=25 * 60,  # 25 минут
    worker_max_tasks_per_child=100,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    worker_concurrency=4,
    broker_connection_retry_on_startup=True,
)

# Автоматическое обнаружение задач
celery_app.autodiscover_tasks(["app.infra.celery"])


@celery_app.task(bind=True)
def debug_task(self):
    """Тестовая задача для отладки"""
    print(f"Request: {self.request!r}")