"""
Конфигурация приложения
"""
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # База данных
    DATABASE_URL: str = "sqlite:///./nmck.db"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Приложение
    DEBUG: bool = True
    SECRET_KEY: str = "your-secret-key-here-change-in-production"
    API_V1_STR: str = "/api"
    
    # Парсер ЕИС
    EIS_BASE_URL: str = "https://zakupki.gov.ru"
    EIS_SEARCH_DELAY: int = 1
    EIS_MAX_RESULTS: int = 50
    
    # Файловое хранилище
    UPLOAD_DIR: str = "uploads"
    MAX_UPLOAD_SIZE: int = 10485760  # 10MB
    
    # WebSocket
    WEBSOCKET_PING_INTERVAL: int = 30
    WEBSOCKET_PING_TIMEOUT: int = 10
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
