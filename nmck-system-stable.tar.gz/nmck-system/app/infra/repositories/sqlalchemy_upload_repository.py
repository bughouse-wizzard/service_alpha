"""
SQLAlchemy реализация репозитория загрузок
"""
from typing import List, Optional
from sqlalchemy.orm import Session

from app.domain.entities.upload import UploadEntity
from app.domain.repositories.upload_repository import UploadRepository
from app.infra.database.models import Upload as UploadModel


class SQLAlchemyUploadRepository(UploadRepository):
    """SQLAlchemy реализация репозитория загрузок"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def get_by_id(self, upload_id: str) -> Optional[UploadEntity]:
        """Получить загрузку по ID"""
        model = self.session.query(UploadModel).filter(UploadModel.id == upload_id).first()
        if model:
            return self._to_entity(model)
        return None
    
    def get_by_session_id(self, session_id: str, limit: int = 20) -> List[UploadEntity]:
        """Получить загрузки по session_id"""
        models = (
            self.session.query(UploadModel)
            .filter(UploadModel.session_id == session_id)
            .order_by(UploadModel.created_at.desc())
            .limit(limit)
            .all()
        )
        return [self._to_entity(model) for model in models]
    
    def create(self, upload: UploadEntity) -> UploadEntity:
        """Создать загрузку"""
        model = UploadModel(
            id=upload.id,
            session_id=upload.session_id,
            filename=upload.filename,
            mime=upload.mime,
            storage_url=upload.storage_url,
            extracted_json=upload.extracted_json,
            created_at=upload.created_at,
        )
        self.session.add(model)
        self.session.flush()
        return self._to_entity(model)
    
    def update(self, upload: UploadEntity) -> UploadEntity:
        """Обновить загрузку"""
        model = self.session.query(UploadModel).filter(UploadModel.id == upload.id).first()
        if not model:
            raise ValueError(f"Загрузка с ID {upload.id} не найдена")
        
        model.filename = upload.filename
        model.mime = upload.mime
        model.storage_url = upload.storage_url
        model.extracted_json = upload.extracted_json
        
        self.session.flush()
        return self._to_entity(model)
    
    def delete(self, upload_id: str) -> bool:
        """Удалить загрузку"""
        model = self.session.query(UploadModel).filter(UploadModel.id == upload_id).first()
        if not model:
            return False
        
        self.session.delete(model)
        return True
    
    def _to_entity(self, model: UploadModel) -> UploadEntity:
        """Преобразовать модель в сущность"""
        return UploadEntity(
            id=model.id,
            session_id=model.session_id,
            filename=model.filename,
            mime=model.mime,
            storage_url=model.storage_url,
            extracted_json=model.extracted_json,
            created_at=model.created_at,
        )