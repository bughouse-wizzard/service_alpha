"""
SQLAlchemy реализация репозитория задач
"""
from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session

from app.domain.entities.task import TaskEntity, TaskStatus
from app.domain.repositories.task_repository import TaskRepository
from app.infra.database.models import Task as TaskModel


class SQLAlchemyTaskRepository(TaskRepository):
    """SQLAlchemy реализация репозитория задач"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def get_by_id(self, task_id: str) -> Optional[TaskEntity]:
        """Получить задачу по ID"""
        model = self.session.query(TaskModel).filter(TaskModel.id == task_id).first()
        if model:
            return self._to_entity(model)
        return None
    
    def get_by_session_id(self, session_id: str, limit: int = 50) -> List[TaskEntity]:
        """Получить задачи по session_id"""
        models = (
            self.session.query(TaskModel)
            .filter(TaskModel.session_id == session_id)
            .order_by(TaskModel.created_at.desc())
            .limit(limit)
            .all()
        )
        return [self._to_entity(model) for model in models]
    
    def create(self, task: TaskEntity) -> TaskEntity:
        """Создать задачу"""
        model = TaskModel(
            id=task.id,
            session_id=task.session_id,
            upload_id=task.upload_id,
            status=task.status.value,
            stage=task.stage,
            progress=task.progress,
            region=task.region,
            period_from=task.period_from,
            period_to=task.period_to,
            created_at=task.created_at,
            started_at=task.started_at,
            finished_at=task.finished_at,
            error_code=task.error_code,
            error_detail=task.error_detail,
        )
        self.session.add(model)
        self.session.flush()
        return self._to_entity(model)
    
    def update(self, task: TaskEntity) -> TaskEntity:
        """Обновить задачу"""
        model = self.session.query(TaskModel).filter(TaskModel.id == task.id).first()
        if not model:
            raise ValueError(f"Задача с ID {task.id} не найдена")
        
        model.status = task.status.value
        model.stage = task.stage
        model.progress = task.progress
        model.started_at = task.started_at
        model.finished_at = task.finished_at
        model.error_code = task.error_code
        model.error_detail = task.error_detail
        
        self.session.flush()
        return self._to_entity(model)
    
    def update_status(self, task_id: str, status: TaskStatus, stage: Optional[str] = None, 
                     progress: Optional[int] = None, error_code: Optional[str] = None, 
                     error_detail: Optional[str] = None) -> Optional[TaskEntity]:
        """Обновить статус задачи"""
        model = self.session.query(TaskModel).filter(TaskModel.id == task_id).first()
        if not model:
            return None
        
        model.status = status.value
        
        if stage is not None:
            model.stage = stage
        
        if progress is not None:
            model.progress = progress
        
        if error_code is not None:
            model.error_code = error_code
        
        if error_detail is not None:
            model.error_detail = error_detail
        
        # Обновляем временные метки
        if status == TaskStatus.SEARCHING and model.started_at is None:
            model.started_at = datetime.utcnow()
        elif status in [TaskStatus.DONE, TaskStatus.ERROR] and model.finished_at is None:
            model.finished_at = datetime.utcnow()
        
        self.session.flush()
        return self._to_entity(model)
    
    def delete(self, task_id: str) -> bool:
        """Удалить задачу"""
        model = self.session.query(TaskModel).filter(TaskModel.id == task_id).first()
        if not model:
            return False
        
        self.session.delete(model)
        return True
    
    def _to_entity(self, model: TaskModel) -> TaskEntity:
        """Преобразовать модель в сущность"""
        return TaskEntity(
            id=model.id,
            session_id=model.session_id,
            upload_id=model.upload_id,
            status=TaskStatus(model.status),
            stage=model.stage,
            progress=model.progress,
            region=model.region,
            period_from=model.period_from,
            period_to=model.period_to,
            created_at=model.created_at,
            started_at=model.started_at,
            finished_at=model.finished_at,
            error_code=model.error_code,
            error_detail=model.error_detail,
        )