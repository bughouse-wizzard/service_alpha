"""
SQLAlchemy реализация репозитория контрактов
"""
from typing import List, Optional
from sqlalchemy.orm import Session

from app.domain.entities.contract import ContractEntity, MatchType, VendorStatus
from app.domain.repositories.contract_repository import ContractRepository
from app.infra.database.models import Contract as ContractModel


class SQLAlchemyContractRepository(ContractRepository):
    """SQLAlchemy реализация репозитория контрактов"""
    
    def __init__(self, session: Session):
        self.session = session
    
    def get_by_id(self, contract_id: str) -> Optional[ContractEntity]:
        """Получить контракт по ID"""
        model = self.session.query(ContractModel).filter(ContractModel.id == contract_id).first()
        if model:
            return self._to_entity(model)
        return None
    
    def get_by_task_id(self, task_id: str) -> List[ContractEntity]:
        """Получить контракты по task_id"""
        models = (
            self.session.query(ContractModel)
            .filter(ContractModel.task_id == task_id)
            .order_by(ContractModel.match_percent.desc())
            .all()
        )
        return [self._to_entity(model) for model in models]
    
    def create(self, contract: ContractEntity) -> ContractEntity:
        """Создать контракт"""
        model = ContractModel(
            id=contract.id,
            task_id=contract.task_id,
            reg_number=contract.reg_number,
            eis_url=contract.eis_url,
            supplier_name=contract.supplier_name,
            supplier_inn=contract.supplier_inn,
            sign_date=contract.sign_date,
            unit_price=contract.unit_price,
            currency=contract.currency,
            match_percent=contract.match_percent,
            match_type=contract.match_type.value,
            vendor_status=contract.vendor_status.value,
            raw_payload_json=contract.raw_payload_json,
        )
        self.session.add(model)
        self.session.flush()
        return self._to_entity(model)
    
    def create_batch(self, contracts: List[ContractEntity]) -> List[ContractEntity]:
        """Создать несколько контрактов"""
        models = []
        for contract in contracts:
            model = ContractModel(
                id=contract.id,
                task_id=contract.task_id,
                reg_number=contract.reg_number,
                eis_url=contract.eis_url,
                supplier_name=contract.supplier_name,
                supplier_inn=contract.supplier_inn,
                sign_date=contract.sign_date,
                unit_price=contract.unit_price,
                currency=contract.currency,
                match_percent=contract.match_percent,
                match_type=contract.match_type.value,
                vendor_status=contract.vendor_status.value,
                raw_payload_json=contract.raw_payload_json,
            )
            models.append(model)
        
        self.session.bulk_save_objects(models)
        self.session.flush()
        
        # Возвращаем сущности с ID
        return [self._to_entity(model) for model in models]
    
    def update(self, contract: ContractEntity) -> ContractEntity:
        """Обновить контракт"""
        model = self.session.query(ContractModel).filter(ContractModel.id == contract.id).first()
        if not model:
            raise ValueError(f"Контракт с ID {contract.id} не найдена")
        
        model.reg_number = contract.reg_number
        model.eis_url = contract.eis_url
        model.supplier_name = contract.supplier_name
        model.supplier_inn = contract.supplier_inn
        model.sign_date = contract.sign_date
        model.unit_price = contract.unit_price
        model.currency = contract.currency
        model.match_percent = contract.match_percent
        model.match_type = contract.match_type.value
        model.vendor_status = contract.vendor_status.value
        model.raw_payload_json = contract.raw_payload_json
        
        self.session.flush()
        return self._to_entity(model)
    
    def delete_by_task_id(self, task_id: str) -> int:
        """Удалить контракты по task_id"""
        result = self.session.query(ContractModel).filter(ContractModel.task_id == task_id).delete()
        return result
    
    def _to_entity(self, model: ContractModel) -> ContractEntity:
        """Преобразовать модель в сущность"""
        return ContractEntity(
            id=model.id,
            task_id=model.task_id,
            reg_number=model.reg_number,
            eis_url=model.eis_url,
            supplier_name=model.supplier_name,
            supplier_inn=model.supplier_inn,
            sign_date=model.sign_date,
            unit_price=model.unit_price,
            currency=model.currency,
            match_percent=model.match_percent,
            match_type=MatchType(model.match_type),
            vendor_status=VendorStatus(model.vendor_status),
            raw_payload_json=model.raw_payload_json,
        )