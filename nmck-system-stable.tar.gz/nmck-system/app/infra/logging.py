import logging
import sys
from typing import Any, Dict
import structlog
from app.infra.config import settings


def setup_logging():
    """Настройка структурированного логирования"""
    
    # Настройка structlog
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    
    # Настройка стандартного logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, settings.log_level.upper()),
    )
    
    # Устанавливаем уровень логирования для внешних библиотек
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy").setLevel(logging.WARNING)
    logging.getLogger("celery").setLevel(logging.WARNING)
    
    # Создаем логгер
    logger = structlog.get_logger()
    logger.info("Logging configured", level=settings.log_level)
    
    return logger


def get_logger(name: str = None) -> structlog.BoundLogger:
    """Получить логгер"""
    return structlog.get_logger(name)


def log_task_progress(task_id: str, stage: str, progress: int, message: str = None, **kwargs):
    """Логировать прогресс задачи"""
    
    logger = get_logger("task")
    logger.info(
        "task.progress",
        task_id=task_id,
        stage=stage,
        progress=progress,
        message=message,
        **kwargs,
    )


def log_task_completed(task_id: str, result: Dict[str, Any]):
    """Логировать завершение задачи"""
    
    logger = get_logger("task")
    logger.info(
        "task.completed",
        task_id=task_id,
        result=result,
    )


def log_task_error(task_id: str, error_code: str, error_detail: str, **kwargs):
    """Логировать ошибку задачи"""
    
    logger = get_logger("task")
    logger.error(
        "task.error",
        task_id=task_id,
        error_code=error_code,
        error_detail=error_detail,
        **kwargs,
    )


def log_eis_request(url: str, method: str, status_code: int = None, duration: float = None, **kwargs):
    """Логировать запрос к ЕИС"""
    
    logger = get_logger("eis")
    logger.info(
        "eis.request",
        url=url,
        method=method,
        status_code=status_code,
        duration=duration,
        **kwargs,
    )


def log_eis_error(url: str, method: str, error: str, **kwargs):
    """Логировать ошибку запроса к ЕИС"""
    
    logger = get_logger("eis")
    logger.error(
        "eis.error",
        url=url,
        method=method,
        error=error,
        **kwargs,
    )