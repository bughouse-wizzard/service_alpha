"""
Исправленный воркер для выполнения поиска контрактов в ЕИС
"""
import time
import random
from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy.orm import Session

from app.domain.entities.task import TaskEntity, TaskStatus
from app.domain.entities.upload import UploadEntity
from app.domain.entities.contract import ContractEntity, MatchType, VendorStatus
from app.domain.entities.audit import ContractAuditEntity
from app.domain.entities.selection import TaskSelectionEntity
from app.domain.entities.calculation import TaskCalculationEntity
from app.adapters.eis.sync_adapter import SyncEISParser
from app.adapters.match_engine import MatchEngine, MatchType as MatchTypeEnum, VendorStatus as VendorStatusEnum
from app.workers.celery_app import celery_app
from app.infra.database import SessionLocal


@celery_app.task(bind=True, name="app.workers.search_worker.run_search_task")
def run_search_task(self, task_id: str):
    """
    Основная функция воркера для выполнения поиска контрактов.
    
    Args:
        task_id: ID задачи
    """
    # Создаем сессию базы данных
    db = SessionLocal()
    try:
        # Получаем задачу
        task = db.query(TaskEntity).filter(TaskEntity.id == task_id).first()
        if not task:
            print(f"Задача {task_id} не найдена")
            db.close()
            return
        
        # Обновляем статус задачи
        task.status = TaskStatus.SEARCHING
        task.started_at = datetime.utcnow()
        task.stage = "Поиск контрактов"
        task.progress = 10
        db.commit()
        
        # Получаем данные загрузки
        upload = db.query(UploadEntity).filter(UploadEntity.id == task.upload_id).first()
        if not upload:
            task.status = TaskStatus.ERROR
            task.error_code = "UPLOAD_NOT_FOUND"
            task.error_detail = "Загрузка не найдена"
            task.finished_at = datetime.utcnow()
            db.commit()
            db.close()
            return
        
        # Извлекаем требования
        requirements = upload.extracted_json or {}
        ktru_code = requirements.get("ktru_code", "")
        product_name = requirements.get("name", "")
        expected_characteristics = requirements.get("characteristics", {})
        expected_vendor = requirements.get("vendor", "")
        
        # Создаем парсер ЕИС
        parser = SyncEISParser(region=task.region, law_type=task.law_type)
        
        # Обновляем статус
        task.stage = "Поиск контрактов в ЕИС"
        task.progress = 20
        db.commit()
        
        # Ищем контракты
        try:
            contracts_data = parser.search_contracts(
                ktru_code=ktru_code,
                product_name=product_name,
                period_from=task.period_from,
                period_to=task.period_to
            )
        except Exception as e:
            task.status = TaskStatus.ERROR
            task.error_code = "EIS_SEARCH_ERROR"
            task.error_detail = f"Ошибка поиска в ЕИС: {str(e)}"
            task.finished_at = datetime.utcnow()
            db.commit()
            print(f"Ошибка при поиске контрактов: {e}")
            return
        
        # Обновляем статус
        task.stage = "Анализ контрактов"
        task.progress = 40
        task.total_found = len(contracts_data)
        db.commit()
        
        # Создаем движок сопоставления
        match_engine = MatchEngine()
        
        # Анализируем контракты
        contracts = []
        for i, contract_data in enumerate(contracts_data):
            # Обновляем прогресс
            task.progress = 40 + int((i / len(contracts_data)) * 40)
            db.commit()

            try:
                # Извлекаем характеристики
                found_characteristics = parser.extract_characteristics(contract_data["url"])
                found_vendor = parser.get_contract_vendor(contract_data["url"])
                
                # Рассчитываем совпадение (упрощенная версия, пока нет полноценного match engine)
                match_percent = 0.0
                match_type = MatchType.DIFFERENT
                vendor_status = VendorStatus.UNKNOWN
                audit_log = []
                
                # TODO: Реализовать полноценный match engine
                # Временная заглушка - рассчитываем процент совпадения
                if expected_characteristics:
                    # Упрощенный расчет
                    match_percent = 50.0  # Заглушка
                    match_type = MatchType.HOMOGENEOUS
                
                # Проверка вендора (упрощенная)
                if expected_vendor and found_vendor:
                    if expected_vendor.lower() in found_vendor.lower() or found_vendor.lower() in expected_vendor.lower():
                        vendor_status = VendorStatus.MATCH
                    else:
                        vendor_status = VendorStatus.MISMATCH
                
                # Преобразуем дату
                sign_date = datetime.utcnow()
                if contract_data.get("date"):
                    try:
                        # Пробуем разные форматы дат
                        date_str = contract_data["date"]
                        for fmt in ["%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"]:
                            try:
                                sign_date = datetime.strptime(date_str, fmt)
                                break
                            except ValueError:
                                continue
                    except:
                        pass
                
                # Создаем контракт
                contract = ContractEntity(
                    task_id=task.id,
                    reg_number=contract_data["reg_number"],
                    eis_url=contract_data["url"],
                    supplier_name=contract_data["supplier_name"],
                    supplier_inn="",  # TODO: Извлечь ИНН из деталей контракта
                    sign_date=sign_date,
                    unit_price=contract_data.get("price", 0.0),
                    currency=contract_data.get("currency", "RUB"),
                    match_percent=match_percent,
                    match_type=match_type,
                    vendor_status=vendor_status,
                    raw_payload_json=contract_data
                )
                db.add(contract)
                db.flush()  # Получаем ID контракта
                
                # Сохраняем лог сверки (упрощенный)
                if expected_characteristics:
                    for key, expected_value in expected_characteristics.items():
                        found_value = found_characteristics.get(key, "")
                        is_diff = expected_value != found_value
                        
                        audit_row = ContractAuditEntity(
                            contract_id=contract.id,
                            key=key,
                            expected_value=str(expected_value),
                            found_value=str(found_value),
                            is_diff=is_diff,
                            diff_reason="Не найдено" if not found_value else "Значение отличается"
                        )
                        db.add(audit_row)
                
                contracts.append(contract)
                
            except Exception as e:
                print(f"Ошибка при анализе контракта {contract_data.get('reg_number', 'N/A')}: {e}")
                continue

        # Обновляем статус
        task.stage = "Выбор контрактов"
        task.progress = 85
        task.total_analyzed = len(contracts)
        db.commit()

        # Автоматически выбираем 3 лучших контракта
        selected_contracts = _auto_select_contracts(contracts, db)

        # Рассчитываем НМЦК
        nmck_value = _calculate_nmck(selected_contracts)

        # Сохраняем расчет
        calculation = TaskCalculationEntity(
            task_id=task.id,
            method="average",
            nmc_value=nmck_value,
            currency="RUB",
            details_json={
                "selected_contracts": [str(c.id) for c in selected_contracts],
                "calculation_method": "average",
                "calculation_date": datetime.utcnow().isoformat()
            }
        )
        db.add(calculation)

        # Обновляем задачу
        task.status = TaskStatus.DONE
        task.stage = "Завершено"
        task.progress = 100
        task.nmck_value = nmck_value
        task.nmck_currency = "RUB"
        task.finished_at = datetime.utcnow()
        db.commit()

        print(f"Задача {task_id} успешно выполнена. Найдено {len(contracts)} контрактов.")

    except Exception as e:
        # Обрабатываем ошибку
        task.status = TaskStatus.ERROR
        task.error_code = "SEARCH_ERROR"
        task.error_detail = str(e)
        task.finished_at = datetime.utcnow()
        db.commit()
        print(f"Ошибка при выполнении задачи {task_id}: {e}")
    finally:
        # Закрываем сессию
        db.close()


def _auto_select_contracts(contracts: List[ContractEntity], db: Session) -> List[ContractEntity]:
    """
    Автоматически выбирает 3 лучших контракта с учетом ограничений.
    
    Args:
        contracts: Список контрактов
        db: Сессия базы данных
        
    Returns:
        Список выбранных контрактов
    """
    if not contracts:
        return []
    
    # Сортируем по проценту совпадения (по убыванию)
    sorted_contracts = sorted(contracts, key=lambda c: c.match_percent, reverse=True)
    
    # Выбираем 3 лучших, но не более 2 от одного поставщика
    selected_contracts = []
    supplier_count = {}
    
    for contract in sorted_contracts:
        supplier = contract.supplier_name
        if supplier not in supplier_count:
            supplier_count[supplier] = 0
        
        # Проверяем правило: не более 2 контрактов от одного поставщика
        if supplier_count[supplier] < 2:
            selected_contracts.append(contract)
            supplier_count[supplier] += 1
        
        if len(selected_contracts) >= 3:
            break
    
    # Сохраняем выбранные контракты
    for contract in selected_contracts:
        selection = TaskSelectionEntity(
            task_id=contract.task_id,
            contract_id=contract.id,
            selected_at=datetime.utcnow()
        )
        db.add(selection)
    
    return selected_contracts


def _calculate_nmck(contracts: List[ContractEntity]) -> float:
    """
    Рассчитывает НМЦК как среднее арифметическое цен выбранных контрактов.
    
    Args:
        contracts: Список контрактов
        
    Returns:
        Значение НМЦК
    """
    if not contracts:
        return 0.0
    
    total_price = sum(c.unit_price for c in contracts)
    return total_price / len(contracts)