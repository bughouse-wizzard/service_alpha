"""
Celery воркер для системы НМЦК
"""
import os
import sys

# Добавляем путь к проекту
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.workers.search_worker import celery_app

if __name__ == '__main__':
    celery_app.start()
