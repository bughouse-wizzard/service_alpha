"""
Рефакторинг воркера с использованием новой архитектуры
"""
from app.application.use_cases.search_contracts import SearchContractsUseCase
from app.infra.repositories.sqlalchemy_task_repository import SQLAlchemyTaskRepository
from app.infra.repositories.sqlalchemy_upload_repository import SQLAlchemyUploadRepository
from app.infra.repositories.sqlalchemy_contract_repository import SQLAlchemyContractRepository
from app.adapters.eis.sync_adapter import SyncEISParser
from app.adapters.match_engine import MatchEngine
from app.workers.celery_app import celery_app
from app.infra.database import SessionLocal


@celery_app.task(bind=True, name="app.workers.search_worker_refactored.run_search_task")
def run_search_task(self, task_id: str):
    """
    Основная функция воркера с использованием новой архитектуры
    
    Args:
        task_id: ID задачи
    """
    # Создаем сессию базы данных
    db = SessionLocal()
    try:
        # Создаем репозитории
        task_repository = SQLAlchemyTaskRepository(db)
        upload_repository = SQLAlchemyUploadRepository(db)
        contract_repository = SQLAlchemyContractRepository(db)
        
        # Создаем адаптеры
        eis_parser = SyncEISParser()
        match_engine = MatchEngine()
        
        # Создаем use case
        use_case = SearchContractsUseCase(
            task_repository=task_repository,
            upload_repository=upload_repository,
            contract_repository=contract_repository,
            eis_parser=eis_parser,
            match_engine=match_engine,
        )
        
        # Выполняем поиск контрактов
        result = use_case.execute(task_id)
        
        if result["success"]:
            print(f"Поиск завершен успешно. Найдено контрактов: {result.get('contracts_found', 0)}")
        else:
            print(f"Ошибка поиска: {result.get('error', 'Неизвестная ошибка')}")
        
        db.commit()
        
    except Exception as e:
        db.rollback()
        print(f"Критическая ошибка в воркере: {e}")
        raise
    
    finally:
        db.close()


# Для обратной совместимости оставляем старую функцию
@celery_app.task(bind=True, name="app.workers.search_worker.run_search_task_legacy")
def run_search_task_legacy(self, task_id: str):
    """
    Легаси функция для обратной совместимости
    """
    return run_search_task(task_id)