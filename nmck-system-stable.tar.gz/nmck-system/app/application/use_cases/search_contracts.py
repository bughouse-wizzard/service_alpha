"""
Use case для поиска контрактов
"""
from typing import List, Dict, Any
from datetime import datetime

from app.domain.repositories.task_repository import TaskRepository
from app.domain.repositories.upload_repository import UploadRepository
from app.domain.repositories.contract_repository import ContractRepository
from app.domain.entities.task import TaskStatus
from app.adapters.eis.sync_adapter import SyncEISParser
from app.adapters.match_engine import MatchEngine


class SearchContractsUseCase:
    """Use case для поиска контрактов"""
    
    def __init__(
        self,
        task_repository: TaskRepository,
        upload_repository: UploadRepository,
        contract_repository: ContractRepository,
        eis_parser: SyncEISParser,
        match_engine: MatchEngine,
    ):
        self.task_repository = task_repository
        self.upload_repository = upload_repository
        self.contract_repository = contract_repository
        self.eis_parser = eis_parser
        self.match_engine = match_engine
    
    def execute(self, task_id: str) -> Dict[str, Any]:
        """
        Выполнить поиск контрактов
        
        Args:
            task_id: ID задачи
            
        Returns:
            Результат выполнения
        """
        # Получаем задачу
        task = self.task_repository.get_by_id(task_id)
        if not task:
            return {"success": False, "error": "Задача не найдена"}
        
        # Обновляем статус задачи
        task = self.task_repository.update_status(
            task_id=task_id,
            status=TaskStatus.SEARCHING,
            stage="Поиск контрактов",
            progress=10,
        )
        
        # Получаем данные загрузки
        upload = self.upload_repository.get_by_id(task.upload_id)
        if not upload:
            task = self.task_repository.update_status(
                task_id=task_id,
                status=TaskStatus.ERROR,
                error_code="UPLOAD_NOT_FOUND",
                error_detail="Загрузка не найдена",
            )
            return {"success": False, "error": "Загрузка не найдена"}
        
        try:
            # Извлекаем требования из загрузки
            requirements = self._extract_requirements(upload)
            if not requirements:
                task = self.task_repository.update_status(
                    task_id=task_id,
                    status=TaskStatus.ERROR,
                    error_code="NO_REQUIREMENTS",
                    error_detail="Не удалось извлечь требования из загрузки",
                )
                return {"success": False, "error": "Не удалось извлечь требования"}
            
            # Обновляем прогресс
            task = self.task_repository.update_status(
                task_id=task_id,
                status=TaskStatus.SEARCHING,
                stage="Поиск контрактов в ЕИС",
                progress=20,
            )
            
            # Ищем контракты в ЕИС
            contracts = self._search_contracts(task, requirements)
            
            # Обновляем прогресс
            task = self.task_repository.update_status(
                task_id=task_id,
                status=TaskStatus.SEARCHING,
                stage="Анализ найденных контрактов",
                progress=50,
            )
            
            # Анализируем контракты
            analyzed_contracts = self._analyze_contracts(contracts, requirements)
            
            # Обновляем прогресс
            task = self.task_repository.update_status(
                task_id=task_id,
                status=TaskStatus.SEARCHING,
                stage="Сохранение результатов",
                progress=80,
            )
            
            # Сохраняем контракты в БД
            saved_contracts = self._save_contracts(task_id, analyzed_contracts)
            
            # Обновляем статус задачи
            task = self.task_repository.update_status(
                task_id=task_id,
                status=TaskStatus.DONE,
                stage="Завершено",
                progress=100,
            )
            
            return {
                "success": True,
                "task_id": task_id,
                "contracts_found": len(contracts),
                "contracts_saved": len(saved_contracts),
                "task_status": task.status.value,
            }
            
        except Exception as e:
            # Обрабатываем ошибки
            task = self.task_repository.update_status(
                task_id=task_id,
                status=TaskStatus.ERROR,
                error_code="SEARCH_ERROR",
                error_detail=str(e),
            )
            return {"success": False, "error": str(e), "task_id": task_id}
    
    def _extract_requirements(self, upload) -> Dict[str, Any]:
        """Извлечь требования из загрузки"""
        if not upload.extracted_json:
            return {}
        
        requirements = upload.extracted_json.copy()
        
        # Преобразуем характеристики в формат для Match Engine
        characteristics = requirements.get("characteristics", [])
        if characteristics:
            requirements["characteristics_dict"] = {
                char.get("key", ""): char.get("value", "")
                for char in characteristics
                if char.get("key")
            }
        
        return requirements
    
    def _search_contracts(self, task, requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Поиск контрактов в ЕИС"""
        try:
            contracts = self.eis_parser.search_contracts(
                ktru_code=requirements.get("ktru_code"),
                product_name=requirements.get("name"),
                region=task.region or "Северо-Западный ФО",
                period_from=task.period_from,
                period_to=task.period_to,
                law_type="44-ФЗ",
                max_results=50,
            )
            return contracts
        except Exception as e:
            raise Exception(f"Ошибка поиска контрактов: {e}")
    
    def _analyze_contracts(self, contracts: List[Dict[str, Any]], requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Анализ найденных контрактов"""
        analyzed_contracts = []
        
        for i, contract in enumerate(contracts):
            try:
                # Получаем детали контракта
                contract_details = self.eis_parser.get_contract_details(contract["url"])
                
                # Объединяем базовую информацию и детали
                analyzed_contract = {**contract, **contract_details}
                
                # Рассчитываем совпадение с требованиями
                if requirements.get("characteristics_dict"):
                    match_result = self._calculate_match(requirements, analyzed_contract)
                    analyzed_contract.update(match_result)
                
                analyzed_contracts.append(analyzed_contract)
                
            except Exception as e:
                print(f"Ошибка анализа контракта {contract.get('reg_number', 'unknown')}: {e}")
                continue
        
        return analyzed_contracts
    
    def _calculate_match(self, requirements: Dict[str, Any], contract: Dict[str, Any]) -> Dict[str, Any]:
        """Рассчитать совпадение с требованиями"""
        expected_characteristics = requirements.get("characteristics_dict", {})
        expected_vendor = requirements.get("vendor")
        
        # Извлекаем найденные характеристики
        found_characteristics = {}
        found_vendor = contract.get("vendor")
        
        # Преобразуем характеристики из контракта
        for char in contract.get("characteristics", []):
            key = char.get("key", "")
            value = char.get("value", "")
            if key and value:
                found_characteristics[key] = value
        
        # Рассчитываем совпадение
        match_percent, match_type, audit_log = self.match_engine.calculate_match(
            expected_characteristics,
            found_characteristics,
            expected_vendor,
            found_vendor,
        )
        
        return {
            "match_percent": match_percent,
            "match_type": match_type.value,
            "vendor_status": self.match_engine.compare_vendor(expected_vendor, found_vendor).value,
            "audit_log": audit_log,
        }
    
    def _save_contracts(self, task_id: str, contracts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Сохранить контракты в БД"""
        # Удаляем старые контракты для этой задачи
        self.contract_repository.delete_by_task_id(task_id)
        
        # Создаем сущности контрактов
        contract_entities = []
        for contract in contracts:
            try:
                entity = self._create_contract_entity(task_id, contract)
                contract_entities.append(entity)
            except Exception as e:
                print(f"Ошибка создания сущности контракта: {e}")
                continue
        
        # Сохраняем контракты
        if contract_entities:
            saved_entities = self.contract_repository.create_batch(contract_entities)
            return [self._entity_to_dict(entity) for entity in saved_entities]
        
        return []
    
    def _create_contract_entity(self, task_id: str, contract_data: Dict[str, Any]):
        """Создать сущность контракта"""
        from app.domain.entities.contract import ContractEntity, MatchType, VendorStatus
        
        # Преобразуем строковые значения в enum
        match_type_str = contract_data.get("match_type", "different")
        vendor_status_str = contract_data.get("vendor_status", "unknown")
        
        try:
            match_type = MatchType(match_type_str)
        except ValueError:
            match_type = MatchType.DIFFERENT
        
        try:
            vendor_status = VendorStatus(vendor_status_str)
        except ValueError:
            vendor_status = VendorStatus.UNKNOWN
        
        return ContractEntity(
            task_id=task_id,
            reg_number=contract_data.get("reg_number", ""),
            eis_url=contract_data.get("url", ""),
            supplier_name=contract_data.get("supplier_name", ""),
            supplier_inn=contract_data.get("supplier_inn", ""),
            sign_date=contract_data.get("sign_date"),
            unit_price=contract_data.get("unit_price", 0.0),
            currency=contract_data.get("currency", "RUB"),
            match_percent=contract_data.get("match_percent", 0.0),
            match_type=match_type,
            vendor_status=vendor_status,
            raw_payload_json=contract_data,
        )
    
    def _entity_to_dict(self, entity) -> Dict[str, Any]:
        """Преобразовать сущность в словарь"""
        return {
            "id": entity.id,
            "reg_number": entity.reg_number,
            "supplier_name": entity.supplier_name,
            "unit_price": entity.unit_price,
            "match_percent": entity.match_percent,
            "match_type": entity.match_type.value,
            "vendor_status": entity.vendor_status.value,
        }