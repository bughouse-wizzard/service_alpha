"""
Парсер файлов с требованиями к товару с поддержкой OCR для PDF
"""
import os
import re
import json
import tempfile
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

import pandas as pd
from docx import Document
import pdfplumber
from openpyxl import load_workbook
from pdf2image import convert_from_path
import pytesseract
from PIL import Image

class FileParser:
    """Парсер файлов различных форматов с поддержкой OCR"""
    
    def __init__(self):
        self.characteristic_patterns = {
            'ram': r'(ОЗУ|RAM|оперативная память|память)\s*[:=]?\s*(\d+)\s*(GB|ГБ|МБ|MB)',
            'ssd': r'(SSD|жесткий диск|накопитель)\s*[:=]?\s*(\d+)\s*(GB|ГБ|ТБ|TB)',
            'cpu': r'(процессор|CPU|ЦП)\s*[:=]?\s*([\w\s\-]+)\s*(\d+\.?\d*)\s*(GHz|ГГц)',
            'screen': r'(экран|дисплей|screen)\s*[:=]?\s*(\d+\.?\d*)\s*(дюйм|inch|")',
            'weight': r'(вес|weight)\s*[:=]?\s*(\d+\.?\d*)\s*(кг|kg|г|g)',
        }
        
        self.unit_mapping = {
            'GB': 'GB', 'ГБ': 'GB', 'MB': 'MB', 'МБ': 'MB',
            'TB': 'TB', 'ТБ': 'TB', 'GHz': 'GHz', 'ГГц': 'GHz',
            'дюйм': 'inch', 'inch': 'inch', '"': 'inch',
            'кг': 'kg', 'kg': 'kg', 'г': 'g', 'g': 'g'
        }
        
        self.operator_mapping = {
            '=': '=',
            '>=': '>=',
            '<=': '<=',
            '>': '>',
            '<': '<',
            '≈': '≈',
            '~': '~'
        }
        
        # Паттерны для поиска КТРУ кода
        self.ktru_patterns = [
            r'КТРУ\s*[:=]?\s*(\d{2}\.\d{2}\.\d{2}\.\d{2}-\d{8})',
            r'(\d{2}\.\d{2}\.\d{2}\.\d{2}-\d{8})',
            r'код\s*КТРУ\s*[:=]?\s*(\d{2}\.\d{2}\.\d{2}\.\d{2}-\d{8})'
        ]
        
        # Паттерны для поиска наименования товара
        self.name_patterns = [
            r'наименование\s*[:=]?\s*(.+)',
            r'товар\s*[:=]?\s*(.+)',
            r'продукт\s*[:=]?\s*(.+)',
            r'изделие\s*[:=]?\s*(.+)'
        ]
        
        # Паттерны для поиска производителя
        self.vendor_patterns = [
            r'производитель\s*[:=]?\s*(.+)',
            r'вендор\s*[:=]?\s*(.+)',
            r'бренд\s*[:=]?\s*(.+)',
            r'изготовитель\s*[:=]?\s*(.+)'
        ]
    
    def parse_file(self, filepath: str, file_ext: str) -> Dict[str, Any]:
        """Парсит файл в зависимости от его расширения"""
        try:
            if file_ext == '.txt':
                return self._parse_txt(filepath)
            elif file_ext == '.xlsx':
                return self._parse_xlsx(filepath)
            elif file_ext == '.docx':
                return self._parse_docx(filepath)
            elif file_ext == '.pdf':
                return self._parse_pdf(filepath)
            else:
                raise ValueError(f"Неподдерживаемый формат файла: {file_ext}")
        except Exception as e:
            return {
                "ktru_code": None,
                "name": None,
                "vendor": None,
                "characteristics": [],
                "warnings": [f"Ошибка парсинга файла: {str(e)}"]
            }
    
    def _parse_txt(self, filepath: str) -> Dict[str, Any]:
        """Парсит текстовый файл"""
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return self._extract_from_text(content)
    
    def _parse_xlsx(self, filepath: str) -> Dict[str, Any]:
        """Парсит Excel файл"""
        result = {
            "ktru_code": None,
            "name": None,
            "vendor": None,
            "characteristics": [],
            "warnings": []
        }
        
        try:
            # Пробуем прочитать как таблицу с помощью pandas
            df = pd.read_excel(filepath, header=None)
            
            # Ищем КТРУ код
            for i in range(min(10, len(df))):
                for j in range(min(10, len(df.columns))):
                    cell_value = str(df.iat[i, j])
                    if re.match(r'^\d{2}\.\d{2}\.\d{2}\.\d{2}-\d{8}$', cell_value):
                        result["ktru_code"] = cell_value
                        break
                if result["ktru_code"]:
                    break
            
            # Ищем наименование товара
            for i in range(min(5, len(df))):
                for j in range(min(5, len(df.columns))):
                    cell_value = str(df.iat[i, j])
                    if len(cell_value) > 10 and not cell_value.startswith('http'):
                        result["name"] = cell_value
                        break
                if result["name"]:
                    break
            
            # Извлекаем характеристики из всех ячеек
            text_content = ""
            for i in range(len(df)):
                for j in range(len(df.columns)):
                    cell_value = str(df.iat[i, j])
                    if cell_value and cell_value != 'nan':
                        text_content += cell_value + " "
            
            # Парсим характеристики из текста
            text_result = self._extract_from_text(text_content)
            result["characteristics"] = text_result.get("characteristics", [])
            result["warnings"].extend(text_result.get("warnings", []))
            
        except Exception as e:
            result["warnings"].append(f"Ошибка парсинга XLSX: {str(e)}")
        
        return result
    
    def _parse_docx(self, filepath: str) -> Dict[str, Any]:
        """Парсит Word документ"""
        doc = Document(filepath)
        
        # Извлекаем весь текст
        text_content = ""
        for paragraph in doc.paragraphs:
            text_content += paragraph.text + "\n"
        
        # Извлекаем текст из таблиц
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text_content += cell.text + " "
        
        return self._extract_from_text(text_content)
    
    def _parse_pdf(self, filepath: str) -> Dict[str, Any]:
        """Парсит PDF файл с поддержкой OCR для сканированных документов"""
        text_content = ""
        warnings = []
        
        # Пытаемся извлечь текст стандартным способом
        try:
            with pdfplumber.open(filepath) as pdf:
                for page in pdf.pages:
                    text = page.extract_text()
                    if text:
                        text_content += text + "\n"
                    else:
                        warnings.append(f"Страница {page.page_number}: не удалось извлечь текст (возможно, это сканированный документ)")
        except Exception as e:
            warnings.append(f"Ошибка открытия PDF: {str(e)}")
        
        # Если текст не извлекся или слишком короткий, пробуем OCR
        if len(text_content.strip()) < 100:
            ocr_text = self._extract_text_with_ocr(filepath)
            if ocr_text:
                text_content += "\n" + ocr_text
                warnings.append("Текст извлечен с помощью OCR (сканированный документ)")
            else:
                warnings.append("Не удалось извлечь текст даже с помощью OCR")
        
        result = self._extract_from_text(text_content)
        result["warnings"].extend(warnings)
        
        return result
    
    def _extract_text_with_ocr(self, filepath: str) -> str:
        """Извлекает текст из PDF с помощью OCR"""
        try:
            # Конвертируем PDF в изображения
            images = convert_from_path(filepath, dpi=300)
            
            extracted_text = ""
            
            # Обрабатываем каждую страницу
            for i, image in enumerate(images):
                try:
                    # Используем pytesseract для распознавания текста
                    text = pytesseract.image_to_string(image, lang='rus+eng')
                    extracted_text += text + "\n"
                except Exception as e:
                    print(f"Ошибка OCR для страницы {i+1}: {e}")
                    continue
            
            return extracted_text
            
        except Exception as e:
            print(f"Ошибка при конвертации PDF в изображения: {e}")
            return ""
    
    def _extract_from_text(self, text: str) -> Dict[str, Any]:
        """Извлекает информацию из текста"""
        result = {
            "ktru_code": None,
            "name": None,
            "vendor": None,
            "characteristics": [],
            "warnings": []
        }
        
        # Ищем КТРУ код с использованием всех паттернов
        for pattern in self.ktru_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                result["ktru_code"] = match.group(1)
                break
        
        # Ищем наименование товара
        for pattern in self.name_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                # Ограничиваем длину названия
                if len(name) > 5 and len(name) < 200:
                    result["name"] = name
                    break
        
        # Если не нашли по паттерну, ищем первую значимую строку
        if not result["name"]:
            lines = text.split('\n')
            for line in lines:
                line = line.strip()
                if (len(line) > 10 and len(line) < 200 and 
                    not line.startswith('http') and 
                    not re.match(r'^\d', line) and
                    not re.match(r'^[^a-zA-Zа-яА-Я]*$', line)):
                    result["name"] = line
                    break
        
        # Ищем производителя
        for pattern in self.vendor_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                vendor = match.group(1).strip()
                if len(vendor) > 2 and len(vendor) < 50:
                    result["vendor"] = vendor
                    break
        
        # Если не нашли по паттерну, ищем известных производителей
        if not result["vendor"]:
            vendors = ['Dell', 'HP', 'Lenovo', 'Apple', 'Asus', 'Acer', 'Microsoft', 'Samsung', 'Xiaomi', 'Huawei']
            for vendor in vendors:
                if vendor.lower() in text.lower():
                    result["vendor"] = vendor
                    break
        
        # Извлекаем характеристики по паттернам
        for key, pattern in self.characteristic_patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                characteristic = {
                    "key": self._normalize_key(key),
                    "value": match.group(2),
                    "unit": self._normalize_unit(match.group(3)) if match.group(3) else None,
                    "operator": "=",
                    "source": "file"
                }
                result["characteristics"].append(characteristic)
        
        # Ищем характеристики в формате "ключ: значение"
        key_value_pattern = r'([\w\s]+)\s*[:=]\s*([\w\d\.\s\-]+)(?:\s*([\w\/]+))?'
        matches = re.finditer(key_value_pattern, text)
        
        for match in matches:
            key = match.group(1).strip().lower()
            value = match.group(2).strip()
            unit = match.group(3).strip() if match.group(3) else None
            
            # Пропускаем очевидные не-характеристики
            if key in ['дата', 'date', 'номер', 'number', 'страница', 'page']:
                continue
            
            # Нормализуем ключ
            normalized_key = self._normalize_key(key)
            
            characteristic = {
                "key": normalized_key,
                "value": value,
                "unit": self._normalize_unit(unit) if unit else None,
                "operator": "=",
                "source": "file"
            }
            
            # Проверяем, нет ли уже такой характеристики
            if not any(c["key"] == normalized_key for c in result["characteristics"]):
                result["characteristics"].append(characteristic)
        
        # Если не нашли характеристик, добавляем предупреждение
        if not result["characteristics"]:
            result["warnings"].append("Не удалось извлечь характеристики из файла")
        
        return result
    
    def _normalize_key(self, key: str) -> str:
        """Нормализует ключ характеристики"""
        key = key.lower().strip()
        
        # Маппинг синонимов
        synonyms = {
            'озу': 'ram',
            'оперативная память': 'ram',
            'память': 'ram',
            'жесткий диск': 'storage',
            'накопитель': 'storage',
            'процессор': 'cpu',
            'цп': 'cpu',
            'экран': 'screen_size',
            'дисплей': 'screen_size',
            'вес': 'weight',
            'цвет': 'color',
            'материал': 'material',
            'габариты': 'dimensions',
            'размер': 'size',
            'мощность': 'power',
            'напряжение': 'voltage',
            'частота': 'frequency',
            'скорость': 'speed',
            'емкость': 'capacity',
            'объем': 'volume',
            'длина': 'length',
            'ширина': 'width',
            'высота': 'height',
            'глубина': 'depth',
            'диаметр': 'diameter',
            'толщина': 'thickness',
        }
        
        return synonyms.get(key, key)
    
    def _normalize_unit(self, unit: str) -> str:
        """Нормализует единицу измерения"""
        if not unit:
            return None
        
        unit = unit.strip()
        return self.unit_mapping.get(unit, unit)
    
    def _normalize_operator(self, operator: str) -> str:
        """Нормализует оператор сравнения"""
        if not operator:
            return "="
        
        operator = operator.strip()
        return self.operator_mapping.get(operator, "=")
