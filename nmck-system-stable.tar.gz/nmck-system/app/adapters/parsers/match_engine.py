import re
from typing import Dict, List, Any, Tuple, Optional
from difflib import SequenceMatcher


class MatchEngine:
    """Движок для сопоставления характеристик"""
    
    def __init__(self):
        # Словарь для нормализации ключей
        self.key_normalization = {
            "озу": "ram",
            "оперативная память": "ram",
            "ram": "ram",
            "память": "ram",
            "объем памяти": "ram",
            "ssd": "ssd_capacity",
            "жесткий диск": "hdd_capacity",
            "hdd": "hdd_capacity",
            "накопитель": "storage",
            "процессор": "cpu",
            "cpu": "cpu",
            "частота процессора": "cpu_frequency",
            "частота": "frequency",
            "тактовая частота": "frequency",
            "диагональ": "screen_size",
            "экран": "screen_size",
            "размер экрана": "screen_size",
            "разрешение": "resolution",
            "операционная система": "os",
            "os": "os",
            "система": "os",
            "вес": "weight",
            "масса": "weight",
            "габариты": "dimensions",
            "размеры": "dimensions",
            "цвет": "color",
            "материал": "material",
            "производитель": "vendor",
            "вендор": "vendor",
            "бренд": "vendor",
            "изготовитель": "vendor",
            "модель": "model",
            "артикул": "article",
            "код": "code",
            "тип": "type",
            "мощность": "power",
            "напряжение": "voltage",
            "емкость": "capacity",
            "скорость": "speed",
            "длина": "length",
            "ширина": "width",
            "высота": "height",
            "глубина": "depth",
            "толщина": "thickness",
        }
        
        # Словарь для нормализации единиц измерения
        self.unit_normalization = {
            "гб": "gb",
            "gb": "gb",
            "гигабайт": "gb",
            "гигабайта": "gb",
            "гигабайтов": "gb",
            "мб": "mb",
            "mb": "mb",
            "мегабайт": "mb",
            "мегабайта": "mb",
            "мегабайтов": "mb",
            "кг": "kg",
            "kg": "kg",
            "килограмм": "kg",
            "килограмма": "kg",
            "килограммов": "kg",
            "г": "g",
            "g": "g",
            "грамм": "g",
            "грамма": "g",
            "граммов": "g",
            "см": "cm",
            "cm": "cm",
            "сантиметр": "cm",
            "сантиметра": "cm",
            "сантиметров": "cm",
            "мм": "mm",
            "mm": "mm",
            "миллиметр": "mm",
            "миллиметра": "mm",
            "миллиметров": "mm",
            "дюйм": "inch",
            "inch": "inch",
            '"': "inch",
            "дюйма": "inch",
            "дюймов": "inch",
            "гц": "hz",
            "hz": "hz",
            "герц": "hz",
            "герца": "hz",
            "герц": "hz",
            "кгц": "khz",
            "khz": "khz",
            "килогерц": "khz",
            "килогерца": "khz",
            "мгц": "mhz",
            "mhz": "mhz",
            "мегагерц": "mhz",
            "мегагерца": "mhz",
            "ггц": "ghz",
            "ghz": "ghz",
            "гигагерц": "ghz",
            "гигагерца": "ghz",
            "в": "v",
            "v": "v",
            "вольт": "v",
            "вольта": "v",
            "вт": "w",
            "w": "w",
            "ватт": "w",
            "ватта": "w",
            "квт": "kw",
            "kw": "kw",
            "киловатт": "kw",
            "киловатта": "kw",
            "л": "l",
            "l": "l",
            "литр": "l",
            "литра": "l",
            "литров": "l",
            "мл": "ml",
            "ml": "ml",
            "миллилитр": "ml",
            "миллилитра": "ml",
        }
        
        # Ключи, которые считаются обязательными
        self.mandatory_keys = {"ram", "cpu", "screen_size", "vendor"}
        
        # Ключи, которые считаются важными
        self.important_keys = {"ssd_capacity", "hdd_capacity", "os", "resolution"}
        
        # Допустимые отклонения для числовых значений (в процентах)
        self.numeric_tolerance = {
            "ram": 10,  # ±10% для ОЗУ
            "ssd_capacity": 20,  # ±20% для SSD
            "hdd_capacity": 20,  # ±20% для HDD
            "cpu_frequency": 5,  # ±5% для частоты процессора
            "screen_size": 5,  # ±5% для диагонали экрана
            "weight": 15,  # ±15% для веса
        }
    
    async def compare_characteristics(
        self,
        requirements: Dict[str, Any],
        contract_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Сравнить требования с характеристиками контракта"""
        
        # Извлекаем характеристики из требований
        req_chars = requirements.get("characteristics", [])
        req_vendor = requirements.get("vendor")
        
        # Извлекаем характеристики из контракта
        contract_chars = contract_data.get("characteristics", [])
        contract_vendor = contract_data.get("vendor")
        
        # Нормализуем характеристики
        normalized_req = self._normalize_characteristics(req_chars)
        normalized_contract = self._normalize_characteristics(contract_chars)
        
        # Сравниваем характеристики
        match_results = []
        total_score = 0
        max_score = 0
        
        for req_key, req_data in normalized_req.items():
            max_score += self._get_key_weight(req_key)
            
            if req_key in normalized_contract:
                contract_data = normalized_contract[req_key]
                match_result = self._compare_single_characteristic(req_data, contract_data)
                match_results.append(match_result)
                
                if match_result["match"]:
                    total_score += self._get_key_weight(req_key) * match_result["score"]
            else:
                # Характеристика не найдена в контракте
                match_results.append({
                    "key": req_key,
                    "expected": req_data,
                    "found": None,
                    "match": False,
                    "score": 0,
                    "reason": "Характеристика не найдена",
                })
        
        # Рассчитываем процент совпадения
        match_percent = int((total_score / max_score * 100)) if max_score > 0 else 0
        
        # Проверяем совпадение вендора
        vendor_match = self._compare_vendors(req_vendor, contract_vendor)
        
        # Формируем лог сверки
        audit_log = self._create_audit_log(match_results, vendor_match, req_vendor, contract_vendor)
        
        return {
            "match_percent": match_percent,
            "vendor_match": vendor_match,
            "audit_log": audit_log,
            "details": {
                "total_characteristics": len(normalized_req),
                "matched_characteristics": len([r for r in match_results if r["match"]]),
                "vendor_status": "match" if vendor_match else "mismatch",
            },
        }
    
    def _normalize_characteristics(self, characteristics: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """Нормализовать список характеристик"""
        
        normalized = {}
        
        for char in characteristics:
            key = char.get("key", "").lower().strip()
            value = char.get("value", "").strip()
            unit = char.get("unit", "").lower().strip() if char.get("unit") else None
            operator = char.get("operator", "=")
            
            # Нормализуем ключ
            normalized_key = self._normalize_key(key)
            
            # Нормализуем значение
            normalized_value, normalized_unit = self._normalize_value(value, unit)
            
            if normalized_key:
                normalized[normalized_key] = {
                    "original_key": key,
                    "original_value": value,
                    "value": normalized_value,
                    "unit": normalized_unit,
                    "operator": operator,
                    "is_numeric": self._is_numeric(normalized_value),
                }
        
        return normalized
    
    def _normalize_key(self, key: str) -> str:
        """Нормализовать ключ характеристики"""
        
        # Удаляем лишние символы
        key = re.sub(r'[^\w\s]', ' ', key)
        key = ' '.join(key.split())  # Удаляем лишние пробелы
        
        # Ищем совпадение в словаре нормализации
        for pattern, normalized in self.key_normalization.items():
            if pattern in key.lower():
                return normalized
        
        # Если не нашли, возвращаем исходный ключ
        return key.lower()
    
    def _normalize_value(self, value: str, unit: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
        """Нормализовать значение и единицу измерения"""
        
        # Если значение пустое
        if not value:
            return None, None
        
        # Пытаемся извлечь число
        number_match = re.search(r'[\d.,]+', value.replace(' ', ''))
        if not number_match:
            return value, unit
        
        number_str = number_match.group().replace(',', '.')
        
        # Пытаемся преобразовать в число
        try:
            if '.' in number_str:
                number = float(number_str)
            else:
                number = int(number_str)
        except ValueError:
            return value, unit
        
        # Если единица измерения не указана, пытаемся извлечь из значения
        if not unit:
            unit_match = re.search(r'[a-zA-Zа-яА-Я°"\'″]+', value.lower())
            if unit_match:
                extracted_unit = unit_match.group()
                # Нормализуем единицу измерения
                unit = self._normalize_unit(extracted_unit)
        
        # Нормализуем единицу измерения, если она указана
        if unit:
            unit = self._normalize_unit(unit)
        
        return str(number), unit
    
    def _normalize_unit(self, unit: str) -> str:
        """Нормализовать единицу измерения"""
        
        unit_lower = unit.lower().strip()
        
        for pattern, normalized in self.unit_normalization.items():
            if pattern == unit_lower or f" {pattern} " in f" {unit_lower} ":
                return normalized
        
        return unit_lower
    
    def _is_numeric(self, value: str) -> bool:
        """Проверить, является ли значение числовым"""
        
        try:
            float(value)
            return True
        except (ValueError, TypeError):
            return False
    
    def _compare_single_characteristic(
        self,
        req_data: Dict[str, Any],
        contract_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Сравнить одну характеристику"""
        
        req_value = req_data["value"]
        contract_value = contract_data["value"]
        operator = req_data.get("operator", "=")
        
        # Если значения текстовые
        if not req_data["is_numeric"]:
            similarity = SequenceMatcher(None, req_value.lower(), contract_value.lower()).ratio()
            match = similarity > 0.8  # Порог схожести 80%
            
            return {
                "key": req_data["original_key"],
                "expected": req_value,
                "found": contract_value,
                "match": match,
                "score": similarity,
                "reason": None if match else "Текстовые значения не совпадают",
            }
        
        # Если значения числовые
        try:
            req_num = float(req_value)
            contract_num = float(contract_value)
            
            # Проверяем по оператору
            if operator == "=":
                tolerance = self.numeric_tolerance.get(req_data["original_key"], 0)
                diff_percent = abs(req_num - contract_num) / req_num * 100 if req_num > 0 else 100
                match = diff_percent <= tolerance
                score = 1 - (diff_percent / 100) if diff_percent <= 100 else 0
                
            elif operator == ">=":
                match = contract_num >= req_num
                score = 1.0 if match else 0.0
                
            elif operator == "<=":
                match = contract_num <= req_num
                score = 1.0 if match else 0.0
                
            elif operator == ">":
                match = contract_num > req_num
                score = 1.0 if match else 0.0
                
            elif operator == "<":
                match = contract_num < req_num
                score = 1.0 if match else 0.0
                
            else:
                match = False
                score = 0.0
            
            return {
                "key": req_data["original_key"],
                "expected": f"{req_value} {req_data.get('unit', '')}",
                "found": f"{contract_value} {contract_data.get('unit', '')}",
                "match": match,
                "score": score,
                "reason": None if match else f"Числовое значение не соответствует оператору {operator}",
            }
            
        except (ValueError, TypeError):
            return {
                "key": req_data["original_key"],
                "expected": req_value,
                "found": contract_value,
                "match": False,
                "score": 0,
                "reason": "Ошибка при сравнении числовых значений",
            }
    
    def _compare_vendors(self, req_vendor: Optional[str], contract_vendor: Optional[str]) -> bool:
        """Сравнить вендоров"""
        
        if not req_vendor or not contract_vendor:
            return True  # Если вендор не указан в требованиях, считаем совпадением
        
        req_vendor_lower = req_vendor.lower()
        contract_vendor_lower = contract_vendor.lower()
        
        # Простое сравнение строк
        if req_vendor_lower == contract_vendor_lower:
            return True
        
        # Проверяем частичное совпадение
        if req_vendor_lower in contract_vendor_lower or contract_vendor_lower in req_vendor_lower:
            return True
        
        # Проверяем схожесть
        similarity = SequenceMatcher(None, req_vendor_lower, contract_vendor_lower).ratio()
        return similarity > 0.7  # Порог схожести 70%
    
    def _get_key_weight(self, key: str) -> float:
        """Получить вес характеристики"""
        
        if key in self.mandatory_keys:
            return 2.0
        elif key in self.important_keys:
            return 1.5
        else:
            return 1.0
    
    def _create_audit_log(
        self,
        match_results: List[Dict[str, Any]],
        vendor_match: bool,
        req_vendor: Optional[str],
        contract_vendor: Optional[str],
    ) -> List[Dict[str, Any]]:
        """Создать лог сверки"""
        
        audit_log = []
        
        # Добавляем результаты сравнения характеристик
        for result in match_results:
            audit_log.append({
                "key": result["key"],
                "expected_value": result["expected"],
                "found_value": result["found"],
                "is_diff": not result["match"],
                "diff_reason": result.get("reason"),
            })
        
        # Добавляем сравнение вендоров
        audit_log.append({
            "key": "Производитель",
            "expected_value": req_vendor,
            "found_value": contract_vendor,
            "is_diff": not vendor_match,
            "diff_reason": None if vendor_match else "Производитель не совпадает",
        })
        
        return audit_log