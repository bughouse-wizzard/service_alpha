import io
import re
from typing import Tuple, List, Dict, Any, Optional
import pandas as pd
from docx import Document
import pdfplumber
from openpyxl import load_workbook


class FileParser:
    """Парсер файлов с требованиями"""
    
    def __init__(self):
        # Словарь для нормализации ключей характеристик
        self.key_normalization = {
            "озу": "ram",
            "оперативная память": "ram",
            "ram": "ram",
            "ssd": "ssd_capacity",
            "жесткий диск": "hdd_capacity",
            "hdd": "hdd_capacity",
            "процессор": "cpu",
            "cpu": "cpu",
            "частота процессора": "cpu_frequency",
            "частота": "frequency",
            "диагональ": "screen_size",
            "экран": "screen_size",
            "разрешение": "resolution",
            "операционная система": "os",
            "os": "os",
            "вес": "weight",
            "габариты": "dimensions",
            "цвет": "color",
            "материал": "material",
            "производитель": "vendor",
            "вендор": "vendor",
            "бренд": "vendor",
        }
        
        # Словарь для нормализации единиц измерения
        self.unit_normalization = {
            "гб": "gb",
            "gb": "gb",
            "гигабайт": "gb",
            "мб": "mb",
            "mb": "mb",
            "мегабайт": "mb",
            "кг": "kg",
            "kg": "kg",
            "килограмм": "kg",
            "г": "g",
            "g": "g",
            "грамм": "g",
            "см": "cm",
            "cm": "cm",
            "сантиметр": "cm",
            "мм": "mm",
            "mm": "mm",
            "миллиметр": "mm",
            "дюйм": "inch",
            "inch": "inch",
            '"': "inch",
            "гц": "hz",
            "hz": "hz",
            "герц": "hz",
            "кгц": "khz",
            "khz": "khz",
            "килогерц": "khz",
            "мгц": "mhz",
            "mhz": "mhz",
            "мегагерц": "mhz",
            "ггц": "ghz",
            "ghz": "ghz",
            "гигагерц": "ghz",
        }
    
    async def parse_file(
        self,
        file_content: bytes,
        filename: str,
        mime_type: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], List[str]]:
        """Разобрать файл и извлечь требования"""
        
        file_extension = filename.lower().split('.')[-1]
        warnings = []
        
        try:
            if file_extension == 'txt':
                return self._parse_txt(file_content, warnings)
            elif file_extension == 'xlsx':
                return self._parse_xlsx(file_content, warnings)
            elif file_extension == 'docx':
                return self._parse_docx(file_content, warnings)
            elif file_extension == 'pdf':
                return self._parse_pdf(file_content, warnings)
            else:
                warnings.append(f"Неподдерживаемый формат файла: {file_extension}")
                return {}, warnings
                
        except Exception as e:
            warnings.append(f"Ошибка при разборе файла: {str(e)}")
            return {}, warnings
    
    def _parse_txt(self, content: bytes, warnings: List[str]) -> Tuple[Dict[str, Any], List[str]]:
        """Разобрать TXT файл"""
        
        text = content.decode('utf-8', errors='ignore')
        lines = text.split('\n')
        
        detected = {
            "ktru_code": None,
            "name": None,
            "vendor": None,
            "characteristics": [],
        }
        
        # Поиск КТРУ кода
        ktru_pattern = r'\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8}\b'
        ktru_match = re.search(ktru_pattern, text)
        if ktru_match:
            detected["ktru_code"] = ktru_match.group()
        
        # Поиск характеристик в формате "ключ: значение"
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Проверяем, является ли строка названием товара
            if not detected["name"] and len(line) < 100 and not ':' in line:
                detected["name"] = line
                continue
            
            # Ищем характеристики
            if ':' in line:
                parts = line.split(':', 1)
                if len(parts) == 2:
                    key = parts[0].strip().lower()
                    value = parts[1].strip()
                    
                    # Нормализуем ключ
                    normalized_key = self._normalize_key(key)
                    if normalized_key == "vendor" and not detected["vendor"]:
                        detected["vendor"] = value
                        continue
                    
                    # Извлекаем значение, единицу измерения и оператор
                    norm_value, unit, operator = self._extract_value_unit_operator(value)
                    
                    if norm_value:
                        detected["characteristics"].append({
                            "key": normalized_key,
                            "value": norm_value,
                            "unit": unit,
                            "operator": operator,
                        })
        
        return detected, warnings
    
    def _parse_xlsx(self, content: bytes, warnings: List[str]) -> Tuple[Dict[str, Any], List[str]]:
        """Разобрать XLSX файл"""
        
        detected = {
            "ktru_code": None,
            "name": None,
            "vendor": None,
            "characteristics": [],
        }
        
        try:
            # Используем pandas для чтения Excel
            df = pd.read_excel(io.BytesIO(content), sheet_name=None, header=None)
            
            # Ищем данные в первом листе
            first_sheet = list(df.values())[0] if df else None
            
            if first_sheet is not None:
                # Преобразуем в список списков
                data = first_sheet.values.tolist()
                
                for row in data:
                    row_str = ' '.join([str(cell) for cell in row if pd.notna(cell)])
                    
                    # Поиск КТРУ кода
                    if not detected["ktru_code"]:
                        ktru_pattern = r'\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8}\b'
                        ktru_match = re.search(ktru_pattern, row_str)
                        if ktru_match:
                            detected["ktru_code"] = ktru_match.group()
                    
                    # Поиск названия товара
                    if not detected["name"] and len(row_str) < 100:
                        detected["name"] = row_str
                    
                    # Поиск характеристик
                    for cell in row:
                        if pd.notna(cell):
                            cell_str = str(cell)
                            if ':' in cell_str:
                                parts = cell_str.split(':', 1)
                                if len(parts) == 2:
                                    key = parts[0].strip().lower()
                                    value = parts[1].strip()
                                    
                                    normalized_key = self._normalize_key(key)
                                    if normalized_key == "vendor" and not detected["vendor"]:
                                        detected["vendor"] = value
                                        continue
                                    
                                    norm_value, unit, operator = self._extract_value_unit_operator(value)
                                    
                                    if norm_value:
                                        detected["characteristics"].append({
                                            "key": normalized_key,
                                            "value": norm_value,
                                            "unit": unit,
                                            "operator": operator,
                                        })
        
        except Exception as e:
            warnings.append(f"Ошибка при разборе XLSX: {str(e)}")
        
        return detected, warnings
    
    def _parse_docx(self, content: bytes, warnings: List[str]) -> Tuple[Dict[str, Any], List[str]]:
        """Разобрать DOCX файл"""
        
        detected = {
            "ktru_code": None,
            "name": None,
            "vendor": None,
            "characteristics": [],
        }
        
        try:
            doc = Document(io.BytesIO(content))
            full_text = []
            
            # Извлекаем текст из параграфов
            for para in doc.paragraphs:
                full_text.append(para.text)
            
            # Извлекаем текст из таблиц
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        full_text.append(cell.text)
            
            text = '\n'.join(full_text)
            
            # Поиск КТРУ кода
            ktru_pattern = r'\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8}\b'
            ktru_match = re.search(ktru_pattern, text)
            if ktru_match:
                detected["ktru_code"] = ktru_match.group()
            
            # Поиск характеристик
            lines = text.split('\n')
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                # Поиск названия товара
                if not detected["name"] and len(line) < 100 and not ':' in line:
                    detected["name"] = line
                    continue
                
                # Ищем характеристики
                if ':' in line:
                    parts = line.split(':', 1)
                    if len(parts) == 2:
                        key = parts[0].strip().lower()
                        value = parts[1].strip()
                        
                        normalized_key = self._normalize_key(key)
                        if normalized_key == "vendor" and not detected["vendor"]:
                            detected["vendor"] = value
                            continue
                        
                        norm_value, unit, operator = self._extract_value_unit_operator(value)
                        
                        if norm_value:
                            detected["characteristics"].append({
                                "key": normalized_key,
                                "value": norm_value,
                                "unit": unit,
                                "operator": operator,
                            })
        
        except Exception as e:
            warnings.append(f"Ошибка при разборе DOCX: {str(e)}")
        
        return detected, warnings
    
    def _parse_pdf(self, content: bytes, warnings: List[str]) -> Tuple[Dict[str, Any], List[str]]:
        """Разобрать PDF файл (только текстовые PDF)"""
        
        detected = {
            "ktru_code": None,
            "name": None,
            "vendor": None,
            "characteristics": [],
        }
        
        try:
            with pdfplumber.open(io.BytesIO(content)) as pdf:
                text = ""
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
                
                if not text.strip():
                    warnings.append("PDF файл не содержит извлекаемого текста (возможно, это скан)")
                    return detected, warnings
                
                # Поиск КТРУ кода
                ktru_pattern = r'\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8}\b'
                ktru_match = re.search(ktru_pattern, text)
                if ktru_match:
                    detected["ktru_code"] = ktru_match.group()
                
                # Поиск характеристик
                lines = text.split('\n')
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue
                    
                    # Поиск названия товара
                    if not detected["name"] and len(line) < 100 and not ':' in line:
                        detected["name"] = line
                        continue
                    
                    # Ищем характеристики
                    if ':' in line:
                        parts = line.split(':', 1)
                        if len(parts) == 2:
                            key = parts[0].strip().lower()
                            value = parts[1].strip()
                            
                            normalized_key = self._normalize_key(key)
                            if normalized_key == "vendor" and not detected["vendor"]:
                                detected["vendor"] = value
                                continue
                            
                            norm_value, unit, operator = self._extract_value_unit_operator(value)
                            
                            if norm_value:
                                detected["characteristics"].append({
                                    "key": normalized_key,
                                    "value": norm_value,
                                    "unit": unit,
                                    "operator": operator,
                                })
        
        except Exception as e:
            warnings.append(f"Ошибка при разборе PDF: {str(e)}")
        
        return detected, warnings
    
    def _normalize_key(self, key: str) -> str:
        """Нормализовать ключ характеристики"""
        key_lower = key.lower()
        for pattern, normalized in self.key_normalization.items():
            if pattern in key_lower:
                return normalized
        return key_lower
    
    def _extract_value_unit_operator(self, value_str: str) -> Tuple[Optional[str], Optional[str], str]:
        """Извлечь значение, единицу измерения и оператор из строки"""
        
        # Определяем оператор
        operator = "="
        if ">=" in value_str:
            operator = ">="
            value_str = value_str.replace(">=", "").strip()
        elif "<=" in value_str:
            operator = "<="
            value_str = value_str.replace("<=", "").strip()
        elif ">" in value_str:
            operator = ">"
            value_str = value_str.replace(">", "").strip()
        elif "<" in value_str:
            operator = "<"
            value_str = value_str.replace("<", "").strip()
        elif "~" in value_str:
            operator = "~"
            value_str = value_str.replace("~", "").strip()
        
        # Ищем числовое значение
        number_match = re.search(r'[\d.,]+', value_str)
        if not number_match:
            return None, None, operator
        
        number_str = number_match.group().replace(',', '.')
        
        # Пытаемся преобразовать в число
        try:
            if '.' in number_str:
                number = float(number_str)
            else:
                number = int(number_str)
        except ValueError:
            return None, None, operator
        
        # Ищем единицу измерения
        unit = None
        for unit_pattern, normalized_unit in self.unit_normalization.items():
            if re.search(rf'\b{re.escape(unit_pattern)}\b', value_str.lower()):
                unit = normalized_unit
                break
        
        return str(number), unit, operator