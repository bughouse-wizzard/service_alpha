"""
Движок сопоставления характеристик
"""
import re
from typing import Dict, List, Tuple, Optional
from enum import Enum

class MatchType(str, Enum):
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    DIFFERENT = "different"

class VendorStatus(str, Enum):
    MATCH = "match"
    MISMATCH = "mismatch"
    UNKNOWN = "unknown"

class MatchEngine:
    """Движок для сопоставления характеристик"""
    
    # Словарь синонимов для нормализации ключей
    KEY_SYNONYMS = {
        "ram": ["ram", "озу", "оперативная память", "memory"],
        "ssd": ["ssd", "жесткий диск", "hdd", "storage", "накопитель"],
        "processor": ["processor", "процессор", "cpu"],
        "screen_size": ["screen_size", "размер экрана", "диагональ"],
        "vendor": ["vendor", "производитель", "manufacturer", "бренд"]
    }
    
    # Словарь единиц измерения
    UNIT_CONVERSIONS = {
        "gb": ["gb", "гб", "гигабайт"],
        "mb": ["mb", "мб", "мегабайт"],
        "ghz": ["ghz", "ггц", "гигагерц"],
        "mhz": ["mhz", "мгц", "мегагерц"],
        "inch": ["inch", "дюйм", "дюймов"],
        "mm": ["mm", "мм", "миллиметр"]
    }
    
    def __init__(self):
        self._build_reverse_maps()
    
    def _build_reverse_maps(self):
        """Построить обратные карты для быстрого поиска"""
        self._key_to_canonical = {}
        for canonical, synonyms in self.KEY_SYNONYMS.items():
            for synonym in synonyms:
                self._key_to_canonical[synonym.lower()] = canonical
        
        self._unit_to_canonical = {}
        for canonical, synonyms in self.UNIT_CONVERSIONS.items():
            for synonym in synonyms:
                self._unit_to_canonical[synonym.lower()] = canonical
    
    def normalize_key(self, key: str) -> str:
        """Нормализовать ключ характеристики"""
        key_lower = key.lower().strip()
        return self._key_to_canonical.get(key_lower, key_lower)
    
    def normalize_unit(self, unit: str) -> str:
        """Нормализовать единицу измерения"""
        if not unit:
            return ""
        unit_lower = unit.lower().strip()
        return self._unit_to_canonical.get(unit_lower, unit_lower)
    
    def normalize_value(self, value: str) -> Tuple[float, str, str]:
        """
        Нормализовать значение характеристики.
        
        Returns:
            (числовое значение, единица измерения, оператор)
        """
        if not value:
            return 0.0, "", "="
        
        # Извлекаем оператор
        operator = "="
        value_str = str(value).strip()
        
        if value_str.startswith(">="):
            operator = ">="
            value_str = value_str[2:].strip()
        elif value_str.startswith("<="):
            operator = "<="
            value_str = value_str[2:].strip()
        elif value_str.startswith(">"):
            operator = ">"
            value_str = value_str[1:].strip()
        elif value_str.startswith("<"):
            operator = "<"
            value_str = value_str[1:].strip()
        elif value_str.startswith("="):
            value_str = value_str[1:].strip()
        
        # Извлекаем числовое значение и единицу измерения
        match = re.match(r"([\d\.]+)\s*([a-zA-Zа-яА-Я]+)?", value_str)
        if match:
            num_value = float(match.group(1))
            unit = match.group(2) or ""
            unit_norm = self.normalize_unit(unit)
            return num_value, unit_norm, operator
        
        # Если не удалось извлечь число, возвращаем как строку
        return 0.0, "", operator
    
    def compare_values(self, expected: str, found: str, key: str) -> Tuple[bool, int, str]:
        """
        Сравнить значения характеристик.
        
        Args:
            expected: Ожидаемое значение
            found: Найденное значение
            key: Ключ характеристики
            
        Returns:
            (совпадает ли, процент совпадения, причина различия)
        """
        if not expected and not found:
            return True, 100, ""
        
        if not expected or not found:
            return False, 0, "Отсутствует значение"
        
        # Нормализуем значения
        exp_num, exp_unit, exp_op = self.normalize_value(expected)
        found_num, found_unit, _ = self.normalize_value(found)
        
        # Проверяем единицы измерения
        if exp_unit and found_unit and exp_unit != found_unit:
            return False, 0, f"Разные единицы измерения: {exp_unit} vs {found_unit}"
        
        # Сравниваем значения в зависимости от оператора
        if exp_op == "=":
            if abs(exp_num - found_num) < 0.01:  # Погрешность для float
                return True, 100, ""
            else:
                diff_percent = min(100, max(0, 100 - abs(exp_num - found_num) / exp_num * 100))
                return False, int(diff_percent), f"Значения отличаются: {expected} vs {found}"
        
        elif exp_op == ">=":
            if found_num >= exp_num:
                return True, 100, ""
            else:
                diff_percent = min(100, max(0, found_num / exp_num * 100))
                return False, int(diff_percent), f"Найдено меньше требуемого: {found} < {expected}"
        
        elif exp_op == "<=":
            if found_num <= exp_num:
                return True, 100, ""
            else:
                diff_percent = min(100, max(0, exp_num / found_num * 100))
                return False, int(diff_percent), f"Найдено больше требуемого: {found} > {expected}"
        
        elif exp_op == ">":
            if found_num > exp_num:
                return True, 100, ""
            else:
                diff_percent = min(100, max(0, found_num / exp_num * 100))
                return False, int(diff_percent), f"Найдено меньше или равно требуемого: {found} <= {expected}"
        
        elif exp_op == "<":
            if found_num < exp_num:
                return True, 100, ""
            else:
                diff_percent = min(100, max(0, exp_num / found_num * 100))
                return False, int(diff_percent), f"Найдено больше или равно требуемого: {found} >= {expected}"
        
        # Для строковых значений
        if expected.lower() == found.lower():
            return True, 100, ""
        else:
            # Простая проверка на частичное совпадение
            if expected.lower() in found.lower() or found.lower() in expected.lower():
                return False, 50, f"Частичное совпадение: {expected} vs {found}"
            return False, 0, f"Значения отличаются: {expected} vs {found}"
    
    def compare_vendor(self, expected_vendor: str, found_vendor: str) -> VendorStatus:
        """Сравнить производителей"""
        if not expected_vendor or not found_vendor:
            return VendorStatus.UNKNOWN
        
        exp_norm = expected_vendor.lower().strip()
        found_norm = found_vendor.lower().strip()
        
        if exp_norm == found_norm:
            return VendorStatus.MATCH
        
        # Проверяем частичное совпадение (например, "Dell Inc." и "Dell")
        if exp_norm in found_norm or found_norm in exp_norm:
            return VendorStatus.MATCH
        
        return VendorStatus.MISMATCH
    
    def calculate_match(self, expected: Dict[str, str], found: Dict[str, str], expected_vendor: Optional[str] = None, found_vendor: Optional[str] = None) -> Tuple[int, MatchType, List[Dict]]:
        """
        Рассчитать совпадение характеристик.
        
        Args:
            expected: Ожидаемые характеристики {ключ: значение}
            found: Найденные характеристики {ключ: значение}
            expected_vendor: Ожидаемый производитель
            found_vendor: Найденный производитель
            
        Returns:
            (процент совпадения, тип совпадения, лог сверки)
        """
        if not expected:
            return 0, MatchType.DIFFERENT, []
        
        # Нормализуем ключи
        exp_norm = {self.normalize_key(k): v for k, v in expected.items()}
        found_norm = {self.normalize_key(k): v for k, v in found.items()}
        
        audit_log = []
        matched_count = 0
        total_count = len(exp_norm)
        
        # Сравниваем характеристики
        for key, exp_value in exp_norm.items():
            found_value = found_norm.get(key)
            
            if found_value:
                matches, percent, reason = self.compare_values(exp_value, found_value, key)
                is_diff = not matches
                
                audit_log.append({
                    "key": key,
                    "expected_value": exp_value,
                    "found_value": found_value,
                    "is_diff": is_diff,
                    "diff_reason": reason if is_diff else None,
                    "match_percent": percent
                })
                
                if matches:
                    matched_count += 1
                elif percent >= 80:  # Порог для однородных совпадений
                    matched_count += 0.5  # Половина очка за частичное совпадение
            else:
                audit_log.append({
                    "key": key,
                    "expected_value": exp_value,
                    "found_value": None,
                    "is_diff": True,
                    "diff_reason": "Характеристика не найдена",
                    "match_percent": 0
                })
        
        # Рассчитываем процент совпадения
        match_percent = int((matched_count / total_count) * 100) if total_count > 0 else 0
        
        # Определяем тип совпадения
        if match_percent == 100:
            match_type = MatchType.IDENTICAL
        elif match_percent >= 70:
            match_type = MatchType.HOMOGENEOUS
        else:
            match_type = MatchType.DIFFERENT
        
        # Добавляем проверку производителя в лог
        if expected_vendor or found_vendor:
            vendor_status = self.compare_vendor(expected_vendor, found_vendor)
            audit_log.append({
                "key": "vendor",
                "expected_value": expected_vendor,
                "found_value": found_vendor,
                "is_diff": vendor_status == VendorStatus.MISMATCH,
                "diff_reason": "Производитель отличается" if vendor_status == VendorStatus.MISMATCH else None,
                "match_percent": 100 if vendor_status == VendorStatus.MATCH else 0
            })
        
        return match_percent, match_type, audit_log