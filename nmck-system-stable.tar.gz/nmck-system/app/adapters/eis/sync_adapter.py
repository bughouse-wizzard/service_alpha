"""
Адаптер для использования асинхронного парсера ЕИС в синхронном коде
"""
import asyncio
from typing import List, Dict, Any, Optional
from datetime import datetime
from .parser_with_retry import EISParserWithRetry


class SyncEISParser:
    """Синхронная обертка над асинхронным парсером ЕИС"""
    
    def __init__(self, region: str = "Северо-Западный ФО", law_type: str = "44-ФЗ"):
        self.region = region
        self.law_type = law_type
        self._parser = EISParserWithRetry(max_concurrent=3, max_retries=3)
        self._loop = None
    
    def _get_event_loop(self):
        """Получить или создать event loop"""
        try:
            return asyncio.get_event_loop()
        except RuntimeError:
            # Если нет текущего loop (в потоке), создаем новый
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop
    
    def search_contracts(self, ktru_code: str, product_name: str, 
                        period_from: datetime, period_to: datetime) -> List[Dict[str, Any]]:
        """
        Синхронный поиск контрактов
        
        Args:
            ktru_code: Код КТРУ
            product_name: Наименование товара
            period_from: Начало периода
            period_to: Конец периода
            
        Returns:
            Список контрактов
        """
        loop = self._get_event_loop()
        
        # Запускаем асинхронную функцию в синхронном контексте
        return loop.run_until_complete(
            self._parser.search_contracts(
                ktru_code=ktru_code,
                product_name=product_name,
                region=self.region,
                period_from=period_from,
                period_to=period_to,
                law_type=self.law_type,
                max_results=50  # Ограничиваем для MVP
            )
        )
    
    def extract_characteristics(self, contract_url: str) -> Dict[str, Any]:
        """
        Синхронное извлечение характеристик из контракта
        
        Args:
            contract_url: URL контракта
            
        Returns:
            Характеристики контракта
        """
        loop = self._get_event_loop()
        
        # Получаем детали контракта
        contract_details = loop.run_until_complete(
            self._parser.get_contract_details(contract_url)
        )
        
        # Извлекаем характеристики из деталей
        characteristics = contract_details.get("characteristics", [])
        
        # Преобразуем в формат, ожидаемый системой
        result = {}
        for char in characteristics:
            key = char.get("key", "").lower()
            value = char.get("value", "")
            if key and value:
                result[key] = value
        
        return result
    
    def get_contract_vendor(self, contract_url: str) -> str:
        """
        Получить вендора/производителя из контракта
        
        Args:
            contract_url: URL контракта
            
        Returns:
            Наименование вендора
        """
        loop = self._get_event_loop()
        
        contract_details = loop.run_until_complete(
            self._parser.get_contract_details(contract_url)
        )
        
        return contract_details.get("vendor", "")
    
    def close(self):
        """Закрыть соединения"""
        loop = self._get_event_loop()
        loop.run_until_complete(self._parser.close())