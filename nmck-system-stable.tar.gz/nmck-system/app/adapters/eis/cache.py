"""
Кэширование результатов парсинга ЕИС
"""
import json
import hashlib
from typing import Any, Optional
from datetime import datetime, timedelta
import redis
import pickle


class EISCache:
    """Кэш для результатов парсинга ЕИС"""
    
    def __init__(self, redis_url: str = "redis://localhost:6379/0", default_ttl: int = 3600):
        """
        Инициализация кэша
        
        Args:
            redis_url: URL Redis сервера
            default_ttl: Время жизни кэша по умолчанию (в секундах)
        """
        self.redis_url = redis_url
        self.default_ttl = default_ttl
        self._redis = None
    
    @property
    def redis(self) -> redis.Redis:
        """Ленивая инициализация Redis клиента"""
        if self._redis is None:
            try:
                self._redis = redis.from_url(self.redis_url, decode_responses=False)
                # Проверяем соединение
                self._redis.ping()
            except Exception as e:
                print(f"Ошибка подключения к Redis: {e}")
                # Создаем заглушку для работы без Redis
                self._redis = None
        return self._redis
    
    def _generate_key(self, prefix: str, *args) -> str:
        """Генерация ключа кэша"""
        key_str = ":".join(str(arg) for arg in args)
        key_hash = hashlib.md5(key_str.encode()).hexdigest()
        return f"eis:{prefix}:{key_hash}"
    
    def cache_search_results(self, search_params: dict, results: list, ttl: Optional[int] = None) -> bool:
        """
        Кэширование результатов поиска
        
        Args:
            search_params: Параметры поиска
            results: Результаты поиска
            ttl: Время жизни кэша (в секундах)
            
        Returns:
            True если успешно, False если ошибка
        """
        if not self.redis:
            return False
        
        try:
            key = self._generate_key("search", json.dumps(search_params, sort_keys=True))
            value = pickle.dumps({
                "results": results,
                "cached_at": datetime.utcnow().isoformat(),
                "params": search_params,
            })
            
            ttl = ttl or self.default_ttl
            self.redis.setex(key, ttl, value)
            return True
            
        except Exception as e:
            print(f"Ошибка кэширования результатов поиска: {e}")
            return False
    
    def get_cached_search_results(self, search_params: dict) -> Optional[list]:
        """
        Получение кэшированных результатов поиска
        
        Args:
            search_params: Параметры поиска
            
        Returns:
            Результаты поиска или None если нет в кэше
        """
        if not self.redis:
            return None
        
        try:
            key = self._generate_key("search", json.dumps(search_params, sort_keys=True))
            cached_data = self.redis.get(key)
            
            if cached_data:
                data = pickle.loads(cached_data)
                # Проверяем актуальность (не старше 1 дня)
                cached_at = datetime.fromisoformat(data["cached_at"])
                if datetime.utcnow() - cached_at < timedelta(days=1):
                    return data["results"]
            
        except Exception as e:
            print(f"Ошибка получения кэшированных результатов: {e}")
        
        return None
    
    def cache_contract_details(self, contract_url: str, details: dict, ttl: Optional[int] = None) -> bool:
        """
        Кэширование деталей контракта
        
        Args:
            contract_url: URL контракта
            details: Детали контракта
            ttl: Время жизни кэша (в секундах)
            
        Returns:
            True если успешно, False если ошибка
        """
        if not self.redis:
            return False
        
        try:
            key = self._generate_key("contract", contract_url)
            value = pickle.dumps({
                "details": details,
                "cached_at": datetime.utcnow().isoformat(),
                "url": contract_url,
            })
            
            ttl = ttl or (self.default_ttl * 24)  # Для контрактов кэшируем дольше
            self.redis.setex(key, ttl, value)
            return True
            
        except Exception as e:
            print(f"Ошибка кэширования деталей контракта: {e}")
            return False
    
    def get_cached_contract_details(self, contract_url: str) -> Optional[dict]:
        """
        Получение кэшированных деталей контракта
        
        Args:
            contract_url: URL контракта
            
        Returns:
            Детали контракта или None если нет в кэше
        """
        if not self.redis:
            return None
        
        try:
            key = self._generate_key("contract", contract_url)
            cached_data = self.redis.get(key)
            
            if cached_data:
                data = pickle.loads(cached_data)
                # Проверяем актуальность (не старше 7 дней)
                cached_at = datetime.fromisoformat(data["cached_at"])
                if datetime.utcnow() - cached_at < timedelta(days=7):
                    return data["details"]
            
        except Exception as e:
            print(f"Ошибка получения кэшированных деталей контракта: {e}")
        
        return None
    
    def cache_specification(self, contract_url: str, specification: str, ttl: Optional[int] = None) -> bool:
        """
        Кэширование спецификации контракта
        
        Args:
            contract_url: URL контракта
            specification: Спецификация (HTML/текст)
            ttl: Время жизни кэша (в секундах)
            
        Returns:
            True если успешно, False если ошибка
        """
        if not self.redis:
            return False
        
        try:
            key = self._generate_key("spec", contract_url)
            value = pickle.dumps({
                "specification": specification,
                "cached_at": datetime.utcnow().isoformat(),
                "url": contract_url,
            })
            
            ttl = ttl or (self.default_ttl * 24)
            self.redis.setex(key, ttl, value)
            return True
            
        except Exception as e:
            print(f"Ошибка кэширования спецификации: {e}")
            return False
    
    def get_cached_specification(self, contract_url: str) -> Optional[str]:
        """
        Получение кэшированной спецификации
        
        Args:
            contract_url: URL контракта
            
        Returns:
            Спецификация или None если нет в кэше
        """
        if not self.redis:
            return None
        
        try:
            key = self._generate_key("spec", contract_url)
            cached_data = self.redis.get(key)
            
            if cached_data:
                data = pickle.loads(cached_data)
                # Проверяем актуальность (не старше 7 дней)
                cached_at = datetime.fromisoformat(data["cached_at"])
                if datetime.utcnow() - cached_at < timedelta(days=7):
                    return data["specification"]
            
        except Exception as e:
            print(f"Ошибка получения кэшированной спецификации: {e}")
        
        return None
    
    def invalidate_search_cache(self, search_params: dict) -> bool:
        """
        Инвалидация кэша поиска
        
        Args:
            search_params: Параметры поиска
            
        Returns:
            True если успешно, False если ошибка
        """
        if not self.redis:
            return False
        
        try:
            key = self._generate_key("search", json.dumps(search_params, sort_keys=True))
            self.redis.delete(key)
            return True
            
        except Exception as e:
            print(f"Ошибка инвалидации кэша поиска: {e}")
            return False
    
    def invalidate_contract_cache(self, contract_url: str) -> bool:
        """
        Инвалидация кэша контракта
        
        Args:
            contract_url: URL контракта
            
        Returns:
            True если успешно, False если ошибка
        """
        if not self.redis:
            return False
        
        try:
            # Удаляем все кэши связанные с контрактом
            patterns = [
                self._generate_key("contract", contract_url),
                self._generate_key("spec", contract_url),
            ]
            
            for pattern in patterns:
                self.redis.delete(pattern)
            
            return True
            
        except Exception as e:
            print(f"Ошибка инвалидации кэша контракта: {e}")
            return False
    
    def clear_all_cache(self) -> bool:
        """
        Очистка всего кэша
        
        Returns:
            True если успешно, False если ошибка
        """
        if not self.redis:
            return False
        
        try:
            # Удаляем все ключи с префиксом eis:
            keys = self.redis.keys("eis:*")
            if keys:
                self.redis.delete(*keys)
            return True
            
        except Exception as e:
            print(f"Ошибка очистки кэша: {e}")
            return False
    
    def get_cache_stats(self) -> dict:
        """
        Получение статистики кэша
        
        Returns:
            Словарь со статистикой
        """
        if not self.redis:
            return {"error": "Redis не доступен"}
        
        try:
            stats = {
                "total_keys": 0,
                "search_keys": 0,
                "contract_keys": 0,
                "spec_keys": 0,
            }
            
            # Считаем ключи по типам
            for key_type in ["search", "contract", "spec"]:
                pattern = f"eis:{key_type}:*"
                keys = self.redis.keys(pattern)
                count = len(keys)
                
                if key_type == "search":
                    stats["search_keys"] = count
                elif key_type == "contract":
                    stats["contract_keys"] = count
                elif key_type == "spec":
                    stats["spec_keys"] = count
                
                stats["total_keys"] += count
            
            return stats
            
        except Exception as e:
            print(f"Ошибка получения статистики кэша: {e}")
            return {"error": str(e)}