"""
Парсер ЕИС с обработкой ошибок и retry-логикой
"""
import asyncio
import re
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import httpx
from bs4 import BeautifulSoup


class EISParserWithRetry:
    """Парсер ЕИС с обработкой ошибок и retry"""
    
    def __init__(self, max_concurrent: int = 3, max_retries: int = 3, use_cache: bool = True):
        self.base_url = "https://zakupki.gov.ru"
        self.max_retries = max_retries
        self.use_cache = use_cache
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            },
        )
        self.semaphore = asyncio.Semaphore(max_concurrent)
        
        if use_cache:
            try:
                from .cache import EISCache
                self.cache = EISCache()
            except ImportError:
                print("Предупреждение: Redis не доступен, кэширование отключено")
                self.cache = None
                self.use_cache = False
        else:
            self.cache = None
    
    async def _request_with_retry(self, url: str, params: Optional[Dict] = None, method: str = "GET") -> httpx.Response:
        """Выполнить запрос с retry-логикой"""
        
        for attempt in range(self.max_retries):
            try:
                if method == "GET":
                    response = await self.client.get(url, params=params)
                else:
                    response = await self.client.post(url, params=params)
                
                response.raise_for_status()
                return response
                
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 429:  # Too Many Requests
                    wait_time = (attempt + 1) * 2  # Exponential backoff
                    print(f"Получен 429, ждем {wait_time} секунд...")
                    await asyncio.sleep(wait_time)
                    continue
                elif e.response.status_code >= 500:
                    wait_time = (attempt + 1) * 1
                    print(f"Серверная ошибка {e.response.status_code}, ждем {wait_time} секунд...")
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    raise
            except (httpx.RequestError, httpx.TimeoutException) as e:
                if attempt < self.max_retries - 1:
                    wait_time = (attempt + 1) * 1
                    print(f"Сетевая ошибка: {e}, ждем {wait_time} секунд...")
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    raise
        
        raise httpx.RequestError("Превышено максимальное количество попыток")
    
    async def search_contracts(
        self,
        ktru_code: Optional[str] = None,
        product_name: Optional[str] = None,
        region: str = "Северо-Западный ФО",
        period_from: Optional[datetime] = None,
        period_to: Optional[datetime] = None,
        law_type: str = "44-ФЗ",
        max_results: int = 50,
    ) -> List[Dict[str, Any]]:
        """Поиск контрактов с обработкой ошибок"""
        
        # Строим параметры поиска
        params = self._build_search_params(
            ktru_code=ktru_code,
            product_name=product_name,
            region=region,
            period_from=period_from,
            period_to=period_to,
            law_type=law_type,
        )
        
        # Пробуем получить из кэша
        if self.use_cache and self.cache:
            cached_results = self.cache.get_cached_search_results(params)
            if cached_results:
                print(f"Используем кэшированные результаты поиска ({len(cached_results)} контрактов)")
                return cached_results[:max_results]
        
        contracts = []
        page = 1
        
        while len(contracts) < max_results:
            params["pageNumber"] = page
            
            try:
                response = await self._request_with_retry(
                    f"{self.base_url}/epz/order/extendedsearch/results.html",
                    params=params
                )
                
                page_contracts = await self._parse_search_results(response.text)
                contracts.extend(page_contracts)
                
                # Проверяем, есть ли следующая страница
                if not self._has_next_page(response.text) or len(contracts) >= max_results:
                    break
                
                page += 1
                await asyncio.sleep(1)  # Задержка между запросами
                
            except Exception as e:
                print(f"Ошибка при поиске контрактов: {e}")
                break
        
        results = contracts[:max_results]
        
        # Нормализуем результаты
        try:
            from .normalizer import DataNormalizer
            results = DataNormalizer.normalize_search_results(results)
        except ImportError:
            print("Предупреждение: Нормализатор не доступен")
        
        # Кэшируем результаты
        if self.use_cache and self.cache and results:
            self.cache.cache_search_results(params, results)
        
        return results
    
    def _build_search_params(
        self,
        ktru_code: Optional[str] = None,
        product_name: Optional[str] = None,
        region: str = "Северо-Западный ФО",
        period_from: Optional[datetime] = None,
        period_to: Optional[datetime] = None,
        law_type: str = "44-ФЗ",
    ) -> Dict[str, Any]:
        """Построить параметры поиска"""
        
        params = {
            "searchString": product_name or "",
            "pageNumber": 1,
            "recordsPerPage": "_50",
            "sortBy": "UPDATE_DATE",
            "sortDirection": "false",
        }
        
        # Фильтр по закону
        if law_type == "44-ФЗ":
            params["fz44"] = "on"
            params["fz223"] = "off"
        elif law_type == "223-ФЗ":
            params["fz44"] = "off"
            params["fz223"] = "on"
        
        # Фильтр по статусу
        params["contractStage"] = "EXECUTION_COMPLETED"
        
        # Фильтр по периоду
        if period_from:
            params["contractDateFrom"] = period_from.strftime("%d.%m.%Y")
        if period_to:
            params["contractDateTo"] = period_to.strftime("%d.%m.%Y")
        
        # Фильтр по КТРУ
        if ktru_code:
            params["ktruCodes"] = ktru_code
        
        # Фильтр по региону
        region_code = self._get_region_code(region)
        if region_code:
            params["regions"] = region_code
        
        return params
    
    def _get_region_code(self, region_name: str) -> str:
        """Получить код региона ЕИС"""
        from .regions import get_region_code
        return get_region_code(region_name)
    
    async def _parse_search_results(self, html: str) -> List[Dict[str, Any]]:
        """Парсинг результатов поиска"""
        
        soup = BeautifulSoup(html, "lxml")
        contracts = []
        
        # Ищем блоки с результатами
        result_blocks = soup.find_all("div", class_="search-registry-entry-block")
        
        for block in result_blocks:
            try:
                # Ищем div с классом registry-entry__header-mid__number
                number_div = block.find("div", class_="registry-entry__header-mid__number")
                if not number_div:
                    continue
                
                # Внутри div ищем ссылку
                link_tag = number_div.find("a")
                if not link_tag:
                    continue
                
                contract_url = link_tag.get("href")
                if not contract_url.startswith("http"):
                    contract_url = self.base_url + contract_url
                
                # Извлекаем номер контракта
                contract_number = link_tag.text.strip()
                contract_number = re.sub(r'[№\s]+', '', contract_number)
                
                # Извлекаем поставщика
                supplier_name = ""
                supplier_div = block.find("div", class_="registry-entry__body-href")
                if supplier_div:
                    supplier_link = supplier_div.find("a")
                    if supplier_link:
                        supplier_name = supplier_link.text.strip()
                
                # Извлекаем дату
                date_str = ""
                date_div = block.find("div", class_="data-block__value")
                if date_div:
                    date_str = date_div.text.strip()
                
                # Извлекаем цену
                price = 0.0
                price_div = block.find("div", class_="price-block__value")
                if price_div:
                    price_text = price_div.text.strip()
                    price_clean = re.sub(r'[^\d,.]', '', price_text)
                    price_clean = price_clean.replace(',', '.')
                    try:
                        price = float(price_clean)
                    except ValueError:
                        numbers = re.findall(r'[\d\s,]+', price_text)
                        if numbers:
                            try:
                                num = numbers[0].replace(' ', '').replace(',', '.')
                                price = float(num)
                            except:
                                pass
                
                # Извлекаем объект закупки
                purchase_object = ""
                object_div = block.find("div", class_="registry-entry__body-value")
                if object_div:
                    purchase_object = object_div.text.strip()[:200]
                
                contracts.append({
                    "url": contract_url,
                    "reg_number": contract_number,
                    "supplier_name": supplier_name,
                    "date": date_str,
                    "price": price,
                    "currency": "RUB",
                    "purchase_object": purchase_object,
                })
                
            except Exception as e:
                print(f"Ошибка при парсинге блока результата: {e}")
                continue
        
        return contracts
    
    def _has_next_page(self, html: str) -> bool:
        """Проверить наличие следующей страницы"""
        
        soup = BeautifulSoup(html, "lxml")
        next_button = soup.find("a", string=re.compile(r"Следующая|>"))
        return next_button is not None
    
    async def get_contract_details(self, contract_url: str) -> Dict[str, Any]:
        """Получить детали контракта с обработкой ошибок"""
        
        # Пробуем получить из кэша
        if self.use_cache and self.cache:
            cached_details = self.cache.get_cached_contract_details(contract_url)
            if cached_details:
                print(f"Используем кэшированные детали контракта: {contract_url}")
                return cached_details
        
        async with self.semaphore:
            try:
                response = await self._request_with_retry(contract_url)
                
                # Парсим основную информацию
                contract_data = await self._parse_contract_page(response.text)
                contract_data["url"] = contract_url
                
                # Пытаемся получить спецификацию
                try:
                    specification = await self._get_contract_specification(contract_url)
                    if specification:
                        contract_data["specification"] = specification
                        contract_data["characteristics"] = self._extract_characteristics_from_specification(specification)
                except Exception as e:
                    print(f"Ошибка при получении спецификации: {e}")
                
                # Если нет характеристик, пробуем печатную форму
                if not contract_data.get("characteristics"):
                    try:
                        printed_form_data = await self._get_printed_form_data(contract_url)
                        if printed_form_data:
                            contract_data["printed_form"] = printed_form_data
                            contract_data["characteristics"] = self._extract_characteristics_from_printed_form(printed_form_data)
                    except Exception as e:
                        print(f"Ошибка при получении печатной формы: {e}")
                
                # Гарантируем, что characteristics всегда есть
                if "characteristics" not in contract_data:
                    contract_data["characteristics"] = []
                
                # Нормализуем детали контракта
                try:
                    from .normalizer import DataNormalizer
                    contract_data = DataNormalizer.normalize_contract_data(contract_data)
                except ImportError:
                    print("Предупреждение: Нормализатор не доступен")
                
                # Кэшируем детали контракта
                if self.use_cache and self.cache:
                    self.cache.cache_contract_details(contract_url, contract_data)
                
                return contract_data
                
            except Exception as e:
                print(f"Ошибка при получении деталей контракта {contract_url}: {e}")
                return {"characteristics": []}
    
    async def _parse_contract_page(self, html: str) -> Dict[str, Any]:
        """Парсинг страницы контракта"""
        
        soup = BeautifulSoup(html, "lxml")
        contract_data = {}
        
        try:
            # Извлекаем номер контракта
            number_tag = soup.find("span", class_="cardMainInfo__purchaseLink")
            if number_tag:
                contract_data["reg_number"] = number_tag.text.strip()
            
            # Извлекаем поставщика
            supplier_tag = soup.find("span", string=re.compile(r"Поставщик|Исполнитель"))
            if supplier_tag:
                supplier_value = supplier_tag.find_next("span")
                if supplier_value:
                    contract_data["supplier_name"] = supplier_value.text.strip()
            
            # Извлекаем ИНН поставщика
            inn_tag = soup.find("span", string=re.compile(r"ИНН"))
            if inn_tag:
                inn_value = inn_tag.find_next("span")
                if inn_value:
                    contract_data["supplier_inn"] = inn_value.text.strip()
            
            # Извлекаем дату подписания
            date_tag = soup.find("span", string=re.compile(r"Дата заключения|Дата подписания"))
            if date_tag:
                date_value = date_tag.find_next("span")
                if date_value:
                    date_str = date_value.text.strip()
                    try:
                        contract_data["sign_date"] = datetime.strptime(date_str, "%d.%m.%Y")
                    except ValueError:
                        contract_data["sign_date"] = datetime.utcnow()
            
            # Извлекаем цену
            price_tag = soup.find("span", string=re.compile(r"Цена контракта|Сумма контракта"))
            if price_tag:
                price_value = price_tag.find_next("span")
                if price_value:
                    price_text = price_value.text.strip()
                    price_match = re.search(r"[\d\s,]+", price_text.replace(" ", ""))
                    if price_match:
                        try:
                            price = float(price_match.group().replace(",", "."))
                            contract_data["unit_price"] = price
                            contract_data["currency"] = "RUB"
                        except ValueError:
                            pass
            
            # Извлекаем вендора/производителя
            vendor_tag = soup.find("span", string=re.compile(r"Производитель|Вендор|Бренд", re.IGNORECASE))
            if vendor_tag:
                vendor_value = vendor_tag.find_next("span")
                if vendor_value:
                    contract_data["vendor"] = vendor_value.text.strip()
            
        except Exception as e:
            print(f"Ошибка при парсинге страницы контракта: {e}")
        
        return contract_data
    
    async def _get_contract_specification(self, contract_url: str) -> Optional[str]:
        """Получить спецификацию контракта"""
        
        try:
            spec_url = contract_url.replace("common-info.html", "specification.html")
            response = await self._request_with_retry(spec_url)
            
            if response.status_code == 200:
                return response.text
            
        except Exception:
            pass
        
        return None
    
    async def _get_printed_form_data(self, contract_url: str) -> Optional[Dict[str, Any]]:
        """Получить данные из печатной формы контракта"""
        
        try:
            # Пробуем скачать печатную форму в разных форматах
            formats = [
                ("printForm.html", "html"),
                ("printForm.pdf", "pdf"),
                ("printForm.docx", "docx"),
            ]
            
            for url_suffix, format_type in formats:
                try:
                    print_url = contract_url.replace("common-info.html", url_suffix)
                    response = await self._request_with_retry(print_url)
                    
                    if response.status_code == 200:
                        if format_type == "html":
                            soup = BeautifulSoup(response.text, "lxml")
                            tables = soup.find_all("table")
                            for table in tables:
                                if self._is_specification_table(table):
                                    return {
                                        "html": str(table),
                                        "text": table.get_text(),
                                        "format": "html",
                                    }
                        elif format_type == "pdf":
                            # Парсим PDF
                            from .document_parser import DocumentParser
                            result = DocumentParser.parse_pdf_content(response.content)
                            result["format"] = "pdf"
                            return result
                        elif format_type == "docx":
                            # Парсим DOCX
                            from .document_parser import DocumentParser
                            result = DocumentParser.parse_docx_content(response.content)
                            result["format"] = "docx"
                            return result
                            
                except Exception as e:
                    print(f"Ошибка при загрузке {format_type}: {e}")
                    continue
        
        except Exception as e:
            print(f"Ошибка при получении печатной формы: {e}")
        
        return None
    
    def _is_specification_table(self, table) -> bool:
        """Проверить, является ли таблица таблицей спецификации"""
        
        text = table.get_text().lower()
        keywords = ["наименование", "количество", "цена", "сумма", "ед.", "изм."]
        
        keyword_count = sum(1 for keyword in keywords if keyword in text)
        return keyword_count >= 3
    
    def _extract_characteristics_from_specification(self, specification_html: str) -> List[Dict[str, Any]]:
        """Извлечь характеристики из спецификации"""
        
        characteristics = []
        soup = BeautifulSoup(specification_html, "lxml")
        
        rows = soup.find_all("tr")
        
        for row in rows:
            cells = row.find_all("td")
            if len(cells) >= 2:
                key = cells[0].get_text().strip()
                value = cells[1].get_text().strip()
                
                if key and value and len(key) < 100:
                    characteristics.append({
                        "key": key,
                        "value": value,
                        "source": "specification",
                    })
        
        return characteristics
    
    def _extract_characteristics_from_printed_form(self, printed_form_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Извлечь характеристики из печатной формы"""
        
        characteristics = []
        text = printed_form_data.get("text", "")
        
        lines = text.split("\n")
        
        for line in lines:
            line = line.strip()
            if ":" in line:
                parts = line.split(":", 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    
                    if key and value:
                        characteristics.append({
                            "key": key,
                            "value": value,
                            "source": "printed_form",
                        })
        
        return characteristics
    
    async def close(self):
        """Закрыть клиент"""
        await self.client.aclose()