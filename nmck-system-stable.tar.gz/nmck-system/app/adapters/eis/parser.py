import asyncio
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import httpx
from bs4 import BeautifulSoup
import urllib.parse
from app.infra.config import settings


class EISParser:
    """Парсер ЕИС zakupki.gov.ru"""
    
    def __init__(self):
        self.base_url = settings.EIS_BASE_URL
        self.search_url = f"{settings.EIS_BASE_URL}/epz/order/extendedsearch/results.html"
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Cache-Control": "max-age=0",
            },
            follow_redirects=True,
            verify=False,  # Отключаем проверку SSL для тестирования
        )
        self.semaphore = asyncio.Semaphore(3)  # Максимум 3 одновременных запроса
    
    async def search_contracts(
        self,
        ktru_code: Optional[str] = None,
        product_name: Optional[str] = None,
        region: str = "Северо-Западный ФО",
        period_from: Optional[datetime] = None,
        period_to: Optional[datetime] = None,
        law_type: str = "44-ФЗ",
        max_results: int = 200,
    ) -> List[Dict[str, Any]]:
        """Поиск контрактов по расширенному поиску"""
        
        # Формируем параметры запроса
        params = self._build_search_params(
            ktru_code=ktru_code,
            product_name=product_name,
            region=region,
            period_from=period_from,
            period_to=period_to,
            law_type=law_type,
        )
        
        contracts = []
        page = 1
        
        try:
            while len(contracts) < max_results:
                # Добавляем параметр страницы
                params["pageNumber"] = page
                
                # Выполняем запрос
                response = await self.client.get(self.search_url, params=params)
                response.raise_for_status()
                
                # Парсим результаты
                page_contracts = await self._parse_search_results(response.text)
                
                if not page_contracts:
                    break
                
                contracts.extend(page_contracts)
                
                # Проверяем, есть ли следующая страница
                if not self._has_next_page(response.text):
                    break
                
                page += 1
                
                # Задержка между запросами
                await asyncio.sleep(settings.EIS_SEARCH_DELAY)
            
            # Ограничиваем количество результатов
            return contracts[:max_results]
            
        except Exception as e:
            print(f"Ошибка при поиске контрактов: {e}")
            return []
    
    async def get_contract_details(self, contract_url: str) -> Dict[str, Any]:
        """Получить детальную информацию о контракте"""
        
        async with self.semaphore:
            try:
                # Загружаем страницу контракта
                response = await self.client.get(contract_url)
                response.raise_for_status()
                
                # Парсим основную информацию
                contract_data = await self._parse_contract_page(response.text)
                contract_data["url"] = contract_url
                
                # Пытаемся получить спецификацию
                try:
                    specification = await self._get_contract_specification(contract_url)
                    if specification:
                        contract_data["specification"] = specification
                        contract_data["characteristics"] = self._extract_characteristics_from_specification(specification)
                except Exception as e:
                    print(f"Ошибка при получении спецификации: {e}")
                
                # Если нет характеристик в спецификации, пробуем скачать печатную форму
                if not contract_data.get("characteristics"):
                    try:
                        printed_form_data = await self._get_printed_form_data(contract_url)
                        if printed_form_data:
                            contract_data["printed_form"] = printed_form_data
                            contract_data["characteristics"] = self._extract_characteristics_from_printed_form(printed_form_data)
                    except Exception as e:
                        print(f"Ошибка при получении печатной формы: {e}")
                
                return contract_data
                
            except Exception as e:
                print(f"Ошибка при получении деталей контракта {contract_url}: {e}")
                return {}
    
    def _build_search_params(
        self,
        ktru_code: Optional[str] = None,
        product_name: Optional[str] = None,
        region: str = "Северо-Западный ФО",
        period_from: Optional[datetime] = None,
        period_to: Optional[datetime] = None,
        law_type: str = "44-ФЗ",
    ) -> Dict[str, Any]:
        """Построить параметры поиска"""
        
        if period_to is None:
            period_to = datetime.now()
        if period_from is None:
            period_from = period_to - timedelta(days=3 * 365)  # 3 года
        
        params = {
            "morphology": "on",
            "search-filter": "Поиск",
            "sortBy": "PUBLISH_DATE",
            "pageNumber": 1,
            "sortDirection": "false",
            "recordsPerPage": "_50",
            "showLotsInfoHidden": "false",
            "fz44": "on" if law_type == "44-ФЗ" else "off",
            "fz223": "on" if law_type == "223-ФЗ" else "off",
            "contractStage": "EXECUTION_COMPLETED,EXECUTION_TERMINATED",
            "contractDateFrom": period_from.strftime("%d.%m.%Y"),
            "contractDateTo": period_to.strftime("%d.%m.%Y"),
            "regionDeleted": "false",
        }
        
        # Добавляем КТРУ код
        if ktru_code:
            params["ktruCodes"] = ktru_code
        
        # Добавляем ключевые слова из названия товара
        if product_name:
            params["searchString"] = product_name
        
        # Добавляем регион (упрощенная реализация)
        if region:
            # В реальной системе нужно мапить регион на код региона ЕИС
            params["regions"] = self._get_region_code(region)
        
        return params
    
    def _get_region_code(self, region_name: str) -> str:
        """Получить код региона ЕИС по названию"""
        # Упрощенная реализация - в реальной системе нужен полный справочник
        region_mapping = {
            "Северо-Западный ФО": "78000000000",
            "Центральный ФО": "77000000000",
            "Южный ФО": "61000000000",
            "Приволжский ФО": "16000000000",
            "Уральский ФО": "66000000000",
            "Сибирский ФО": "24000000000",
            "Дальневосточный ФО": "27000000000",
        }
        return region_mapping.get(region_name, "78000000000")  # По умолчанию СЗФО
    
    async def _parse_search_results(self, html: str) -> List[Dict[str, Any]]:
        """Парсинг результатов поиска (исправленные селекторы)"""
        
        soup = BeautifulSoup(html, "lxml")
        contracts = []
        
        # Ищем блоки с результатами
        result_blocks = soup.find_all("div", class_="search-registry-entry-block")
        
        for block in result_blocks:
            try:
                # Ищем div с классом registry-entry__header-mid__number
                number_div = block.find("div", class_="registry-entry__header-mid__number")
                if not number_div:
                    continue
                
                # Внутри div ищем ссылку
                link_tag = number_div.find("a")
                if not link_tag:
                    continue
                
                contract_url = link_tag.get("href")
                if not contract_url.startswith("http"):
                    contract_url = self.base_url + contract_url
                
                # Извлекаем номер контракта из текста ссылки
                contract_number = link_tag.text.strip()
                # Очищаем номер от лишних символов
                import re
                contract_number = re.sub(r'[№\s]+', '', contract_number)
                
                # Извлекаем поставщика
                supplier_name = ""
                supplier_div = block.find("div", class_="registry-entry__body-href")
                if supplier_div:
                    supplier_link = supplier_div.find("a")
                    if supplier_link:
                        supplier_name = supplier_link.text.strip()
                
                # Извлекаем дату (первая дата в блоке)
                date_str = ""
                date_div = block.find("div", class_="data-block__value")
                if date_div:
                    date_str = date_div.text.strip()
                
                # Извлекаем цену
                price = 0.0
                price_div = block.find("div", class_="price-block__value")
                if price_div:
                    price_text = price_div.text.strip()
                    # Убираем все нецифровые символы кроме точки и запятой
                    price_clean = re.sub(r'[^\d,.]', '', price_text)
                    # Заменяем запятую на точку
                    price_clean = price_clean.replace(',', '.')
                    try:
                        price = float(price_clean)
                    except ValueError:
                        # Пробуем другой подход - ищем числа в тексте
                        numbers = re.findall(r'[\d\s,]+', price_text)
                        if numbers:
                            try:
                                num = numbers[0].replace(' ', '').replace(',', '.')
                                price = float(num)
                            except:
                                pass
                
                # Извлекаем объект закупки
                purchase_object = ""
                object_div = block.find("div", class_="registry-entry__body-value")
                if object_div:
                    purchase_object = object_div.text.strip()[:200]
                
                contracts.append({
                    "url": contract_url,
                    "reg_number": contract_number,
                    "supplier_name": supplier_name,
                    "date": date_str,
                    "price": price,
                    "currency": "RUB",
                    "purchase_object": purchase_object,
                })
                
            except Exception as e:
                print(f"Ошибка при парсинге блока результата: {e}")
                continue
        
        return contracts
    
    def _has_next_page(self, html: str) -> bool:
        """Проверить наличие следующей страницы"""
        
        soup = BeautifulSoup(html, "lxml")
        next_button = soup.find("a", string=re.compile(r"Следующая|>"))
        return next_button is not None
    
    async def _parse_contract_page(self, html: str) -> Dict[str, Any]:
        """Парсинг страницы контракта - улучшенная версия"""
        
        soup = BeautifulSoup(html, "lxml")
        contract_data = {}
        
        try:
            # Извлекаем номер контракта - несколько способов
            # Способ 1: поиск по классу
            number_tag = soup.find("span", class_="cardMainInfo__purchaseLink")
            if not number_tag:
                # Способ 2: поиск по тексту "Реестровый номер"
                number_tag = soup.find(string=re.compile(r"Реестровый номер|Номер контракта"))
                if number_tag:
                    number_tag = number_tag.find_parent()
            
            if number_tag:
                contract_data["reg_number"] = number_tag.text.strip()
            
            # Извлекаем поставщика - несколько способов
            supplier_name = None
            
            # Способ 1: поиск по таблице с более широкими критериями
            supplier_rows = soup.find_all("tr")
            for row in supplier_rows:
                th = row.find("th")
                td = row.find("td")
                if th and td:
                    th_text = th.text.strip().lower()
                    td_text = td.text.strip()
                    
                    # Проверяем различные варианты названия поля
                    if any(keyword in th_text for keyword in ["поставщик", "исполнитель", "подрядчик", "участник"]):
                        if len(td_text) > 5 and len(td_text) < 200:  # Фильтруем слишком короткие/длинные
                            supplier_name = td_text
                            break
            
            # Способ 2: поиск по тексту с регулярными выражениями
            if not supplier_name:
                supplier_patterns = [
                    r"Поставщик[\s:]+([^\n\r<]+)",
                    r"Исполнитель[\s:]+([^\n\r<]+)",
                    r"Подрядчик[\s:]+([^\n\r<]+)",
                    r"Участник[\s:]+([^\n\r<]+)",
                ]
                
                for pattern in supplier_patterns:
                    match = re.search(pattern, soup.text, re.IGNORECASE)
                    if match:
                        candidate = match.group(1).strip()
                        if len(candidate) > 5 and len(candidate) < 200:
                            supplier_name = candidate
                            break
            
            # Способ 3: поиск организаций в тексте (по ключевым словам)
            if not supplier_name:
                org_keywords = ["ООО", "АО", "ПАО", "ГУ", "МУ", "КУ", "ФГУП", "МБУ", "ГАУ"]
                lines = soup.text.split('\n')
                for line in lines:
                    line = line.strip()
                    if any(keyword in line for keyword in org_keywords):
                        if 10 < len(line) < 150:  # Разумная длина для названия организации
                            supplier_name = line
                            break
            
            if supplier_name:
                # Очищаем название от лишних символов
                supplier_name = re.sub(r'\s+', ' ', supplier_name).strip()
                contract_data["supplier_name"] = supplier_name
            
            # Извлекаем ИНН поставщика
            inn_tag = soup.find(string=re.compile(r"ИНН"))
            if inn_tag:
                inn_parent = inn_tag.find_parent()
                if inn_parent:
                    # Ищем ИНН в тексте
                    inn_match = re.search(r"\b\d{10,12}\b", inn_parent.text)
                    if inn_match:
                        contract_data["supplier_inn"] = inn_match.group()
            
            # Извлекаем дату подписания - несколько способов
            date_found = False
            
            # Паттерны для поиска даты
            date_patterns = [
                r"Дата заключения[\s:]+(\d{2}\.\d{2}\.\d{4})",
                r"Дата подписания[\s:]+(\d{2}\.\d{2}\.\d{4})",
                r"Срок действия[\s:]+(\d{2}\.\d{2}\.\d{4})",
                r"Дата[\s:]+(\d{2}\.\d{2}\.\d{4})",
                r"(\d{2}\.\d{2}\.\d{4})\s*г\.",
                r"(\d{2}\.\d{2}\.\d{4})\s*год",
            ]
            
            for pattern in date_patterns:
                date_match = re.search(pattern, soup.text, re.IGNORECASE)
                if date_match:
                    date_str = date_match.group(1)
                    try:
                        contract_data["sign_date"] = datetime.strptime(date_str, "%d.%m.%Y")
                        date_found = True
                        break
                    except ValueError:
                        continue
            
            # Способ 2: поиск в таблицах
            if not date_found:
                date_rows = soup.find_all("tr")
                for row in date_rows:
                    th = row.find("th")
                    td = row.find("td")
                    if th and td:
                        th_text = th.text.strip().lower()
                        if "дата" in th_text:
                            td_text = td.text.strip()
                            date_match = re.search(r"\d{2}\.\d{2}\.\d{4}", td_text)
                            if date_match:
                                try:
                                    contract_data["sign_date"] = datetime.strptime(date_match.group(), "%d.%m.%Y")
                                    date_found = True
                                    break
                                except ValueError:
                                    continue
            
            # Извлекаем цену - несколько способов
            price_found = False
            
            # Способ 1: поиск по тексту
            price_patterns = [
                r"Цена контракта[\s:]+([\d\s,]+(?:\s*[₽руб\.])?)",
                r"Сумма контракта[\s:]+([\d\s,]+(?:\s*[₽руб\.])?)",
                r"Начальная цена[\s:]+([\d\s,]+(?:\s*[₽руб\.])?)",
                r"Цена[\s:]+([\d\s,]+(?:\s*[₽руб\.])?)",
                r"([\d\s,]+)\s*₽",
                r"([\d\s,]+)\s*руб",
            ]
            
            for pattern in price_patterns:
                price_match = re.search(pattern, soup.text, re.IGNORECASE)
                if price_match:
                    price_text = price_match.group(1).strip()
                    try:
                        # Очищаем текст от пробелов и символов валюты
                        clean_price = re.sub(r"[^\d,.]", "", price_text.replace(" ", ""))
                        price = float(clean_price.replace(",", "."))
                        contract_data["unit_price"] = price
                        contract_data["currency"] = "RUB"
                        price_found = True
                        break
                    except ValueError:
                        continue
            
            # Способ 2: поиск в таблицах
            if not price_found:
                price_rows = soup.find_all("tr")
                for row in price_rows:
                    th = row.find("th")
                    td = row.find("td")
                    if th and td:
                        th_text = th.text.strip().lower()
                        if "цена" in th_text or "сумма" in th_text:
                            td_text = td.text.strip()
                            price_match = re.search(r"[\d\s,]+", td_text.replace(" ", ""))
                            if price_match:
                                try:
                                    clean_price = re.sub(r"[^\d,.]", "", price_match.group())
                                    price = float(clean_price.replace(",", "."))
                                    contract_data["unit_price"] = price
                                    contract_data["currency"] = "RUB"
                                    price_found = True
                                    break
                                except ValueError:
                                    continue
            
            # Извлекаем вендора/производителя
            vendor_tag = soup.find(string=re.compile(r"Производитель|Вендор|Бренд|Изготовитель", re.IGNORECASE))
            if vendor_tag:
                vendor_parent = vendor_tag.find_parent()
                if vendor_parent:
                    # Ищем текст после метки
                    vendor_text = vendor_parent.text
                    vendor_match = re.search(r"(?:Производитель|Вендор|Бренд|Изготовитель)[:\s]+([^\n\r]+)", vendor_text, re.IGNORECASE)
                    if vendor_match:
                        contract_data["vendor"] = vendor_match.group(1).strip()
            
            # Пытаемся извлечь характеристики из таблиц на странице
            characteristics = []
            
            # Ищем таблицы с характеристиками
            tables = soup.find_all("table")
            for table in tables:
                rows = table.find_all("tr")
                for row in rows:
                    cells = row.find_all(["td", "th"])
                    if len(cells) >= 2:
                        key = cells[0].text.strip()
                        value = cells[1].text.strip()
                        
                        # Фильтруем очевидные не-характеристики
                        exclude_keywords = [
                            "№", "номер", "дата", "сумма", "цена", "статус", "кбк", "итого", "всего",
                            "счет", "банк", "реквизиты", "платеж", "оплата", "договор", "контракт",
                            "заказчик", "поставщик", "исполнитель", "подрядчик", "участник",
                            "заявка", "предложение", "лот", "извещение", "уведомление"
                        ]
                        
                        key_lower = key.lower()
                        value_lower = value.lower()
                        
                        # Проверяем, не является ли это финансовой или административной информацией
                        is_financial = any(word in key_lower for word in ["₽", "руб", "коп", "долл", "евро", "тенге"])
                        is_administrative = any(word in key_lower for word in exclude_keywords)
                        is_numeric_key = re.match(r"^\d+$", key)
                        is_empty_key = re.match(r"^[^a-zA-Zа-яА-Я]*$", key)
                        is_too_short = len(key) < 2 or len(value) < 1
                        is_too_long = len(key) > 50 or len(value) > 100
                        
                        # Проверяем, не является ли это технической характеристикой
                        is_technical = any(word in key_lower for word in [
                            "характеристика", "параметр", "свойство", "описание",
                            "размер", "вес", "цвет", "материал", "мощность", "напряжение",
                            "частота", "скорость", "емкость", "объем", "диаметр", "толщина",
                            "длина", "ширина", "высота", "глубина", "экран", "дисплей",
                            "процессор", "память", "озу", "ssd", "hdd", "видеокарта"
                        ])
                        
                        if (key and value and 
                            not is_too_short and not is_too_long and
                            not is_financial and not is_administrative and
                            not is_numeric_key and not is_empty_key and
                            (is_technical or len(key_lower.split()) <= 5)):  # Не слишком длинные ключи
                            
                            # Нормализуем ключ
                            normalized_key = self._normalize_characteristic_key(key)
                            
                            # Пропускаем дубликаты
                            if not any(c["key"] == normalized_key for c in characteristics):
                                characteristics.append({
                                    "key": normalized_key,
                                    "value": value,
                                    "unit": self._extract_unit(value),
                                    "operator": "=",
                                    "source": "contract_page"
                                })
            
            if characteristics:
                contract_data["characteristics"] = characteristics
            
        except Exception as e:
            print(f"Ошибка при парсинге страницы контракта: {e}")
            import traceback
            traceback.print_exc()
        
        return contract_data
    
    def _normalize_characteristic_key(self, key: str) -> str:
        """Нормализует ключ характеристики"""
        key_lower = key.lower().strip()
        
        # Разбиваем ключ на слова
        words = re.findall(r'\b\w+\b', key_lower)
        
        # Маппинг синонимов (точные совпадения слов)
        synonyms = {
            'озу': 'ram',
            'оперативная': 'ram',
            'память': 'ram',
            'жесткий': 'storage',
            'диск': 'storage',
            'накопитель': 'storage',
            'процессор': 'cpu',
            'цп': 'cpu',
            'экран': 'screen_size',
            'дисплей': 'screen_size',
            'вес': 'weight',
            'цвет': 'color',
            'материал': 'material',
            'габариты': 'dimensions',
            'размер': 'size',
            'мощность': 'power',
            'напряжение': 'voltage',
            'частота': 'frequency',
            'скорость': 'speed',
            'емкость': 'capacity',
            'объем': 'volume',
            'длина': 'length',
            'ширина': 'width',
            'высота': 'height',
            'глубина': 'depth',
            'диаметр': 'diameter',
            'толщина': 'thickness',
        }
        
        # Проверяем каждое слово
        for word in words:
            if word in synonyms:
                return synonyms[word]
        
        # Если не нашли точного совпадения, проверяем частичные совпадения для многословных ключей
        multiword_synonyms = {
            'оперативная память': 'ram',
            'жесткий диск': 'storage',
        }
        
        for phrase, normalized in multiword_synonyms.items():
            if phrase in key_lower:
                return normalized
        
        return key_lower
    
    def _extract_unit(self, value: str) -> Optional[str]:
        """Извлекает единицу измерения из значения"""
        units = {
            'gb': ['gb', 'гб'],
            'mb': ['mb', 'мб'],
            'tb': ['tb', 'тб'],
            'ghz': ['ghz', 'ггц'],
            'mhz': ['mhz', 'мгц'],
            'inch': ['inch', 'дюйм', '"'],
            'mm': ['mm', 'мм'],
            'cm': ['cm', 'см'],
            'kg': ['kg', 'кг'],
            'g': ['g', 'г'],
            'w': ['w', 'вт'],
            'v': ['v', 'в'],
            'hz': ['hz', 'гц'],
        }
        
        value_lower = value.lower()
        for unit, patterns in units.items():
            for pattern in patterns:
                if pattern in value_lower:
                    return unit
        
        return None
    
    async def _get_contract_specification(self, contract_url: str) -> Optional[str]:
        """Получить спецификацию контракта"""
        
        try:
            # Пробуем получить страницу со спецификацией
            spec_url = contract_url.replace("common-info.html", "specification.html")
            response = await self.client.get(spec_url)
            
            if response.status_code == 200:
                return response.text
            
        except Exception:
            pass
        
        return None
    
    async def _get_printed_form_data(self, contract_url: str) -> Optional[Dict[str, Any]]:
        """Получить данные из печатной формы контракта"""
        
        try:
            # Пробуем скачать печатную форму
            print_url = contract_url.replace("common-info.html", "printForm.html")
            response = await self.client.get(print_url)
            
            if response.status_code == 200:
                # Парсим печатную форму
                soup = BeautifulSoup(response.text, "lxml")
                
                # Ищем таблицу спецификации
                tables = soup.find_all("table")
                for table in tables:
                    # Проверяем, похожа ли таблица на спецификацию
                    if self._is_specification_table(table):
                        return {
                            "html": str(table),
                            "text": table.get_text(),
                        }
        
        except Exception as e:
            print(f"Ошибка при получении печатной формы: {e}")
        
        return None
    
    def _is_specification_table(self, table) -> bool:
        """Проверить, является ли таблица таблицей спецификации"""
        
        text = table.get_text().lower()
        keywords = ["наименование", "количество", "цена", "сумма", "ед.", "изм."]
        
        keyword_count = sum(1 for keyword in keywords if keyword in text)
        return keyword_count >= 3
    
    def _extract_characteristics_from_specification(self, specification_html: str) -> List[Dict[str, Any]]:
        """Извлечь характеристики из спецификации"""
        
        characteristics = []
        soup = BeautifulSoup(specification_html, "lxml")
        
        # Ищем строки с характеристиками
        rows = soup.find_all("tr")
        
        for row in rows:
            cells = row.find_all("td")
            if len(cells) >= 2:
                key = cells[0].get_text().strip()
                value = cells[1].get_text().strip()
                
                if key and value and len(key) < 100:  # Фильтруем слишком длинные ключи
                    characteristics.append({
                        "key": key,
                        "value": value,
                        "source": "specification",
                    })
        
        return characteristics
    
    def _extract_characteristics_from_printed_form(self, printed_form_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Извлечь характеристики из печатной формы"""
        
        characteristics = []
        text = printed_form_data.get("text", "")
        
        # Упрощенный парсинг - ищем пары ключ: значение
        lines = text.split("\n")
        
        for line in lines:
            line = line.strip()
            if ":" in line:
                parts = line.split(":", 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    
                    if key and value:
                        characteristics.append({
                            "key": key,
                            "value": value,
                            "source": "printed_form",
                        })
        
        return characteristics
    
    async def close(self):
        """Закрыть клиент"""
        await self.client.aclose()