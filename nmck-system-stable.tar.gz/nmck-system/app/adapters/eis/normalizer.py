"""
Нормализация данных из ЕИС
"""
import re
from datetime import datetime
from typing import Dict, Any, Optional, List
from decimal import Decimal, ROUND_HALF_UP


class DataNormalizer:
    """Нормализация данных контрактов"""
    
    @staticmethod
    def normalize_price(price_text: str, currency: str = "RUB") -> Dict[str, Any]:
        """
        Нормализация цены
        
        Args:
            price_text: Текст с ценой
            currency: Валюта (по умолчанию RUB)
            
        Returns:
            Нормализованная цена
        """
        if not price_text:
            return {"value": 0.0, "currency": currency, "original": price_text}
        
        # Убираем все нецифровые символы кроме точки, запятой и пробелов
        cleaned = re.sub(r'[^\d\s,.]', '', price_text)
        
        # Заменяем запятую на точку
        cleaned = cleaned.replace(',', '.')
        
        # Убираем пробелы (разделители тысяч)
        cleaned = cleaned.replace(' ', '')
        
        try:
            # Пробуем преобразовать в Decimal для точности
            value = Decimal(cleaned)
            # Округляем до 2 знаков после запятой
            value = value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            float_value = float(value)
            
            return {
                "value": float_value,
                "currency": currency,
                "original": price_text,
                "normalized": True,
            }
        except:
            # Если не удалось преобразовать, пробуем найти числа в тексте
            numbers = re.findall(r'[\d\s,]+', price_text)
            if numbers:
                try:
                    num = numbers[0].replace(' ', '').replace(',', '.')
                    value = Decimal(num).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                    return {
                        "value": float(value),
                        "currency": currency,
                        "original": price_text,
                        "normalized": True,
                    }
                except:
                    pass
        
        return {"value": 0.0, "currency": currency, "original": price_text, "normalized": False}
    
    @staticmethod
    def normalize_date(date_text: str) -> Optional[datetime]:
        """
        Нормализация даты
        
        Args:
            date_text: Текст с датой
            
        Returns:
            Нормализованная дата или None
        """
        if not date_text:
            return None
        
        date_text = date_text.strip()
        
        # Паттерны дат
        patterns = [
            # DD.MM.YYYY
            (r'(\d{2})\.(\d{2})\.(\d{4})', '%d.%m.%Y'),
            # DD/MM/YYYY
            (r'(\d{2})/(\d{2})/(\d{4})', '%d/%m/%Y'),
            # YYYY-MM-DD
            (r'(\d{4})-(\d{2})-(\d{2})', '%Y-%m-%d'),
            # DD.MM.YY
            (r'(\d{2})\.(\d{2})\.(\d{2})', '%d.%m.%y'),
        ]
        
        for pattern, date_format in patterns:
            match = re.search(pattern, date_text)
            if match:
                try:
                    date_str = match.group()
                    return datetime.strptime(date_str, date_format)
                except ValueError:
                    continue
        
        # Пробуем извлечь дату из текста
        day_match = re.search(r'\b(\d{1,2})\b', date_text)
        month_match = re.search(r'\b(янв|фев|мар|апр|май|июн|июл|авг|сен|окт|ноя|дек|января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\b', date_text, re.IGNORECASE)
        year_match = re.search(r'\b(20\d{2})\b', date_text)
        
        if day_match and month_match and year_match:
            try:
                day = int(day_match.group())
                month_str = month_match.group().lower()
                year = int(year_match.group())
                
                # Преобразуем месяц
                month_map = {
                    'янв': 1, 'января': 1,
                    'фев': 2, 'февраля': 2,
                    'мар': 3, 'марта': 3,
                    'апр': 4, 'апреля': 4,
                    'май': 5, 'мая': 5,
                    'июн': 6, 'июня': 6,
                    'июл': 7, 'июля': 7,
                    'авг': 8, 'августа': 8,
                    'сен': 9, 'сентября': 9,
                    'окт': 10, 'октября': 10,
                    'ноя': 11, 'ноября': 11,
                    'дек': 12, 'декабря': 12,
                }
                
                month = month_map.get(month_str)
                if month:
                    return datetime(year, month, day)
            except:
                pass
        
        return None
    
    @staticmethod
    def normalize_characteristic_value(value: str, key: str = "") -> Dict[str, Any]:
        """
        Нормализация значения характеристики
        
        Args:
            value: Значение характеристики
            key: Ключ характеристики (для контекста)
            
        Returns:
            Нормализованное значение
        """
        if not value:
            return {"original": value, "normalized": value, "type": "string"}
        
        value = value.strip()
        
        # Определяем тип значения
        value_lower = value.lower()
        key_lower = key.lower() if key else ""
        
        # Проверяем, является ли числом
        if re.match(r'^-?\d+[\.,]?\d*$', value):
            # Это число
            try:
                num_value = float(value.replace(',', '.'))
                return {
                    "original": value,
                    "normalized": num_value,
                    "type": "number",
                }
            except:
                pass
        
        # Проверяем, содержит ли единицы измерения
        unit_patterns = [
            (r'(\d+[\.,]?\d*)\s*(GB|ГБ|MB|МБ|TB|ТБ)', 'storage'),
            (r'(\d+[\.,]?\d*)\s*(GHz|ГГц|MHz|МГц)', 'frequency'),
            (r'(\d+[\.,]?\d*)\s*(дюйм|inch|"|\'\')', 'size'),
            (r'(\d+[\.,]?\d*)\s*(кг|kg|г|g)', 'weight'),
            (r'(\d+[\.,]?\d*)\s*(мм|mm|см|cm|м|m)', 'length'),
            (r'(\d+[\.,]?\d*)\s*(В|V|Вт|W)', 'power'),
        ]
        
        for pattern, unit_type in unit_patterns:
            match = re.search(pattern, value, re.IGNORECASE)
            if match:
                try:
                    num = float(match.group(1).replace(',', '.'))
                    unit = match.group(2)
                    return {
                        "original": value,
                        "normalized": num,
                        "unit": unit,
                        "type": unit_type,
                    }
                except:
                    pass
        
        # Проверяем булевые значения
        bool_map = {
            'да': True, 'yes': True, 'true': True, '1': True, 'есть': True,
            'нет': False, 'no': False, 'false': False, '0': False, 'нету': False,
        }
        
        if value_lower in bool_map:
            return {
                "original": value,
                "normalized": bool_map[value_lower],
                "type": "boolean",
            }
        
        # Для строковых значений нормализуем регистр
        if value.isupper():
            normalized = value.title()
        elif value.islower():
            normalized = value.capitalize()
        else:
            normalized = value
        
        return {
            "original": value,
            "normalized": normalized,
            "type": "string",
        }
    
    @staticmethod
    def normalize_characteristic_key(key: str) -> str:
        """
        Нормализация ключа характеристики
        
        Args:
            key: Ключ характеристики
            
        Returns:
            Нормализованный ключ
        """
        if not key:
            return ""
        
        key = key.strip().lower()
        
        # Словарь синонимов
        synonyms = {
            # Память
            'оперативная память': 'ram',
            'озу': 'ram',
            'ram': 'ram',
            'память': 'memory',
            
            # Хранилище
            'жесткий диск': 'storage',
            'ssd': 'storage',
            'hdd': 'storage',
            'накопитель': 'storage',
            'диск': 'storage',
            
            # Процессор
            'процессор': 'cpu',
            'cpu': 'cpu',
            'центральный процессор': 'cpu',
            
            # Экран
            'диагональ': 'screen_size',
            'экран': 'screen',
            'screen': 'screen',
            'монитор': 'screen',
            
            # Операционная система
            'операционная система': 'os',
            'ос': 'os',
            'os': 'os',
            
            # Производитель
            'производитель': 'vendor',
            'вендор': 'vendor',
            'бренд': 'vendor',
            'изготовитель': 'vendor',
            'manufacturer': 'vendor',
            
            # Модель
            'модель': 'model',
            'артикул': 'model',
            'код': 'model',
            'article': 'model',
            
            # Цвет
            'цвет': 'color',
            'colour': 'color',
            
            # Вес
            'вес': 'weight',
            'масса': 'weight',
            'weight': 'weight',
            
            # Цена
            'цена': 'price',
            'стоимость': 'price',
            'price': 'price',
            
            # Количество
            'количество': 'quantity',
            'кол-во': 'quantity',
            'amount': 'quantity',
            
            # Единица измерения
            'единица измерения': 'unit',
            'ед. изм.': 'unit',
            'unit': 'unit',
            
            # Разрешение
            'разрешение': 'resolution',
            'resolution': 'resolution',
            
            # Частота
            'частота': 'frequency',
            'frequency': 'frequency',
            
            # Мощность
            'мощность': 'power',
            'power': 'power',
            
            # Габариты
            'габариты': 'dimensions',
            'размеры': 'dimensions',
            'dimensions': 'dimensions',
            
            # Материал
            'материал': 'material',
            'material': 'material',
            
            # Страна
            'страна производства': 'country',
            'страна': 'country',
            'country': 'country',
        }
        
        # Проверяем точное совпадение
        if key in synonyms:
            return synonyms[key]
        
        # Проверяем частичное совпадение
        for synonym, normalized in synonyms.items():
            if synonym in key or key in synonym:
                return normalized
        
        # Если ключ короткий и содержит только буквы, оставляем как есть
        if len(key) < 30 and re.match(r'^[а-яa-z\s]+$', key, re.IGNORECASE):
            # Убираем лишние пробелы и приводим к snake_case
            normalized = key.strip().replace(' ', '_')
            return normalized
        
        return key
    
    @staticmethod
    def normalize_contract_data(contract_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Нормализация всех данных контракта
        
        Args:
            contract_data: Данные контракта
            
        Returns:
            Нормализованные данные контракта
        """
        normalized = contract_data.copy()
        
        # Нормализуем цену
        if "price" in normalized:
            price_data = DataNormalizer.normalize_price(str(normalized["price"]))
            normalized["price_normalized"] = price_data
        
        if "unit_price" in normalized:
            price_data = DataNormalizer.normalize_price(str(normalized["unit_price"]))
            normalized["unit_price_normalized"] = price_data
        
        # Нормализуем даты
        if "date" in normalized and isinstance(normalized["date"], str):
            normalized["date_normalized"] = DataNormalizer.normalize_date(normalized["date"])
        
        if "sign_date" in normalized and isinstance(normalized["sign_date"], str):
            normalized["sign_date_normalized"] = DataNormalizer.normalize_date(normalized["sign_date"])
        
        # Нормализуем характеристики
        if "characteristics" in normalized and isinstance(normalized["characteristics"], list):
            normalized_characteristics = []
            for char in normalized["characteristics"]:
                if isinstance(char, dict):
                    norm_char = char.copy()
                    
                    # Нормализуем ключ
                    if "key" in norm_char:
                        norm_char["key_normalized"] = DataNormalizer.normalize_characteristic_key(norm_char["key"])
                    
                    # Нормализуем значение
                    if "value" in norm_char:
                        key = norm_char.get("key", "")
                        value_data = DataNormalizer.normalize_characteristic_value(str(norm_char["value"]), key)
                        norm_char["value_normalized"] = value_data
                    
                    normalized_characteristics.append(norm_char)
                else:
                    normalized_characteristics.append(char)
            
            normalized["characteristics_normalized"] = normalized_characteristics
        
        # Нормализуем поставщика (убираем лишние пробелы, кавычки)
        if "supplier_name" in normalized and isinstance(normalized["supplier_name"], str):
            supplier = normalized["supplier_name"].strip()
            supplier = re.sub(r'["\']', '', supplier)  # Убираем кавычки
            supplier = re.sub(r'\s+', ' ', supplier)  # Убираем лишние пробелы
            normalized["supplier_name_normalized"] = supplier
        
        # Нормализуем номер контракта
        if "reg_number" in normalized and isinstance(normalized["reg_number"], str):
            reg_num = normalized["reg_number"].strip()
            reg_num = re.sub(r'[№\s]+', '', reg_num)  # Убираем № и пробелы
            normalized["reg_number_normalized"] = reg_num
        
        # Добавляем метку о нормализации
        normalized["_normalized"] = True
        
        return normalized
    
    @staticmethod
    def normalize_search_results(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Нормализация результатов поиска
        
        Args:
            results: Список контрактов
            
        Returns:
            Нормализованный список контрактов
        """
        normalized_results = []
        
        for contract in results:
            if isinstance(contract, dict):
                normalized_contract = DataNormalizer.normalize_contract_data(contract)
                normalized_results.append(normalized_contract)
            else:
                normalized_results.append(contract)
        
        return normalized_results