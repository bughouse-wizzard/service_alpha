"""
Парсер печатных форм контрактов (PDF, DOCX)
"""
import re
import io
from typing import List, Dict, Any, Optional
from datetime import datetime


class DocumentParser:
    """Парсер документов печатных форм"""
    
    @staticmethod
    def parse_pdf_content(pdf_content: bytes) -> Dict[str, Any]:
        """
        Парсинг PDF документа
        
        Args:
            pdf_content: Байты PDF файла
            
        Returns:
            Словарь с извлеченными данными
        """
        try:
            # Для парсинга PDF нужна библиотека PyPDF2 или pdfplumber
            # В MVP используем упрощенный подход
            import PyPDF2
            
            pdf_file = io.BytesIO(pdf_content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
            
            return DocumentParser._extract_data_from_text(text)
            
        except ImportError:
            # Если PyPDF2 не установлен, возвращаем пустой результат
            print("Предупреждение: PyPDF2 не установлен, парсинг PDF недоступен")
            return {"text": "", "characteristics": []}
        except Exception as e:
            print(f"Ошибка при парсинге PDF: {e}")
            return {"text": "", "characteristics": []}
    
    @staticmethod
    def parse_docx_content(docx_content: bytes) -> Dict[str, Any]:
        """
        Парсинг DOCX документа
        
        Args:
            docx_content: Байты DOCX файла
            
        Returns:
            Словарь с извлеченными данными
        """
        try:
            # Для парсинга DOCX нужна библиотека python-docx
            import docx
            
            docx_file = io.BytesIO(docx_content)
            doc = docx.Document(docx_file)
            
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            
            # Также извлекаем таблицы
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + " | "
                    text += "\n"
            
            return DocumentParser._extract_data_from_text(text)
            
        except ImportError:
            print("Предупреждение: python-docx не установлен, парсинг DOCX недоступен")
            return {"text": "", "characteristics": []}
        except Exception as e:
            print(f"Ошибка при парсинге DOCX: {e}")
            return {"text": "", "characteristics": []}
    
    @staticmethod
    def _extract_data_from_text(text: str) -> Dict[str, Any]:
        """
        Извлечение данных из текста документа
        
        Args:
            text: Текст документа
            
        Returns:
            Словарь с извлеченными данными
        """
        characteristics = []
        
        # Паттерны для извлечения характеристик
        patterns = [
            # Характеристики товара
            (r"(?:Наименование|Название|Товар)[:\s]+(.+?)(?:\n|$)", "name"),
            (r"(?:Модель|Артикул|Код)[:\s]+(.+?)(?:\n|$)", "model"),
            (r"(?:Производитель|Вендор|Бренд|Изготовитель)[:\s]+(.+?)(?:\n|$)", "vendor"),
            (r"(?:Страна производства|Страна)[:\s]+(.+?)(?:\n|$)", "country"),
            
            # Технические характеристики
            (r"(?:ОЗУ|RAM|оперативная память)[:\s]+([\d\.]+)\s*(?:GB|ГБ|MB|МБ)", "ram"),
            (r"(?:SSD|HDD|жесткий диск|накопитель)[:\s]+([\d\.]+)\s*(?:GB|ГБ|TB|ТБ)", "storage"),
            (r"(?:Процессор|CPU)[:\s]+(.+?)(?:\n|$)", "cpu"),
            (r"(?:Частота процессора)[:\s]+([\d\.]+)\s*(?:GHz|ГГц)", "cpu_frequency"),
            (r"(?:Диагональ|Экран|Screen)[:\s]+([\d\.]+)\s*(?:дюйм|inch|\")", "screen_size"),
            (r"(?:Разрешение|Resolution)[:\s]+(.+?)(?:\n|$)", "resolution"),
            (r"(?:ОС|Операционная система|OS)[:\s]+(.+?)(?:\n|$)", "os"),
            (r"(?:Вес|Масса)[:\s]+([\d\.]+)\s*(?:кг|kg|г|g)", "weight"),
            (r"(?:Цвет|Color)[:\s]+(.+?)(?:\n|$)", "color"),
            
            # Цена и количество
            (r"(?:Цена|Стоимость)[:\s]+([\d\s,]+)\s*(?:руб|₽|RUB)", "price"),
            (r"(?:Количество|Кол-во|Amount)[:\s]+([\d\s,]+)", "quantity"),
            (r"(?:Единица измерения|Ед\. изм\.)[:\s]+(.+?)(?:\n|$)", "unit"),
            
            # Контрактные данные
            (r"(?:Номер контракта|№ контракта)[:\s]+(.+?)(?:\n|$)", "contract_number"),
            (r"(?:Дата заключения|Дата контракта)[:\s]+(\d{2}\.\d{2}\.\d{4})", "contract_date"),
            (r"(?:Поставщик|Исполнитель)[:\s]+(.+?)(?:\n|$)", "supplier"),
            (r"(?:ИНН)[:\s]+(\d{10,12})", "inn"),
        ]
        
        for pattern, key in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    value = match[0]
                else:
                    value = match
                
                if value and value.strip():
                    characteristics.append({
                        "key": key,
                        "value": value.strip(),
                        "source": "printed_form",
                    })
        
        # Также ищем таблицы с характеристиками
        table_patterns = [
            r"(\w.+?)\s+(\d+[\.,]?\d*)\s*(\w*)",  # Название значение единица
            r"(.+?):\s*(.+)",  # Ключ: значение
        ]
        
        for pattern in table_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                if len(match) >= 2:
                    key = match[0].strip()
                    value = match[1].strip()
                    
                    if key and value and len(key) < 50:
                        # Нормализуем ключ
                        key_norm = DocumentParser._normalize_key(key)
                        if key_norm:
                            characteristics.append({
                                "key": key_norm,
                                "value": value,
                                "source": "printed_form_table",
                            })
        
        return {
            "text": text,
            "characteristics": characteristics,
        }
    
    @staticmethod
    def _normalize_key(key: str) -> str:
        """Нормализация ключа характеристики"""
        
        key = key.lower().strip()
        
        # Словарь синонимов
        synonyms = {
            "оперативная память": "ram",
            "озу": "ram",
            "ram": "ram",
            "жесткий диск": "storage",
            "ssd": "storage",
            "hdd": "storage",
            "накопитель": "storage",
            "процессор": "cpu",
            "cpu": "cpu",
            "диагональ": "screen_size",
            "экран": "screen_size",
            "screen": "screen_size",
            "операционная система": "os",
            "ос": "os",
            "производитель": "vendor",
            "вендор": "vendor",
            "бренд": "vendor",
            "изготовитель": "vendor",
            "модель": "model",
            "артикул": "model",
            "код": "model",
            "цвет": "color",
            "вес": "weight",
            "масса": "weight",
            "цена": "price",
            "стоимость": "price",
            "количество": "quantity",
            "кол-во": "quantity",
            "единица измерения": "unit",
            "ед. изм.": "unit",
        }
        
        # Проверяем точное совпадение
        if key in synonyms:
            return synonyms[key]
        
        # Проверяем частичное совпадение
        for synonym, normalized in synonyms.items():
            if synonym in key or key in synonym:
                return normalized
        
        # Если ключ короткий и содержит только буквы, оставляем как есть
        if len(key) < 30 and re.match(r'^[а-яa-z\s]+$', key, re.IGNORECASE):
            return key
        
        return ""