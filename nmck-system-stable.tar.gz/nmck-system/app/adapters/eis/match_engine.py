"""
Match Engine для сравнения характеристик
"""
import re
from typing import Dict, Any, List, Optional, Tuple
from difflib import SequenceMatcher
from decimal import Decimal


class MatchEngine:
    """Движок для сравнения характеристик"""
    
    def __init__(self):
        # Веса характеристик для расчета совпадения
        self.characteristic_weights = {
            "ram": 10,
            "storage": 8,
            "cpu": 9,
            "screen_size": 7,
            "os": 6,
            "vendor": 5,
            "model": 4,
            "resolution": 3,
            "weight": 2,
            "color": 1,
            "country": 1,
        }
        
        # Допустимые отклонения для числовых характеристик
        self.tolerances = {
            "ram": 0.1,  # 10%
            "storage": 0.15,  # 15%
            "screen_size": 0.05,  # 5%
            "weight": 0.2,  # 20%
        }
        
        # Синонимы для вендоров
        self.vendor_synonyms = {
            "dell": ["dell inc.", "dell technologies", "dell computer"],
            "hp": ["hewlett packard", "hp inc.", "hewlett-packard"],
            "lenovo": ["lenovo group", "lenovo china"],
            "asus": ["asustek computer", "asus computer"],
            "acer": ["acer inc.", "acer computer"],
            "apple": ["apple inc.", "apple computer"],
            "samsung": ["samsung electronics", "samsung group"],
            "huawei": ["huawei technologies", "huawei device"],
            "xiaomi": ["xiaomi corporation", "xiaomi tech"],
            "microsoft": ["microsoft corporation", "microsoft inc."],
        }
    
    def calculate_match_score(
        self,
        required_characteristics: List[Dict[str, Any]],
        found_characteristics: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Расчет процента совпадения характеристик
        
        Args:
            required_characteristics: Требуемые характеристики
            found_characteristics: Найденные характеристики
            
        Returns:
            Результат сравнения
        """
        if not required_characteristics or not found_characteristics:
            return {
                "match_percent": 0.0,
                "match_type": "no_match",
                "matched_characteristics": [],
                "missing_characteristics": required_characteristics.copy() if required_characteristics else [],
                "vendor_match": "unknown",
            }
        
        # Нормализуем характеристики
        norm_required = self._normalize_characteristics(required_characteristics)
        norm_found = self._normalize_characteristics(found_characteristics)
        
        # Сравниваем характеристики
        comparison = self._compare_characteristics(norm_required, norm_found)
        
        # Рассчитываем процент совпадения
        total_weight = sum(self.characteristic_weights.get(char.get("key_normalized", ""), 1) 
                          for char in norm_required)
        
        if total_weight == 0:
            match_percent = 0.0
        else:
            matched_weight = sum(
                self.characteristic_weights.get(char.get("key_normalized", ""), 1)
                for char in comparison["matched"]
            )
            match_percent = (matched_weight / total_weight) * 100
        
        # Определяем тип совпадения
        if match_percent >= 95:
            match_type = "identical"
        elif match_percent >= 70:
            match_type = "homogeneous"
        else:
            match_type = "partial"
        
        # Проверяем совпадение вендора
        vendor_match = self._check_vendor_match(norm_required, norm_found)
        
        return {
            "match_percent": round(match_percent, 2),
            "match_type": match_type,
            "matched_characteristics": comparison["matched"],
            "missing_characteristics": comparison["missing"],
            "different_characteristics": comparison["different"],
            "vendor_match": vendor_match,
            "total_required": len(norm_required),
            "total_matched": len(comparison["matched"]),
        }
    
    def _normalize_characteristics(self, characteristics: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Нормализация характеристик для сравнения"""
        normalized = []
        
        for char in characteristics:
            norm_char = char.copy()
            
            # Нормализуем ключ
            key = char.get("key", "")
            if isinstance(key, str):
                norm_char["key_normalized"] = self._normalize_key(key)
            
            # Нормализуем значение
            value = char.get("value", "")
            if isinstance(value, str):
                norm_char["value_normalized"] = self._normalize_value(value, norm_char.get("key_normalized", ""))
            
            normalized.append(norm_char)
        
        return normalized
    
    def _normalize_key(self, key: str) -> str:
        """Нормализация ключа характеристики"""
        key = key.lower().strip()
        
        # Базовые синонимы
        synonyms = {
            "оперативная память": "ram",
            "озу": "ram",
            "ram": "ram",
            "жесткий диск": "storage",
            "ssd": "storage",
            "hdd": "storage",
            "накопитель": "storage",
            "процессор": "cpu",
            "cpu": "cpu",
            "диагональ": "screen_size",
            "экран": "screen_size",
            "screen": "screen_size",
            "операционная система": "os",
            "ос": "os",
            "os": "os",
            "производитель": "vendor",
            "вендор": "vendor",
            "бренд": "vendor",
            "изготовитель": "vendor",
            "модель": "model",
            "артикул": "model",
            "код": "model",
            "цвет": "color",
            "вес": "weight",
            "масса": "weight",
            "страна": "country",
            "разрешение": "resolution",
        }
        
        # Проверяем точное совпадение
        if key in synonyms:
            return synonyms[key]
        
        # Проверяем частичное совпадение
        for synonym, normalized in synonyms.items():
            if synonym in key or key in synonym:
                return normalized
        
        return key
    
    def _normalize_value(self, value: str, key: str = "") -> Any:
        """Нормализация значения характеристики"""
        value = value.strip()
        
        # Для числовых значений
        if re.match(r'^\d+[\.,]?\d*$', value):
            try:
                return float(value.replace(',', '.'))
            except:
                pass
        
        # Для значений с единицами измерения
        unit_patterns = [
            (r'(\d+[\.,]?\d*)\s*(GB|ГБ)', 'gb'),
            (r'(\d+[\.,]?\d*)\s*(MB|МБ)', 'mb'),
            (r'(\d+[\.,]?\d*)\s*(TB|ТБ)', 'tb'),
            (r'(\d+[\.,]?\d*)\s*(GHz|ГГц)', 'ghz'),
            (r'(\d+[\.,]?\d*)\s*(дюйм|inch|"|\'\')', 'inch'),
            (r'(\d+[\.,]?\d*)\s*(кг|kg)', 'kg'),
            (r'(\d+[\.,]?\d*)\s*(г|g)', 'g'),
        ]
        
        for pattern, unit in unit_patterns:
            match = re.search(pattern, value, re.IGNORECASE)
            if match:
                try:
                    num = float(match.group(1).replace(',', '.'))
                    return {"value": num, "unit": unit}
                except:
                    pass
        
        return value.lower()
    
    def _compare_characteristics(
        self, 
        required: List[Dict[str, Any]], 
        found: List[Dict[str, Any]]
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Сравнение характеристик"""
        matched = []
        missing = []
        different = []
        
        # Создаем словарь найденных характеристик по нормализованным ключам
        found_dict = {}
        for char in found:
            key = char.get("key_normalized", "")
            if key:
                found_dict[key] = char
        
        for req_char in required:
            req_key = req_char.get("key_normalized", "")
            req_value = req_char.get("value_normalized", "")
            
            if not req_key:
                continue
            
            if req_key in found_dict:
                found_char = found_dict[req_key]
                found_value = found_char.get("value_normalized", "")
                
                # Сравниваем значения
                if self._values_match(req_value, found_value, req_key):
                    matched_char = req_char.copy()
                    matched_char["found_value"] = found_value
                    matched_char["found_original"] = found_char.get("value", "")
                    matched.append(matched_char)
                else:
                    diff_char = req_char.copy()
                    diff_char["found_value"] = found_value
                    diff_char["found_original"] = found_char.get("value", "")
                    diff_char["difference"] = self._calculate_difference(req_value, found_value)
                    different.append(diff_char)
            else:
                missing.append(req_char)
        
        return {
            "matched": matched,
            "missing": missing,
            "different": different,
        }
    
    def _values_match(self, req_value: Any, found_value: Any, key: str) -> bool:
        """Проверка совпадения значений"""
        if req_value is None or found_value is None:
            return False
        
        # Для числовых значений
        if isinstance(req_value, (int, float)) and isinstance(found_value, (int, float)):
            tolerance = self.tolerances.get(key, 0.1)
            if req_value == 0:
                return found_value == 0
            diff = abs(req_value - found_value) / req_value
            return diff <= tolerance
        
        # Для значений с единицами измерения
        if isinstance(req_value, dict) and isinstance(found_value, dict):
            if req_value.get("unit") == found_value.get("unit"):
                req_num = req_value.get("value")
                found_num = found_value.get("value")
                if isinstance(req_num, (int, float)) and isinstance(found_num, (int, float)):
                    tolerance = self.tolerances.get(key, 0.1)
                    if req_num == 0:
                        return found_num == 0
                    diff = abs(req_num - found_num) / req_num
                    return diff <= tolerance
        
        # Для строковых значений
        if isinstance(req_value, str) and isinstance(found_value, str):
            similarity = SequenceMatcher(None, req_value.lower(), found_value.lower()).ratio()
            return similarity >= 0.8
        
        # Для сравнения строки с числом
        if isinstance(req_value, str) and isinstance(found_value, (int, float)):
            try:
                req_num = float(req_value.replace(',', '.'))
                tolerance = self.tolerances.get(key, 0.1)
                if req_num == 0:
                    return found_value == 0
                diff = abs(req_num - found_value) / req_num
                return diff <= tolerance
            except:
                return False
        
        return str(req_value).lower() == str(found_value).lower()
    
    def _calculate_difference(self, req_value: Any, found_value: Any) -> str:
        """Расчет разницы между значениями"""
        if isinstance(req_value, (int, float)) and isinstance(found_value, (int, float)):
            if req_value == 0:
                return "100%" if found_value != 0 else "0%"
            diff_percent = abs(req_value - found_value) / req_value * 100
            return f"{diff_percent:.1f}%"
        
        return "разные значения"
    
    def _check_vendor_match(
        self, 
        required: List[Dict[str, Any]], 
        found: List[Dict[str, Any]]
    ) -> str:
        """Проверка совпадения вендора"""
        # Ищем вендор в требуемых характеристиках
        req_vendor = None
        for char in required:
            if char.get("key_normalized") == "vendor":
                req_vendor = char.get("value", "")
                break
        
        # Ищем вендор в найденных характеристиках
        found_vendor = None
        for char in found:
            if char.get("key_normalized") == "vendor":
                found_vendor = char.get("value", "")
                break
        
        if not req_vendor or not found_vendor:
            return "unknown"
        
        req_vendor_lower = req_vendor.lower().strip()
        found_vendor_lower = found_vendor.lower().strip()
        
        # Проверяем точное совпадение
        if req_vendor_lower == found_vendor_lower:
            return "match"
        
        # Проверяем синонимы
        for vendor, synonyms in self.vendor_synonyms.items():
            if (req_vendor_lower == vendor or req_vendor_lower in synonyms) and \
               (found_vendor_lower == vendor or found_vendor_lower in synonyms):
                return "match"
        
        # Проверяем частичное совпадение
        if req_vendor_lower in found_vendor_lower or found_vendor_lower in req_vendor_lower:
            return "partial"
        
        # Проверяем схожесть
        similarity = SequenceMatcher(None, req_vendor_lower, found_vendor_lower).ratio()
        if similarity >= 0.7:
            return "partial"
        
        return "mismatch"
    
    def create_audit_log(
        self,
        required_characteristics: List[Dict[str, Any]],
        found_characteristics: List[Dict[str, Any]],
        match_result: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Создание лога сверки
        
        Args:
            required_characteristics: Требуемые характеристики
            found_characteristics: Найденные характеристики
            match_result: Результат сравнения
            
        Returns:
            Лог сверки
        """
        audit_log = []
        
        # Добавляем совпадающие характеристики
        for matched in match_result.get("matched_characteristics", []):
            audit_log.append({
                "key": matched.get("key", ""),
                "expected_value": matched.get("value", ""),
                "found_value": matched.get("found_original", ""),
                "is_diff": False,
                "diff_reason": "",
                "match_type": "identical",
            })
        
        # Добавляем разные характеристики
        for different in match_result.get("different_characteristics", []):
            audit_log.append({
                "key": different.get("key", ""),
                "expected_value": different.get("value", ""),
                "found_value": different.get("found_original", ""),
                "is_diff": True,
                "diff_reason": different.get("difference", "разные значения"),
                "match_type": "different",
            })
        
        # Добавляем отсутствующие характеристики
        for missing in match_result.get("missing_characteristics", []):
            audit_log.append({
                "key": missing.get("key", ""),
                "expected_value": missing.get("value", ""),
                "found_value": "",
                "is_diff": True,
                "diff_reason": "отсутствует",
                "match_type": "missing",
            })
        
        # Добавляем вендор
        vendor_match = match_result.get("vendor_match", "unknown")
        if vendor_match != "unknown":
            audit_log.append({
                "key": "Производитель",
                "expected_value": self._get_vendor_from_characteristics(required_characteristics),
                "found_value": self._get_vendor_from_characteristics(found_characteristics),
                "is_diff": vendor_match != "match",
                "diff_reason": "не совпадает" if vendor_match != "match" else "",
                "match_type": "vendor",
            })
        
        return audit_log
    
    def _get_vendor_from_characteristics(self, characteristics: List[Dict[str, Any]]) -> str:
        """Получение вендора из характеристик"""
        for char in characteristics:
            if char.get("key", "").lower() in ["производитель", "вендор", "vendor", "бренд"]:
                return char.get("value", "")
        return ""