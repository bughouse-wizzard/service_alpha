import io
from typing import Optional
from minio import Minio
from minio.error import S3Error
from app.infra.config import settings


class MinioClient:
    """Клиент для работы с MinIO/S3"""
    
    def __init__(self):
        self.client = Minio(
            endpoint=settings.minio_endpoint,
            access_key=settings.minio_access_key,
            secret_key=settings.minio_secret_key,
            secure=settings.minio_secure,
        )
        self._ensure_bucket_exists()
    
    def _ensure_bucket_exists(self):
        """Убедиться, что бакет существует"""
        try:
            if not self.client.bucket_exists(settings.minio_bucket):
                self.client.make_bucket(settings.minio_bucket)
        except S3Error as e:
            raise Exception(f"Ошибка при создании бакета: {e}")
    
    async def upload_file(
        self,
        bucket_name: str,
        filename: str,
        content: bytes,
        content_type: Optional[str] = None,
    ) -> str:
        """Загрузить файл в MinIO"""
        
        try:
            data = io.BytesIO(content)
            length = len(content)
            
            self.client.put_object(
                bucket_name=bucket_name,
                object_name=filename,
                data=data,
                length=length,
                content_type=content_type or "application/octet-stream",
            )
            
            # Возвращаем URL файла
            return f"{bucket_name}/{filename}"
            
        except S3Error as e:
            raise Exception(f"Ошибка при загрузке файла в MinIO: {e}")
    
    async def get_file(self, bucket_name: str, filename: str) -> bytes:
        """Получить файл из MinIO"""
        
        try:
            response = self.client.get_object(bucket_name, filename)
            return response.read()
        except S3Error as e:
            raise Exception(f"Ошибка при получении файла из MinIO: {e}")
        finally:
            response.close()
            response.release_conn()
    
    async def delete_file(self, bucket_name: str, filename: str):
        """Удалить файл из MinIO"""
        
        try:
            self.client.remove_object(bucket_name, filename)
        except S3Error as e:
            raise Exception(f"Ошибка при удалении файла из MinIO: {e}")
    
    async def get_presigned_url(
        self,
        bucket_name: str,
        filename: str,
        expires_seconds: int = 3600,
    ) -> str:
        """Получить предварительно подписанный URL для доступа к файлу"""
        
        try:
            return self.client.presigned_get_object(
                bucket_name=bucket_name,
                object_name=filename,
                expires=expires_seconds,
            )
        except S3Error as e:
            raise Exception(f"Ошибка при получении подписанного URL: {e}")