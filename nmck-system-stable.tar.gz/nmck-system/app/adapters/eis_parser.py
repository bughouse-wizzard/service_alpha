"""
Адаптер для парсинга ЕИС (заглушка для тестирования)
"""
import time
import random
from typing import List, Dict, Any
from datetime import datetime

class EISParser:
    """Парсер ЕИС (заглушка для тестирования)"""
    
    def __init__(self, region: str = "Северо-Западный ФО", law_type: str = "44-ФЗ"):
        self.region = region
        self.law_type = law_type
    
    def search_contracts(self, ktru_code: str, product_name: str, period_from: datetime, period_to: datetime) -> List[Dict[str, Any]]:
        """
        Поиск контрактов в ЕИС (заглушка).
        
        Args:
            ktru_code: Код КТРУ
            product_name: Наименование товара
            period_from: Начало периода
            period_to: Конец периода
            
        Returns:
            Список контрактов
        """
        # Имитация задержки поиска
        time.sleep(2)
        
        # Генерируем тестовые данные
        contracts = []
        for i in range(random.randint(5, 15)):
            contract = {
                "reg_number": f"1234567890{i}",
                "eis_url": f"https://zakupki.gov.ru/epz/order/notice/printForm/view.html?regNumber=1234567890{i}",
                "supplier_name": f"Поставщик {i+1} ООО",
                "supplier_inn": f"123456789{i:03d}",
                "sign_date": datetime.now().replace(year=random.randint(2023, 2025), month=random.randint(1, 12), day=random.randint(1, 28)),
                "unit_price": random.uniform(10000, 500000),
                "currency": "RUB",
                "characteristics": {
                    "ram": f"{random.choice([8, 16, 32])} GB",
                    "ssd": f"{random.choice([256, 512, 1024])} GB",
                    "processor": random.choice(["Intel Core i5", "Intel Core i7", "AMD Ryzen 5", "AMD Ryzen 7"]),
                    "screen_size": f"{random.choice([13.3, 14, 15.6])} дюймов"
                },
                "vendor": random.choice(["Dell", "HP", "Lenovo", "Asus", "Acer", "Apple"])
            }
            contracts.append(contract)
        
        return contracts
    
    def extract_characteristics(self, contract_url: str) -> Dict[str, Any]:
        """
        Извлечение характеристик из контракта (заглушка).
        
        Args:
            contract_url: URL контракта
            
        Returns:
            Характеристики контракта
        """
        # Имитация задержки
        time.sleep(0.5)
        
        # Возвращаем тестовые характеристики
        return {
            "ram": f"{random.choice([8, 16, 32])} GB",
            "ssd": f"{random.choice([256, 512, 1024])} GB",
            "processor": random.choice(["Intel Core i5", "Intel Core i7", "AMD Ryzen 5", "AMD Ryzen 7"]),
            "screen_size": f"{random.choice([13.3, 14, 15.6])} дюймов"
        }
