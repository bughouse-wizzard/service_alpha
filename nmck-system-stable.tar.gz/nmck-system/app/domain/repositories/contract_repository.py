"""
Интерфейс репозитория контрактов
"""
from abc import ABC, abstractmethod
from typing import List, Optional
from app.domain.entities.contract import ContractEntity


class ContractRepository(ABC):
    """Абстрактный репозиторий контрактов"""
    
    @abstractmethod
    def get_by_id(self, contract_id: str) -> Optional[ContractEntity]:
        """Получить контракт по ID"""
        pass
    
    @abstractmethod
    def get_by_task_id(self, task_id: str) -> List[ContractEntity]:
        """Получить контракты по task_id"""
        pass
    
    @abstractmethod
    def create(self, contract: ContractEntity) -> ContractEntity:
        """Создать контракт"""
        pass
    
    @abstractmethod
    def create_batch(self, contracts: List[ContractEntity]) -> List[ContractEntity]:
        """Создать несколько контрактов"""
        pass
    
    @abstractmethod
    def update(self, contract: ContractEntity) -> ContractEntity:
        """Обновить контракт"""
        pass
    
    @abstractmethod
    def delete_by_task_id(self, task_id: str) -> int:
        """Удалить контракты по task_id"""
        pass