"""
Интерфейс репозитория загрузок
"""
from abc import ABC, abstractmethod
from typing import List, Optional
from app.domain.entities.upload import UploadEntity


class UploadRepository(ABC):
    """Абстрактный репозиторий загрузок"""
    
    @abstractmethod
    def get_by_id(self, upload_id: str) -> Optional[UploadEntity]:
        """Получить загрузку по ID"""
        pass
    
    @abstractmethod
    def get_by_session_id(self, session_id: str, limit: int = 20) -> List[UploadEntity]:
        """Получить загрузки по session_id"""
        pass
    
    @abstractmethod
    def create(self, upload: UploadEntity) -> UploadEntity:
        """Создать загрузку"""
        pass
    
    @abstractmethod
    def update(self, upload: UploadEntity) -> UploadEntity:
        """Обновить загрузку"""
        pass
    
    @abstractmethod
    def delete(self, upload_id: str) -> bool:
        """Удалить загрузку"""
        pass