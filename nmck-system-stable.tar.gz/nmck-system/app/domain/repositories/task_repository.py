"""
Интерфейс репозитория задач
"""
from abc import ABC, abstractmethod
from typing import List, Optional
from datetime import datetime
from app.domain.entities.task import TaskEntity, TaskStatus


class TaskRepository(ABC):
    """Абстрактный репозиторий задач"""
    
    @abstractmethod
    def get_by_id(self, task_id: str) -> Optional[TaskEntity]:
        """Получить задачу по ID"""
        pass
    
    @abstractmethod
    def get_by_session_id(self, session_id: str, limit: int = 50) -> List[TaskEntity]:
        """Получить задачи по session_id"""
        pass
    
    @abstractmethod
    def create(self, task: TaskEntity) -> TaskEntity:
        """Создать задачу"""
        pass
    
    @abstractmethod
    def update(self, task: TaskEntity) -> TaskEntity:
        """Обновить задачу"""
        pass
    
    @abstractmethod
    def update_status(self, task_id: str, status: TaskStatus, stage: Optional[str] = None, 
                     progress: Optional[int] = None, error_code: Optional[str] = None, 
                     error_detail: Optional[str] = None) -> Optional[TaskEntity]:
        """Обновить статус задачи"""
        pass
    
    @abstractmethod
    def delete(self, task_id: str) -> bool:
        """Удалить задачу"""
        pass