from datetime import datetime
from sqlalchemy import DateTime, String, Float, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
from .base import BaseEntity
from .task import TaskEntity


class TaskCalculationEntity(BaseEntity):
    __tablename__ = "task_calculations"
    
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False)
    method: Mapped[str] = mapped_column(String(100), nullable=False)
    nmc_value: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(10), default="RUB", nullable=False)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    details: Mapped[dict] = mapped_column(JSON, nullable=True)
    
    # Связи
    task: Mapped["TaskEntity"] = relationship("TaskEntity")