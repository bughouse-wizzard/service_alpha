from datetime import datetime
from sqlalchemy import DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
from .base import BaseEntity
from .task import TaskEntity
from .contract import ContractEntity


class TaskSelectionEntity(BaseEntity):
    __tablename__ = "task_selection"
    
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False)
    contract_id: Mapped[UUID] = mapped_column(ForeignKey("contracts.id"), nullable=False)
    selected_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Связи
    task: Mapped["TaskEntity"] = relationship("TaskEntity", back_populates="selection")
    contract: Mapped["ContractEntity"] = relationship("ContractEntity")