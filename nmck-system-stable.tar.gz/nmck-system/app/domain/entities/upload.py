from sqlalchemy import JSON, String, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
from .base import BaseEntity
from .session import SessionEntity


class UploadEntity(BaseEntity):
    __tablename__ = "uploads"
    
    session_id: Mapped[UUID] = mapped_column(ForeignKey("sessions.id"), nullable=False)
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(100), nullable=False)
    storage_url: Mapped[str] = mapped_column(String(500), nullable=False)
    extracted_data: Mapped[dict] = mapped_column(JSON, nullable=True)
    warnings: Mapped[list] = mapped_column(JSON, nullable=True, default=list)
    
    # Связи
    session: Mapped["SessionEntity"] = relationship("SessionEntity")
    tasks: Mapped[list["TaskEntity"]] = relationship("TaskEntity", back_populates="upload", cascade="all, delete-orphan")