from datetime import datetime
from enum import Enum
from sqlalchemy import Enum as SQLEnum, DateTime, String, Integer, Float, ForeignKey, JSON, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
from .base import BaseEntity
from .upload import UploadEntity


class TaskStatus(str, Enum):
    QUEUED = "queued"
    SEARCHING = "searching"
    DOWNLOADING = "downloading"
    ANALYZING = "analyzing"
    DONE = "done"
    ERROR = "error"
    CANCELLED = "cancelled"
    STOPPED = "stopped"


class TaskEntity(BaseEntity):
    __tablename__ = "tasks"
    
    session_id: Mapped[UUID] = mapped_column(ForeignKey("sessions.id"), nullable=False)
    upload_id: Mapped[UUID] = mapped_column(ForeignKey("uploads.id"), nullable=False)
    status: Mapped[TaskStatus] = mapped_column(SQLEnum(TaskStatus), default=TaskStatus.QUEUED, nullable=False)
    stage: Mapped[str] = mapped_column(String(100), nullable=True)
    progress: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    message: Mapped[str] = mapped_column(String(500), nullable=True)
    
    # Параметры поиска
    region: Mapped[str] = mapped_column(String(100), nullable=False)
    period_from: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    period_to: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    law_type: Mapped[str] = mapped_column(String(50), default="44-ФЗ", nullable=False)
    
    # Информация о товаре (для отображения в истории)
    product_name: Mapped[str] = mapped_column(String(200), nullable=True)
    ktru_code: Mapped[str] = mapped_column(String(100), nullable=True)

    # Результаты
    started_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    error_code: Mapped[str] = mapped_column(String(100), nullable=True)
    error_detail: Mapped[str] = mapped_column(Text, nullable=True)
    
    # Сводка результатов
    total_found: Mapped[int] = mapped_column(Integer, default=0)
    total_analyzed: Mapped[int] = mapped_column(Integer, default=0)
    nmck_value: Mapped[float] = mapped_column(Float, nullable=True)
    nmck_currency: Mapped[str] = mapped_column(String(10), default="RUB", nullable=True)
    
    # Связи
    session: Mapped["SessionEntity"] = relationship("SessionEntity")
    upload: Mapped["UploadEntity"] = relationship("UploadEntity", back_populates="tasks")
    contracts: Mapped[list["ContractEntity"]] = relationship("ContractEntity", back_populates="task", cascade="all, delete-orphan")
    selection: Mapped[list["TaskSelectionEntity"]] = relationship("TaskSelectionEntity", back_populates="task", cascade="all, delete-orphan")