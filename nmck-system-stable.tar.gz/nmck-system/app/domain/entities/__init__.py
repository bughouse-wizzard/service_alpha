"""
Импорт всех сущностей для автоматического создания таблиц
"""
from .base import BaseEntity
from .session import SessionEntity
from .upload import UploadEntity
from .task import TaskEntity
from .contract import ContractEntity
from .audit import ContractAuditEntity
from .selection import TaskSelectionEntity
from .calculation import TaskCalculationEntity

__all__ = [
    "BaseEntity",
    "SessionEntity",
    "UploadEntity",
    "TaskEntity",
    "ContractEntity",
    "ContractAuditEntity",
    "TaskSelectionEntity",
    "TaskCalculationEntity",
]