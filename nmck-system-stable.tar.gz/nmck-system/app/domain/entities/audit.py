from sqlalchemy import String, Text, Boolean, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
from .base import BaseEntity
from .contract import ContractEntity


class ContractAuditEntity(BaseEntity):
    __tablename__ = "contract_audit_rows"
    
    contract_id: Mapped[UUID] = mapped_column(ForeignKey("contracts.id"), nullable=False)
    key: Mapped[str] = mapped_column(String(200), nullable=False)
    expected_value: Mapped[str] = mapped_column(Text, nullable=True)
    found_value: Mapped[str] = mapped_column(Text, nullable=True)
    is_diff: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    diff_reason: Mapped[str] = mapped_column(String(500), nullable=True)
    
    # Связи
    contract: Mapped["ContractEntity"] = relationship("ContractEntity", back_populates="audit_logs")