from datetime import datetime
from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column
from uuid import UUID
from .base import BaseEntity


class SessionEntity(BaseEntity):
    __tablename__ = "sessions"
    
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_agent: Mapped[str] = mapped_column(String(512), nullable=True)
    ip_address: Mapped[str] = mapped_column(String(45), nullable=True)