from datetime import datetime
from enum import Enum
from sqlalchemy import Enum as SQLEnum, DateTime, String, Float, Integer, Boolean, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
from .base import BaseEntity
from .task import TaskEntity


class MatchType(str, Enum):
    IDENTICAL = "identical"
    HOMOGENEOUS = "homogeneous"
    DIFFERENT = "different"


class VendorStatus(str, Enum):
    MATCH = "match"
    MISMATCH = "mismatch"
    UNKNOWN = "unknown"


class ContractEntity(BaseEntity):
    __tablename__ = "contracts"
    
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False)
    reg_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    eis_url: Mapped[str] = mapped_column(String(500), nullable=False)
    supplier_name: Mapped[str] = mapped_column(String(500), nullable=False)
    supplier_inn: Mapped[str] = mapped_column(String(20), nullable=True)
    sign_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    unit_price: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(10), default="RUB", nullable=False)
    
    # Совпадение характеристик
    match_percent: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    match_type: Mapped[MatchType] = mapped_column(SQLEnum(MatchType), default=MatchType.DIFFERENT, nullable=False)
    vendor_status: Mapped[VendorStatus] = mapped_column(SQLEnum(VendorStatus), default=VendorStatus.UNKNOWN, nullable=False)
    
    # Дополнительные данные
    raw_data: Mapped[dict] = mapped_column(JSON, nullable=True)
    is_selected: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Связи
    task: Mapped["TaskEntity"] = relationship("TaskEntity", back_populates="contracts")
    audit_logs: Mapped[list["ContractAuditEntity"]] = relationship("ContractAuditEntity", back_populates="contract", cascade="all, delete-orphan")