#!/usr/bin/env python3
"""
Скрипт для запуска системы НМЦК
"""
import os
import sys
import uvicorn
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

if __name__ == "__main__":
    # Создаем таблицы при запуске
    from app.infra.database import Base, engine
    print("Создание таблиц базы данных...")
    Base.metadata.create_all(bind=engine)
    print("Таблицы созданы успешно")
    
    # Запускаем FastAPI приложение
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
